docker login iad.ocir.io -u=idju1jqntdg2/ramu.yarru -p=$2
rm -rf node_modules
yarn && yarn build
docker build -t iad.ocir.io/idju1jqntdg2/super-webapp:$1 .
docker push iad.ocir.io/idju1jqntdg2/super-webapp:$1