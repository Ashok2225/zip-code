export function sendMessageToExtension(msg) {
    try {
        return new Promise((resolve, reject) => {
            window.chrome.runtime.sendMessage(window._SUPER_EXTENSION_ID || process.env.REACT_APP_CHROME_TAB_ID, msg, (response) => {
                if (window.chrome.runtime.lastError) reject(window.chrome.runtime.lastError.message)
                else resolve(response)
            })    
        })
    } catch (e) {
        // 
    }
}