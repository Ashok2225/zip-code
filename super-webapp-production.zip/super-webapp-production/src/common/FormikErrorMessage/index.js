import React, { Fragment } from "react";
import { getIn } from "formik";

const FormikErrorMessage = (props) => {
  const { errors, touched, field } = props;
  let error = getIn(errors, field);
  let touch = getIn(touched, field);

  if (touch && error) {
    return (
      <Fragment>
        <span className="errorMessage text-danger">{error}</span>
      </Fragment>
    );
  }
  return "";
};

export default FormikErrorMessage;
