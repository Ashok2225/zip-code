import * as Yup from "yup";

export const validationSchemaOrganizationMember = Yup.object().shape({
  name: Yup.string().required("Name is required"),
  email: Yup.string().email("Invalid email").required("Email is required."),
});
