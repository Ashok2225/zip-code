import * as Yup from "yup";
const digitsOnly = (value) => /^[\+]?\d+$/.test(value);

export const AccountSettingSchema = Yup.object().shape({
  firstName: Yup.string().required("First name is required"),
  lastName: Yup.string().required("Last name is required"),
  //country: Yup.string().required("Country is required"),
  email: Yup.string().email("Invalid email").required("Email is required."),
  // contactNumber: Yup.string()
  //   .required("Required")
  //   .test("Digits only", "Invalid Contact", digitsOnly)
  //   .typeError("Must be a number"),
});
