import * as Yup from "yup";

export const validationSchemaOrganization = Yup.object().shape({
  // email: Yup.string().email("Invalid email").required("Email is required."),
  name: Yup.string().required("Name is required"),
  // url: Yup.string()
  //   .matches(
  //     /((https?):\/\/)?(www.)?[a-z0-9]+(\.[a-z]{2,}){1,3}(#?\/?[a-zA-Z0-9#]+)*\/?(\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$/,
  //     "Enter correct url!"
  //   )
  //   .required("Url is required"),
  // location: Yup.string().required("Name is required"),
  // billingEmail: Yup.string()
  //   .matches(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  //     "Invalid email"
  //   )
  //   .required("Billing Email is required"),
  description: Yup.string().required("Description is required"),
});
