import { store } from "../redux";

class SocketManager {
  constructor(config) {
    this.url = config.url;
    this.uuid = config.uuid;
    this.user = config.user;
    this.sendDefault = config.sendDefault;
    this.conn = null;
    this.onMessage = config.onMessage;
    this.onReadyState = config.onReadyState;
    this.token = config.token;
  }

  init = (callback) => {
    if (this.conn && (this.conn.readyState === WebSocket.OPEN || this.conn.readyState === WebSocket.CONNECTING)) {
      return callback();
    }
    this.conn = this.token
      ? new WebSocket(`${this.url}/${this.uuid}?t=${this.token}`) 
      : new WebSocket(`${this.url}/${this.uuid}`);

    this.conn.onmessage = (message) => {
      this.onMessage(message);
    };

    this.conn.onopen = () => {
      this.onReadyState();
      callback()
      setInterval(() => { 
        let msg = JSON.stringify({ type: 'ping' })
        if (this.conn && this.conn.readyState === WebSocket.OPEN) {
          // this.conn.send(msg);
        }
      }, 1000)
    };

    this.conn.onclose = () => {
      console.log("[SOCKET] Connection closed with ws API");
      setTimeout(this.init(() => {
        console.log('[SOCKET] reconnecting WS')
      }), 5 * 1000)

    };
    this.conn.onerror = (e) => {
      console.log("Connection error", e);
      this.conn.close()
    };
  };

  loadHistory = () => {
    if (!this.conn) {
      return "Invalid Socket Conn";
    }
    for (let message of this.sendDefault) {
      if (this.conn && this.conn.readyState === WebSocket.OPEN) {
        this.conn.send(message);
      }
    }
  };

  switchConnection = (uuid) => {
    let metadata = `$$metadata$$ ${uuid}`;
    var lt = 1;
    var gt = 0;
    let req_his = `$$req_his$$ lt=>${lt}$$gt=>${gt}`;
    let sendDefault = [metadata, req_his];
    this.uuid = uuid;
    this.sendDefault = sendDefault;
    this.conn.close();
    this.conn = null;
    this.init(() => {
        console.log("Connected to WS")
    })
  }

  status = () => this.conn.readyState;
  isOpen = () => this.conn.readyState === WebSocket.OPEN;
  webMessageToBotMessage(message, rasa, token, greetUtterance, skill) {
    let organization = localStorage.getItem("orgDetails");
    organization = JSON.parse(organization);
    return {
      isBot: false,
      from: {
        id: this.uuid,
        name: this.uuid,
        client: true,
        user_id: this.uuid, 
        user_profile: this.user,
        refreshToken: token,
        utterance: greetUtterance,
        organization: organization || null
      },
      type: "message",
      text: rasa ? message.text : (skill ? message.text.replace(/\s+/g, "_") : message.text),
      payload: message.payload || null,
      localTimestamp: new Date(),
      startOver: message.start_over,
      rasa: rasa
    };
  }
  finalPayload(message, rasa, token, greetUtterance = "", skill = false) {
    return JSON.stringify(
      this.webMessageToBotMessage(message, rasa, token, greetUtterance, skill)
    );
  }
  statusVerbose = () => {
    switch (this.conn.readyState) {
      case WebSocket.CONNECTING:
        return "CONNECTING";
      case WebSocket.OPEN:
        return "OPEN";
      case WebSocket.CLOSING:
        return "CLOSING";
      case WebSocket.CLOSED:
        return "CLOSED";
      default:
        return "NOT_FOUND";
    }
  };
}

export { SocketManager };
