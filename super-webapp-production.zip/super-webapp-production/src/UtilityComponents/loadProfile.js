import React from "react";
import empty_profile from "../Assets/emptyimage.png";

function LoadProfile(props){
    let imgUrl = null;
    props.profilePic ? (imgUrl = props.profilePic) : (imgUrl = empty_profile);
    return(
        <img src={imgUrl} alt="emptyprofile.png"></img>
    )
}

export default LoadProfile;