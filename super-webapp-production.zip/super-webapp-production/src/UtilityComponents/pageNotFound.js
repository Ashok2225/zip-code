import React from "react";
import pageNotFound from "../Assets/404.png";

function PageNotFound(props) {
    return (
      <div className="container text-center">
        <img src={pageNotFound} style={{ width: "100%" }} alt="404"></img>
        <button className="btn" onClick={() => props.history.push("/")}>
          Home
        </button>
      </div>
    );
}

export default PageNotFound;