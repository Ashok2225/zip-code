import * as types from "../constants/snackConstants";
const initialState = {
  open: false,
  snackType: "",
  snackMessage: "",
};
export default function (state = initialState, action) {
  switch (action.type) {
    case types.SHOW_SNACK:
      return {
        ...state,
        open: true,
        snackType: action.snackType,
        snackMessage: action.message,
      };
    case types.CLOSE_SNACK:
      return { ...state, open: false };
    default:
      return state;
  }
}


