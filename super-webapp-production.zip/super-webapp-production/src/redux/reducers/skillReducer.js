import * as types from "../constants/skillConstants";
const initialState = {
  isLoading: { status: true },
  skills: [],
  my_skills: [],
  draft_skills: [],
  trainDraft: [],
  draftSession: null,
  trainer_record: [],
  current_property_skill: null,
  skillArea: [],
  skill_fields: [],
  searchTerm: null,
  searchSkill: "",
  favoriteSkills: [],
  skillsToFavorite: [],
  helper: null,
  pageInfoSkill: [],
  pageInfoDraft: [],
  helperTask: [],
  userHelper: [],
  isActive: "Create",
  activeCategory: "",
  createTemplate: null,
  isRecording: {},
  headers: [],
  sortedVar: [],
  toogleDataMapper: false,
  changeView: "isBusinessView",
  advancedConfigPanel: null,
  startTimer: null,
  unsavedChanges: false,
  loading: false,
  skillMeta: null,
  flowVariables: [],
  devices:[]
};
const skillReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.IS_LOADING:
      return { ...state, isLoading: action.payload.status };
    case types.LOADING:
      return { ...state, loading: action.payload };

    case types.CREATE_DRAFT:
      return { ...state, createTemplate: action.payload };

    case types.SAVE_FAVOURITE_SKILLS:
      return Object.assign({}, state, {
        favoriteSkills: [...state.favoriteSkills, action.payload],
      });

    case types.GET_FAVOURITE_SKILLS:
      return Object.assign({}, state, {
        favoriteSkills: [...action.payload],
      });

    case types.REMOVE_FAVOURITE_SKILLS:
      return Object.assign({}, state, {
        favoriteSkills: action.payload,
      });

    case types.GET_MY_SKILLS:
      return Object.assign({}, state, {
        my_skills: action.payload,
      });

    case types.SEARCH_SKILLS:
      return Object.assign({}, state, {
        searchSkill: action.payload,
      });

    case types.GET_SKILLS:
      return { ...state, skills: action.payload };

    case types.GET_DRAFTS:
      return { ...state, draft_skills: action.payload };

    case types.GET_DRAFTS_BY_ID:
      return {
        ...state,
        trainDraft: action.payload,
        skillMeta: action.skillMeta ? action.skillMeta : null,
        unsavedChanges: false,
        loading: false,
        advancedConfigPanel: null,
      };

    case types.SET_DRAFT:
      return Object.assign({}, state, {
        trainDraft: action.payload,
        unsavedChanges: true,
      });

    case types.SET_ADVANCED_PANEL:
      return Object.assign({}, state, {
        advancedConfigPanel: action.payload,
      });

    case types.CLOSE_ADVANCED_PANEL:
      return Object.assign({}, state, {
        advancedConfigPanel: action.payload,
      });

    case types.CLEAR_DRAFTS:
      return { ...state, trainDraft: [], helper: null };

    case types.START_SKILL_RECORD:
      return { ...state, draftSession: action.payload, devices: action.devices,
      };

    case types.DEVICES:
      return {
        ...state,
        draftSession: action.payload,
        devices: action.devices,
      };

    case types.ADD_TRAINER:
      return { ...state, trainer_record: action.payload };

    case types.OPEN_PANEL:
      return { ...state, current_property_skill: action.payload };

    case types.DISABLE_USER_POPUP:
      return {
        ...state,
        skill_user_screen: false,
        skill_fields: [],
        current_skill: {},
      };

    case types.UPDATE_SKILL_VIEW:
      return { ...state, skillArea: action.payload };

    case types.USER_UPLOAD:
      return {
        ...state,
        skill_user_screen: true,
        skill_fields: action.payload === undefined ? [] : action.payload,
        current_skill: action.item,
      };

    case types.UPDATE_SEARCH_TERM:
      return { ...state, searchTerm: action.payload };
    case types.VIEW_HELPER_ITEM:
      return { ...state, helper: action.payload };
    case types.PAGE_INFO_SKILL:
      return { ...state, pageInfoSkill: action.payload };
    case types.PAGE_INFO_DRAFT:
      return { ...state, pageInfoDraft: action.payload };
    case types.GET_HELPER_TASK:
      return { ...state, helperTask: action.payload };
    case types.GET_USER_HELPER:
      return { ...state, userHelper: action.payload };
    case types.GET_ACTIVE_TAB:
      return { ...state, isActive: action.payload };
    case types.GET_ACTIVE_CATEGORY:
      return { ...state, activeCategory: action.payload };
    case types.UPDATE_DRAFT:
      return { ...state, trainDraft: action.payload, unsavedChanges: false };
    case types.IS_RECORDING:
      return { ...state, isRecording: action.payload };

    case types.GET_SHEET_HEADERS:
      return { ...state, headers: action.payload };
    case types.TOOGLE_DATA_MAPPER:
      return {
        ...state,
        toogleDataMapper: action.payload,
      };
    case types.STAT_CHANGE_FLOW:
      return { ...state, changeView: action.payload };
    case types.SET_TIMER:
      return { ...state, startTimer: action.payload };
    default:
      return state;
  }
};

export default skillReducer;
