import * as types from "../constants/analytics";


const initialState = {
    analyticsRecord:{}
};


const analyticsReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.UPDATE_ANALYTICS_RECORD:
      return { ...state, analyticsRecord: action.payload };
     
    default:
      return state;
  }
};

export default analyticsReducer;

