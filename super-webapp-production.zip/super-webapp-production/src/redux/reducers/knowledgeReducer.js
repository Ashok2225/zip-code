import * as types from "../constants/knowledgeContants";

const initialState = {
  myKnowledgeArea: "",
  knowledge: [],
  sharedKnowledge: [],
  isLoading: true,
  createArticle: "",
  createQA: "",
  isLoadingKnowledge: true,
  isLoadingView: false,
  viewKnowledge: [],
  suggestedTags: [],
  updatedKnowledge: [],
  deleteKnowledge: [],
  shareKnowledge: [],
  isViewEmpty: null,
  pageInfoNotes: []
};
const knowledgeReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.GET_SUGGESTED_TAGS:
      return { ...state, suggestedTags: action.payload };

    case types.IS_LOADING_KNOWLEDGE:
      return { ...state, isLoadingKnowledge: action.payload.status };

    case types.IS_LOADING_SHARED:
      return { ...state, isLoadingShared: action.payload.status };

    case types.UPDATE_KNOWLEDGE:
      return { ...state, updatedKnowledge: action.payload };

    case types.GET_MY_KNOWLEDGE:
      return { ...state, knowledge: action.payload };

    case types.GET_MY_SHARED_KNOWLEDGE:
      return { ...state, sharedKnowledge: action.payload.sharedKnowledge };

    case types.UPDATE_KNOWLEDGE_VIEW:
      return { ...state, myKnowledgeArea: action.payload };

    case types.CHANGE_VIEW_MODE:
      return { ...state, isViewEmpty: action.payload };
    case types.CREATE_ARTICLE:
      return { ...state, createArticle: action.payload };

    case types.CREATE_QA:
      return { ...state, createQA: action.payload };

    case types.VIEW_KNOWLEDGE:
      return { ...state, viewKnowledge: action.payload };
    case types.DELETE_KNOWLEDGE:
      return { ...state, deleteKnowledge: action.payload };

    case types.SHARE_KNOWLEDGE:
      return { ...state, shareKnowledge: action.payload };

    case types.PAGE_INFO_NOTES:
      return { ...state, pageInfoNotes: action.payload };
    default:
      return state;
  }
};

export default knowledgeReducer;
