import * as types from "../constants/authConstants";


const initialState = {
  apiAccessToken: [],
  allTokensList: [],
  deleteToken:[],
};


const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.API_ACCESS_TOKEN:
      return { ...state, apiAccessToken: action.payload };
      case types.GET_ALL_TOKENS:
      return { ...state, allTokensList: action.payload };
      case types.DELETE_TOKEN:
      return { ...state, deleteToken: action.payload };
    default:
      return state;
  }
};

export default authReducer;

