import * as types from "../constants/skillConstants"
const initialState = {
 filtered_prebuild:[]
};
export default function (state = initialState, action) {
  switch (action.type) {
      case types.GET_PREBUILD_SUCCESS:
          return {...state,filtered_prebuild:action.payload}
    
      default:
      return state;
  }
}
