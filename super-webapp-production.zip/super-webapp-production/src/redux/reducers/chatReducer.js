import { act } from "@testing-library/react";
import * as types from "../constants/chatConstants";

let initialState = {
  ready: false,
  historyLoaded: false,
  chatHistory: [],
  messages: [],
  notified: 0,
  lt: 1,
  gt: 0,
  limit: 20
};

const chatReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.RECEIVED_MESSAGE:
      return Object.assign({}, state, {
        messages: [action.payload, ...state.messages,]
      });
    case types.SET_MESSAGE:
      return Object.assign({}, state, {
        messages: [action.payload, ...state.messages]
      });
    case types.CLEAR_MESSAGE:
      return Object.assign({}, state, {
        messages: [],
        chatHistory: [],
        historyLoaded: false
      });
    case types.SET_HISTORY:
      return Object.assign({}, state, {
        chatHistory: [...action.payload, ...state.chatHistory],
        historyLoaded: true
      });
    case types.SET_READY_STATE:
      return Object.assign({}, state, {
        ready: action.payload != null ? action.payload : true
      });
    case types.SET_LIMIT:
      return Object.assign({}, state, {
        lt: action.payload.lt,
        gt: action.payload.gt,
        limit: action.payload.limit
      });
    default:
      return state;
  }
};

export default chatReducer;

