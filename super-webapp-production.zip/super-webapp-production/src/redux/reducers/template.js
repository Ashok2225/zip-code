import * as types from "../constants/templateConstants";
const { v4: uuid } = require("uuid");

const initialState = {
  template: [],
  currentAction: {},
  allTemplates: [],
  createTemplate: null,
  getTemplate: null,
  loading: false,
};
const templateReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.LOADING:
      return { ...state, loading: action.payload };
    case types.SET_TEMPLATE:
      return { ...state, template: [...state.template, action.payload] };

    case types.EDIT_TEMPLATE:
      return { ...state, template: action.payload };

    case types.SET_CURRENT_ACTION:
      return { ...state, currentAction: action.payload };

    case types.GET_ALL_TEMPLATES:
      return { ...state, allTemplates: action.payload };

    case types.IMPORT_TEMPLATE:
      return { ...state, createTemplate: action.payload };
    case types.GET_TEMPLATE:
      return { ...state, getTemplate: action.payload };
    case types.SET_TEMPLATE_DATA:
      return Object.assign({}, state, {
        getTemplate: action.payload,
      });
    case types.UPDATE_TEMPLATE:
      return { ...state, getTemplate: action.payload };
    default:
      return state;
  }
};

export default templateReducer;
