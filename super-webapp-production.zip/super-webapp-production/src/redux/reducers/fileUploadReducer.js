import * as types from "../constants/fileUploadConstants"
const initialState = {
   fileDetails:[],
   isLoadingFile:true
  };
  const fileUploadReducer = (state = initialState, action) => {
    switch (action.type) {
     
      case types.IS_LOADING_FILE:
        return { ...state, isLoadingFile: action.payload.status };
  
      case types.GET_FILE_URL:
        return { ...state, fileDetails: action.payload };

  
      default:
        return state;
    }
  };
  
  export default fileUploadReducer;