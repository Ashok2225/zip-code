import { combineReducers } from "redux";

//import all reducers here
import appReducer from "./appReducer";
import knowledgeReducer from "./knowledgeReducer";
import userReducer from './userReducer';
import skillReducer from "./skillReducer";
import fileUploadReducer from "./fileUploadReducer";
import organizationReducer from "./organizationReducer";
import snackReducer from "./snackReducer";
import chatReducer from "./chatReducer";
import prebuildSkillsReducer from "./prebuildSkillsReducer";
import authReducer from "./authReducer";
import logsReducer from "./logsReducer";
import templateReducer from "./template";
import analyticsReducer from "./analyticsReducer"


export default combineReducers({
  analyticsReducer,
  appReducer,
  knowledgeReducer,
  userReducer,
  skillReducer,
  fileUploadReducer,
  organizationReducer,
  snackReducer,
  chatReducer,
  prebuildSkillsReducer,
  authReducer,
  logsReducer,
  templateReducer,
  
  

});
