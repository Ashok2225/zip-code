import * as types from "../constants/organizationConstants";
const initialState = {
  isLoading: { status: true },
  organizationList: [],
  myOrganizationList: [],
  organizationTeams: [],
  organizationPeople: [],
  organizationCategories: [],
  organizationDetails: {},
  teamDetails: {},
  teamMembers: [],
  currentOrganization: { name: "" },
  currentOrgUser:[]
};
export default function (state = initialState, action) {
  switch (action.type) {
    case types.IS_LOADING:
      return { ...state, isLoading: action.payload.status };

    case types.GET_ORGANIZATIONS:
      return { ...state, organizationList: action.payload };

    case types.GET_MY_ORGANIZATIONS:
      return { ...state, myOrganizationList: action.payload };

    case types.GET_ORGANIZATION_BY_ID:
      return { ...state, organizationDetails: action.payload };

    case types.GET_TEAMS_OF_AN_ORGANIZATION:
      return { ...state, organizationTeams: action.payload };

    case types.GET_USERS_OF_AN_ORGANIZATION:
      return { ...state, organizationPeople: action.payload };

    case types.GET_TEAM_BY_ID:
      return { ...state, teamDetails: action.payload };

    case types.GET_USERS_OF_A_TEAM:
      return { ...state, teamMembers: action.payload };

    case types.CREATE_ORGANIZATION:
      return {
        ...state,
        organizationList: [action.data, ...state.organizationList],
      };

    case types.ADD_MEMBER_TO_TEAM:
      return {
        ...state,
        teamMembers: [action.data, ...state.teamMembers],
      };

    case types.REMOVE_ORGANIZATION:
      let filteredOrgList = state.organizationList.filter(
        (item) => item.id != action.id
      );
      return {
        ...state,
        organizationList: filteredOrgList,
      };

    case types.REMOVE_USER_FROM_AN_ORGANIZATION:
      let filteredList = state.organizationPeople.filter(
        (item) => item.id != action.id
      );
      return {
        ...state,
        organizationPeople: filteredList,
      };

    case types.REMOVE_TEAM_FROM_AN_ORGANIZATION:
      let filteredTeamList = state.organizationTeams.filter(
        (item) => item.id != action.id
      );
      return {
        ...state,
        organizationTeams: filteredTeamList,
      };

    case types.REMOVE_MEMBER_FROM_A_TEAM:
      let filteredTeamMembers = state.teamMembers.filter(
        (item) => item.id != action.id
      );
      return {
        ...state,
        teamMembers: filteredTeamMembers,
      };

    case types.CREATE_TEAM:
      return {
        ...state,
        organizationTeams: [action.data, ...state.organizationTeams],
      };

    case types.TOGGLE_USER_OF_ORG:
      let tempArr = [...state.organizationPeople];
      const rowToChange = tempArr.findIndex((ele) => {
        return ele.id === action.payload.id;
      });
      tempArr[rowToChange].disabled = !tempArr[rowToChange].disabled;
      return {
        ...state,
        organizationPeople: tempArr,
      };

    case types.TOGGLE_USER_OF_TEAM:
      let tempArrTeam = [...state.teamMembers];
      const rowToChangeTeam = tempArrTeam.findIndex((ele) => {
        return ele.id === action.payload.id;
      });
      tempArrTeam[rowToChangeTeam].disabled =
        !tempArrTeam[rowToChangeTeam].disabled;
      return {
        ...state,
        teamMembers: tempArrTeam,
      };

    case types.GET_CATEGORIES_OF_AN_ORGANIZATION:
      return { ...state, organizationCategories: action.payload };

    case types.ADD_CATEGORY_TO_ORG:
      return {
        ...state,
        organizationCategories: [action.data, ...state.organizationCategories],
      };

    case types.REMOVE_CATEGORY_FROM_AN_ORGANIZATION:
      let filteredCategories = state.organizationCategories.filter(
        (item) => item.id != action.id
      );
      return {
        ...state,
        organizationCategories: filteredCategories,
      };

    case types.SET_CURRENT_ORGANIZATION:
      return { ...state, currentOrganization: action.payload.org };
    case types.SET_CURRENT_ORG_USER:
      return { ...state, currentOrgUser: action.payload };

    default:
      return state;
  }
}
