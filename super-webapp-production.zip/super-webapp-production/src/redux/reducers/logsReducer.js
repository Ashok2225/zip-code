import * as types from "../constants/logsConstants";
const initialState = {
  automationBuildLogs: [],
  total: 0
};

const logsReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.AUTOMATION_BUILD_LOGS:
      return { ...state, automationBuildLogs: action.payload, total: action.total };
    default:
      return state;
  };
}
export default logsReducer;