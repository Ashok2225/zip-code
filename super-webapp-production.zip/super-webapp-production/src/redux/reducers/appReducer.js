import * as types from "../constants/appConstants";

let initialState = {
  init: false,
  snackType: "",
  snackMessage: "",
  open: false,
  notifications: [],
  notified: 0,
  minMode: false,
};


const appReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.INIT_APP:
      return Object.assign({}, state, {
        init: true,
        status: action.status,
      });
    case types.GET_NOTIFY:
      return { ...state, notifications: action.payload}
    case types.NOTIFICATION_MESSAGE:
      return Object.assign({}, state, {
        notified: action.payload
      });
    case types.MODE_CHANGE:
      return { ...state, minMode:action.payload}
    // case types.SHOW_SNACK:
    //   return { ...state, open: true, snackType: action.snackType, snackMessage: action.message }
    // case types.CLOSE_SNACK: return { ...state, open: false }

    default:
      return state;
  }
};

export default appReducer;

