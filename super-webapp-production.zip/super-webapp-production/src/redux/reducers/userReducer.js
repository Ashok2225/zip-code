import * as types from "../constants/userConstants";

const initialState = {
  user: null,
  devicename: '',
  agentUrl:''
};
const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.SET_CURRENT_USER:
      return { ...state, user: action.payload };
    case types.SUPER_WINDOW_DEVICE_NAME:
      return { ...state, devicename: action.payload }; 
    case types.SUPER_AGENT_URL:
      return{...state,agentUrl:action.payload}
    default:
      return state;
  }
};

export default userReducer;
