import * as types from "../constants/fileUploadConstants";
import axios from "axios";
import { getKeycloackToken } from "./auth";

export const getFileUrl = (file) => async (dispatch, getState) => {
  try {
    dispatch({ type: types.IS_LOADING_FILE, payload: { status: true } });
    let token = await getKeycloackToken();

    const formData = new FormData();
    formData.append("file", file);
    var config = {
      method: "POST",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },

      data: formData,
    };

    const upload = await axios(config);
    const fileDetails = ` ${process.env.REACT_APP_BOT_SERVICE_URL}/image/${upload.data.data.image_id}`;
    dispatch({
      type: types.GET_FILE_URL,
      payload: fileDetails,
    });
    dispatch({ type: types.IS_LOADING_FILE, payload: { status: false } });

    return fileDetails;
  } catch (err) {
    dispatch({ type: types.IS_LOADING_FILE, payload: { status: false } });
  }
};

export const updateFileUrl =
  (file, imageFileName) => async (dispatch, getState) => {
    try {
      dispatch({ type: types.IS_LOADING_FILE, payload: { status: true } });
      let token = await getKeycloackToken();
      const formData = new FormData();
      formData.append("fileName", imageFileName);
      formData.append("file", file);
      var config = {
        method: "POST",
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload/mask`,
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },

        data: formData,
      };

      const upload = await axios(config);
      const fileDetails = ` ${process.env.REACT_APP_BOT_SERVICE_URL}/image/${upload.data.data.image_id}`;
      dispatch({
        type: types.GET_FILE_URL,
        payload: fileDetails,
      });
      dispatch({ type: types.IS_LOADING_FILE, payload: { status: false } });

      return fileDetails;
    } catch (err) {
      dispatch({
        type: types.IS_LOADING_FILE,
        payload: { status: false },
      });
    }
  };
