import * as types from "../constants/templateConstants";
import axios from "axios";
import { getKeycloackToken } from "./auth";
import { notify } from "./snack";

export const updateTemplateAcions = (action) => (dispatch) => {
  dispatch({ type: types.SET_TEMPLATE, payload: action });
};

export const editTemplateAction = (action) => (dispatch, getState) => {
  const { template } = getState().templateReducer;

  var currentAction = null;
  template.map((tempAction) => {
    if (tempAction.id == action.id) {
      tempAction.isShow = !tempAction.isShow;
      currentAction = tempAction;
    }
  });

  console.log("final", template);

  dispatch({ type: types.SET_CURRENT_ACTION, payload: currentAction });
  dispatch({ type: types.EDIT_TEMPLATE, payload: template });
};

export const setCurrentAction = (action) => (dispatch, getState) => {
  dispatch({ type: types.SET_CURRENT_ACTION, payload: action });
};

export const getAllTemplates = (orgId) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/templates/getAllTemplate?orgId=${orgId}`,
    };
    const result = await axios(config);

    dispatch({
      type: types.GET_ALL_TEMPLATES,
      payload: result.data.data.results,
    });
    return result;
  } catch (err) {
    dispatch(notify("error", "Failed : " + err.toString()));
  }
};

export const createTemplate = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  data["orgId"] = orgId;

  try {
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/templates/createTemplate`,
      data: data,
    };
    const result = await axios(config);
    if (result?.data?.data) {
      dispatch({
        type: types.IMPORT_TEMPLATE,
        payload: result?.data?.data?.results,
      });
      dispatch(notify("success", "Successfully created template"));
    }
    return result;
  } catch (err) {
    console.log(err, "err");
    dispatch(notify("error", "Failed to create template: " + err.toString()));
  }
};

export const getTemplateById = (id) => async (dispatch) => {
  dispatch({ type: types.LOADING, payload: true });

  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/templates/getTemplateById?id=${id}`,
    };
    const result = await axios(config);
    console.log(result);
    dispatch({
      type: types.GET_TEMPLATE,
      payload: result?.data?.data,
    });
    dispatch({ type: types.LOADING, payload: false });

    return result;
  } catch (err) {
    dispatch({ type: types.LOADING, payload: false });

    dispatch(notify("error", "Failed : " + err.toString()));
  }
};

export const setTemplateData = (item) => (dispatch) => {
  dispatch({ type: types.SET_TEMPLATE_DATA, payload: item });
};
export const updateTemplateData = (data) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/templates/updateTemplate?id=${data.id}`,
      data: data,
    };
    const result = await axios(config);
    if (result) {
      dispatch(notify("success", "Successfully Updated template"));
    }
    return result;
  } catch (err) {
    console.log(err, "err");
    dispatch(notify("error", "Failed to create template: " + err.toString()));
  }
};
export const setLoading = (payload) => (dispatch) => {
  dispatch({ type: types.LOADING, payload: payload });
};

export const deleteTemplate = (id) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "delete",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/templates/deleteTemplate?id=${id}`,
    };
    const result = await axios(config);
    if (result) {
      dispatch(notify("success", "Successfully deleted template"));
    }
    return result;
  } catch (err) {
    console.log(err, "err");
    dispatch(notify("error", "Failed to create template: " + err.toString()));
  }
};
