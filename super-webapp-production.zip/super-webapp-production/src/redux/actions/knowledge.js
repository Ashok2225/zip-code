import * as types from "../constants/knowledgeContants";
import axios from "axios";
import { getKeycloackToken } from "./auth";
import { notify } from "./snack";

export const createQA = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  const qaData = data;
  let temp = qaData.filter((i) => i.visibility === "organization");
  if (temp.length > 0 && !orgId) {
    dispatch(notify("error", "No Organization found "));
  } else {
    qaData.forEach((element) => {
      if (orgId) {
        element.orgDetails = getOrgDetails;
      }
    });

    let token = await getKeycloackToken();
    const config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/createQA`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      data: qaData
    };

    try {
      const response = await axios(config);

      if (response.status) {
        dispatch({
          type: types.CREATE_QA,
          payload: response.data
        });
        dispatch(
          notify(
            "success",
            "Your QnA is being processed. You will be notified upon completion. "
          )
        );

        return response;
      }
    } catch (err) {
      dispatch(notify("error", "Something went wrong: " + err.toString()));
      console.log(err, "err");

      console.log(err.toString());
    }
  }
};

export const uploadQA = (file) => async (dispatch) => {
  let token = await getKeycloackToken();

  const formData = new FormData();
  formData.append("file", file);
  var config = {
    method: "POST",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/azureqa`,

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: formData
  };

  try {
    const upload = await axios(config);
    if (upload.data) {
      return upload;
    }
  } catch (err) {
    console.log(err.toString());
  }
};

export const createArticle = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  if (orgId) {
    data = { ...data, userOrg: getOrgDetails };
  } else {
    if (data.visibility === "organization") {
      dispatch(notify("error", "No Organization found "));
      return;
    } else {
      data = { ...data, userOrg: null };
    }
  }
  let token = await getKeycloackToken();
  const config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/createArticle`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: data
  };
  try {
    const response = await axios(config);
    if (response.status) {
      dispatch({
        type: types.CREATE_ARTICLE,
        payload: response.data
      });
      return response;
    }
  } catch (err) {
    dispatch(notify("error", "Something went wrong: " + err.toString()));

    console.log(err.toString());
  }
};

export const deleteKnowledge = (id) => async (dispatch) => {
  let token = await getKeycloackToken();
  var config = {
    method: "DELETE",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/deleteKnowledge`,

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: {
      id
    }
  };
  try {
    var datain = await axios(config);

    return true;
  } catch (err) {
    console.log(err);
  }
};

export const updateKnowledge = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  if (orgId) {
    data = { ...data, userOrg: getOrgDetails };
  } else {
    data = { ...data, userOrg: null };
  }
  let token = await getKeycloackToken();

  var config = {
    method: "put",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/article`,

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: data
  };
  try {
    var updateData = await axios(config);
    if (updateData) {
      return true;
    }
  } catch (err) {
    console.log(err);
  }
};

export const shareKnowledge = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let _updatedPayload = data;
  _updatedPayload.data.organizationId = orgId;

  let token = await getKeycloackToken();

  var config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/shareKnowledge`,

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },

    data: _updatedPayload
  };

  try {
    var shareStatus = await axios(config);
    if (shareStatus) {
      return true;
    }
  } catch (err) {
    console.log(err);
  }
};

export const viewKnowledge = (e) => async (dispatch) => {
  let token = await getKeycloackToken();

  var config = {
    method: "POST",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/retrieveArticleByQueId`,

    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: {
      e
    }
  };
  try {
    var datain = await axios(config);
    if (datain) {
      dispatch({
        type: types.UPDATE_KNOWLEDGE_VIEW,
        payload: datain.data.data
      });
      dispatch({
        type: types.IS_LOADING_VIEW,
        payload: { status: false }
      });
      return datain.data.data;
    }
  } catch (err) {
    console.log(err);
    dispatch(notify("error", "Something went wrong: " + err.toString()));
    dispatch({
      type: types.IS_LOADING_VIEW,
      payload: { status: false }
    });
  }
};

export const getCreatedKnowledge = () => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let token = await getKeycloackToken();
  const config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/retrieveArticleByUser?organizationId=${orgId}`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: {}
  };
  try {
    const response = await axios(config);
    var sorted = response.data.data;
    dispatch({
      type: types.GET_MY_KNOWLEDGE,
      payload: sorted
    });
   
    dispatch({
      type: types.IS_LOADING_KNOWLEDGE,
      payload: { status: false }
    });

    return sorted;
  } catch (err) {
    console.log(err.toString());
  }
};

export const changeKnowledgeView = (area) => (dispatch, getState) => {
  dispatch({ type: types.UPDATE_KNOWLEDGE_VIEW, payload: area });
  return area;
};

export const changeViewMode = (mode) => (dispatch, getState) => {
  dispatch({ type: types.CHANGE_VIEW_MODE, payload: mode });
};
export const getSharedKnowledge = () => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;

  let token = await getKeycloackToken();

  try {
    var config = {
      method: "get",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/shareKnowledge?organizationId=${orgId}`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      }
    };
    const response = await axios(config);
    var shared = response.data.data;
    dispatch({
      type: types.GET_MY_SHARED_KNOWLEDGE,
      payload: { sharedKnowledge: shared }
    });

    dispatch({ type: types.IS_LOADING_SHARED, payload: { status: false } });
    return shared;
  } catch (err) {
    console.log(err.toString(), "err");
  }
};

export const approveSharedKnowledge = (data) => async (dispatch, getState) => {
  let token = await getKeycloackToken();
  var config = {
    method: "put",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/approveKnowledge`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: {
      data: data
    }
  };
  try {
    const result = await axios(config);
  } catch (err) {
    console.log("approve error");
  }
};

export const rejectSharedKnowledge = (data) => async (dispatch, getState) => {
  let token = await getKeycloackToken();
  var config = {
    method: "delete",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/knowledge/rejectKnowledge`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    data: {
      data: data
    }
  };
  try {
    const result = await axios(config);
  } catch (err) {
    console.log("reject error");
  }
};

export const getSuggestedTags = () => async (dispatch, getState) => {
  let token = await getKeycloackToken();

  const config = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieve`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`
    }
  };
  try {
    const response = await axios(config);
    var sortedSkills = response.data.data; //Sorts the array based on usage count
    sortedSkills.sort((a, b) => {
      if (a.USAGE_COUNT > b.USAGE_COUNT) return -1;
      if (b.USAGE_COUNT > a.USAGE_COUNT) return 1;
    });
    dispatch({ type: types.GET_SUGGESTED_TAGS, payload: sortedSkills });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
    return sortedSkills;
  } catch (err) {
    console.log(err.toString());
  }
};
