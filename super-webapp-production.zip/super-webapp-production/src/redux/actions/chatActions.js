import * as types from "../constants/chatConstants";
import { store } from "../../redux";

export const setIncommingMessage = (message) => async (dispatch) => {
  message = JSON.parse(message.data)
  if (message.chat_history) {
    let { chatReducer } = store.getState();
    let { lt, gt, limit, chatHistory } = chatReducer;
    if(message.payload.length == 0 && limit && chatHistory.length == 0){
      let limitHis = {
        lt: lt-1,
        gt: gt-1,
        limit: limit-1
      }
      await dispatch({ type: types.SET_LIMIT, payload: limitHis });
      let req_his = `$$req_his$$ lt=>${lt-1}$$gt=>${gt-1}`;
      window.chatSocket.conn.send(req_his)
    } else {
      await dispatch({ type: types.SET_HISTORY, payload: message.payload.reverse() });
    }
  } else {
    await dispatch({ type: types.RECEIVED_MESSAGE, payload: message });
  }
};

export const setMessage = (message) => (dispatch) => { 
  message = JSON.parse(message)
  dispatch({ type: types.SET_MESSAGE, payload: message });
};

export const clearMessages = () => (dispatch) => {
  dispatch({ type: types.CLEAR_MESSAGE });
};

export const setReadyState = (value = null) => (dispatch) => {
  dispatch({ type: types.SET_READY_STATE, payload: value });
};

export const setHistoryLimit = (value) => (dispatch) => { 
  dispatch({ type: types.SET_LIMIT, payload: value });
};
