import * as types from "../constants/skillConstants";
import axios from "axios";
import { getKeycloackToken } from "./auth";
import { notify } from "./snack";
import { read, utils } from "xlsx";
import _ from "lodash";
import { sendMessageToExtension } from "../../utility/extension";

export const filterSearchItem = (currentItem) => (dispatch) => {
  dispatch({ type: types.UPDATE_SEARCH_TERM, payload: currentItem });
};

export const publishFlow = (payload) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/publish`,
      data: payload,
    };
    const result = await axios(config);
    dispatch(notify("Success", "Published Flow successfully "));
  } catch (err) {
    dispatch(
      notify("error", "Failed to delete Draft Skill: " + err.toString())
    );
  }
};

export const updateSkillVariables = (payload) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/variables`,
      data: payload,
    };
    const result = await axios(config);
    dispatch({ type: types.GET_DRAFTS_BY_ID, payload: result.data.data });
    dispatch(notify("Success", "Saved successfully "));
  } catch (err) {
    dispatch(
      notify("error", "Failed to delete Draft Skill: " + err.toString())
    );
  }
};

export const automationSearch = (data) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let token = await getKeycloackToken();

  var newUrl;
  if (data) {
    newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/searchAutomation?query=${data.query}&page=${data.page}&pageSize=10`;
  }
  const config = {
    method: "get",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    url: newUrl,
  };
  const config2 = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieveUserSkills?organizationId=${orgId}`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };
  const res = await axios(config);
  const response = await axios(config2);
  try {
    var sorted = response.data.data;

    var skillResponse = res.data.data.pageInfo;

    var all_skills = res.data.data.results;
    for (var i = 0; i < all_skills.length; i++) {
      for (var j = 0; j < sorted.length; j++) {
        if (sorted[j].SKILL_NAME === all_skills[i].skill_name) {
          all_skills[i]["isAvailable"] = true;
        }
      }
    }

    return res.data.data;
  } catch (err) {
    dispatch(notify("error", "Failed to retrieve Search : " + err.toString()));
  }
};

export const helperSearch = (data) => async (dispatch) => {
  var newUrl;
  try {
    let token = await getKeycloackToken();

    if (data) {
      newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/searchHelper?query=${data.query}&page=${data.page}&pageSize=10`;
    }
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };

    const result = await axios(config);
    const sendResponse = result.data.data.results;
    return result.data.data;
  } catch (err) {
    dispatch(notify("error", "Failed to retrieve Search : " + err.toString()));
  }
};

export const changeSkillAreaView = (area) => (dispatch, getState) => {
  dispatch({ type: types.UPDATE_SKILL_VIEW, payload: area });
  return area;
};

export const changeActiveCategory = (area) => (dispatch, getState) => {
  dispatch({ type: types.GET_ACTIVE_CATEGORY, payload: area });
  return area;
};

export const changeActiveTab = (tab) => (dispatch) => {
  dispatch({ type: types.GET_ACTIVE_TAB, payload: tab });
  return tab;
};

export const toogleDataMapper = (data) => (dispatch) => {
  dispatch({ type: types.TOOGLE_DATA_MAPPER, payload: data });
};

export const clearDraft = () => (dispatch) => {
  dispatch({ type: types.CLEAR_DRAFTS, payload: [] });
};

export const setDraft = (item) => (dispatch) => {
  dispatch({ type: types.SET_DRAFT, payload: item });
};

export const startTimer = (payload) => (dispatch) => {
  dispatch({ type: types.SET_TIMER, payload: payload });
};

export const setLoading = (payload) => (dispatch) => {
  dispatch({ type: types.LOADING, payload: payload });
};

export const closeAdvancedConfigPanel = () => async (dispatch) => {
  dispatch({
    type: types.CLOSE_ADVANCED_PANEL,
    payload: {
      record: {},
      mandatory_fields: [],
      optional_fields: [],
      default_values: [],
    },
  });
};

export const setAdvancedConfigPanel = (record) => async (dispatch) => {
  dispatch({
    type: types.SET_ADVANCED_PANEL,
    payload: {
      record: record,
      mandatory_fields: [],
      optional_fields: [],
      default_values: [],
    },
  });
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/getFlowRequirements?type=${record.type}`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    const {
      data: { data },
    } = await axios(config);
    const response = data[0];
    let mandatory_fields =
      response.MANDATORY_PARAMS !== ""
        ? response.MANDATORY_PARAMS.split(",")
        : [];
    let optional_fields =
      response.OPTIONAL_PARAMS !== ""
        ? response.OPTIONAL_PARAMS.split(",")
        : [];
    let default_values = _.difference(Object.keys(response.DEFAULT_VALUES), [
      ...mandatory_fields,
      ...optional_fields,
    ]);

    dispatch({
      type: types.SET_ADVANCED_PANEL,
      payload: {
        record: record,
        mandatory_fields,
        optional_fields,
        default_values,
      },
    });
  } catch (e) {
    console.log(e);
  }
};

export const saveFavoriteSkill = (skill) => (dispatch) => {
  let skills = localStorage.getItem("_tf_skill");
  if (skills) {
    skills = JSON.parse(skills);
  } else {
    skills = [];
  }
  skills.push(skill);
  localStorage.setItem("_tf_skill", JSON.stringify(skills));
  dispatch({ type: types.SAVE_FAVOURITE_SKILLS, payload: skill });
};

export const getFavoriteSkills = () => (dispatch) => {
  let skills = localStorage.getItem("_tf_skill");
  if (skills) {
    skills = JSON.parse(skills);
  } else {
    skills = [];
  }
  dispatch({ type: types.GET_FAVOURITE_SKILLS, payload: skills });
};

export const removeFavoriteSkill = (skill) => (dispatch) => {
  let skills = localStorage.getItem("_tf_skill");
  if (skills) {
    skills = JSON.parse(skills);
  } else {
    skills = [];
  }
  skills = skills.filter((item) => item.ID !== skill.ID);
  localStorage.setItem("_tf_skill", JSON.stringify(skills));
  dispatch({ type: types.REMOVE_FAVOURITE_SKILLS, payload: skills });
};

export const updateFormatedData = (data) => async (dispatch) => {
  let token = await getKeycloackToken();

  const config1 = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/updateRpaPayload`,
    method: "put",
    headers: {
      "Content-type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    data: data,
  };

  try {
    const res = await axios(config1);
    const formatData = res.data.data;
    dispatch({ type: types.UPDATE_DRAFT, payload: formatData });

    return formatData;
  } catch (err) {
    console.log(err.toString());
  }
};

export const getSkillsFromStore = (page) => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let token = await getKeycloackToken();
  var skillUrl;
  if (page) {
    skillUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieve?page=${page}`;
  } else {
    skillUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieve `;
  }
  const config1 = {
    url: skillUrl,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };
  const config2 = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieveUserSkills?organizationId=${orgId}`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };

  const config3 = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieve?TYPE=SkillHub&category=all&page=-1&pageSize=10&_org=${orgId}`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };

  try {
    const res = await axios(config1);

    const response = await axios(config2);
    // console.log("response",response)
    // const response2 = await axios(config3);

    var sorted = response.data.data;
    // var sorted2 = response2.data.data.results;
    var skillResponse = res.data.data.pageInfo;
    var all_skills = res.data.data.results;

    for (var i = 0; i < all_skills.length; i++) {
      for (var j = 0; j < sorted.length; j++) {
        if (sorted[j].SKILL_NAME === all_skills[i].skill_name) {
          all_skills[i]["isAvailable"] = true;
        }
      }
    }

    // for (var a = 0; a < all_skills.length; a++) {
    //   for (var b = 0; b < sorted2.length; b++) {
    //     if (sorted2[b].SKILL_NAME === all_skills[a].skill_name) {
    //       all_skills[a]["isAvailable"] = true;
    //     }
    //   }
    // }

    dispatch({ type: types.GET_SKILLS, payload: all_skills });
    dispatch({ type: types.PAGE_INFO_SKILL, payload: skillResponse });

    // dispatch({ type: types.IS_LOADING, payload: { status: false } });

    return res.data.data;
  } catch (err) {
    dispatch({ type: types.GET_SKILLS, payload: [] });
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    console.log(err.toString());
  }
};
// get user onboarded skills from skill store
export const getUserSkills = (data) => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let token = await getKeycloackToken();

  const config = {
    url: `${
      process.env.REACT_APP_BOT_SERVICE_URL
    }/skills/retrieveUserSkills?page=${
      data ? data.page : 1
    }&pageSize=10&organizationId=${orgId}`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      // "user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };
  try {
    const response = await axios(config);
    var sorted = response.data.data; //Sorts the array based on usage count
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });

    sorted.sort((a, b) => {
      if (a.USAGE_COUNT > b.USAGE_COUNT) return -1;
      if (b.USAGE_COUNT > a.USAGE_COUNT) return 1;
    });

    dispatch({ type: types.GET_MY_SKILLS, payload: sorted });
    return response;
  } catch (err) {
    console.log(err.toString());
  }
};

export const searchSKills = (search) => async (dispatch) => {
  try {
    dispatch({
      type: types.SEARCH_SKILLS,
      payload: search,
    });
  } catch (err) {
    console.log(err.toString());
  }
};

export const searchMySKills = (search) => async (dispatch, getState) => {
  const { filterable_myskills } = getState().skills;

  try {
    //this.setState({ skills: sorted, isLoading: false })
    let filtered_skills = [];
    filterable_myskills.map((skill) => {
      if (
        skill.SKILL_NAME.toLowerCase()
          .replace(/\s+/g, "")
          .includes(search.toLowerCase().replace(/\s+/g, ""))
      ) {
        filtered_skills.push(skill);
      }
    });
    dispatch({
      type: types.GET_MY_SKILLS,
      payload: { skills: filtered_skills },
    });
  } catch (err) {
    console.log(err.toString());
  }
};
export const deleteMySkill = (id) => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  try {
    let token = await getKeycloackToken();
    const config = {
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/user`,
      method: "delete",
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: {
        skill_id: id,
        organisationId: orgId,
      },
    };
    const res = await axios(config);

    dispatch(notify("success", "Skill deleted"));
    // dispatch(getUserSkills(false));
    return res;
  } catch (err) {
    dispatch(notify("error", "Unable to delete skill: " + err.toString()));
  }
};
export const disableUserPopup = () => (dispatch) => {
  dispatch({ type: types.DISABLE_USER_POPUP });
};

export const getPrebuildSkills = () => async (dispatch) => {
  let token = await getKeycloackToken();
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  const config = {
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieveUserSkills?organizationId=${orgId}`,
    method: "get",
    headers: {
      "Content-type": "application/json",
      //"user_id": user_id,
      Authorization: `Bearer ${token}`,
    },
  };
  try {
    const response = await axios(config);
    var user_skills = response.data.data; //Sorts the array based on usage count
    var prebuild;
    const response1 = await axios.get(
      `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/retrieve`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    prebuild = response1.data.data;

    for (var i = 0; i < user_skills.length; i++) {
      for (var j = 0; j < prebuild.length; j++) {
        if (user_skills[i].SKILL_NAME === prebuild[j].skill_name) {
          prebuild.splice(j, 1);
        }
      }
    }
    // this.setState({ skills: sorted, isLoading: false })
    dispatch({ type: types.GET_PREBUILD_SUCCESS, payload: prebuild });
  } catch (err) {
    console.log(err.toString());
  }
};
export const addSkillToUser = (item) => (dispatch) => {
  dispatch({
    type: types.USER_UPLOAD,
    payload: item.tags[0].skill_fields,
    item: item,
  });
};
export const changeFlowView = (data) => async (dispatch) => {
  dispatch({
    type: types.STAT_CHANGE_FLOW,
    payload: data,
  });
};

export const viewHelperSkill = (item) => (dispatch) => {
  dispatch({
    type: types.VIEW_HELPER_ITEM,
    payload: item,
  });
};

export const publishHelperSkill = (id, payload) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/update/${id}`,
      data: payload,
    };
    const result = await axios(config);
    return result;
  } catch (err) {
    dispatch(
      notify("error", "Failed to delete Draft Skill: " + err.toString())
    );
  }
};
export const updateDraftSkill = (id, payload) => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/update/${id}`,
      data: payload,
    };
    const result = await axios(config);
    dispatch({ type: types.GET_DRAFTS_BY_ID, payload: result.data.data });
    return result;
  } catch (err) {
    console.log(err, "e");
    dispatch(notify("error", "Update Failed!"));
  }
};

export const deleteDraftSkill = (id) => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "delete",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/delete?id=${id}`,
    };
    const result = await axios(config);
    dispatch(notify("success", "Skill deleted successfully"));
    return result;
  } catch (err) {
    dispatch(
      notify("error", "Failed to delete Draft Skill: " + err.toString())
    );
  }
};

export const getSession = (data) => async (dispatch) => {
  let token = await getKeycloackToken();

  var conf = {
    method: "get",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  const sessionRes = await axios(conf);
  const sessionData = sessionRes.data.data.results;
  let getCurrentSession = (sessionData[0] && sessionData[0].id) || null;
  dispatch({
    type: types.DEVICES,
    payload: getCurrentSession,
    devices: sessionData,
  });
  return sessionData[0];
};

export const startRecord = (data) => async (dispatch, getState) => {
  dispatch({
    type: types.IS_RECORDING,
    payload: { status: true, nodeId: data.nodeId },
  });
  let token = await getKeycloackToken();

  var conf = {
    method: "get",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };

  const sessionRes = await axios(conf);
  const sessionData = sessionRes.data.data.results;
  if (sessionData.length === 0) {
    dispatch(
      notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      )
    );
  } else {
    let getCurrentSession = sessionData[0].id;
    dispatch({ type: types.START_SKILL_RECORD, payload: getCurrentSession });

    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/start-recording`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: {
        deviceId: getCurrentSession,
        skillId: data.skillId,
        markerIndex: data.markerIndex,
        nodeId: data.nodeId,
      },
    };

    const res = await axios(config);
    if (res) {
      if (res.data.status === "failed") {
        dispatch(notify("error", "Failed to start Training"));
        dispatch({
          type: types.IS_RECORDING,
          payload: { status: false, nodeId: data.nodeId },
        });
        dispatch({
          type: types.SET_TIMER,
          payload: false,
        });
      } else {
        dispatch(notify("success", "Show process started"));
        return res.data;
      }
    }
  }
};

export const stopRecord = (data) => async (dispatch, getState) => {
  let token = await getKeycloackToken();
  var config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/stop-recording`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    data: {
      deviceId: data.deviceId,
      skillId: data.skillId,
      markerIndex: data.markerIndex,
      nodeId: data.nodeId,
    },
  };
  const res = await axios(config);
  if (res) {
    dispatch({
      type: types.IS_RECORDING,
      payload: { status: false, nodeId: data.nodeId },
    });

    dispatch(
      notify(
        "success",
        "Show process stopped. Please wait while we process the data"
      )
    );
  } else {
    dispatch({
      type: types.IS_RECORDING,
      payload: { status: false, nodeId: data.nodeId },
    });
  }

  return res.data;
};

export const triggerPannel = (record) => async (dispatch) => {
  dispatch({
    type: types.OPEN_PANEL,
    payload: {
      record: record,
      mandatory_fields: [],
      optional_fields: [],
      default_values: [],
    },
  });
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/getFlowRequirements?type=${record.type}`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    const response = await axios(config);
    let default_values = [];
    for (const [key, value] of Object.entries(
      response.data.data[0].DEFAULT_VALUES
    )) {
      default_values.push(key);
    }
    dispatch({
      type: types.OPEN_PANEL,
      payload: {
        record: record,
        mandatory_fields:
          response.data.data[0].MANDATORY_PARAMS != ""
            ? response.data.data[0].MANDATORY_PARAMS.split(",")
            : [],
        optional_fields:
          response.data.data[0].OPTIONAL_PARAMS != ""
            ? response.data.data[0].OPTIONAL_PARAMS.split(",")
            : [],
        default_values: default_values,
      },
    });
  } catch (e) {
    console.log(e);
  }
};

export const createDraftSkill =
  (skill, callback) => async (dispatch, getState) => {
    try {
      const organisationId =
        getState().organizationReducer.currentOrganization.id;
      skill["organizationId"] = organisationId;
      let token = await getKeycloackToken();
      var config = {
        method: "post",
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/create`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: skill,
      };
      const result = await axios(config);
      if (result?.data?.status) {
        callback();
        skill["id"] = result.data.data.id;
        dispatch({ type: types.CREATE_DRAFT, payload: skill });
        return result;
      } else {
        return result;
      }
    } catch (err) {
      dispatch(notify("error", "Failed to Create Skill: " + err.toString()));
    }
  };

export const getDraftSkills = (data) => async (dispatch, getState) => {
  var newUrl;
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  // const orgId = getState().organizationReducer.currentOrganization.id;
  try {
    if (data && data === "SkillHub") {
      newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveAllHelperSkill&_org=${orgId}`;
    } else if (data && data.type === "SkillHub" && data.category && data.page) {
      newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieve?TYPE=SkillHub&category=${data.category}&page=${data.page}&pageSize=10&_org=${orgId}`;
    } else if (data === "getCount") {
      newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieve?TYPE=SkillHub&getCount&_org=${orgId}`;
    } else if (data && data.applyFilter === "all") {
      newUrl = `${
        process.env.REACT_APP_BOT_SERVICE_URL
      }/draftSkills/retrieveRegularSkill?filterSkills=all&page=${
        data ? data.page : 1
      }&pageSize=10&_org=${orgId}`;
    } else {
      newUrl = `${
        process.env.REACT_APP_BOT_SERVICE_URL
      }/draftSkills/retrieveRegularSkill?page=${
        data ? data.page : 1
      }&pageSize=10&_org=${orgId}`;
    }
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };
    const result = await axios(config);
    dispatch({ type: types.GET_DRAFTS, payload: result.data.data.results });
    dispatch({ type: types.PAGE_INFO_DRAFT, payload: result.data.data });
    return result.data.data;
  } catch (err) {
    console.log(err, "err");
    dispatch(
      notify("error", "Failed to retrieve Draft Skill: " + err.toString())
    );
  }
};

export const getMetaDataSkills = (data) => async () => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  var newUrl = `${
    process.env.REACT_APP_BOT_SERVICE_URL
  }/draftSkills/retrieveMetaDataSkill?page=${
    data ? data.page : 1
  }&pageSize=10&_org=${orgId}`;
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };
    const result = await axios(config);
    return result;
  } catch (err) {
    console.log(err, "err");
    // dispatch(notify("error", "Failed to retrieve Draft Skill "));
  }
};

export const getDraftSkillCount = () => async (dispatch) => {
  var newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveHelperCount`;
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };
    const result = await axios(config);
    return result.data.data;
  } catch (err) {
    console.log(err, "err");
    dispatch(notify("error", "Failed to retrieve Draft Skill "));
  }
};
export const getUserHelperSkills = (data) => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  var newUrl;
  if (data && data.page) {
    newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveUserHelper?page=${data.page}&pageSize=10&_org=${orgId}`;
  } else {
    newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveUserHelper&_org=${orgId}`;
  }
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };
    const result = await axios(config);
    // console.log("result", result);
    dispatch({
      type: types.GET_USER_HELPER,
      payload: result.data.data,
    });
    // dispatch({ type: types.PAGE_INFO_DRAFT, payload: result.data.data });
    return result.data.data;
  } catch (err) {
    console.log(err, "err");
    dispatch(notify("error", "Failed to retrieve Draft Skill "));
  }
};

export const getHelperTask = (data) => async (dispatch) => {
  var newUrl;
  if (data) {
    newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveHelperTask?page=${data}&pageSize=15`;
  } else {
    newUrl = `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveHelperTask`;
  }

  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: newUrl,
    };
    const result = await axios(config);
    dispatch({ type: types.GET_HELPER_TASK, payload: result.data.data });
    return result.data.data;
  } catch (err) {
    dispatch(
      notify("error", "Failed to retrieve Draft Skill: " + err.toString())
    );
  }
};

export const getDraftSkillsById = (id) => async (dispatch, getState) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;

  try {
    dispatch({ type: types.LOADING, payload: true });
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      headers: {
        "Content-Type": "application/json",

        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/retrieveDraft`,
      data: { id, orgId },
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_DRAFTS_BY_ID,
      payload: result.data.data,
      skillMeta: result.data.skillMeta,
    });
    dispatch({ type: types.LOADING, payload: false });
    return result;
  } catch (err) {
    console.log(err, "error");
    dispatch({ type: types.LOADING, payload: false });
    dispatch(
      notify("error", "Failed to retrieve Draft Skill: " + err.toString())
    );
  }
};

export const approveDraftSkill = (payload, status) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/updateTaskStatus?status=${status}`,
      data: payload,
    };
    const result = await axios(config);
    if (result) {
      return result;
    }
  } catch (err) {
    dispatch(
      notify("error", "Failed to approve Draft Skill: " + err.toString())
    );
  }
};

export const executeFlow = (data) => async (dispatch) => {
  var _data;
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  if (data.variables) {
    _data = {
      deviceId: data.deviceId,
      skillId: data.skillId,
      variables: data.variables,
      orgId: orgId,
      ...data,
    };
  } else {
    _data = {
      deviceId: data.deviceId,
      skillId: data.skillId,
      orgId: orgId,
      ...data,
    };
  }
  try {
    let token = await getKeycloackToken();

    var config = {
      method: "post",
      headers: {
        "Content-Type": "application/json",

        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/extension/execute`,
      data: _data,
    };
    const result = await axios(config);
    console.log(result, "result");
    if (result.data.status === true) {
      dispatch(
        notify("success", "Please wait while we trigger the automation skill")
      );
      return result;
    } else {
      if (result?.data?.status === "failed") {
        dispatch(notify("error", result?.data?.message));
      }
      if (result?.data?.status === false) {
        dispatch(notify("error", result?.data?.message));
      }

      return result;
    }
  } catch (err) {
    dispatch(notify("error", "Failed to execute the automation skill"));
  }
};

export const searchDraft = (data) => async (dispatch) => {
  let token = await getKeycloackToken();

  var config = {
    method: "get",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/search?query=${data.query}&page=${data.page}`,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  const response = await axios(config);
  return response.data.data;
};

export const sendRequestAccess = (data) => async (dispatch, getState) => {
  let token = await getKeycloackToken();
  var config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/inviteEmail`,
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: {
      to: ["E-workforce@techforce.ai"],
      subject: `Super Assistant App - Enquiry about ${data.tempDetail} template`,
      body: `The following user requested for ${data.tempDetail} template.<br/> Name: ${data.userInfo.Name}. <br/> Email: ${data.userInfo.Email} <br/> Mobile: ${data.userInfo.contactNumber} <br/> Thank You.`,
    },
  };
  try {
    const { data } = await axios(config);
    return true;
  } catch (err) {
    return false;
  }
};

export const addBranchNode = (data) => async (dispatch, getState) => {
  let token = await getKeycloackToken();
  var config = {
    method: "put",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/branch`,
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: data,
  };
  try {
    const response = await axios(config);
    return true;
  } catch (err) {
    return false;
  }
};

// Get Sheet Headers

export const getSheetHeaders = (sheetUrl, sheetName) => async (dispatch) => {
  try {
    let url;
    let _urlObj = new URL(sheetUrl);
    if (_urlObj.hostname.match("google.com")) {
      url = _urlObj.href.replace("/edit", "/export?format=csv");
    } else {
      url = sheetUrl;
    }
    let { data } = await axios.get(url, { responseType: "arraybuffer" });
    var file = new Blob([data], { type: "application/vnd.ms-excel" });
    let workBook = await read(await file.arrayBuffer(), { type: "array" });
    sheetName = sheetName || "Sheets1";
    var sheetData = utils.sheet_to_json(workBook.Sheets[sheetName], {
      header: 1,
    });
    dispatch({ type: types.GET_SHEET_HEADERS, payload: sheetData[0] });
    return sheetData[0];
  } catch (e) {
    console.log(e);
  }
};

export const addSkillFromStore = (data) => async (dispatch) => {
  try {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? parseInt(getOrgDetails.id) : null;
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/user/uploadSkill`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: {
        skill_meta: data.skillMeta,
        skill_name: data.skillName,
        skill_id: data.skillId,
        organization_id: orgId,
      },
    };
    const response = await axios(config);
  } catch (err) {
    dispatch(notify("error", "Failed to add skill: " + err.toString()));
  }
};
