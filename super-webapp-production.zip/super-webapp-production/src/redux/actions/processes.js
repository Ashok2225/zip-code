import { getDraftSkills } from "./skill";
export const getProcesses = () => async (dispatch, getState) => {
  await dispatch(getDraftSkills());
  var data = getState().skillReducer.draft_skills;

  data = data.filter(
    (skill) =>
      (skill.status === "published" || skill.status === "approved") &&
      skill.TEMPLATE !== "UserDocumentation"
  );

  return {
    count: data.length,
    rows: data,
  };
};
