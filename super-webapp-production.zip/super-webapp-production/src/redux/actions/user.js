import keycloak from "../../keycloak";
import axios from "axios";
import * as types from "../constants/userConstants";
import { getKeycloackToken } from "./auth";
import { notify } from "./snackActions";
import {getMyOrganizations} from "./organizationAction"

export const setCurrentUser = (user) => (dispatch) => {
  dispatch({ type: types.SET_CURRENT_USER, payload: user });
};

export const setSuperWindowDeviceName = (devicename) => (dispatch) => {
  dispatch({ type: types.SUPER_WINDOW_DEVICE_NAME, payload: devicename });
};

export const getSuperAgent = (agentUrl) => (dispatch) => {
  dispatch({ type: types.SUPER_AGENT_URL, payload: agentUrl });
};

export const logout = () => (dispatch) => {
  setTimeout(function () {
    try {
      localStorage.clear();
      keycloak.logout();
    } catch (err) {
      console.log("err", err);
    }
  }, 1000);
};

export const updatePassword =
  (checkPwdPayload, updatePwdPayload) => async (dispatch, getState) => {
    try {
      let keytoken = await getKeycloackToken();
      var config = {
        method: "post",
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/update-password`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${keytoken}`,
        },
        data: { checkPwdPayload, updatePwdPayload },
      };
      await axios(config);
      dispatch(notify("success", "Password updated"));
    } catch (err) {
      dispatch(notify("error", "Failed to update password: " + err.response.data.error));
    }
  };

export const updateProfile = (payload) => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    let config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/update-profile`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    const res = await keycloak.loadUserInfo();
    dispatch(setCurrentUser(res));
    dispatch(notify("success", "Profile updated"));
  } catch (err) {
    dispatch(notify("error", "Failed to update profile: " + err.toString()));
  }
};


export const acceptInvite = (code) => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    let config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/checkInvite`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: {code},
    };
    const {data:{data}} = await axios(config);
    dispatch(getMyOrganizations())
    dispatch(notify("success", data));
  } catch (err) {
    dispatch(notify("error", "Failed : " + err.response.data.error.toString()));
  }
};
