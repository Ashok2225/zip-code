import * as types from "../constants/logsConstants";
import axios from "axios";
import { getKeycloackToken } from "./auth";
import { notify } from "./snack";
import qs from "qs";

export const getAutomationBuildLogs = (skillId, opt) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    console.log(opt)
    let filters = qs.stringify(opt.filters||{})
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/automationBuildLogs/${skillId}?page=${opt?.page || 1 }&pageSize=${opt?.pageSize || 100}&${filters}`,
    };
    const result = await axios(config);

    dispatch({
      type: types.AUTOMATION_BUILD_LOGS,
      payload: result.data.data,
      total: result.data.pagination.total
    });
    return result?.data?.data?.results;
  } catch (err) {
    dispatch(
      notify("error", "Failed to  Draft Skill: " + err.toString())
    );
  }
};
