import * as types from "../constants/analytics";
export const updateAnalyticsRecord=(record)=>(dispatch)=>{

dispatch({type:types.UPDATE_ANALYTICS_RECORD,payload:record})

}