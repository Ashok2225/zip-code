import { getKeycloackToken } from "./auth";
import { v4 as uuid } from "uuid";
import * as types from "../constants/skillConstants";

const axios = require("axios");
const { dispatch } = require("rxjs/internal/observable/pairs");

export const setSecret = async (secretValue) => {
  let token = await getKeycloackToken();
  var config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/azureVault`,
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    data: {
      secretValue,
    },
  };

  try {
    const res = await axios(config);
    return { status: true, data: res.data.data };
  } catch (err) {
    return { status: false, data: err.toString() };
  }
};

export const addGetSecretAction =
  (insertLocId, secretName) => (dispatch, getState) => {
    const state = getState();
    let { trainDraft } = state.skillReducer;
    let { RAW_DATA } = state.skillReducer.trainDraft;

    let secretActionId = uuid();

    const action = {
      id: secretActionId,
      actionType: "GET_AZURESECRET",
      label: "Get Secret",
      key: "GetSecret",
      allowNesting: false,
      AssetName: secretName,
      variable: secretName,
      variableName: "",
      // "instruction": "api_config = {method:'POST' ,header:[\"Content-Type:application/x-www-form-urlencoded\"],body:\"username=undefined&password=undefined&grant_type=password&client_id=admin-cli\"} \n api undefined/protocol/openid-connect/token \n token_data = api_json.access_token \n api_config = {method:'GET',  header:[ ]} \n api undefined/v1/csrftoken \n csrf_token = api_json.csrfToken \n api_config = {method:'GET',  header:[ 'Authorization: Bearer `token_data`','X-Frame-Options:sameorigin','set_cookie:HttpOnly','strict-transport-security:max-age=31536000; includeSubDomains','Public-Key-Pins:pin-sha256=\"AbCdEf123=\"; pin-sha256=\"ZyXwVu456=\";max-age=2592000; includeSubDomains','X-XSS-Protection:1; mode=block','x-content-type-options:nosniff','X-Download-Options:noopen','csrfToken:`csrf_token`']} \n api undefined/v1/vault/getUniqueId?secret_name="+secretName+" \n "+secretName+"=api_json.value ",

      description: "Gets the text data from Secretvault",
      status: true,
    };

    let newActions = findAndInsert(
      trainDraft?.RAW_DATA?.actions,
      insertLocId,
      action
    );

    return {
      ...trainDraft,
      RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
    };
  };
const findAndInsert = (arr, id, payload) => {
  let found = arr.findIndex((i) => i.id == id);
  if (found > -1) {
    arr.splice(found - 1, 0, payload);
  } else {
    arr.forEach((element) => {
      if (
        [
          "branch",
          "condition",
          "loop",
          "loop-nodes",
          "try",
          "try-catch-node",
        ].includes(element.type)
      ) {
        findAndInsert(element.children, id, payload);
      }
    });
  }
  return arr;
};
