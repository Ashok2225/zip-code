import axios from "axios";
import * as types from "../constants/organizationConstants";
import { notify } from "./snackActions";
import { getKeycloackToken } from "./auth";
import { changeActiveTab } from "./skill";
export const getOrganizations = () => async (dispatch, getState) => {
  //let state = getState()

  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveAllOrganization`,
    };
    const result = await axios(config);

    dispatch({
      type: types.GET_ORGANIZATIONS,
      payload: result.data.data,
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });

    return result;
  } catch (err) {
    dispatch(
      notify("error", "Failed to fetch organizations: " + err.toString())
    );
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getMyOrganizations = () => async (dispatch, getState) => {
  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveMyOrganizations`,
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_MY_ORGANIZATIONS,
      payload: result.data.data,
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(
      notify("error", "Failed to get your organizations: " + err.toString())
    );
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getOrganizationById = (id) => async (dispatch, getState) => {
  //let state = getState()
  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveOrganization?id=${id}`,
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_ORGANIZATION_BY_ID,
      payload: result.data.data.results[0],
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(notify("error", "Failed to retrieve teams: " + err.toString()));
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getTeamsOfAnOrganization = (id) => async (dispatch, getState) => {
  //let state = getState()
  if (id === undefined) {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    id = orgId;
  }
  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/retrieveTeamsOfAnOrganization?id=${id}`,
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_TEAMS_OF_AN_ORGANIZATION,
      payload: result.data.data.results,
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    console.log(err, "err");
    dispatch(
      notify(
        "error",
        "Failed to retrieve teams of an organization: " + err.toString()
      )
    );
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getUsersOfAnOrganization = (id) => async (dispatch, getState) => {
  if (id === undefined) {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    id = orgId;
  }
  //let state = getState()
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveMembersFromOrganization?organization_id=${id}`,
    };
    var configForInviteUser = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveInvitedMembersFromOrganization?organization_id=${id}`,
    };
    const result = await axios(config);
    const responseOfInviteUsers = await axios(configForInviteUser);
    let { results } = responseOfInviteUsers.data.data;
    results = results.map((people) => {
      if (!people.name) {
        people.name = "No name";
      }
      return people;
    });
    dispatch({
      type: types.GET_USERS_OF_AN_ORGANIZATION,
      payload: [
        ...result.data.data.results,
        ...responseOfInviteUsers.data.data.results,
      ],
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(
      notify("error", "Failed to retrieve users of teams: " + err.toString())
    );
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getTeamById = (id) => async (dispatch, getState) => {
  //let state = getState()
  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/retrieve?id=${id}`,
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_TEAM_BY_ID,
      payload: result.data.data.results[0],
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(notify("error", "Failed to retrieve team: " + err.toString()));
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getMembersOfTeam = (id) => async (dispatch, getState) => {
  //let state = getState()

  try {
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/retrieveMembersFromTeam?id=${id}`,
    };
    const result = await axios(config);
    dispatch({
      type: types.GET_USERS_OF_A_TEAM,
      payload: result.data.data.results,
    });
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
    return result.data.data.results;
  } catch (err) {
    dispatch(
      notify("error", "Failed to retrieve members of team: " + err.toString())
    );
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const createOrganization = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/create`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    const res = await axios(config);
    // dispatch(notify("success", "Organization created"));
    // Update success msg to alias team
    dispatch(notify("success", "Team created"));

    dispatch(getMyOrganizations());
    dispatch({ type: types.CREATE_ORGANIZATION, data: res.data.data });
    return true;
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    // Update error msg to alias team

    // dispatch(
    //   notify("error", "Failed to Create organization: " + err.toString())
    // );
    dispatch(notify("error", "Failed to Create Team: " + err.toString()));
    return false;
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const deleteOrganization = (id) => async (dispatch, getState) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    const config = {
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/deleteOrganization?id=${id}`,
      method: "delete",
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    await axios(config);
    dispatch(notify("success", "Successfully deleted"));
    dispatch(getMyOrganizations());
    dispatch({ type: types.REMOVE_ORGANIZATION, id });
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    const response = await dispatch(getOrganizations());
    dispatch(setCurrentOrganization(response.data.data[0]));
    dispatch(changeActiveTab("Create"));
  } catch (err) {
    dispatch(
      notify("error", "Unable to delete organization: " + err.toString())
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const removeMemberFromAnOrganization =
  (id) => async (dispatch, getState) => {
    let state = getState();
    const { user } = state.userReducer;
    try {
      //const { sub } = getState().item.userInfo
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      const config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/removeMemberFromOrganization?id=${id}`,
        method: "delete",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      const res = await axios(config);
      dispatch(notify("success", "Memeber removed"));
      dispatch({ type: types.REMOVE_USER_FROM_AN_ORGANIZATION, id });
      if (user.email === res.data.data.email) dispatch(getMyOrganizations());
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    } catch (err) {
      dispatch(
        notify(
          "error",
          "Unable to remove member from organization: " + err.toString()
        )
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const removeInviteMemberFromAnOrganization =
  (id) => async (dispatch, getState) => {
    let state = getState();
    const { user } = state.userReducer;
    try {
      //const { sub } = getState().item.userInfo
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      const config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/removeInviteMemberFromOrganization?id=${id}`,
        method: "delete",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      const res = await axios(config);
      dispatch(notify("success", "Invite removed"));
      dispatch({ type: types.REMOVE_USER_FROM_AN_ORGANIZATION, id });
      if (user.email === res.data.data.email) dispatch(getMyOrganizations());
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    } catch (err) {
      dispatch(
        notify(
          "error",
          "Unable to remove member from organization: " + err.toString()
        )
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const createTeam = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/create`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    const res = await axios(config);
    dispatch({ type: types.CREATE_TEAM, data: res.data.data });
    // dispatch(getTeamsOfAnOrganization(payload.organization_id));
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    return res.data.data;
  } catch (err) {
    dispatch(notify("error", "Failed to Create team: " + err.toString()));
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const removeMemberFromTeam =
  (id, teamId) => async (dispatch, getState) => {
    try {
      //const { sub } = getState().item.userInfo
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      const config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/removeMemberFromTeam?id=${id}`,
        method: "delete",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      await axios(config);
      dispatch(notify("success", "Memeber removed"));
      dispatch({ type: types.REMOVE_MEMBER_FROM_A_TEAM, id });
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
      // dispatch(getMembersOfTeam(teamId));
    } catch (err) {
      dispatch(
        notify("error", "Unable to remove member from team: " + err.toString())
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const removeTeamFromOrganization =
  (id) => async (dispatch, getState) => {
    try {
      //const { sub } = getState().item.userInfo
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      const config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/delete?id=${id}`,
        method: "delete",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      const res = await axios(config);
      dispatch(notify("success", "Team deleted"));
      dispatch({ type: types.REMOVE_TEAM_FROM_AN_ORGANIZATION, id });
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
      // dispatch(getTeamsOfAnOrganization(res.data.data.organization_id));
    } catch (err) {
      dispatch(
        notify(
          "error",
          "Unable to delete team from organization: " + err.toString()
        )
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const updateOrganization = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/update`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    // dispatch({ type: types.CREATE_ORGANIZATION, payload });
    dispatch(notify("success", "Updated Successfully"));
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    // dispatch(getOrganizationById(payload.id));
  } catch (err) {
    dispatch(
      notify("error", "Failed to update organization: " + err.toString())
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const updateTeam = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/update`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    // dispatch({ type: types.CREATE_ORGANIZATION, payload });
    dispatch(notify("success", "Team Updated"));
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    // dispatch(getOrganizationById(payload.id));
  } catch (err) {
    dispatch(notify("error", "Failed to update team: " + err.toString()));
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const addMemberToTeam = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/addMemberToTeam`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    const res = await axios(config);
    dispatch({ type: types.ADD_MEMBER_TO_TEAM, data: res.data.data });
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    // dispatch(getMembersOfTeam(payload.team_id));
  } catch (err) {
    dispatch(
      notify("error", "Failed to add member to team: " + err.toString())
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const addMemberToOrganization =
  (payload) => async (dispatch, getState) => {
    let state = getState();
    const { user } = state.userReducer;
    try {
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      var config = {
        method: "post",
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/addMemberToOrganization`,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: payload,
      };
      const res = await axios(config);
      dispatch({ type: types.ADD_MEMBER_TO_ORG });
      dispatch(notify("success", "Invitation sent successfully"));
      if (user.email === payload.email) dispatch(getMyOrganizations());
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    } catch (err) {
      dispatch(
        notify("error", "Failed to add member to team: " + err.toString())
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const updateUserOfOrg = (payload) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/updateUser`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    dispatch(getUsersOfAnOrganization(payload.organization_id));
  } catch (err) {
    dispatch(
      notify(
        "error",
        "Failed to update user of organization: " + err.toString()
      )
    );
  }
};

export const toggleUserOfOrg = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    dispatch({ type: types.TOGGLE_USER_OF_ORG, payload });
    var config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/updateUser`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(
      notify(
        "error",
        "Failed to update user of organization: " + err.toString()
      )
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const toggleUserOfTeam = (payload) => async (dispatch, getState) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    dispatch({ type: types.TOGGLE_USER_OF_TEAM, payload });
    var config = {
      method: "put",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/team/updateUser`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    await axios(config);
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(
      notify("error", "Failed to update user of team: " + err.toString())
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const getCategoriesOfAnOrganization =
  (id) => async (dispatch, getState) => {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    dispatch({ type: types.IS_LOADING, payload: { status: true } });
    if (orgId) {
      id = orgId;
      try {
        let token = await getKeycloackToken();
        var config = {
          method: "get",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/categories/retrieve?organization_id=${id}`,
        };
        const result = await axios(config);
        dispatch({
          type: types.GET_CATEGORIES_OF_AN_ORGANIZATION,
          payload: result.data.data.results,
        });
        dispatch({ type: types.IS_LOADING, payload: { status: false } });
      } catch (err) {
        dispatch(
          notify(
            "error",
            "Failed to retrieve users of organization: " + err.toString()
          )
        );
        dispatch({ type: types.IS_LOADING, payload: { status: false } });
      }
    } else {
      dispatch({
        type: types.GET_CATEGORIES_OF_AN_ORGANIZATION,
        payload: [],
      });
    }
    dispatch({ type: types.IS_LOADING, payload: { status: false } });
  };

export const addCategoryToOrganization = (payload) => async (dispatch) => {
  try {
    // dispatch({ type: types.IS_LOADING, payload: { status: true } });
    let token = await getKeycloackToken();
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/categories/add`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      data: payload,
    };
    const res = await axios(config);
    dispatch({ type: types.ADD_CATEGORY_TO_ORG, data: res.data.data });
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  } catch (err) {
    dispatch(
      notify(
        "error",
        "Failed to add category to organization: " + err.toString()
      )
    );
    // dispatch({ type: types.IS_LOADING, payload: { status: false } });
  }
};

export const removeCategoryFromOrganization =
  (id) => async (dispatch, getState) => {
    try {
      //const { sub } = getState().item.userInfo
      // dispatch({ type: types.IS_LOADING, payload: { status: true } });
      let token = await getKeycloackToken();
      const config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/categories/delete?id=${id}`,
        method: "delete",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      };
      await axios(config);
      dispatch(notify("success", "Team deleted"));
      dispatch({ type: types.REMOVE_CATEGORY_FROM_AN_ORGANIZATION, id });
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    } catch (err) {
      dispatch(
        notify(
          "error",
          "Unable to delete team from organization: " + err.toString()
        )
      );
      // dispatch({ type: types.IS_LOADING, payload: { status: false } });
    }
  };

export const validateOrganization = (data) => async (dispatch) => {
  let token = await getKeycloackToken();

  var config = {
    method: "post",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/validateOrgList`,
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    data: data,
  };

  const result = await axios(config);
  return result.data;
};

export const setCurrentOrganization = (org) => (dispatch) => {
  dispatch({ type: types.SET_CURRENT_ORGANIZATION, payload: { org } });
};

export const getCurrentUser = (email) => async (dispatch) => {
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/getCurrentUser?email=${email}&orgId=${orgId}`,
    };
    const result = await axios(config);
    console.log(result, "resr");
    dispatch({
      type: types.SET_CURRENT_ORG_USER,
      payload: result.data.data[0],
    });
  } catch (err) {
    dispatch(notify("error", "Failed to retrieve teams: " + err.toString()));
  }
};
