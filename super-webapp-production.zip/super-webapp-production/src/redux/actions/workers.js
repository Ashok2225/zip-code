import { getSession } from "./skill";

export const getWorkers = () => async (dispatch, getState) => {
  let results = await dispatch(getSession());
  var worker_id = getState().skillReducer.draftSession;
  return [
    {
      worker_id: worker_id,
      worker_type: "standard",
      queue_name: worker_id,
      worker_name: results.session_name,
    },
  ];
};
