import axios from "axios";
import { getKeycloackToken } from "./auth";
import * as types from "../constants/appConstants";

export const setNotificationMessage = (message) => (dispatch) => {
  message = JSON.parse(message.data)
  dispatch({ type: types.NOTIFICATION_MESSAGE, payload: message });
};

export const loadNotifications = () => async (dispatch) => {
    try {
      var token = await getKeycloackToken();
      axios
        .get(`${process.env.REACT_APP_BOT_SERVICE_URL}/user/getNotifications`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then(async (res) => {
          let notifications = res.data.data;
          dispatch({ type: types.GET_NOTIFY, payload: notifications });
        })
        .catch((err) => {
          dispatch({ type: types.GET_NOTIFY, payload: [] });
        });
    } catch (e) {
      console.log(e.toString());
    }
  };

export const deleteNotifications = (notifications) => async (dispatch) => {
    try {
      var token = await getKeycloackToken();
      axios
        .delete(`${process.env.REACT_APP_BOT_SERVICE_URL}/user/deleteNotifications`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          data: notifications
        })
        .then(async (res) => {
          dispatch({ type: types.GET_NOTIFY, payload: [] });
          console.log("Notifications Deleted")
        })
        .catch((err) => {
          console.log("Delete Notifications Error")
        });
    } catch (e) {
      console.log(e.toString());
    }
  };
 export const changeMode= (data) => async(dispatch) => {
  dispatch({ type: types.MODE_CHANGE,payload:data})
   
  };