import axios from "axios";
import keycloak from "../../keycloak";
import * as types from "../constants/authConstants";
import { notify } from "./snackActions";
import { Base64 } from "js-base64";

var qs = require("qs");

export const updateLoginComponent = (componentName) => (dispatch) => {
  dispatch({ type: types.UPDATE_LOGIN, payload: componentName });
};

export const updateMainComponent = (componentName) => (dispatch) => {
  dispatch({
    type: types.UPDATE_MAIN,
    payload: { componentName: componentName },
  });
};

export const signInFailed = (message) => (dispatch) => {
  dispatch({ type: types.SIGN_FAILED, payload: { loginMessage: message } });
};
export const signInSuccess = (user) => (dispatch) => {
  dispatch({ type: types.SIGN_SUCCESS, payload: { userInfo: user } });
};

export const storeUserSecret = (payload) => (dispatch) => {
  dispatch({ type: types.STORE_SECRET, payload: payload });
};

export const signIn = (username, password) => async (dispatch) => {
  dispatch(updateMainComponent("LoginArea"));
  var data = qs.stringify({
    username: username,
    password: password,
    client_id: process.env.REACT_APP_KEYCLOAK_CLIENT_ID,
    grant_type: "password",
  });
  var config = {
    method: "post",
    url: `${process.env.REACT_APP_KEYCLOAK_URL}realms/${process.env.REACT_APP_KEYCLOAK_REALM}/protocol/openid-connect/token`,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    data: data,
  };
  try {
    const response = await axios(config);

    if (response.status == 200) {
      localStorage.setItem("refresh_token", response.data.refresh_token);
      dispatch(loadUserInfo(response.data.access_token));

      localStorage.setItem(
        "secret",
        JSON.stringify({ username: username, password: password })
      );
      dispatch(storeUserSecret({ username: username, password: password }));

      try {
        // registerWorker(username, password)
      } catch (err) {
        console.log(err.toString());
      }
    }
  } catch (er) {
    if (er.toString() === "Error: Network Error") {
      dispatch(signInFailed("Please check you Network connection"));
    } else dispatch(signInFailed("Invalid Credentials"));
  }
};

export const generateApiAccessToken = (access_token) => async (dispatch) => {
  try {
    let token = await getKeycloackToken();
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;

    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/token/create`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
      data: {
        "orgId": orgId,
        "roles": ['read']
      }
    }
    const response = await axios(config)
    
    dispatch({
      type: types.API_ACCESS_TOKEN,
      payload: response.data.data
    })
    return response.data.data
  } catch (err) {

    dispatch(
      notify("error", "Failed: " + err.toString())
    );
  }
};

export const getAllApiTokens = () => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/token/all`,
      headers: {
        Authorization: `Bearer ${token}`,
        
      },
      data: {
        "orgId": orgId,
      }
    }
    const response = await axios(config);
    console.log(response,"RESPONSE")
    dispatch({
      type: types.GET_ALL_TOKENS,
      payload: response.data.data,
    });
  } catch (err) {
    console.log(err,"ERROR")
    dispatch(
      notify("error", "Failed to get your tokens: " + err.toString())
    );
  }
};

export const deleteToken = (id) => async (dispatch, getState) => {
  try {
    let token = await getKeycloackToken();
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    var config = {
      method: "delete",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/token/delete?id=${id}`,
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${token}`,
        
      },
      data: {
        "orgId": orgId,
      }
    }
    const response = await axios(config);
    console.log(response,"RESPONSE")
    dispatch({
      type: types.DELETE_TOKEN,id,
      payload: response.data.data,
    });
    dispatch(notify("success", "Successfully deleted"));
    dispatch(getAllApiTokens());
  } catch (err) {
    console.log(err,"ERROR")
    dispatch(
      notify("error", "Unable to delete token: " + err.toString())
    );
  }
};

export const loadUserProfile = () => async (dispatch) => {
  let token = await getKeycloackToken();
  var config = {
    method: "get",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/profile`,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
  const response = await axios(config);
  if (response.status == 200 && response.data.data.results.length > 0) {
    console.log(response.data.data.results[0].profile_img);
    dispatch({
      type: types.LOAD_PROFILE,
      payload: response.data.data.results[0],
    });
  }
};

export const loadUserInfo = (access_token) => async (dispatch) => {
  var config = {
    method: "get",
    url: `${process.env.REACT_APP_KEYCLOAK_URL}realms/${process.env.REACT_APP_KEYCLOAK_REALM}/protocol/openid-connect/userinfo`,
    headers: {
      Authorization: `Bearer ${access_token}`,
    },
  };
  const response = await axios(config);
  if (response.status == 200) {
    dispatch(signInSuccess(response.data));
    dispatch(loadUserProfile(response.data.sub));
  }
};
export const isLoggedIn = () => async (dispatch) => {
  let refreshToken = localStorage.getItem("refresh_token");
  if (refreshToken != undefined) {
    var data = qs.stringify({
      client_id: process.env.REACT_APP_KEYCLOAK_CLIENT_ID,
      grant_type: "refresh_token",
      refresh_token: refreshToken,
    });
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_KEYCLOAK_URL}realms/${process.env.REACT_APP_KEYCLOAK_REALM}/protocol/openid-connect/token`,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: data,
    };
    try {
      const response = await axios(config);
      if (response.status == 200) {
        localStorage.removeItem("refresh_token");
        localStorage.setItem("refresh_token", response.data.refresh_token);
        dispatch(loadUserInfo(response.data.access_token));
        dispatch(storeUserSecret(JSON.parse(localStorage.getItem("secret"))));
      }
    } catch (err) {
      localStorage.removeItem("refresh_token");
      dispatch(signInFailed(""));
    }
  } else {
    dispatch(updateMainComponent("LoginArea"));
  }
};

export const logOut = () => (dispatch) => {
  localStorage.removeItem("refresh_token");
  dispatch(updateMainComponent("LoginArea"));
};

/*=====================Signup Actions=============================================================*/

export const signUpSuccess = () => ({
  type: types.SIGNUP_SUCCESS,
});
export const signUpFail = () => ({
  type: types.SIGNUP_FAIL,
});

export const signUp = async (signUpBody) => {
  try {
    let email = signUpBody.email.replace(/\./g, "_");
    email = email.replace(/-/g, "_");
    email = email.replace(/@/g, "_");
    var data = JSON.stringify({
      user_id: signUpBody.user_id,
      email: email,
    });
    var config = {
      method: "post",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/createNlpModel`,
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    var res = await axios(config);
    return 200;
  } catch (e) {
    return 500;
  }
};

export const getKeycloackToken = async () => {
  let token = keycloak.token;
  if (!token) {
    keycloak.login();
    return;
  } else {
    let isTokenExpired = keycloak.isTokenExpired();
    if (isTokenExpired) {
      try {
        let flag = await keycloak.updateToken(180);
        if (flag) {
          return keycloak.token;
        } else {
          keycloak.login();
        }
      } catch (e) {
        keycloak.login();
      }
    } else {
      return token;
    }
  }
};

export const getKeycloackRefreshToken = async () => {
  let token = keycloak.refreshToken;
  if (!token) {
    keycloak.login();
    return;
  } else {
    let isTokenExpired = keycloak.isTokenExpired();
    if (isTokenExpired) {
      try {
        let flag = await keycloak.updateToken(180);
        if (flag) {
          return keycloak.refreshToken;
        } else {
          keycloak.login();
        }
      } catch (e) {
        keycloak.login();
      }
    } else {
      return token;
    }
  }
};

export const forgetPasswordSuccess = (message) => ({
  type: types.FORGET_SUCCESS,
});
export const forgetPasswordFail = (error) => ({
  type: types.FORGET_FAILED,
});

export const forgetPassword = (forgetPasswordBody) => {
  return async (dispatch) => {
    try {
      //console.log("in actions",forgetPasswordBody);
      var config = {
        method: "post",
        url: `${process.env.REACT_APP_EMCONSOLE_URL}/v1/user/userid`,
        data: {
          email: forgetPasswordBody.email,
        },
      };
      axios(config)
        .then((response) => {
          console.log(response);
          let config2 = {
            id: response.data.id,
          };
          axios
            .post(
              `${process.env.REACT_APP_EMCONSOLE_URL}/v1/user/sendmail`,
              config2
            )
            .then((res) => {
              console.log("rses", res);
              var details = {
                userId: response,
                sendmail: res,
              };
              dispatch(forgetPasswordSuccess(details));
            })
            .catch((err) => {
              dispatch(forgetPasswordFail("failed"));
            });
        })
        .catch((err) => {
          dispatch(forgetPasswordFail("failed"));
        });
      // dispatch(forgetPasswordSuccess(data))
      //
    } catch (e) {
      console.log(e.response);
      dispatch(forgetPasswordFail("failed"));
    }
  };
};

export const register = async (payload) => {
  var cropUrl = process.env.REACT_APP_WEB_APP_URL;
  payload.redirectUri = cropUrl;
  try {
    let data = await axios.post(
      `${process.env.REACT_APP_EMCONSOLE_URL}/v1/user/register`,
      payload
    );
    return data;
  } catch (err) {
    console.log("error while registering user in  keyclock", err.message);
    return {
      message: "Server Not responding! plese try after some time",
      status: 409,
    };
  }
};

export const changePasswordDisplay = (user_details) => async (dispatch) => {
  var keycloakAdmin = Base64.decode(process.env.REACT_APP_KEYCLOAK_ADMIN);
  keycloakAdmin = JSON.parse(keycloakAdmin);
  let { username, password } = keycloakAdmin;
  var data = qs.stringify({
    username: username,
    password: password,
    client_id: "admin-cli",
    grant_type: "password",
  });

  var config = {
    method: "post",
    url: `${process.env.REACT_APP_KEYCLOAK_URL}realms/master/protocol/openid-connect/token`,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    data: data,
  };
  try {
    const response = await axios(config);
    if (response.status == 200) {
      let token = response.data.access_token;

      var user_id = user_details.sub;
      var config = {
        method: "get",
        url: `${process.env.REACT_APP_KEYCLOAK_URL}admin/realms/${process.env.REACT_APP_KEYCLOAK_REALM}/users/${user_id}`,
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };
      try {
        const response = await axios(config);
        if (response.status == 200) {
          if (response.data.federatedIdentities.length == 0) {
            dispatch({ type: types.VERIFY_SOCIALUSER, payload: false });
          } else {
            dispatch({ type: types.VERIFY_SOCIALUSER, payload: true });
          }
        }
      } catch (err) {
        console.log(err.toString());
      }
    }
  } catch (err) {
    console.log(err.toString());
  }
};
