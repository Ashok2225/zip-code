import axios from "axios"
import { getKeycloackToken } from "./auth";
export const createSchedule = async (schedule) => {


    var data = schedule

    let keytoken = await getKeycloackToken();
    var config = {
        method: 'post',
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/schedule`,
        headers: {
            'Authorization': 'Bearer ' + keytoken,
            'Content-Type': 'application/json',

        },
        data: data
    };

    try {
        let { status } = await axios(config);
        return status;
    }
    catch (err) {
        console.log("Error while uploading bot", err.message);
    }

}


export const getSchedules = async () => {


    let keytoken = await getKeycloackToken();
    var config = {
        method: 'get',
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/schedule`,
        headers: {
            'Authorization': 'Bearer ' + keytoken,
            'Content-Type': 'application/json',

        },
      
    };

    try {
        let { data } = await axios(config);
        return data;
    }
    catch (err) {
        console.log("Error while retrieving", err.message);
    }
}


export const deleteSchedule = async (key) => {
    let keytoken = await getKeycloackToken();
    var config = {
        method: 'delete',
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/schedule?key=${key}`,
        headers: {
            'Authorization': 'Bearer ' + keytoken,
            'Content-Type': 'application/json',

        },
      
    };

    try {
        let { status } = await axios(config);
        return status;
    }
    catch (err) {
        console.log("Error while deleting", err.message);
    }
}

