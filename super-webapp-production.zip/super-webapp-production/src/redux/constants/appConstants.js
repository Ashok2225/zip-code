export const INIT_APP = "INIT_APP";
export const SHOW_SNACK = "SHOW_SNACK"
export const CLOSE_SNACK = "CLOSE_SNACK"
export const GET_NOTIFY = "GET_NOTIFY"
export const NOTIFICATION_MESSAGE = "NOTIFICATION_MESSAGE"
export const MODE_CHANGE = "MODE_CHANGE"

