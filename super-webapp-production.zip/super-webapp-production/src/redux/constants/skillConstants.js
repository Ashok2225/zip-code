export const GET_SKILLS = "GET_SKILLS";
export const IS_LOADING = "IS_LOADING";
export const GET_MY_SKILLS = "GET_MY_SKILLS";
export const ADD_TRAINER = "ADD_TRAINER";
export const OPEN_PANEL = "OPEN_PANEL";
export const CREATE_DRAFT = "CREATE_DRAFT";
export const GET_DRAFTS = "GET_DRAFTS";
export const UPDATE_DRAFT = "UPDATE_DRAFT";
export const UPDATE_MYSKILL_AREA = "UPDATE_MYSKILL_AREA";
export const UPDATE_SEARCH_TERM = "UPDATE_SEARCH_TERM";
export const USER_UPLOAD = "USER_UPLOAD";
export const SWITCH_PANEL_MODE = "SWITCH_PANEL_MODE";
export const ADD_DYNAMIC_SKILL_DATA = "ADD_DYNAMIC_SKILL_DATA";
export const UPDATE_RPA_RECORD = "UPDATE_RPA_RECORD";
export const GET_DRAFTS_BY_ID = "GET_DRAFTS_BY_ID";
export const CLEAR_DRAFTS = "CLEAR_DRAFTS";
export const START_SKILL_RECORD = "START_SKILL_RECORD";
export const DEVICES = "DEVICES";
export const UPDATE_SKILL_VIEW = "UPDATE_SKILL_VIEW";
export const DISABLE_USER_POPUP = "DISABLE_USER_POPUP";
export const GET_PREBUILD_SUCCESS = "GET_PREBUILD_SUCCESS";
export const SAVE_FAVOURITE_SKILLS = "SAVE_FAVOURITE_SKILLS";
export const GET_FAVOURITE_SKILLS = "GET_FAVOURITE_SKILLS";
export const REMOVE_FAVOURITE_SKILLS = "REMOVE_FAVOURITE_SKILLS";
export const VIEW_HELPER_ITEM = "VIEW_HELPER_ITEM";
export const PAGE_INFO_SKILL = "PAGE_INFO_SKILL";
export const PAGE_INFO_DRAFT = "PAGE_INFO_DRAFT";
export const UPDATE_SKILL_VARIABLES = "UPDATE_SKILL_VARIABLES";
export const GET_HELPER_TASK = "GET_HELPER_TASK";
export const GET_USER_HELPER = "GET_USER_HELPER";
export const GET_ACTIVE_TAB = "GET_ACTIVE_TAB";
export const GET_ACTIVE_CATEGORY = "GET_ACTIVE_CATEGORY";
export const SEARCH_SKILLS = "SEARCH_SKILLS";
export const SET_DRAFT = "SET_DRAFT";
export const IS_RECORDING = "IS_RECORDING";
export const GET_SHEET_HEADERS = "GET_SHEET_HEADERS";
export const TOOGLE_DATA_MAPPER = "TOOGLE_DATA_MAPPER";
export const STAT_CHANGE_FLOW = "STAT_CHANGE_FLOW";
export const SET_ADVANCED_PANEL = "SET_ADVANCED_PANEL";
export const CLOSE_ADVANCED_PANEL = "CLOSE_ADVANCED_PANEL";
export const SET_TIMER = "SET_TIMER";
export const LOADING = "LOADING";
export const ADDABLE_SKILL_TYPES = [
  "start",
  "end",
  "record",
  "continue",
  "break",
  "wait",
  "read",
  "filesandfolders",
  "excel",
  "echo",
  "TECHNOLOGY",
  "OPENAPP",
  "CLOSEAPP",
  "SWITCHAPP",
  "messagebox",
  "httpapi",
  "assign",
  // "GET_AZURESECRET",
  "sendMail",
  "invokeSkill",
  "toDoSkill",
  "condition",
  "stop",
  "loop",
  "loop-nodes",
  "data-set",
  "branch",
  "S3_CONNECT",
  "S3_FILE_DOWNLOAD",
  "S3_FILE_ARCHIVE",
  "READ_CREDENTIALS",
  "READ_TABLE",
  "CLOSE",
  "KEY_STROKES",
  "closetab"
  // "try",
  // "try-catch-node"
];
