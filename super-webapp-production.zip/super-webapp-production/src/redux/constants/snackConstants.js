export const SHOW_SNACK = "SHOW_SNACK";
export const CLOSE_SNACK = "CLOSE_SNACK";
