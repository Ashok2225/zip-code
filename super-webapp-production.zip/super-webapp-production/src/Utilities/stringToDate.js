const stringToDate = (datestring) => {

    try {
        if(datestring){
            let time,t,hr,min,stringtodate;
            time = datestring;
            t = new Date(time);
            hr = ("0" + t.getHours()).slice(-2);
            min = ("0" + t.getMinutes()).slice(-2);
            let month =t.getMonth()+1;
            let sec = t.getSeconds() 
            sec = (sec < 10 ? "0" : "" )+ sec;
            stringtodate = t.getFullYear()+"-"+month+"-"+t.getDate()+" "+hr+":"+min+":"+sec;   
            return stringtodate;
        }
    } catch (error) {
        return "--"
    }
      
}
export default stringToDate;
