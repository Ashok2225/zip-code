const datesCompare = (stop_date) => {

    try {        
            let today = new Date();
            let dd = String(today.getDate()).padStart(2, '0');
            let mm = String(today.getMonth() + 1).padStart(2, '0'); 
            let yyyy = today.getFullYear();
            let date1 = dd + '-' + mm + '-' + yyyy     
            let date2 = stop_date.split("-").reverse().join("-");
        
            if(date2 > date1 ){
                return true
            }
            else if(date2 < date1 ){
                return false
            } else {
                return true
            }
            
    } catch (error) {
        return "--"
    }
      
}
export default datesCompare;