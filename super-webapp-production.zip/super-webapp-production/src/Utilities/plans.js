export const plans = [
         {
           id: 0,
           name: "Community",
           description: "For Individual RPA developers",
           emconsole: "Manager on cloud",
           support_sla: "Free Community support",
           payment_frequency: "",
           maximum_bots: "Unlimited Robotic Automation",
           maximum_workers: 0,
           validity: "",
           price: "0$"
         },
         {
           id: 1,
           name: "Start",
           description: "For Individual RPA developers and small teams",
           emconsole: "Manager on cloud",
           support_sla: "Ticketed Support with SLA",
           payment_frequency: "",
           maximum_bots: "Unlimited Robotic Automation",
           maximum_workers: 1,
           validity: "21 Days",
           price: "0$"
         },
         {
           id: 2,
           name: "Scale",
           description:
             "cloud based version of entire RPA Studio for small teams with unlimited Robotic Automation",
           emconsole: "Manager on cloud",
           support_sla: "Ticketed Support with SLA",
           payment_frequency: "monthly/yearly",
           maximum_bots: "Unlimited Robotic Automation",
           maximum_workers: 3,
           validity: "",
           price: "190$/month"
         },
         {
           id: 3,
           name: "Premium",
           description:
             "On premise version of enterprise RPA automation platform for Organizations",
           emconsole: "Manager on premises",
           support_sla: "Ticketed Support with SLA",
           payment_frequency: "monthly/yearly",
           maximum_bots: "Unlimited Robotic Automation",
           maximum_workers: "Unlimited",
           validity: "",
           price: "999$/month"
         }
       ];