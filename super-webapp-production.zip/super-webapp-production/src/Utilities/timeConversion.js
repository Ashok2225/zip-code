const timeConversion = (time) =>{
    if(time){
        let secondsTime=time.toString().split('.')
        let hours = Math.floor(time / 3600);
        time %= 3600;
        let  minutes = Math.floor(time / 60);
        let seconds = secondsTime[0] % 60;
        if(hours.toString().length===1){
            hours='0'+hours
        }
        if(minutes.toString().length===1){
            minutes='0'+minutes
        }
        if(seconds.toString().length===1){
            seconds='0'+seconds

        }
        let data=hours+":"+minutes+":"+seconds
        return data
    }
}

export default timeConversion;