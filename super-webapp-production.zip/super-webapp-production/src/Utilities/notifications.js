import { store } from "react-notifications-component";

export const addNotification = (properties) => {
    return store.addNotification({
        title: properties.title ? properties.title : "Tecforce",
        message: properties.message,
        type: properties.type,
        insert: "top",
        container: properties.container ? properties.container : "top-right",
        animationIn: ["animated", "fadeIn"],
        animationOut: ["animated", "zoomOut"],
        dismiss: {
            duration: 6000,
            pauseOnHover: true
        }
    });
}