import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import reportWebVitals from "./reportWebVitals";

import { Provider } from "react-redux";
import { store } from "./redux";
import keycloak from "./keycloak";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { createBrowserHistory } from "history";
import Registration from "./containers/registration";
import * as Sentry from "@sentry/react";
import { Integrations } from "@sentry/tracing";
import ECS from "./ECS";

if (process.env.REACT_APP_SENTRY_ENABLED) {
  Sentry.init({
    dsn: "https://3c72106ff7ea40dbbcc569df6163f895@o1122122.ingest.sentry.io/6159452",
    integrations: [new Integrations.BrowserTracing()],
    tracesSampleRate: 1.0,
  });
}

window.ECS = new ECS();

keycloak.init({ promiseType: "native" }).then((auth) => {
  if (!auth) {
    var a = window.location.href;
    if (a.includes("signup")) {
      ReactDOM.render(
        <React.StrictMode>
          <Provider store={store}>
            <Router>
              <Route exact path="/try/signup/" component={Registration} />
            </Router>
          </Provider>
        </React.StrictMode>,
        document.getElementById("root")
      );
    } else {
      keycloak.login();
    }
  } else {
    keycloak.loadUserInfo().then((user) => {
      ReactDOM.render(
        <Provider store={store}>
          <Router history={createBrowserHistory()}>
            <App user={user} />

            <Route exact path="/try/signup/" component={Registration} />
          </Router>
        </Provider>,
        document.getElementById("root")
      );
    });
  }
});

reportWebVitals();
