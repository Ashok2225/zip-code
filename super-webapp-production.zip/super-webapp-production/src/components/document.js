import React, { Component } from "react";
import kbdIcon from "../images/kbdIcon.png";
import kpIcon from "../images/kpIcon.png";

import {
  Document,
  Page,
  Text,
  StyleSheet,
  PDFDownloadLink,
  Image,
  View,
} from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    padding: 30,
  },
  header: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "left",
    color: "#000",
    fontWeight: "900",
    borderBottom: "1px solid #cdcdcd",
    paddingBottom: 10,
    textTransform: "capitalize",
  },
  steps: {
    marginTop: "20px",
    marginBottom: "40px",
  },
  text: {
    marginbottom: "15px",
    fontSize: 12,
    color: "#1d262e",
    marginBottom: "10px",
  },
  image: {
    marginTop: "15px",
    marginBottom: "10px",
  },
  pageNumber: {
    position: "absolute",
    fontSize: 12,
    bottom: 10,
    left: 30,
    right: 30,
    textAlign: "center",
    color: "grey",
    borderTop: "1px solid #cdcdcd",
    paddingTop: 10,
  },
  points: {
    fontWeight: "bold",
    fontSize: "12px",
  },
});

const MyDocument = (data) => {
  return data.props && data.props.RAW_DATA ? (
    <Document key={data && data.props.id}>
      <Page size="A4" style={styles.page}>
        <View style={styles.header} fixed>
          {data.props.SKILL_NAME !== "" ? (
            <Text>{data.props.SKILL_NAME}</Text>
          ) : null}
        </View>
        {data.props?.RAW_DATA?.actions?.map((steps, i) => (
          <View style={styles.steps}>
            {steps?.description !== "" ? (
              <Text style={styles.text}>
                <View style={styles.points}>{i + 1}. </View>

                {steps.description}
              </Text>
            ) : (
              <>
                {steps?.text !== "" ? (
                  <Text style={styles.text}>
                    <View style={styles.points}>{i + 1}. </View>

                    {(
                      steps?.actionType?.charAt(0).toUpperCase() +
                      steps?.actionType.slice(1)
                    ).concat(" ", steps?.text)}
                  </Text>
                ) : null}
              </>
            )}

            {steps?.pageScreenshot && steps.pageScreenshot !== "" ? (
              <Image style={styles.image} src={steps.pageScreenshot}></Image>
            ) : (
              <React.Fragment>
                
                {steps?.origin === "desktop" &&
                  steps?.actionType == "kbd" &&
                  !steps?.pageScreenshot && (
                    <Image style={styles.image} src={kbdIcon}></Image>
                  )}
                {steps?.origin === "desktop" &&
                  steps?.actionType === "kp" &&
                  !steps?.pageScreenshot && (
                    <Image style={styles.image} src={kpIcon}></Image>
                  )}
              </React.Fragment>
            )}
          </View>
        ))}
        <Text
          style={styles.pageNumber}
          render={({ pageNumber, totalPages }) =>
            `${pageNumber} / ${totalPages}`
          }
          fixed
        />
      </Page>
    </Document>
  ) : (
    ""
  );
};
export default MyDocument;
