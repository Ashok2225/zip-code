import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { PDFDownloadLink } from "@react-pdf/renderer";
import { useParams, useHistory } from "react-router-dom";
import MyDocument from "./document";
import { getDraftSkillsById } from "../redux/actions/skill";
const DownloadPdf = () => {
  const [exportUrl, setExportUrl] = useState("");

  const params = useParams();
  const history = useHistory();
  const dispatch = useDispatch();

  useEffect(() => {
    let getData = true;
    if (getData) {
      dispatch(getDraftSkillsById(params.id));
    }

    return () => {
      getData = false;
    };
  }, []);

  useEffect(() => {
    if (exportUrl !== "") {
      document.getElementById("export").click();
      history.push("/dashboard/create");
    }

    return () => {};
  }, [exportUrl]);

  const skill = useSelector((state) => state.skillReducer.trainDraft);

  return (
    <div>
      <PDFDownloadLink
        document={skill ? <MyDocument key={skill.id} props={skill} /> : null}
        fileName={skill?.SKILL_NAME}
      >
        {({ blob, url, loading, error }) =>
          error ? (
            ""
          ) : (
            <>
              {url ? <>{setExportUrl(url)}</> : null}
              <button
                id="export"
                className="lg-btn"
                style={{ display: "none" }}
              >
                <span>Export</span>
              </button>
            </>
          )
        }
      </PDFDownloadLink>
    </div>
  );
};

export default DownloadPdf;
