import React, { Component } from 'react'
import EmptyLoader from "./emptyLoader"
class NotFound extends Component {
    render() {
        return (
            <div class="height-100">
                <div className="fw-not-found height-100">

                    <div className="chat-col art-chat ">
                        <div className="empty-view">
                            <EmptyLoader />

                            <div className="not-found">
                                <h1>Oops!</h1>
                                <p>We can't seem to find the page you are looking for</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default NotFound