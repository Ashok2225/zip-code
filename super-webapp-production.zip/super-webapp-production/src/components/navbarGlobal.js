/*global chrome*/
import React, { Component } from "react";
// import { VscDesktopDownload } from 'react-icons/fa';
import fevicon from "../images/fevicon.png";
import dropdown from "../images/dropdown-image.png";
import skills from "../images/skills.png";
import task from "../images/task.png";
import bookmark from "../images/bookmark.png";
import market from "../images/market.png";
import plus from "../images/plus.png";
import notifygold from "../images/notify-gold.png";
import avatar from "../images/avatar.png";
import schedule from "../images/schedule.png";
import windowsIcon from "../images/windows.png";
import superMenu from "../images/super-menu.png";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { withRouter } from "react-router";
import { compose } from "redux";
import {
  getOrganizations,
  createOrganization,
  setCurrentOrganization,
  validateOrganization,
} from "../redux/actions/organizationAction";
import { ReactNotifications, Store } from "react-notifications-component";

import "react-notifications-component/dist/theme.css";
import ConnectDevice from "../containers/dashboard/ConnectDevice";
import { Button } from "reactstrap";
import StepTwo from "../containers/dashboard/ConnectDevice/components/StepTwo";
import StepThree from "../containers/dashboard/ConnectDevice/components/StepThree";
import StepFour from "../containers/dashboard/ConnectDevice/components/StepFour";
import StepFive from "../containers/dashboard/ConnectDevice/components/StepFive";
import StepOne from "../containers/dashboard/ConnectDevice/components/StepOne";
import { changeActiveTab } from "../redux/actions/skill";
import { notify } from "../redux/actions/snackActions";
import "../css/pricing.css";

import $ from "jquery";

import { loadNotifications,changeMode } from "../redux/actions/appActions";
class NavBar extends Component {
  constructor() {
    super();
    this.state = {
      dropDownOpen: false,
      connectDevice: false,
      stepOne: false,
      stepTwo: false,
      stepThree: false,
      stepFour: false,
      stepFive: false,
      superWindowDeviceName: "",
      enableActiveTheme: "Create",
      images: [fevicon, fevicon],
      // selectedImage: fevicon,
      selectedImage: JSON.parse(localStorage.getItem("orgDetails"))
        ? JSON.parse(localStorage.getItem("orgDetails")).profilePic
        : fevicon,
      orgName: JSON.parse(localStorage.getItem("orgDetails"))
        ? JSON.parse(localStorage.getItem("orgDetails")).name
        : "",
      // : "Techforce",
      orgId: null,
      team: {
        name: "",
        //email: "",
        //description: "",
      },
      teamError: "",
      isCreatingTeam: false,
      minMode: false,
    };
  }
  async componentDidMount() {
    this.props.loadNotifications(this.props.user);

    var path = window.location.href;
    if (path.match("/settings")) {
      this.props.changeActiveTab("Settings");
    }
    if (path.match("/dashboard/create")) {
      this.props.changeActiveTab("Create");
    }
    if (path.match("/knowledge")) {
      this.setState({
        enableActiveTheme: "Knowledgebase",
      });
    }

    if (
      path.match("/skills") ||
      path.match("/trainSkill") ||
      path.match("/viewSkill")
    ) {
      this.setState({
        enableActiveTheme: "MySkills",
      });
    }

    if (process.env.REACT_APP_SHOWMYTASK === "true") {
      if (path.match("/dashboard/tasks")) {
        this.props.changeActiveTab("MyTask");
      }
    }

    if (path.match("/search")) {
      this.setState({
        enableActiveTheme: "SearchArea",
      });
    }
    if (path.match("/skill-store")) {
      this.setState({
        enableActiveTheme: "SkillsStore",
      });
    }
    // if (path.match("/myprofile-settings")) {
    //   this.setState({
    //     enableActiveTheme: "MyProfile",
    //   });
    // }
    await this.props.getOrganizations();
    const { userReducer, organizationReducer } = this.props;
    const { email } = userReducer.user;
    if (JSON.parse(localStorage.getItem("orgDetails"))) {
      this.setState({
        orgName: JSON.parse(localStorage.getItem("orgDetails")).name,
      });
    } else if (organizationReducer.organizationList.length) {
      let org = organizationReducer.organizationList[0];
      this.setState({
        orgName: org.name,
      });
      const { id, name, displayName, profilePic } = org;
      const orgDetails = {
        id,
        name,
        displayName,
        profilePic,
      };
      // await localStorage.setItem("orgDetails", JSON.stringify(orgDetails));
      await localStorage.setItem("orgDetails", JSON.stringify(org));
    } else {
      this.setState({ orgName: email });
    }
    this.timer = setInterval(() => {
      this.setState((prevState) => {
        if (prevState.selectedImage === this.state.images[0]) {
          return {
            selectedImage: this.state.images[1],
          };
        } else {
          return {
            selectedImage: this.state.images[0],
          };
        }
      });
    }, 4000);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  toggleLogoMenu = () => {
    this.setState({
      dropDownOpen: !this.state.dropDownOpen,
    });
  };

  setProfileImage = (data) => {
    const newImage = this.state.images.slice();
    newImage[1] = data.profilePic;
    if (newImage[1].length > 0) this.setState({ images: newImage });
  };

  setOrganization = async (data) => {
    const { id, name, displayName, profilePic } = data;
    const orgDetails = {
      id,
      name,
      displayName,
      profilePic,
    };
    this.setState({ orgName: name });
    await localStorage.setItem("orgDetails", JSON.stringify(data));
    // this.props.history.push(window.location.pathname);
    // Temp redirect to create

    this.props.history.push("/dashboard/create");
  };

  renderMyOrganizationList = () => {
    const { organizationReducer, userReducer } = this.props;
    const { myOrganizationList } = organizationReducer;
    const { user } = userReducer;
    if (myOrganizationList && myOrganizationList.length > 0)
      return (
        <ul className="dropdown-menu">
          <li
            onClick={() => {
              localStorage.removeItem("orgDetails");
              const data = { profilePic: fevicon };
              this.setProfileImage(data);
              this.setState({ orgName: user.email });
              this.props.history.push(window.location.pathname);
            }}
          >
            {user ? user.email : this.state.orgName}
          </li>
          {myOrganizationList.map((dropdownData) => (
            <li
              key={dropdownData.id}
              onClick={() => {
                this.setProfileImage(dropdownData);
                this.setOrganization(dropdownData);
                this.props.history.push(window.location.pathname);
              }}
            >
              {dropdownData.profilePic ? (
                <img src={dropdownData.profilePic} alt="profile pic" />
              ) : (
                <img src={fevicon} alt="profile pic" />
              )}
              {dropdownData.name}
            </li>
          ))}
        </ul>
      );
    return null;
  };

  checkChromeExtension = () => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            this.notificationPopUp();
          }
        }
      );
    } catch (error) {
      this.notificationPopUp();
      console.log("error ", error);
    }
  };

  notificationPopUp() {
    Store.addNotification({
      title: "Note: ",
      message:
        "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before creating/using skills.",
      type: "warning",
      insert: "top",
      container: "top-right",
      dismiss: {
        duration: 5000,
        onScreen: true,
      },
    });
    window.setTimeout(function () {
      window.open(
        `https://chrome.google.com/webstore/detail/techforce-ide-extension/${process.env.REACT_APP_CHROME_TAB_ID}`,
        "_blank"
      );
    }, 5000);
  }
  connectDeviceToggle(status) {
    this.setState({
      connectDevice: status,
    });
  }

  stepOneToggle(status) {
    this.setState({
      stepOne: status,
    });
  }
  stepTwoToggle(status) {
    this.setState({
      stepTwo: status,
      // stepOne: false,
    });
  }
  stepThreeToggle(status) {
    this.setState({
      stepThree: status,
      stepTwo: false,
    });
  }
  stepFourToggle(status) {
    this.setState({
      stepFour: status,
      stepThree: false,
    });
  }
  stepFiveToggle(status) {
    this.setState({
      stepFive: status,
      stepFour: false,
    });
  }
  superWindowDeviceNameToggle(deviceName) {
    this.setState({
      superWindowDeviceName: deviceName,
    });
  }

  onChange = async (e) => {
    this.setState({
      team: { ...this.state.team, [e.target.name]: e.target.value },
    });

    if (e.target.name == "name" && e.target.value.length > 3) {
      const result = await this.props.validateOrganization({
        name: e.target.value,
      });
      if (result.status) {
        this.setState({ canCreateTeam: true, teamError: "" });
      } else {
        this.setState({ canCreateTeam: false, teamError: result.err });
      }
    }
  };
  validate = () => {
    let createTeam = true;
    for (const [key, value] of Object.entries(!this.state.team)) {
      if (value == "") {
        createTeam = false;
      }
    }

    if (createTeam && this.state.canCreateTeam) {
      this.setState({
        isCreatingTeam: true,
      });
      // $("#pricing").click();
      this.createTeam();
    } else {
      if (!this.state.createTeam) {
        this.props.notify("error", "Please fill all the fields");
      }
      if (!this.state.canCreateTeam) {
        this.props.notify("error", "Team Name already exists !");
      }
    }
  };
  createTeam = async () => {
    try {
      let results;
      results = await this.props.createOrganization(this.state.team);
      if (results) {
        this.setState({
          team: {
            name: "",
            //email: "",
            description: "",
          },
          isCreatingTeam: false,
          createTeam: false,
          teamError: "",
        });
        $("button.close").click();
        this.props.getOrganizations();
      } else {
        $("button.close").click();
        this.setState({
          team: {
            name: "",
            //email: "",
            description: "",
          },
          isCreatingTeam: false,
          createTeam: false,
          teamError: "",
        });
      }
    } catch (err) {}

    // else {
    //   this.props.notify("error", "Please fill all the fields")
    // }
  };
  render() {
    var currentActiveTab =
      this.props && this.props.skillReducer && this.props.skillReducer.isActive;
    let notified = this.props.notifications.length
      ? this.props.notifications.length
      : 0;

    return (
      <div className={this.props?.appReducer?.minMode ? "fixed-bar active" : "fixed-bar"}>
        <ReactNotifications />
        {/* <div className="logo-dash sidebar-dropdown">
          <div className="drop-content dropdown">
            <div className="logo-dropdown" data-toggle="dropdown">
              <img
                src={this.state.selectedImage}
                className="primary-logo sidebar-logo"
              />
              <marquee scrollamount="2">
                <p className="mn-text">{this.state.orgName}</p>
              </marquee>
              <hr className="arrow-border" />
              <div className="arrow-down-click">
                <img height={13} src={dropdown} className="arrow-dropdown" />
              </div>
            </div>
            {this.renderMyOrganizationList()}
          </div>
        </div> */}

        <div
          className= "logo-dropdown"
          style={{ cursor: "pointer" }}
          data-toggle="dropdown"
        >
          <img
            src={this.state.selectedImage}
            className={this.props?.appReducer?.minMode ? "primary-logo sidebar-logo active" :"primary-logo sidebar-logo"}
            alt=""
            onClick={() => {
              this.props.history.push("/dashboard/create");
              this.props.changeActiveTab("Create");
              this.props.changeMode();
            }}
          />
        </div>

        <div className="menu-list">
          <ul>
            {process.env.REACT_APP_SHOWMYTASK === "true" ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "SearchArea"
                      ? "active"
                      : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "SearchArea" })
                  }
                >
                  <Link to="/dashboard/search">
                    <div
                      className="menu-icon"
                      onClick={this.checkChromeExtension}
                    >
                      <div className="mn-icon super-menu">
                        <img src={superMenu} alt="superMenu" />
                      </div>
                      <p className="mn-text">Super</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )}

            {/* Teams */}

            <li
              className={currentActiveTab === "Team" ? "active" : ""}
              id="create-howto"
              // onClick={() => this.props.changeActiveTab("Team")}
              data-toggle="modal"
              data-target="#teamModal"
            >
              <div className="menu-icon">
                <div className="mn-icon">
                  <img src={plus} alt="Create how to" />
                </div>
                <p className="mn-text">Team</p>
              </div>
            </li>

            {/* <li
              className={
                this.state.enableActiveTheme === "MySkills" ? "active" : ""
              }
              onClick={() => this.setState({ enableActiveTheme: "MySkills" })}
            >
              <Link to="/dashboard/skills">
                <div className="menu-icon">
                  <div className="mn-icon">
                    <img src={skills} alt="skills" />
                  </div>
                  <p className="mn-text">My Skills</p>
                </div>
              </Link>
            </li> */}
            {/* {process.env.REACT_APP_SHOWMYTASK === "true" ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "MyTasks" ? "active" : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "MyTasks" })
                  }
                >
                  <Link to="/dashboard/tasks">
                    <div className="menu-icon">
                      <div className="mn-icon">
                        <img src={task} alt="task" />
                      </div>
                      <p className="mn-text">My Tasks</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )}
            {process.env.REACT_APP_SHOWMYTASK === "true" ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "Knowledgebase"
                      ? "active"
                      : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "Knowledgebase" })
                  }
                >
                  <Link to="/dashboard/knowledge">
                    <div className="menu-icon">
                      <div className="mn-icon">
                        <img src={bookmark} alt="bookmark" />
                      </div>
                      <p className="mn-text">My Notes</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )} */}
            {/* <React.Fragment>
              <li>
                <span
                  onClick={() =>
                    this.setState({
                      connectDevice: !this.state.connectDevice,
                    })
                  }
                >
                  <div className="menu-icon">
                    <p className="mn-text">Get Super For</p>
                    <div className="mn-icon">
                      <img
                        src={windowsIcon}
                        style={{ width: "15px" }}
                        alt="market"
                      />
                    </div>
                  </div>
                </span>
              </li>
            </React.Fragment> */}
          </ul>
          {this.state.connectDevice && (
            <ConnectDevice
              stepOneToggle={(status) => {
                this.stepOneToggle(status);
              }}
              connectDeviceToggle={(status) => {
                this.connectDeviceToggle(status);
              }}
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              connectDevice={this.state.connectDevice}
              superWindowDeviceName={this.state.superWindowDeviceName}
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepThree={this.state.stepThree}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepFour={this.state.stepFour}
            />
          )}
          {this.state.stepOne && (
            <StepOne
              stepOneToggle={(status) => {
                this.stepOneToggle(status);
              }}
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              stepOne={this.state.stepOne}
            />
          )}
          {this.state.stepTwo && (
            <StepTwo
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepTwo={this.state.stepTwo}
            />
          )}
          {this.state.stepThree && (
            <StepThree
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepThree={this.state.stepThree}
            />
          )}
          {this.state.stepFour && (
            <StepFour
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepFour={this.state.stepFour}
              superWindowDeviceNameToggle={(deviceName) => {
                this.superWindowDeviceNameToggle(deviceName);
              }}
            />
          )}
          {this.state.stepFive && <StepFive stepFive={this.state.stepFive} />}
          {/* <ul className="bottom-menu">          
          </ul> */}
        </div>
        <div className="avatar-notify">
          <ul className="av-not">
            {/* <li
              className={
                this.state.enableActiveTheme === "SkillsStore" ? "active" : ""
              }
              onClick={() =>
                this.setState({ enableActiveTheme: "SkillsStore" })
              }
              style={{ marginBottom: "50px" }}
            >
              <Link to="/dashboard/skill-store/automation-skills">
                <div className="menu-icon">
                  <div className="mn-icon">
                    <img src={market} alt="market" />
                  </div>
                  <p className="mn-text">
                    Super
                    <br />
                    Skills
                  </p>
                </div>
              </Link>
            </li> */}
            <li>
              {/* <Link to="/notifications"> */}
              <div>
                <span
                  id="notify-tab"
                  onClick={(e) => this.props.enableNotify(true)} 
                >
                  <div className="menu-icon">
                    <div className="mn-icon">
                      <span className="notify-status">{notified}</span>
                      <img
                        src={notifygold}
                        alt="notify"
                        style={{ marginLeft: "3px" }}
                      />
                    </div>
                  </div>
                </span>
              </div>
              {/* </Link> */}
            </li>
            <li
              className={currentActiveTab === "Settings" ? "active" : ""}
              onClick={() => this.props.changeActiveTab("Settings")}
            >
              <Link
                // to="/settings/myprofile-settings/my-profile"
                to="/settings/myprofile-settings/account-setting"
              >
                <span id="login">
                  <div className="avatar-icon">
                    {this.props.userReducer.user !== null &&
                    this.props.userReducer.user.profilePic ? (
                      <img
                        src={this.props.userReducer.user.profilePic}
                        alt="Avatar"
                      />
                    ) : (
                      <img src={avatar} alt="Avatar" />
                    )}
                  </div>
                </span>
              </Link>
            </li>
          </ul>
        </div>

        <div
          id="teamModal"
          className="modal fade crt-skill"
          role="dialog"
          data-backdrop="static"
          data-keyboard="false"
        >
          <div className="modal-dialog">
            <div className="modal-content crt-content">
              <div className="modal-header">
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  onClick={() =>
                    this.setState({
                      team: {
                        name: "",
                        description: "",
                        teamError: "",
                        isCreatingTeam: false,
                      },
                      teamError: "",
                    })
                  }
                >
                  &times;
                </button>
                <h4 className="modal-title">Create New Team</h4>
              </div>
              <div className="modal-body">
                <div className="form-contain">
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Team Name</span>
                      <input
                        type="text"
                        name="name"
                        placeholder="Enter Team Name"
                        value={this.state.team.name}
                        onChange={this.onChange}
                      />
                      <span style={{ float: "right", color: "red" }}>
                        {this.state.teamError}
                      </span>
                    </div>
                  </div>
                  {/* <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Billing Email</span>
                      <input
                        type="email"
                        name="email"
                        placeholder="Enter"
                        value={this.state.team.email}
                        onChange={this.onChange}
                      />
                    </div>
                  </div> */}
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Description</span>
                      <textarea
                        name="description"
                        placeholder="Enter Description"
                        spellcheck="false"
                        value={this.state.team.description}
                        onChange={this.onChange}
                      ></textarea>
                    </div>
                  </div>
                  <div className="frm-btns">
                    <button
                      className="btn-outline"
                      data-dismiss="modal"
                      onClick={() =>
                        this.setState({
                          team: {
                            name: "",
                            description: "",
                            teamError: "",
                            isCreatingTeam: false,
                          },
                          teamError: "",
                        })
                      }
                    >
                      Cancel
                    </button>

                    <button
                      className="primary-btn text-center"
                      onClick={this.validate}
                    >
                      {this.state.isCreatingTeam ? (
                        <div class="sp sp-circle text-light"></div>
                      ) : (
                        "Create"
                      )}

                      {/* <button
                        className="primary-btn"
                        id="pricing"
                        data-toggle="modal"
                        data-target="#pricingModal"
                        data-dismiss="modal"
                        style={{ display: "none" }}
                      ></button> */}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="pricingModal" className="modal fade crt-skill" role="dialog">
          <div className="modal-dialog modal-lg">
            <div className="modal-content crt-content">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <section className="pricing">
                  <div className="pricing__header">
                    <h1 className="pricing__title">Pricing plans</h1>
                    <h5 className="pricing__subtitle">
                      First 30 days absolutely{" "}
                      <span className="accent-1">free</span> for any plan, no
                      credit card required to get started.
                    </h5>
                    <div className="plan-duration">
                      <div className="plan-duration__text plan-duration--active">
                        Monthly
                      </div>
                      <div className="plan-duration__toggle">
                        <div className="plan-duration__toggle-ball"></div>
                      </div>
                      <div className="plan-duration__text">Yearly</div>
                    </div>
                  </div>
                  <article className="plans">
                    <div className="plans__list">
                      <article className="plan__item">
                        <div className="plan__header">
                          <h3 className="plan__title">Freelance</h3>
                          <h1 className="plan__price">5</h1>
                        </div>

                        <ul className="plan__feature-list">
                          <li className="plan__feature-item">
                            <span className="accent-2">5GB</span> file storage
                          </li>
                          <li className="plan__feature-item">File manager</li>
                          <li className="plan__feature-item">
                            Upgrade any time
                          </li>
                        </ul>

                        <a
                          href="#"
                          onClick={this.createTeam}
                          className="plan__cta-link "
                        >
                          Get Started
                        </a>
                      </article>
                      <article className="plan__item plan__item--active">
                        <div className="plan__header">
                          <h3 className="plan__title">Teams</h3>
                          <h1 className="plan__price">20</h1>
                        </div>
                        <ul className="plan__feature-list">
                          <li className="plan__feature-item">
                            <span className="accent-2">20GB</span> file storage
                          </li>
                          <li className="plan__feature-item">
                            Collaboration mode
                          </li>
                          <li className="plan__feature-item">
                            Up to <span className="accent-2">10</span> users
                          </li>
                          <li className="plan__feature-item">
                            <span className="accent-2">Trello</span> integration
                          </li>
                        </ul>

                        <a
                          href="#"
                          onClick={this.createTeam}
                          className="plan__cta-link plan__cta-link--active"
                        >
                          Get Started
                        </a>
                      </article>
                      <article className="plan__item">
                        <div className="plan__header">
                          <h3 className="plan__title">Enterprise</h3>
                          <h1 className="plan__price">80</h1>
                        </div>

                        <ul className="plan__feature-list">
                          <li className="plan__feature-item">
                            <span className="accent-2">Unlimited</span> storage
                          </li>
                          <li className="plan__feature-item">
                            Admin dashboard
                          </li>
                          <li className="plan__feature-item">
                            <span className="accent-2">Unlimited</span> users
                          </li>
                          <li className="plan__feature-item">All features</li>
                        </ul>

                        <a
                          href="#"
                          onClick={this.createTeam}
                          className="plan__cta-link"
                        >
                          Get Started
                        </a>
                      </article>
                    </div>
                    <div className="plans__special-offer">
                      <p>
                        <strong>Limited offer: </strong> Save 20% on anuual
                        plans. Get the coupon <a href="#">here</a>
                      </p>
                    </div>
                  </article>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  organizationReducer: state.organizationReducer,
  userReducer: state.userReducer,
  notifications: state.appReducer.notifications,
  notified: state.appReducer.notified,
  skillReducer: state.skillReducer,
  appReducer: state.appReducer
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getOrganizations,
    loadNotifications,
    changeActiveTab,
    createOrganization,
    notify,
    setCurrentOrganization,
    validateOrganization,
    changeMode,
  })
)(NavBar);
