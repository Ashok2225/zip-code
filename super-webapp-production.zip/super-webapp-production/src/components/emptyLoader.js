import React from "react";
import emptyIcon from "../images/empty.png";

function Loader(props) {
  return (
    <div className="empty-skill" style={{ ...props.root }}>
      <img src={emptyIcon} alt="" style={{ ...props.styles }} />
      <h3>{props.message}</h3>
    </div>
  );
}

export default Loader;
