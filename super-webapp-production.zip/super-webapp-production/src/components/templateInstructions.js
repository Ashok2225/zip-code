import { React, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import mask from "../images/modal-icons/bg-mask.png";
import playBtn from "../images/modal-icons/play-btn.png";
import bulbIcon from "../images/modal-icons/bulb.png";
import infoIcon from "../images/info-new.png";
const TemplateInstructions = (props) => {
  const [openInstruction, setOpenInstruction] = useState(true);
  const checkSkill = useSelector((state) => state.skillReducer.trainDraft);

  useEffect(() => {
    if (checkSkill && checkSkill.TEMPLATE === "Automation") {
      if (checkSkill?.RAW_DATA?.actions) {
        setOpenInstruction(false);
      }
    } else {
      if (checkSkill && checkSkill.RAW_DATA !== null) {
        setOpenInstruction(false);
      }
    }
  }, []);
  return (
    <div>
      <div className="instruct-pr">
        <div
          className="intsruct-click"
          onClick={(e) => setOpenInstruction(true)}
        >
          <div className="inst-ico">
            <img src={bulbIcon} />
          </div>
          {/* <p>Instructions</p> */}
          <h5>Getting Started</h5>
        </div>

        {openInstruction === true ? (
          <div className="instruct-b-outer">
            <button
              type="button"
              class="close"
              onClick={(e) => setOpenInstruction(false)}
            >
              ×
            </button>
            <div
              className="instruct-block"
              style={{ backgroundImage: `url(${mask})` }}
            >
              <h5>Getting Started</h5>

              {displayInstruction(props.state)}
              {props.state === "UserDocumentation" && (
                <a
                  className="play-instruct"
                  href=" https://youtu.be/98048qIggVI"
                  target={"_blank"}
                >
                  <img src={playBtn} />
                  <p>Watch</p>
                </a>
              )}
              {props.state === "In-App Walkthrough" && (
                <a
                  className="play-instruct"
                  href="https://www.youtube.com/watch?v=SfjmbGXYusE"
                  target={"_blank"}
                >
                  <img src={playBtn} />
                  <p>Watch</p>
                </a>
              )}

              <div className="bulb-instruct">
                <img src={bulbIcon} />
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

const displayInstruction = (template) => {
  switch (template) {
    case "Import Data from Spreadsheet to Web App":
      return automationTempInstruction();
    case "In-App Walkthrough":
      return inAppWalkthroughInstruction();

    case "UserDocumentation":
      return documentTempInstruction();
    case "UserOnboarding":
      return userOnboardingInstruction();
    case "WebAutomation":
      return webAutomationInstruction();
    default:
      return defaultInstruction();
  }
};

const documentTempInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>Carry out all steps that need to be part of your documentation.</p>
    </li>
    <li>
      <span>02</span>
      <p>
        Super Assistant displays default tool tip messages for every captured
        step. You can modify these messages suitably.
      </p>
    </li>
    <li>
      <span>03</span>
      <p>
        Click on + between steps to insert additional steps. You can record or
        add a step manually.
      </p>
    </li>
    <li>
      <span>04</span>
      <p>Click on Export to download the final document.</p>
    </li>
  </ul>
);

const inAppWalkthroughInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>
        Carry out all steps that need to be part of your In-App Walkthrough.
      </p>
    </li>
    <li>
      <span>02</span>
      <p>
        Super Assistant displays default tool tip messages for every step. The
        default choice being AUTO, you can modify the choice to MANUAL as
        needed.
      </p>
    </li>
    <li>
      <span>03</span>
      <p>
        It is recommended not to capture steps which include login credentials.
      </p>
    </li>
    <li>
      <span>04</span>
      <p>
        Click on + between steps to insert additional steps. You can record or
        add a step manually.
      </p>
    </li>
  </ul>
);

const userOnboardingInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>
        Carry out all steps that need to be part of your User Onboarding
        Journey.
      </p>
    </li>
    <li>
      <span>02</span>
      <p>
        Super Assistant displays default tool tip messages for every step. The
        default choice being AUTO, you can modify the choice to MANUAL as
        needed.
      </p>
    </li>
    <li>
      <span>03</span>
      <p>
        It is recommended not to capture steps which include login credentials.
      </p>
    </li>
    <li>
      <span>04</span>
      <p>
        Click on + between steps to insert additional steps. You can record or
        add a step manually.
      </p>
    </li>
  </ul>
);

const webAutomationInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>Carry out all steps that need to be part of your Web Automation.</p>
    </li>
    <li>
      <span>02</span>
      <p>It is recommended not to capture steps which include login credentials.</p>
    </li>
    <li>
      <span>03</span>
      <p>Click on + between steps to insert additional steps.</p>
    </li>

    <li>
      <span>03</span>
      <p>
        It is recommended not to capture steps which include login credentials.
      </p>
    </li>
  </ul>
);

const automationTempInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>
        Browse and upload your spreadsheet from local drive or paste the URL of
        your online spreadsheet.
      </p>
    </li>
    <li>
      <span>02</span>
      <p>
        Currently, Super Assistant does not accept password protected
        spreadsheets.
      </p>
    </li>
    <li>
      <span>03</span>
      <p>
        Super Assistant considers the first row of the spreadsheet as column
        headings. Do ensure to have headings for every column.
      </p>
    </li>
    <li>
      <span>04</span>
      <p>
        At least one row of data is needed in the spreadsheet for creating the
        skill.
      </p>
    </li>
    <li>
      <span>05</span>
      <p>
        Sheet Name is case sensitive. It must match with the sheet name in the
        spreadsheet.
      </p>
    </li>
    <li>
      <span>06</span>
      <p>
        Super Assistant can be trained by entering one row of data into the web
        app, using the unique SHOW feature.
      </p>
    </li>
    <li>
      <span>07</span>
      <p>
        On Mapper Screen, connect spreadsheet column names with the
        corresponding web app data fields.
      </p>
    </li>
  </ul>
);

const defaultInstruction = () => (
  <ul className="ist-block">
    <li>
      <span>01</span>
      <p>Carry out all steps that need to be part of your Automation.</p>
    </li>
    <li>
      <span>02</span>
      <p>
        It is recommended not to capture steps which include login credentials.
      </p>
    </li>
    <li>
      <span>03</span>
      <p>Click on + between steps to insert additional steps.</p>
    </li>

    <li>
      <span>03</span>
      <p>
        It is recommended not to capture steps which include login credentials.
      </p>
    </li>
  </ul>
);

export default TemplateInstructions;
