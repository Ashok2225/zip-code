/*global chrome*/
import React, { Component } from "react";
// import { VscDesktopDownload } from 'react-icons/fa';
import fevicon from "../images/fevicon.png";
import dropdown from "../images/dropdown-image.png";
import skills from "../images/skills.png";
import task from "../images/task.png";
import bookmark from "../images/bookmark.png";
import market from "../images/market.png";
import plus from "../images/plus.png";
import notifygold from "../images/notify-gold.png";
import avatar from "../images/avatar.png";
import schedule from "../images/schedule.png";
import windowsIcon from "../images/windows.png";
import superMenu from "../images/super-menu.png";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { withRouter } from "react-router";
import { compose } from "redux";
import { getMyOrganizations } from "../redux/actions/organizationAction";
import { ReactNotifications, Store } from "react-notifications-component";

import "react-notifications-component/dist/theme.css";
import ConnectDevice from "../containers/dashboard/ConnectDevice";
import { Button } from "reactstrap";
import StepTwo from "../containers/dashboard/ConnectDevice/components/StepTwo";
import StepThree from "../containers/dashboard/ConnectDevice/components/StepThree";
import StepFour from "../containers/dashboard/ConnectDevice/components/StepFour";
import StepFive from "../containers/dashboard/ConnectDevice/components/StepFive";
import StepOne from "../containers/dashboard/ConnectDevice/components/StepOne";

import { loadNotifications } from "../redux/actions/appActions";
class NavBar extends Component {
  constructor() {
    super();
    this.state = {
      dropDownOpen: false,
      connectDevice: false,
      stepOne: false,
      stepTwo: false,
      stepThree: false,
      stepFour: false,
      stepFive: false,
      superWindowDeviceName: "",
      enableActiveTheme: "Create",
      images: [fevicon, fevicon],
      // selectedImage: fevicon,
      selectedImage: JSON.parse(localStorage.getItem("orgDetails"))
        ? JSON.parse(localStorage.getItem("orgDetails")).profilePic
        : fevicon,
      orgName: JSON.parse(localStorage.getItem("orgDetails"))
        ? JSON.parse(localStorage.getItem("orgDetails")).name
        : "",
      // : "Techforce",
    };
  }

  async componentDidMount() {
    this.props.loadNotifications(this.props.user);

    var path = window.location.href;
    if (path.match("/create")) {
      this.setState({
        enableActiveTheme: "Create",
      });
    }
    if (path.match("/knowledge")) {
      this.setState({
        enableActiveTheme: "Knowledgebase",
      });
    }

    if (
      path.match("/skills") ||
      path.match("/trainSkill") ||
      path.match("/viewSkill")
    ) {
      this.setState({
        enableActiveTheme: "MySkills",
      });
    }

    if (process.env.REACT_APP_SHOWMYTASK === "true") {
      if (path.match("/tasks")) {
        this.setState({
          enableActiveTheme: "MyTasks",
        });
      }
    }

    if (path.match("/search")) {
      this.setState({
        enableActiveTheme: "SearchArea",
      });
    }
    if (path.match("/skill-store")) {
      this.setState({
        enableActiveTheme: "SkillsStore",
      });
    }
    if (path.match("/myprofile-settings")) {
      this.setState({
        enableActiveTheme: "MyProfile",
      });
    }
    await this.props.getMyOrganizations();
    const { userReducer, organizationReducer } = this.props;
    const { email } = userReducer.user;
    if (JSON.parse(localStorage.getItem("orgDetails"))) {
      this.setState({
        orgName: JSON.parse(localStorage.getItem("orgDetails")).name,
      });
    } else if (organizationReducer.myOrganizationList.length) {
      let org = organizationReducer.myOrganizationList[0];
      this.setState({
        orgName: org.name,
      });
      const { id, name, displayName, profilePic } = org;
      const orgDetails = {
        id,
        name,
        displayName,
        profilePic,
      };
      localStorage.setItem("orgDetails", JSON.stringify(org));
    } else {
      this.setState({ orgName: email });
    }

    this.timer = setInterval(() => {
      this.setState((prevState) => {
        if (prevState.selectedImage === this.state.images[0]) {
          return {
            selectedImage: this.state.images[1],
          };
        } else {
          return {
            selectedImage: this.state.images[0],
          };
        }
      });
    }, 4000);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  toggleLogoMenu = () => {
    this.setState({
      dropDownOpen: !this.state.dropDownOpen,
    });
  };

  setProfileImage = (data) => {
    const newImage = this.state.images.slice();
    newImage[1] = data.profilePic;
    if (newImage[1].length > 0) this.setState({ images: newImage });
  };

  setOrganization = async (data) => {
    const { id, name, displayName, profilePic } = data;
    const orgDetails = {
      id,
      name,
      displayName,
      profilePic,
    };
    this.setState({ orgName: name });
    await localStorage.setItem("orgDetails", JSON.stringify(data));
    // this.props.history.push(window.location.pathname);

    // Temp redirect to create
    this.props.history.push("/dashboard/create");
  };

  renderMyOrganizationList = () => {
    const { organizationReducer, userReducer } = this.props;
    const { myOrganizationList } = organizationReducer;
    const { user } = userReducer;
    if (myOrganizationList && myOrganizationList.length > 0)
      return (
        <ul className="dropdown-menu">
          <li
            onClick={() => {
              localStorage.removeItem("orgDetails");
              const data = { profilePic: fevicon };
              this.setProfileImage(data);
              this.setState({ orgName: user.email });
              this.props.history.push(window.location.pathname);
            }}
          >
            {user ? user.email : this.state.orgName}
          </li>
          {myOrganizationList.map((dropdownData) => (
            <li
              key={dropdownData.id}
              onClick={() => {
                this.setProfileImage(dropdownData);
                this.setOrganization(dropdownData);
                this.props.history.push(window.location.pathname);
              }}
            >
              {dropdownData.profilePic ? (
                <img src={dropdownData.profilePic} alt="profile pic" />
              ) : (
                <img src={fevicon} alt="profile pic" />
              )}
              {dropdownData.name}
            </li>
          ))}
        </ul>
      );
    return null;
  };

  checkChromeExtension = () => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            this.notificationPopUp();
          }
        }
      );
    } catch (error) {
      this.notificationPopUp();
      console.log("error ", error);
    }
  };

  notificationPopUp() {
    Store.addNotification({
      title: "Note: ",
      message:
        "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before creating/using skills.",
      type: "warning",
      insert: "top",
      container: "top-right",
      dismiss: {
        duration: 5000,
        onScreen: true,
      },
    });
    window.setTimeout(function () {
      window.open(
        `https://chrome.google.com/webstore/detail/techforce-ide-extension/${process.env.REACT_APP_CHROME_TAB_ID}`,
        "_blank"
      );
    }, 5000);
  }
  connectDeviceToggle(status) {
    this.setState({
      connectDevice: status,
    });
  }

  stepOneToggle(status) {
    this.setState({
      stepOne: status,
    });
  }
  stepTwoToggle(status) {
    this.setState({
      stepTwo: status,
      // stepOne: false,
    });
  }
  stepThreeToggle(status) {
    this.setState({
      stepThree: status,
      stepTwo: false,
    });
  }
  stepFourToggle(status) {
    this.setState({
      stepFour: status,
      stepThree: false,
    });
  }
  stepFiveToggle(status) {
    this.setState({
      stepFive: status,
      stepFour: false,
    });
  }
  superWindowDeviceNameToggle(deviceName) {
    this.setState({
      superWindowDeviceName: deviceName,
    });
  }
  render() {
    let notified = this.props.notifications.length
      ? this.props.notifications.length
      : 0;
    let email =
      this.props &&
      this.props.userReducer.user &&
      this.props.userReducer.user.email
        ? this.props.userReducer.user.email
        : null;
    return (
      <div className="fixed-bar">
        <ReactNotifications />
        <div className="logo-dash sidebar-dropdown">
          <div className="drop-content dropdown">
            <div className="logo-dropdown" data-toggle="dropdown">
              <img
                src={this.state.selectedImage}
                className="primary-logo sidebar-logo"
              />
              <marquee scrollamount="2">
                <p className="mn-text">{this.state.orgName}</p>
              </marquee>
              <hr className="arrow-border" />
              <div className="arrow-down-click">
                <img height={13} src={dropdown} className="arrow-dropdown" />
              </div>
            </div>
            {this.renderMyOrganizationList()}
          </div>
        </div>

        <div className="menu-list">
          <ul>
            {process.env.REACT_APP_SHOWMYTASK === "true" ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "SearchArea"
                      ? "active"
                      : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "SearchArea" })
                  }
                >
                  <Link to="/dashboard/search">
                    <div
                      className="menu-icon"
                      onClick={this.checkChromeExtension}
                    >
                      <div className="mn-icon super-menu">
                        <img src={superMenu} alt="superMenu" />
                      </div>
                      <p className="mn-text">Super</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )}
            <li
              className={
                this.state.enableActiveTheme === "Create" ? "active" : ""
              }
              id="create-howto"
              onClick={() => this.setState({ enableActiveTheme: "Create" })}
            >
              <Link to="/dashboard/create">
                <div className="menu-icon">
                  <div className="mn-icon">
                    <img src={plus} alt="Create how to" />
                  </div>
                  <p className="mn-text">Create Skill</p>
                </div>
              </Link>
            </li>
            <li
              className={
                this.state.enableActiveTheme === "MySkills" ? "active" : ""
              }
              onClick={() => this.setState({ enableActiveTheme: "MySkills" })}
            >
              <Link to="/dashboard/skills">
                <div className="menu-icon">
                  <div className="mn-icon">
                    <img src={skills} alt="skills" />
                  </div>
                  <p className="mn-text">My Skills</p>
                </div>
              </Link>
            </li>
            {process.env.REACT_APP_ADMIN1 === email ||
            process.env.REACT_APP_ADMIN2 === email ||
            process.env.REACT_APP_ADMIN3 === email ||
            process.env.REACT_APP_ADMIN4 === email ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "MyTasks" ? "active" : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "MyTasks" })
                  }
                >
                  <Link to="/dashboard/tasks">
                    <div className="menu-icon">
                      <div className="mn-icon">
                        <img src={task} alt="task" />
                      </div>
                      <p className="mn-text">My Tasks</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )}
            {process.env.REACT_APP_SHOWMYTASK === "true" ? (
              <>
                <li
                  className={
                    this.state.enableActiveTheme === "Knowledgebase"
                      ? "active"
                      : ""
                  }
                  onClick={() =>
                    this.setState({ enableActiveTheme: "Knowledgebase" })
                  }
                >
                  <Link to="/dashboard/knowledge">
                    <div className="menu-icon">
                      <div className="mn-icon">
                        <img src={bookmark} alt="bookmark" />
                      </div>
                      <p className="mn-text">My Notes</p>
                    </div>
                  </Link>
                </li>
              </>
            ) : (
              ""
            )}
            <React.Fragment>
              <li>
                <span
                  onClick={() =>
                    this.setState({
                      connectDevice: !this.state.connectDevice,
                    })
                  }
                >
                  <div className="menu-icon">
                    <p className="mn-text">Get Super For</p>
                    <div className="mn-icon">
                      <img
                        src={windowsIcon}
                        style={{ width: "15px" }}
                        alt="market"
                      />
                    </div>
                  </div>
                </span>
              </li>
            </React.Fragment>
          </ul>
          {this.state.connectDevice && (
            <ConnectDevice
              stepOneToggle={(status) => {
                this.stepOneToggle(status);
              }}
              connectDeviceToggle={(status) => {
                this.connectDeviceToggle(status);
              }}
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              connectDevice={this.state.connectDevice}
              superWindowDeviceName={this.state.superWindowDeviceName}
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepThree={this.state.stepThree}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepFour={this.state.stepFour}
            />
          )}
          {this.state.stepOne && (
            <StepOne
              stepOneToggle={(status) => {
                this.stepOneToggle(status);
              }}
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              stepOne={this.state.stepOne}
            />
          )}
          {this.state.stepTwo && (
            <StepTwo
              stepTwoToggle={(status) => {
                this.stepTwoToggle(status);
              }}
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepTwo={this.state.stepTwo}
            />
          )}
          {this.state.stepThree && (
            <StepThree
              stepThreeToggle={(status) => {
                this.stepThreeToggle(status);
              }}
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepThree={this.state.stepThree}
            />
          )}
          {this.state.stepFour && (
            <StepFour
              stepFourToggle={(status) => {
                this.stepFourToggle(status);
              }}
              stepFour={this.state.stepFour}
              superWindowDeviceNameToggle={(deviceName) => {
                this.superWindowDeviceNameToggle(deviceName);
              }}
            />
          )}
          {this.state.stepFive && <StepFive stepFive={this.state.stepFive} />}
          {/* <ul className="bottom-menu">          
          </ul> */}
        </div>
        <div className="avatar-notify">
          <ul className="av-not">
            <li
              className={
                this.state.enableActiveTheme === "SkillsStore" ? "active" : ""
              }
              onClick={() =>
                this.setState({ enableActiveTheme: "SkillsStore" })
              }
              style={{ marginBottom: "50px" }}
            >
              <Link to="/dashboard/skill-store/automation-skills">
                <div className="menu-icon">
                  <div className="mn-icon">
                    <img src={market} alt="market" />
                  </div>
                  <p className="mn-text">
                    Super
                    <br />
                    Skills
                  </p>
                </div>
              </Link>
            </li>
            <li>
              {/* <Link to="/notifications"> */}
              <div>
                <span
                  id="notify-tab"
                  onClick={(e) => this.props.enableNotify(true)}
                >
                  <div className="menu-icon">
                    <div className="mn-icon">
                      <span className="notify-status">{notified}</span>
                      <img
                        src={notifygold}
                        alt="notify"
                        style={{ marginLeft: "3px" }}
                      />
                    </div>
                  </div>
                </span>
              </div>
              {/* </Link> */}
            </li>
            <li
              className={
                this.state.enableActiveTheme === "Myprofile" ? "active" : ""
              }
              onClick={() => this.setState({ enableActiveTheme: "MyProfile" })}
            >
              <Link
                // to="/settings/myprofile-settings/my-profile"
                to="/settings/myprofile-settings/account-setting"
              >
                <span id="login">
                  <div className="avatar-icon">
                    {this.props.userReducer.user !== null &&
                    this.props.userReducer.user.profilePic ? (
                      <img
                        src={this.props.userReducer.user.profilePic}
                        alt="Avatar"
                      />
                    ) : (
                      <img src={avatar} alt="Avatar" />
                    )}
                  </div>
                </span>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  organizationReducer: state.organizationReducer,
  userReducer: state.userReducer,
  notifications: state.appReducer.notifications,
  notified: state.appReducer.notified,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getMyOrganizations,
    loadNotifications,
  })
)(NavBar);
