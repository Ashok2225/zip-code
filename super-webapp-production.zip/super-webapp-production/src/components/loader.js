import React from "react";
import loader from "../images/sp-loader.gif";
function Loader(props) {
  return (
    <div className="empty-skill">
      <img src={loader} alt="" style={{ ...props.styles }} />
      <p>{props.message}</p>
    </div>
  );
}

export default Loader;
