import React, { Component } from "react";
import techforceLogo from "../images/tech-logo.png";
import createSkill from "../images/sidebar-new/plus-icon.png";
import mySkills from "../images/sidebar-new/my-skills.png";
import superSkills from "../images/sidebar-new/skill-store.png";
import dropIcon from "../images/sidebar-new/drop-icon.png";
import getSuperImg from "../images/sidebar-new/get-super-img.png";
import settingIcon from "../images/sidebar-new/settings.png";
import myTask from "../images/sidebar-new/my-task.png";
import platformIcon from "../images/sidebar-new/platform-icon.png";
import analyticsIcon from "../images/sidebar-new/analytics.png";
import createTemplateIcon from "../images/sidebar-new/create-template.png";
import scheduleIcon from "../images/sidebar-new/schedule.png";
import StepTwo from "../containers/dashboard/ConnectDevice/components/StepTwo";
import StepThree from "../containers/dashboard/ConnectDevice/components/StepThree";
import StepFour from "../containers/dashboard/ConnectDevice/components/StepFour";
import StepFive from "../containers/dashboard/ConnectDevice/components/StepFive";
import StepOne from "../containers/dashboard/ConnectDevice/components/StepOne";
import close from "../images/close.png";
import ConnectDevice from "../containers/dashboard/ConnectDevice";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import { changeActiveTab } from "../redux/actions/skill";
import {
  getOrganizations,
  setCurrentOrganization,
  getCurrentUser,
} from "../redux/actions/organizationAction";
import {
  downloadExe,
  getDeviceInfoApi,
} from "../containers/dashboard/ConnectDevice/util";
import { getKeycloackToken } from "../redux/actions/auth";
import axios from "axios";
import ReactTooltip from "react-tooltip";
import { changeMode } from "../redux/actions/appActions";
import editIcon from "../images/edit-icon.png";
import { Satellite } from "@material-ui/icons";

class SideBar extends Component {
  constructor() {
    super();
    this.state = {
      connectDevice: false,
      stepOne: false,
      stepTwo: false,
      stepThree: false,
      stepFour: false,
      stepFive: false,
      superWindowDeviceName: "",
      showUpdateModal: false,
      blobUrl: "",
      current_version: "",
      minMode: false,
    };
  }

  async componentDidMount() {
    var results = await this.props.getOrganizations();

    // this.props.setCurrentOrganization(results.data.data[0]);
    if (JSON.parse(localStorage.getItem("orgDetails"))) {
      this.props.setCurrentOrganization(
        JSON.parse(localStorage.getItem("orgDetails"))
      );
    } else {
      this.props.setCurrentOrganization(results.data.data[0]);
    }
    await this.props.getCurrentUser(this.props?.userReducer?.user?.email);
    this.checkUpdates();
  }

  checkUpdates = async () => {
    var sessionRes = await getDeviceInfoApi();
    var newDownload = await downloadExe();

    if (
      sessionRes &&
      sessionRes?.data &&
      sessionRes?.data?.uniqueDevices?.length
    ) {
      let _storedVersion;
      let _versionNumber;
      let deviceList = sessionRes?.data?.uniqueDevices[0];

      let checkOldVersion = deviceList.meta_data.version.includes("v");
      if (checkOldVersion) {
        _storedVersion = deviceList?.meta_data?.version?.split("v");
        _versionNumber = _storedVersion[1];
      } else {
        _versionNumber = deviceList?.meta_data?.version;
      }

      let blobNameExtract = newDownload.data.blobName.split("-");
      let _manipulate =
        blobNameExtract[blobNameExtract.length - 1].split(".exe");
      let blobVersionExtract = _manipulate[0];
      if (_versionNumber !== blobVersionExtract) {
        this.setState({
          showUpdateModal: true,
          blobUrl: newDownload.data.url,
          current_version: blobVersionExtract,
        });
      }
    }
  };

  connectDeviceToggle(status) {
    this.setState({
      connectDevice: status,
    });
  }

  stepOneToggle(status) {
    this.setState({
      stepOne: status,
    });
  }
  stepTwoToggle(status) {
    this.setState({
      stepTwo: status,
      // stepOne: false,
    });
  }
  stepThreeToggle(status) {
    this.setState({
      stepThree: status,
      stepTwo: false,
    });
  }
  stepFourToggle(status) {
    this.setState({
      stepFour: status,
      stepThree: false,
    });
  }
  stepFiveToggle(status) {
    this.setState({
      stepFive: status,
      stepFour: false,
    });
  }
  superWindowDeviceNameToggle(deviceName) {
    this.setState({
      superWindowDeviceName: deviceName,
    });
  }

  changerOrganization = async (org) => {
    this.props.setCurrentOrganization(org);
    const { id, name, displayName, profilePic } = org;
    const orgDetails = {
      id,
      name,
      displayName,
      profilePic,
    };
    await localStorage.setItem("orgDetails", JSON.stringify(org));
    // this.props.history.push(window.location.pathname);
    // Temp redirect to create

    this.props.history.push("/dashboard/create");
    this.props.changeActiveTab("Create");
    await this.props.getCurrentUser(this.props?.userReducer?.user?.email);
  };

  // checkOrganizationCondition = async (id, currentUser) => {
  //   try {
  //     let token = await getKeycloackToken();
  //     var config = {
  //       method: "get",
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //       },
  //       url: `${process.env.REACT_APP_BOT_SERVICE_URL}/organization/retrieveMembersFromOrganization?organization_id=${id}`,
  //     };
  //     const result = await axios(config);

  //     return result.data.data.results.map((item) => {
  //       if (item.email === currentUser) {
  //         return item.disabled;
  //       }
  //     });
  //   } catch (err) {
  //     return "";
  //   }
  //   // return "";
  // };
  render() {
    const { organizationList, currentOrganization } =
      this.props.organizationReducer;
    var currentUser =
      this.props &&
      this.props.userReducer &&
      this.props.userReducer.user &&
      this.props.userReducer.user.email
        ? this.props.userReducer.user.email
        : null;
    var currentActiveTab =
      this.props && this.props.skillReducer && this.props.skillReducer.isActive;
    return (
      <div
        className={
          this.props?.appReducer?.minMode
            ? "task-list sidebar-global active"
            : "task-list sidebar-global"
        }
        // onClick={this.changeMode() }
        style={{
          display:
            currentActiveTab === "Team" || currentActiveTab === "Settings"
              ? "none"
              : "",
        }}
      >
        <div
          className="flex-title"
          onClick={() => {
            this.props.history.push("/dashboard/create");
          }}
        >
          <img src={techforceLogo} className="logo-sidebar" />
          {this.props?.appReducer?.minMode ? (
            <div
              className={
                this.props?.appReducer?.minMode ? "mb-close" : "mb-close"
              }
              onClick={() => {
                this.props.changeMode(false);
              }}
            >
              {/* <img src={close} alt="" /> */}
            </div>
          ) : null}
        </div>
        {/* <div className="team-admin">
          <button className="btn btn-default"><img src={settingIcon} /> Team Admin</button>
        </div> */}

        <div class="dropdown team-admin">
          <button
            class="btn btn-default dropdown-toggle"
            type="button"
            data-toggle="dropdown"
          >
            <div className="team-name">
              <img
                src={settingIcon}
                onClick={(e) => {
                  if (this.props.organizationReducer.currentOrganization.id) {
                    this.props.changeActiveTab("Settings");
                    this.props.history.push({
                      pathname: `/settings/teams/${this.props.organizationReducer.currentOrganization.id}/people`,
                    });
                    e.stopPropagation();
                  }
                }}
                alt=""
                data-tip="Team Settings"
              />
              <ReactTooltip place="top" type="dark" effect="solid" />
              {organizationList.map((org, index) => {
                if (!org.disabled) {
                  if (org.name === currentOrganization.name) {
                    this.props.setCurrentOrganization("");
                    localStorage.setItem("orgDetails", JSON.stringify(""));
                    return "";
                  }
                  // else {
                  //   return currentOrganization?.name;
                  // }
                }
              })}
              {currentOrganization?.displayName
                ? currentOrganization.displayName + " " + "Team"
                : currentOrganization.name + " " + "Team"}
            </div>
            <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            {organizationList.map((org, index) => {
              if (org.disabled) {
                return (
                  <li
                    style={{
                      cursor: "pointer",
                      textTransform: "capitalize",
                      // pointerEvents: !org.disabled && "none",
                    }}
                    onClick={() => this.changerOrganization(org)}
                  >
                    {org.displayName ? org.displayName : org.name}
                    {org.isAdmin ? (
                      <span
                        onClick={(e) => {
                          if (
                            this.props.organizationReducer.currentOrganization
                              .id
                          ) {
                            this.props.changeActiveTab("Settings");
                            this.props.history.push({
                              pathname: `/settings/teams/${org.id}/people`,
                            });
                            e.stopPropagation();
                          }
                        }}
                        className="edit-name"
                      >
                        <img src={editIcon} />
                      </span>
                    ) : null}
                  </li>
                );
              }
            })}
          </ul>
        </div>

        <div className="create">
          {/* <button className="btn btn-default"><img src={settingIcon} /> Team Admin</button> */}
          <button
            className={
              this.props?.appReducer?.minMode
                ? "btn btn-primary"
                : "btn btn-primary"
            }
            onClick={() => {
              this.props.changeActiveTab("Create");
              this.props.history.push("/dashboard/create");
              this.props.changeMode(false);
            }}
          >
            <span className="plus-white">+</span> Create Skill
          </button>
        </div>

        <ul className="list-group menu-scroll scrollable">
          {/* Accordion Starts */}
          <div className="panel-group panel-menu" id="accordion">
            <div className="panel panel-default">
              <div className="panel-heading">
                <h4 className="panel-title">
                  {currentOrganization.isAdmin ? (
                    <a
                      className={
                        this.props?.appReducer?.minMode
                          ? "list-group-item flex-list-drop"
                          : `list-group-item flex-list-drop ${
                              currentActiveTab === "Published" ||
                              currentActiveTab === "Draft"
                                ? "active"
                                : ""
                            }`
                      }
                      data-toggle="collapse"
                      data-parent="#accordion"
                      href="#collapse1"
                      onClick={() => {
                        this.props.history.push(
                          "/dashboard/analytics/" + currentOrganization.id
                        );
                        this.props.changeMode(false);
                      }}
                    >
                      <div className="left-list-menu">
                        <img src={mySkills} /> <span>My Skills</span>
                      </div>{" "}
                      <img className="drop-icon" src={dropIcon} />
                    </a>
                  ) : (
                    <a
                      className={`list-group-item flex-list-drop ${
                        currentActiveTab === "Published" ||
                        currentActiveTab === "Draft"
                          ? "active"
                          : ""
                      }`}
                      data-toggle="collapse"
                      data-parent="#accordion"
                      href="#collapse1"
                    >
                      <div className="left-list-menu">
                        <img src={mySkills} /> <span>My Skills</span>
                      </div>{" "}
                      <img className="drop-icon" src={dropIcon} />
                    </a>
                  )}
                </h4>
              </div>
              <div id="collapse1" className="panel-collapse collapse">
                <div className="panel-body drop-skills">
                  <ul className="list-group ">
                    <li
                      className={
                        this.props?.appReducer?.minMode
                          ? "list-group-item "
                          : `list-group-item ${
                              currentActiveTab === "Created By Team"
                                ? "active"
                                : ""
                            }`
                      }
                      onClick={() => {
                        this.props.changeActiveTab("Created By Team");

                        this.props.history.push("/dashboard/skills/draft");
                        this.props.changeMode(false);
                      }}
                    >
                      Created By Team
                    </li>

                    <li
                      className={
                        this.props?.appReducer?.minMode
                          ? "list-group-item "
                          : `list-group-item ${
                              currentActiveTab === "Added From Skill Hub"
                                ? "active"
                                : ""
                            }`
                      }
                      onClick={() => {
                        this.props.changeActiveTab("Added From Skill Hub");

                        this.props.history.push("/dashboard/skills/published");
                        this.props.changeMode(false);
                      }}
                    >
                      Added From Skill Hub
                    </li>
                    <li
                      className={
                        this.props?.appReducer?.minMode
                          ? "list-group-item "
                          : `list-group-item ${
                              currentActiveTab === "schedules" ? "active" : ""
                            }`
                      }
                      onClick={() => {
                        this.props.changeActiveTab("schedules");

                        this.props.history.push("/dashboard/schedule");
                        this.props.changeMode(false);
                      }}
                    >
                      Schedules
                    </li>
                    {/* <li
                      className={`list-group-item flex-list-drop ${currentActiveTab === "Snippet Code" ? "active" : ""}`}
                      onClick={() => {
                        this.props.changeActiveTab("Snippet Code");
                        this.props.history.push(
                          "/dashboard/skills/snippetCode"
                        );
                      }}
                    >
                      <div className="left-list-menu">
                        <span>Skill Snippet</span>
                      </div>
                    </li> */}
                  </ul>
                </div>
              </div>
            </div>
            <div className="panel panel-default">
              <div className="panel-heading">
                <h4 className="panel-title">
                  <a
                    className={
                      this.props?.appReducer?.minMode
                        ? "list-group-item flex-list-drop"
                        : `list-group-item flex-list-drop ${
                            currentActiveTab === "Super Skills" ? "active" : ""
                          }`
                    }
                    onClick={() => {
                      this.props.changeActiveTab("Super Skills");

                      this.props.history.push("/dashboard/skill-store/home");
                      this.props.changeMode();
                    }}
                  >
                    <div
                      className="left-list-menu"
                      onClick={() => this.changeMode(false)}
                    >
                      <img src={superSkills} alt="" />{" "}
                      <span> Super Skill Hub</span>
                    </div>{" "}
                    {/* <img className="drop-icon" src={dropIcon} alt="" /> */}
                  </a>
                </h4>
              </div>
              <div id="collapse2" className="panel-collapse collapse">
                <div className="panel-body drop-skills">
                  <ul className="list-group">
                    <li
                      className={`list-group-item ${
                        currentActiveTab === "Automation" ? "active" : ""
                      }`}
                      onClick={() => {
                        this.props.changeActiveTab("Super Skills");

                        this.props.history.push("/dashboard/skill-store/home");
                      }}
                    >
                      Super Skill Hub{" "}
                    </li>
                    {/* <li
                      className={`list-group-item ${
                        currentActiveTab === "Helper" ? "active" : ""
                      }`}
                      onClick={() => {
                        this.props.changeActiveTab("Helper");
                        this.props.history.push(
                          "/dashboard/skill-store/helper-skills/all"
                        );
                      }}
                    >
                      In-App Walkthroughs
                    </li> */}
                  </ul>
                </div>
              </div>
            </div>
            {/* <div className="panel panel-default">
              <div className="panel-heading">
                <h4
                  className="panel-title"
                  onClick={() => {
                    this.props.changeActiveTab("schedule");
                    this.props.history.push("/dashboard/schedule");
                  }}
                >
                  <a
                    className={`list-group-item flex-list-drop ${
                      currentActiveTab === "schedule" ? "active" : ""
                    }`}
                  >
                    <div className="left-list-menu">
                      <img src={scheduleIcon} /> <span>Schedules</span>
                    </div>{" "}
                  </a>
                </h4>
              </div>
            </div> */}
          </div>
          {/* Accordion Ends */}
          {/* My Task Admin  */}
          {/* {currentUser === process.env.REACT_APP_ADMIN1 ||
          currentUser === process.env.REACT_APP_ADMIN2 ||
          currentUser === process.env.REACT_APP_ADMIN3 ||
          currentUser === process.env.REACT_APP_ADMIN4 ? (
            <li
              className={`list-group-item ${
                currentActiveTab === "Platforms" ? "active" : ""
              }`}
              onClick={() => {
                this.props.changeActiveTab("Platforms");
                this.props.history.push("/dashboard/platforms");
              }}
            >
              <img src={platformIcon} />
              <span>Platform</span>
            </li>
          ) : null} */}

          {currentUser === process.env.REACT_APP_ADMIN1 ||
          currentUser === process.env.REACT_APP_ADMIN2 ||
          currentUser === process.env.REACT_APP_ADMIN3 ||
          currentUser === process.env.REACT_APP_ADMIN4 ? (
            <li
              className={`list-group-item ${
                currentActiveTab === "MyTask" ? "active" : ""
              }`}
              onClick={() => {
                this.props.changeActiveTab("MyTask");
                this.props.history.push("/dashboard/tasks/approveWalkThrough");
              }}
            >
              <img src={myTask} />
              <span>My Tasks</span>
            </li>
          ) : null}

          {/* {currentOrganization.isAdmin ? (
            <li
              className={`list-group-item ${
                currentActiveTab === "analytics" ? "active" : ""
              }`}
              onClick={() => {
                this.props.changeActiveTab("analytics");
                this.props.history.push(
                  "/dashboard/analytics/" + currentOrganization.id
                );
              }}
            >
              <img src={analyticsIcon} />
              <span>Analytics</span>
            </li>
          ) : null} */}

          {currentOrganization.isAdmin ? (
            <li
              className={
                this.props?.appReducer?.minMode
                  ? "list-group-item "
                  : `list-group-item ${
                      currentActiveTab === "template" ? "active" : ""
                    }`
              }
              onClick={() => {
                this.props.changeActiveTab("template");
                this.props.history.push("/dashboard/createYourTemplate");
                this.props.changeMode(false);
              }}
            >
              <img src={createTemplateIcon} />
              <span>Create Template</span>
            </li>
          ) : null}
        </ul>
        <div
          className={
            this.props?.appReducer?.minMode
              ? "footer-sidebar"
              : "footer-sidebar"
          }
          onClick={() => this.props.changeMode(false)}
        >
          {/* <button className="outline-new" data-toggle="modal" data-target="#myModal">+ Create a new skill</button> */}
          <div
            className="get-super-block"
            onClick={() =>
              this.setState({
                connectDevice: !this.state.connectDevice,
              })
            }
          >
            {this.state.showUpdateModal ? (
              <span className="label label-primary label-version">
                New Version Available {this.state.current_version}
              </span>
            ) : (
              ""
            )}

            <img src={getSuperImg} />
          </div>
        </div>

        {/* GET SUPER APP */}

        {this.state.connectDevice && (
          <ConnectDevice
            stepOneToggle={(status) => {
              this.stepOneToggle(status);
            }}
            connectDeviceToggle={(status) => {
              this.connectDeviceToggle(status);
            }}
            stepTwoToggle={(status) => {
              this.stepTwoToggle(status);
            }}
            connectDevice={this.state.connectDevice}
            superWindowDeviceName={this.state.superWindowDeviceName}
            stepThreeToggle={(status) => {
              this.stepThreeToggle(status);
            }}
            stepThree={this.state.stepThree}
            stepFourToggle={(status) => {
              this.stepFourToggle(status);
            }}
            stepFour={this.state.stepFour}
          />
        )}
        {this.state.stepOne && (
          <StepOne
            stepOneToggle={(status) => {
              this.stepOneToggle(status);
            }}
            stepTwoToggle={(status) => {
              this.stepTwoToggle(status);
            }}
            stepOne={this.state.stepOne}
          />
        )}
        {this.state.stepTwo && (
          <StepTwo
            stepTwoToggle={(status) => {
              this.stepTwoToggle(status);
            }}
            stepThreeToggle={(status) => {
              this.stepThreeToggle(status);
            }}
            stepFourToggle={(status) => {
              this.stepFourToggle(status);
            }}
            stepTwo={this.state.stepTwo}
          />
        )}
        {this.state.stepThree && (
          <StepThree
            stepThreeToggle={(status) => {
              this.stepThreeToggle(status);
            }}
            stepFourToggle={(status) => {
              this.stepFourToggle(status);
            }}
            stepThree={this.state.stepThree}
          />
        )}
        {this.state.stepFour && (
          <StepFour
            stepFourToggle={(status) => {
              this.stepFourToggle(status);
            }}
            stepFour={this.state.stepFour}
            superWindowDeviceNameToggle={(deviceName) => {
              this.superWindowDeviceNameToggle(deviceName);
            }}
            connectDeviceToggle={(status) => {
              this.connectDeviceToggle(status);
            }}
          />
        )}
        {this.state.stepFive && <StepFive stepFive={this.state.stepFive} />}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  organizationReducer: state.organizationReducer,
  userReducer: state.userReducer,
  notifications: state.appReducer.notifications,
  notified: state.appReducer.notified,
  skillReducer: state.skillReducer,
  appReducer: state.appReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    changeActiveTab,
    getOrganizations,
    setCurrentOrganization,
    changeMode,
    getCurrentUser,
  })
)(SideBar);
