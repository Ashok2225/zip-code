import React, { Component } from "react";
import { connect } from "react-redux";
import {
  loadNotifications,
  deleteNotifications,
} from "../redux/actions/appActions";

class Notifications extends Component {
  constructor() {
    super();
    this.state = {};
  }

  deleteNotification = async () => {
    try {
      await this.props.deleteNotifications(this.props.notifications);
      //   this.props.loadNotifications(this.props.user)
    } catch (err) {
      console.log(err.toString());
    }
  };
  converDateTime = (notifydate) => {
    const notificationDate = new Date(notifydate).toLocaleString();      
    return notificationDate;
  };

  render() {
    let { notifications } = this.props;
    return (
      <div>
        <div className="user-pr">
          <div className="scrollable user-pr-scroll">
            <div id="notification" className={"task-list"} id="task-list">
              <div className="flex-title">
                <h3 className="title">Notifications</h3>
                {notifications.length > 0 ? (
                  <button
                    className="btn btn-danger"
                    onClick={this.deleteNotification}
                  >
                    Clear
                  </button>
                ) : null}
              </div>
              <div className="task-block nt-block scrollable">
                {notifications.length > 0
                  ? notifications.map((notify) => {
                      return (
                        <div className="nf-blck">
                          <div className="nf-inner">
                            <p className="nf-title">{notify.message}</p>
                            <span className="nf-date">
                              {/* {notify.created_at.slice(0, 10)}{" "} */}
                              {this.converDateTime(notify.created_at)}
                              {/* {notify.created_at.split("T")[1].slice(0, 5)} */}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>
          </div>
        </div>

        <div className="overlay"></div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  notifications: state.appReducer.notifications,
  user: state.userReducer.user,
});

export default connect(mapStateToProps, {
  loadNotifications,
  deleteNotifications,
})(Notifications);
