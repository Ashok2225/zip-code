import * as types from "../redux/constants/snackConstants"
export const notify = (type, message) => dispatch => {

    dispatch({ type: types.SHOW_SNACK, snackType: type, message: message })
}

export const closeSnack = (event, reason) =>dispatch=> {
    if (reason === 'clickaway') {
      return;
    }

    dispatch({ type: types.CLOSE_SNACK })
}
  