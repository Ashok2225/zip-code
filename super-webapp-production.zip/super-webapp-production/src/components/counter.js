import React, { useState } from "react";

const Counter = () => {
  const [counter, setCounter] = useState(5);

  React.useEffect(() => {
    const timer =
      counter > 0 && setInterval(() => setCounter(counter - 1), 1000);
    return () => clearInterval(timer);
  }, [counter]);
  if (counter === 0) {
    // dispatch(startRecord(data));
    setCounter(null);
  }
  return <div>{counter ? counter : 0}</div>;
};
export default Counter;
