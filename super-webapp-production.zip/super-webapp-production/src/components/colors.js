import React from "react";

const getRandomColor = (name) => {
  const firstAlphabet = name.charAt(0).toLowerCase();
  const asciiCode = firstAlphabet.charCodeAt(0);

  const colorNum =
    asciiCode.toString() + asciiCode.toString() + asciiCode.toString();
  var num = Math.round(0xff7007 * parseInt(colorNum));
  var r = (num >> 16) & 255;
  var b = (num >> 8) & 255;
  var g = num & 255;

  return "rgb(" + r + ", " + g + ", " + b + "," + "1.0)";
};

const colors = (props) => {
  return getRandomColor(props);
};

export default colors;
