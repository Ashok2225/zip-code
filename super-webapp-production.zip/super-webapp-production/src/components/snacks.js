import React from "react";

import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import { makeStyles } from "@material-ui/core/styles";
import { closeSnack } from "../redux/actions/snack";

import { connect } from "react-redux";
function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2)
    }
  }
}));

function Snacks(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(true);

  return (
    <Snackbar
      anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      open={props && props.snackReducer.open}
      autoHideDuration={3000}
      onClose={props.closeSnack}
    >
      <Alert onClose={props.closeSnack} severity={props.snackReducer.snackType}>
        <span style={{ fontSize: "14px" }}>
          {props.snackReducer.snackMessage} !
        </span>
      </Alert>
    </Snackbar>
  );
}
const mapStateToProps = (state) => ({
  snackReducer: state.snackReducer,
});

export default connect(mapStateToProps, { closeSnack })(Snacks);
