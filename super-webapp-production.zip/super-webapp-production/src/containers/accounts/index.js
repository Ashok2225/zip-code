import React, { Component } from "react";
import { connect } from "react-redux";

class AccountsContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return <h1> Accounts Page</h1>;
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(AccountsContainer);
