import React, { useState, useEffect } from "react";
import queryString from "query-string";
import { FaHubspot, FaSpinner } from 'react-icons/fa';
import { register, signUp } from "../../redux/actions/auth";

import techforceLogo from "../../images/register/tech-logo.png";
import bufferImg from "../../images/buffer/Group 31088@2x.png";
import awsImg from "../../images/buffer/Group 31086@2x.png";
import calendarImg from "../../images/buffer/Group 31089@2x.png";
import slackImg from "../../images/buffer/Group 31087@2x.png";
import salesImg from "../../images/buffer/Group 31085@3x.png";
import OfficeImg from "../../images/buffer/Group 31074@3x.png";

import mailImg from "../../images/buffer/Group 31090@2x.png";
import shopifyImg from "../../images/buffer/Group 31081@2x.png";
import zoomImg from "../../images/buffer/Group 31082@3x.png";
import azureImg from "../../images/buffer/Group 31083@3x.png";
import jiraImg from "../../images/buffer/Group 31076@2x.png";
import excelImg from "../../images/buffer/Group 31080.png";
import hubspotImg from "../../images/buffer/Group 31079.png";
import amazonImg from "../../images/buffer/Group 31078.png";
import canvaImg from "../../images/buffer/Group 31084.png";
import notionImg from "../../images/buffer/Group 31077.png";
import teamsImg from "../../images/buffer/Group 31075.png";

import emailImg from "../../images/register/email@2x.png";
import loginArrowImg from "../../images/register/arrow@2x.png";

import axios from 'axios';
import "./index.css";
import "../../css/login.css";
import "../../css/lg-responsive.css";
// import "./lg-responsive.css";
// import "./bootstrap.min.css";

function UserRegistration(props) {

  let [email, setEmail] = useState();
  let [err, setErr] = useState(false);
  let [loading, setLoading] = useState(false)
  let [msg, setMsg] = useState(false)
  const [subscription_id, setSubscription] = useState('')

  useEffect(() => {
    const parsed = queryString.parse(props.location.search);
    if (parsed.subscriptionId === '0' || parsed.subscriptionId === '1') {
      setSubscription(parsed.subscriptionId)
    } else {
      props.history.push("/")
    }
  }, [props.location, props.history])

  const handleChange = (e) => {
    console.log('handlechange', e)
    setEmail(e.target.value)
    setErr(false);
    setMsg(false)
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true)
    let mail = email.split('@')
    let data = await register({ email, subscription_id });
    if (data.data) {
      let res = await signUp({ email, user_id: data.data.id })
    }
    if (data.status === 201) {
      setMsg(`Congratulations! Your Techforce.ai account is created and verification email has been sent to ${email}. `)
      setLoading(false)
    }
    else if (data.status === 409) {
      setMsg("User already exists. Please register with new User")
      setLoading(false)
    }
  };

  return (
    <div class="container-fluid">
      <div class="lg-left col-md-5">
        <div class="logo">
          <img src={techforceLogo} width="200" alt="logo"></img>
        </div>
        <h1>Make Work Awesome.</h1><br />
        <p>Get ‘Super’ - your own digital work assistant.<br />
          One app to get work done across your apps.</p>

        <div class="floating-img">
          <ul>
            <li class="fl-img img1 wow zoomInLeft" data-wow-duration="2s" data-wow-delay="5s">
              <div class="img-text">
                <img src={bufferImg} alt="" />
              </div>

            </li>
            <li class="fl-img img2">
              <div class="img-text">
                <img src={awsImg} alt="" />
              </div>
            </li>
            <li class="fl-img img3">
              <div class="img-text">
                <img src={calendarImg} alt="" />
              </div>
            </li>
            <li class="fl-img img4">
              <div class="img-text">
                <img src={slackImg} alt="" />
              </div>
            </li>
            <li class="fl-img img5">
              <div class="img-text">
                <img src={salesImg} alt="" />
              </div>
            </li>
            <li class="fl-img img6">
              <div class="img-text">
                <img src={OfficeImg} alt="" />
              </div>
            </li>

            <li class="fl-img img7">
              <div class="img-text">
                <img src={mailImg} alt="" />
              </div>
            </li>
            <li class="fl-img img8">
              <div class="img-text">
                <img src={shopifyImg} alt="" />
              </div>
            </li>
            <li class="fl-img img9">
              <div class="img-text">
                <img src={zoomImg} alt="" />
              </div>
            </li>
            <li class="fl-img img10">
              <div class="img-text">
                <img src={azureImg} alt="" />
              </div>
            </li>
            <li class="fl-img img11">
              <div class="img-text">
                <img src={jiraImg} alt="" />
              </div>
            </li>
            <li class="fl-img img12">
              <div class="img-text">
                <img src={excelImg} alt="" />
              </div>
            </li>
            <li class="fl-img img13">
              <div class="img-text">
                <img src={hubspotImg} alt="" />
              </div>
            </li>
            <li class="fl-img img14">
              <div class="img-text">
                <img src={amazonImg} alt="" />
              </div>
            </li>
            <li class="fl-img img15">
              <div class="img-text">
                <img src={canvaImg} alt="" />
              </div>
            </li>
            <li class="fl-img img16">
              <div class="img-text">
                <img src={notionImg} alt="" />
              </div>
            </li>
            <li class="fl-img img17">
              <div class="img-text">
                <img src={teamsImg} alt="" />
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="lg-right col-md-7">
        <div class="rotating-bg" ></div>
        <div class="form-block">
          <div class="form-content">
            <h1 class="fm-title">Signup</h1>
            <form onSubmit={handleSubmit}>
              {msg !== false ? <div className="alert alert-success" role="alert">{msg}</div> : ""}
              {err ? <div className="alert alert-danger" role="alert">
                Please enter Valid Business Email-ID
              </div> : ""
              }
              <div class="ip-block">
                <label for="">Email</label>
                <div class="ip-icon">
                  <img src={emailImg} alt="" />
                  <input type="text"
                    placeholder="Enter"
                    name="email"
                    value={email}
                    onChange={handleChange}
                    required />
                </div>
              </div>
              <div class="ip-block">
                <a className="register-btn">
                  <button className="rg-text" type="submit" >{loading ?
                    <FaSpinner icon="spinner" style={{ fontSize: "25px" }} className="spinner" />
                    : "SIGN UP"}</button>
                  <span class="sb-ico"><img src={loginArrowImg} alt="" /></span></a>
              </div>
            </form>
            <div class="or-block">
              <p>Or</p>
            </div>

            <p class="text-lg">Already have an account? <a href="/">Login</a></p>
          </div>
          <p class="text-lg font-12">By registering, you agree to the <a href="https://techforce.ai/privacy-policy/" target="_blank">privacy policy</a> and <a href="#">terms of service</a></p>
        </div>
      </div>
    </div>


  );
}

export default UserRegistration;
