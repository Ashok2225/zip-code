import React, { Component } from "react";
import walkthrough from "../../../images/template-img/walkthrough-icon.png";
import automation from "../../../images/template-img/automation-icon.png";
import dataLoading from "../../../images/template-img/data-loading.png";
import webAutomationIcon from "../../../images/template-img/web-automation.png";
import userOnboardingIcon from "../../../images/template-img/user-onboarding.png";
import approval from "../../../images/template-img/approval-workflow.png";
import chatSupport from "../../../images/template-img/chat-support.png";
import emailSupport from "../../../images/template-img/email-support.png";
import extraction from "../../../images/template-img/extraction.png";
import fileFormat from "../../../images/template-img/file-format.png";
import ecommerce from "../../../images/template-img/guided-ecommerce.png";
import messenger from "../../../images/template-img/messenger-support.png";
import mis from "../../../images/template-img/MIS.png";
import survey from "../../../images/template-img/survey.png";
import voiceSupport from "../../../images/template-img/voice-support.png";
import webScraping from "../../../images/template-img/web-scraping.png";
import whatsapp from "../../../images/template-img/whatsapp-support.png";
import comingSoon from "../../../images/coming-soon.png";
import backArrow from "../../../images/back-arrow.png";
import blackArrow from "../../../images/arrow-back-black.png";
import info from "../../../images/info.png";
import browseIcon from "../../../images/modal-icons/upload-icon.png";
import mask from "../../../images/modal-icons/bg-mask.png";
import playBtn from "../../../images/modal-icons/play-btn.png";
import bulbIcon from "../../../images/modal-icons/bulb.png";
import dataTransferIcon from "../../../images/dataTransferIcon.png";
import TemplateCard from "./TemplateCard";
import {
  createDraftSkill,
  startRecord,
  stopRecord,
  changeActiveTab,
  sendRequestAccess,
  getSheetHeaders,
} from "../../../redux/actions/skill";
import { notify } from "../../../redux/actions/snack";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import axios from "axios";
import Counter from "../../../components/counter";
import { getKeycloackToken } from "../../../redux/actions/auth";
import { addMemberToOrganization } from "../../../redux/actions/organizationAction";

import $ from "jquery";
import InviteModal from "./InviteModal";

class CreateTemplate extends Component {
  state = {
    SKILL_NAME: "",
    SKILL_DESCRIPTION: "",
    TEMPLATE: "",
    isRecording: false,
    SKILL_ID: null,
    isLoading: false,
    sheetUrl: null,
    fileUrl: null,
    sheetName: null,
    sheetRange: null,
    stopRecording: false,
    name: "",
    email: "",
    uploadedFileName: "",
    toogleFileView: false,
    isSendingInvite: false,
    requestTemplate: "",
    showCreateTemplate: false,
    isErrorDescription: false,
    dataHeaders: null,
  };

  sendAccessReq = () => {
    let userDetail = this.props?.userReducer?.user;
    let userInfo = {
      Name: userDetail.name,
      Email: userDetail.email,
      contactNumber: userDetail.contactNumber,
    };
    let tempDetail = this.state.requestTemplate;
    let reqData = { userInfo, tempDetail };
    if (this.props.sendRequestAccess(reqData))
      this.props.notify("success", "Request Submitted successfully");
    else this.props.notify("error", "Request Submission failed");
  };

  onStartRecord = async (id) => {
    let markerIndex = 0;
    let skillId = id;
    let data = { skillId, markerIndex };
    const startData = this.props.startRecord(data);
    if (startData) {
      this.setState({
        isRecording: true,
      });
    }
  };

  onStopRecord = () => {
    this.setState({
      stopRecording: true,
    });
    let data = {
      deviceId: this.props.skillReducer.draftSession,
      skillId: this.state.SKILL_ID,
      markerIndex: 0,
    };
    const stopData = this.props.stopRecord(data);
    if (stopData) {
      this.props.changeActiveTab("Draft");
      setTimeout(() => {
        this.setState({
          isRecording: false,
          stopRecording: false,
        });
        this.props.history.push(`/dashboard/skills/viewSkill/${data.skillId}`);
        $(".modal-backdrop").hide();
      }, 5000); // redirect in 5 secs
    }
  };

  checkField = () => {
    if (this.state.SKILL_NAME.trim() === "") {
      this.setState({
        isError: true,
      });
    }
    if (this.state.SKILL_DESCRIPTION.trim() === "") {
      this.setState({
        isErrorDescription: true,
      });
    }
  };

  handleSubmit = async () => {
    this.setState({
      isLoading: true,
    });
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));

    if (this.state.SKILL_NAME.trim() === "") {
      this.props.notify("error", "Skill name cannot be empty");
      this.setState({
        isLoading: false,
      });
      return;
    }
    if (this.state.SKILL_DESCRIPTION.trim() === "") {
      this.props.notify("error", "Skill description cannot be empty");
      this.setState({
        isLoading: false,
      });
      return;
    }

    // if (
    //   this.state.TEMPLATE === "Import Data from Spreadsheet to Web App" &&
    //   (!this.state.sheetUrl || !this.state.sheetName)
    // ) {
    //   this.props.notify("error", "Sheet Name or Sheet Url  cannot be empty");
    //   this.setState({
    //     isLoading: false,
    //   });
    //   return;
    // }
    else {
      let skill = {
        ...this.state,
        SKILL_NAME: this.state.SKILL_NAME,
        USER_ID: this.props.userReducer.user_id,
        TYPE: "regularSkill",
        organisationId: getOrgDetails ? getOrgDetails.id : null,
        status: "self",
        USER_EMAIL: this.props.userReducer.user.email,
      };

      if (this.state.sheetUrl && this.state.sheetName) {
        let headers = await this.props.getSheetHeaders(
          this.state.sheetUrl,
          this.state.sheetName
        );
        skill.dataHeaders = headers;
      }

      const createSkill = await this.props.createDraftSkill(skill, () => {});
      if (createSkill?.data?.status) {
        this.setState({
          isLoading: false,
          isRecording: true,
          SKILL_ID: createSkill.data.data.id,
        });

        this.props.notify("success", "Skill created successfully");
        this.props.history.push(
          `/dashboard/skills/viewSkill/${createSkill.data.data.id}`
        );
        this.props.changeActiveTab("Draft");
        $(".modal-backdrop").hide();
      } else {
        if (createSkill?.data?.response === "failed") {
          this.setState({
            isLoading: false,
          });
          this.props.notify("error", `${createSkill?.data?.error}`);
        } else {
          this.setState({
            isLoading: false,
          });
          this.props.notify("error", "Something went wrong. Please try again");
        }
      }
    }
  };

  onFieldChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
    if (this.state.SKILL_NAME.trim() !== "") {
      this.setState({
        isError: false,
      });
    }
    if (this.state.SKILL_DESCRIPTION.trim() !== "") {
      this.setState({
        isErrorDescription: false,
      });
    }
  };

  toggleFileView = () => {
    if (this.state.SKILL_NAME !== "" && this.state.SKILL_DESCRIPTION !== "") {
      this.setState({
        toogleFileView: true,
      });
      // if (
      //   this.state.SKILL_NAME.includes("-") ||
      //   this.state.SKILL_NAME.includes(" ")
      // ) {
      //   this.props.notify(
      //     "error",
      //     "' - ' and 'spaces' not allowed in skill name"
      //   );
      // } else {
      //   $("#skillInputFields").slideUp("fast");
      //   $("#skillFileFields").animate({ opacity: 1 }).slideDown("fast");
      // }

      $("#skillInputFields").slideUp("fast");
      $("#skillFileFields").animate({ opacity: 1 }).slideDown("fast");
    } else {
      this.props.notify("error", "Skill name and description cannot be empty");
    }
  };

  toggleFileViewBack = () => {
    $("#skillFileFields").slideUp("fast");
    $("#skillInputFields").animate({ opacity: 1 }).slideDown("fast");
  };

  addFileUrl = (e) => {
    var fileUrl = e.target.value;
    if (fileUrl != "") {
      this.setState({
        sheetUrl: e.target.value,
      });
    }
  };

  addFile = async (e) => {
    var _spreadSheetFile = e.target.files[0];
    if (!_spreadSheetFile) {
      this.setState({
        uploadedFileName: this.state.uploadedFileName,
      });
    } else {
      try {
        let token = await getKeycloackToken();
        var _data = new FormData();
        _data.append("file", e.target.files[0]);
        var config = {
          url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload/xl-sheet`,
          method: "post",
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          data: _data,
        };
        const {
          data: {
            data: { url },
          },
        } = await axios(config);
        this.setState({
          sheetUrl: url,
          uploadedFileName: e.target.files[0].name,
        });
      } catch (e) {
        this.props.notify("error", e.response.data.message);
      }
    }
  };

  async componentDidMount() {
    window.$('[data-toggle="popover"]').popover({
      container: "body",
    });
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  validateEmail = (email) => {
    return email.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  };

  submitInvite = async () => {
    this.setState({ isSendingInvite: true });
    const organization_id =
      this.props.organizationReducer.currentOrganization.id;

    if (
      this.state.email != "" &&
      this.state.name != "" &&
      this.validateEmail(this.state.email)
    ) {
      await this.props.addMemberToOrganization({
        email: this.state.email,
        name: this.state.name,
        organization_id: organization_id.toString(),
        role_id: "2",
      });
      $(".close").click();
      this.setState({ isSendingInvite: false, email: "", name: "" });
    } else {
      this.setState({ isSendingInvite: false });
      if (this.state.name === "") {
        this.props.notify("error", "Please Enter Name");
      } else {
        this.props.notify("error", "Please Enter Email");
      }
    }
  };

  render() {
    const email = this.props?.userReducer?.user?.email;

    return (
      <>
        <div className="template-flex">
          <div className="template-box scrollable">
            <div className="tp-title flex-title">
              <h3>Choose A Template To Get Started</h3>
              {/* <button className="btn btn-default" data-toggle="modal"
                data-target="#viewModal">View More Modal</button> */}
              <div className="rt-btns">
                {/* {process.env.REACT_APP_ADMIN1 === email ||
                process.env.REACT_APP_ADMIN2 === email ||
                process.env.REACT_APP_ADMIN3 === email ||
                process.env.REACT_APP_ADMIN4 === email ? (
                  <button
                    className="btn btn-primary btn-outline"
                    data-toggle="modal"
                    data-target="#viewCreateTemplate"
                  >
                    Import Template
                  </button>
                ) : null}
                &nbsp;&nbsp;&nbsp;&nbsp; */}
                <button
                  className="btn btn-primary btn-outline"
                  data-toggle="modal"
                  data-target="#inviteModal"
                >
                  + Invite Team Members
                </button>
              </div>
            </div>

            <div className="tp-boxes">
              <div className="row">
                <div className="col-md-4">
                  <div
                    className="tpb-outer"
                    onClick={() =>
                      this.setState({
                        TEMPLATE: "UserDocumentation",
                      })
                    }
                    data-toggle="modal"
                    data-target="#recordModal"
                  >
                    {/* <div className="tp-time">2 min</div> */}
                    <div className="tlp-icon">
                      <img src={automation} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">User Documentation</h4>
                      <p className="tlp-text">
                        Get freedom from tedious user documentation.
                        Auto-generate user guides instantly by showing your
                        workflow with step-by-step application screenshots and
                        tooltips.
                      </p>
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Get freedom from tedious user documentation.
                        Auto-generate user guides instantly by showing your
                        workflow with step-by-step application screenshots and
                        tooltips."
                      >
                        More
                      </a>
                      {/* <div className="tp-use-now">
                    <button
                      onClick={() =>
                        this.setState({
                          TEMPLATE: "Automation",
                        })
                      }
                      className="btn btn-primary"
                      data-toggle="modal"
                      data-target="#recordModal"
                    >
                      Select
                    </button>
                  </div> */}
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div
                    className="tpb-outer"
                    data-toggle="modal"
                    data-target="#recordModal"
                    onClick={() =>
                      this.setState({
                        TEMPLATE: "In-App Walkthrough",
                      })
                    }
                  >
                    {/* <div className="tp-time">2 min</div> */}
                    <div className="tlp-icon">
                      <img src={walkthrough} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">In-App Walkthroughs</h4>
                      <p className="tlp-text">
                        Create in-app guidance for superior digital adoption.
                        Once created - Super Assistant will walk your teams -
                        step by step - to get the work done in any web or
                        desktop application.
                      </p>
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content=" Create in-app guidance for
                        superior digital adoption. Once created - Super
                        Assistant will walk your teams - step by step - to get
                        the work done in any web or desktop application."
                      >
                        More
                      </a>
                      {/* <div className="tp-use-now">
                    <button
                      className="btn btn-primary"
                      data-toggle="modal"
                      data-target="#recordModal"
                      onClick={() =>
                        this.setState({
                          TEMPLATE: "Helper",
                        })
                      }
                    >
                      Select
                    </button>
                  </div> */}
                    </div>
                  </div>
                </div>

                <div className="col-md-4">
                  <div
                    className="tpb-outer"
                    data-toggle="modal"
                    data-target="#recordModal"
                    onClick={() =>
                      this.setState({
                        TEMPLATE: "Import Data from Spreadsheet to Web App",
                      })
                    }
                  >
                    {/* <div className="tp-time">2 min</div> */}
                    <div className="tlp-icon">
                      <img src={dataLoading} />
                    </div>
                    <div
                      className="tp-content"
                      title="Import Data from Spreadsheet to Web App"
                    >
                      <h4 className="tlp-title">
                        Import Data from Spreadsheet to Web App
                      </h4>
                      <p className="tlp-text">
                        Effortlessly import data from any spreadsheet to any web
                        App. Just show by doing one row entry and delegate rest
                        to Super Assistant. Set it up once and use it forever.
                      </p>
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Effortlessly import data from any spreadsheet to any web
                        App. Just show by doing one row entry and delegate rest
                        to Super Assistant. Set it up once and use it forever."
                      >
                        More
                      </a>
                      {/* <div className="tp-use-now">
                    <button className="btn btn-primary"> Select</button>
                  </div> */}
                    </div>
                    {/* <div className="clearfix">
                    <button className="btn btn-link">Create from scratch &gt;</button>
                  </div>           */}
                  </div>
                </div>

                {/* Web Automation Template ---- */}

                {process.env.REACT_APP_DISABLE_ADDITIONAL_TEMPLATES ===
                "true" ? null : (
                  <div className="col-md-4">
                    <div
                      className="tpb-outer"
                      data-toggle="modal"
                      data-target="#recordModal"
                      onClick={() =>
                        this.setState({
                          TEMPLATE: "WebAutomation",
                        })
                      }
                    >
                      <div className="tlp-icon">
                        <img src={webAutomationIcon} />
                      </div>
                      <div className="tp-content">
                        <h4 className="tlp-title">Web Automation</h4>
                        <p className="tlp-text">
                          Save time and effort in performing repetitive tasks on
                          any website or web application. Capture and replay the
                          web automation steps easily.
                        </p>
                        <a
                          class="more-text"
                          href="javascript:void(0)"
                          data-toggle="popover"
                          data-html="true"
                          data-trigger="hover"
                          data-placement="auto right"
                          data-content=" Save time and effort in performing repetitive tasks on any website or web application. Capture and replay the web automation steps easily."
                        >
                          More
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                {/* User Onboarding */}

                {process.env.REACT_APP_DISABLE_ADDITIONAL_TEMPLATES ===
                "true" ? null : (
                  <div className="col-md-4">
                    <div
                      className="tpb-outer"
                      data-toggle="modal"
                      data-target="#recordModal"
                      onClick={() =>
                        this.setState({
                          TEMPLATE: "UserOnboarding",
                        })
                      }
                    >
                      <div className="tlp-icon">
                        <img src={userOnboardingIcon} />
                      </div>
                      <div className="tp-content">
                        <h4 className="tlp-title">User Onboarding</h4>
                        <p className="tlp-text">
                          Simplify User onboarding journeys for any web
                          application. Onboard Customers or Employees or any
                          other stakeholders with step by step guidance with
                          utmost ease.
                        </p>
                        <a
                          class="more-text"
                          href="javascript:void(0)"
                          data-toggle="popover"
                          data-html="true"
                          data-trigger="hover"
                          data-placement="auto right"
                          data-content="  Simplify User onboarding journeys for any web application. Onboard Customers or Employees or any other stakeholders with step by step guidance with utmost ease."
                        >
                          More
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                {/* {process.env.REACT_APP_ADMIN1 === email ||
                process.env.REACT_APP_ADMIN2 === email ||
                process.env.REACT_APP_ADMIN3 === email ||
                process.env.REACT_APP_ADMIN4 === email ? (
                  <div className="col-md-4">
                    <div
                      className="tpb-outer"
                      data-toggle="modal"
                      data-target="#recordModal"
                      onClick={() =>
                        this.setState({
                          TEMPLATE: "Data Transfer",
                        })
                      }
                    >
                      <div className="tlp-icon">
                        <img src={dataTransferIcon} />
                      </div>
                      <div className="tp-content">
                        <h4 className="tlp-title">Data Transfer</h4>
                        <p className="tlp-text">
                          Easily transfer data between web applications.
                          Validate and filter data before transferring between
                          applications.
                        </p>
                        <a
                          class="more-text"
                          href="javascript:void(0)"
                          data-toggle="popover"
                          data-html="true"
                          data-trigger="hover"
                          data-placement="auto right"
                          data-content=" Easily transfer data between web applications. Validate and filter data before transferring between applications."
                        >
                          More
                        </a>
                      </div>
                    </div>
                  </div>
                ) : null} */}

                <TemplateCard />

                <div className="col-md-4">
                  <div
                    className="tpb-outer create-tlp"
                    data-toggle="modal"
                    data-target="#recordModal"
                    onClick={() =>
                      this.setState({
                        TEMPLATE: "Blank Template",
                      })
                    }
                  >
                    <div className="add-icon">+</div>
                    <div className="tpc-text">
                      <h4 className="tlp-title">
                        {/* Develop A Skill From Scratch */}
                        Blank Template
                      </h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="tp-title">
              {/* <h4>Premium and Upcoming Templates (Coming Soon)</h4> */}
              <h3>Premium Templates</h3>
            </div>
            <div className="tp-boxes coming-soon">
              <div className="row">
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={mis} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">
                        Data download for MIS reporting
                      </h4>
                      <p className="tlp-text">
                        Save time with MIS reporting. Automatically download
                        data from any web or desktop app and perform any
                        excel-based analysis. Just show and tell how to do it
                        once and schedule it for the future to automate all the
                        repetitive MIS reporting work.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Save time with MIS reporting. Automatically download data from any web or desktop app and perform any excel-based analysis. Just show and tell how to do it once and schedule it for the future to automate all the repetitive MIS reporting work."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Data download for MIS reporting",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={survey} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Survey to collect inputs</h4>
                      <p className="tlp-text">
                        Launch your assistant to collect data from colleagues or
                        customers and compile results in a dashboard or export
                        to excel. Now taking feedback or collecting data is as
                        simple as telling your assistant what you want to gather
                        and seeing it create a survey as per your preferences.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Launch your assistant to collect data from colleagues or customers and compile results in a dashboard or export to excel. Now taking feedback or collecting data is as simple as telling your assistant what you want to gather and seeing it create a survey as per your preferences."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Survey to collect inputs",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={chatSupport} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Chat support</h4>
                      <p className="tlp-text">
                        Provide automated chat-based support to colleagues or
                        customers. Create a knowledge note or use show and tell
                        to create a skill on how to deliver automated answering
                        or resolve tickets. Make better use of your's and your
                        team's time to resolve complex issues and let the rest
                        of it be supported automatically.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide automated chat based support to colleagues or customers. Just create a knowledge note or show and tell how to peroform a task for automated answering or  ticket resolutions. Save your's and your team's time to resolve complex issues and let rest of it supported instantly abs automatically."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Chat support",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={extraction} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">
                        Document extraction and data entry
                      </h4>
                      <p className="tlp-text">
                        Extract data from PDF files, forms or images by showing
                        and telling what needs to be extracted and enter the
                        extracted data into excel or any web or desktop app. It
                        saves significant time and gives humans the control to
                        review extracted data before entering it into any end
                        application.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Extract data from PDF files, forms or images by showing and telling what needs to be extracted and enter the extracted data into excel or any web or desktop app. It saves significant time and gives humans the control to review extracted data before entering it into any end application. "
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate:
                              "Document extraction and data entry",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={approval} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Approval workflow</h4>
                      <p className="tlp-text">
                        Launch a quick approval workflow between your teams.
                        Stop using emails to take approvals and manage them
                        centrally from one workflow. Create a multi-level
                        hierarchy and track each stage in real-time. Set up
                        advanced follow-ups/reminders to keep the work flowing.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Launch a quick approval workflow between your teams. Stop using emails to take approvals and manage them centrally from one workflow. Create a multi-level hierarchy and track each stage in real-time. Set up advanced follow-ups/reminders to keep the work flowing. "
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Approval workflow",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={ecommerce} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Guided eCommerce</h4>
                      <p className="tlp-text">
                        Provide a guided ECommerce experience in web-based
                        portals with field-level assistance. You can also
                        provide automated chat-based shopping experiences across
                        channels like WhatsApp, FB messenger, web portals and
                        mobile apps.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide a guided ECommerce experience in web-based portals with field-level assistance. You can also provide automated chat-based shopping experiences across channels like WhatsApp, FB messenger, web portals and mobile apps. "
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Guided eCommerce",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={webScraping} style={{ width: "80%" }} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Web scraping</h4>
                      <p className="tlp-text">
                        Extract data from websites and use the data to enter
                        into a web or desktop or save it into excel. Save time
                        in manual data entry work for collecting data from
                        websites using web scraping.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Extract data from websites and use the data to enter into a web or desktop or save it into excel. Save time in manual data entry work for collecting data from websites using web scraping. "
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Web scraping",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={emailSupport} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Email support</h4>
                      <p className="tlp-text">
                        Provide automated email based support by training your
                        AI assistant to how to respond for queries. Let most
                        common queries and support activities be performed by AI
                        assistant so that you and your team can focus on complex
                        support work.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide automated email based support by training your AI assistant to how to respond for queries. Let most common queries and support activities be performed by AI assistant so that you and your team can focus on complex support work."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Email support",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={fileFormat} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">File format conversion</h4>
                      <p className="tlp-text">
                        Convert files from one format to another using your AI
                        assistant. You and your team can convert PDF files into
                        excel, word or vice versa to use the data for further
                        processing.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Convert files from one format to another using your AI assistant. You and your team can convert PDF files into excel, word or vice versa to use the data for further processing. "
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "File format conversion",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={whatsapp} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">WhatsApp support</h4>
                      <p className="tlp-text">
                        Provide automated Whatsapp based support by training
                        your AI assistant on how to respond to queries. Let most
                        common enquiries and support activities be performed by
                        an AI assistant so that you and your team can focus on
                        complex support work.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide automated Whatsapp based support by training your AI assistant on how to respond to queries. Let most common enquiries and support activities be performed by an AI assistant so that you and your team can focus on complex support work."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "WhatsApp support",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={messenger} />
                    </div>
                    <div className="tp-content">
                      <h4 className="tlp-title">Messenger support</h4>
                      <p className="tlp-text">
                        Provide automated Facebook messenger based support by
                        training your AI assistant on how to respond to queries.
                        Let most common enquiries and support activities be
                        performed by an AI assistant so that you and your team
                        can focus on complex support work.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide automated Facebook messenger based support by training your AI assistant on how to respond to queries. Let most common enquiries and support activities be performed by an AI assistant so that you and your team can focus on complex support work."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Messenger support",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="tpb-outer">
                    <div className="tlp-icon">
                      <img src={voiceSupport} />
                    </div>
                    <div className="tp-content right-popover">
                      <h4 className="tlp-title">Voice support</h4>
                      <p className="tlp-text">
                        Provide automated voice-based support by training your
                        AI assistant on how to respond to queries. Let most
                        common enquiries and support activities be performed by
                        an AI assistant so that you and your team can focus on
                        complex support work.
                      </p>
                    </div>
                    <div className="request-access">
                      <a
                        class="more-text"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement="auto right"
                        data-content="Provide automated voice-based support by training your AI assistant on how to respond to queries. Let most common enquiries and support activities be performed by an AI assistant so that you and your team can focus on complex support work."
                      >
                        More
                      </a>
                      <button
                        onClick={() =>
                          this.setState({
                            requestTemplate: "Voice support",
                          })
                        }
                        className="btn btn-default use-button"
                        data-toggle="modal"
                        data-target="#reqAccessModal"
                      >
                        Request Access
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Record */}

        <div id="recordModal" class="rc-modal modal fade" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                onClick={() =>
                  this.setState({
                    SKILL_NAME: "",
                    SKILL_DESCRIPTION: "",
                    TEMPLATE: "",
                    isRecording: false,
                    SKILL_ID: null,
                    isLoading: false,
                    stopRecording: false,
                    isErrorDescription: false,
                    isError: false,
                  })
                }
              >
                {" "}
                ×
              </button>
              <div class="modal-body">
                <div className="rc-modal-icon">
                  {this.state.TEMPLATE === "UserDocumentation" && (
                    <img src={automation} />
                  )}
                  {this.state.TEMPLATE === "In-App Walkthrough" && (
                    <img src={walkthrough} />
                  )}
                  {this.state.TEMPLATE === "UserOnboarding" && (
                    <img src={userOnboardingIcon} />
                  )}
                  {this.state.TEMPLATE === "WebAutomation" && (
                    <img src={webAutomationIcon} />
                  )}
                  {this.state.TEMPLATE === "Data Transfer" && (
                    <img src={dataTransferIcon} />
                  )}
                  {this.state.TEMPLATE === "In-App Walkthrough" && (
                    <img src={walkthrough} />
                  )}

                  {this.state.TEMPLATE ===
                    "Import Data from Spreadsheet to Web App" && (
                    <img src={dataLoading} />
                  )}
                </div>

                {this.state.isRecording === true ? (
                  <React.Fragment>
                    <h3>
                      {" "}
                      <Counter state={this.state} />{" "}
                    </h3>
                    <h4 className="tlp-title">
                      Your Training starts in a new tab. Capture all steps that
                      you would like Super to learn. Once you are done with
                      training, Click on Stop button{" "}
                    </h4>
                  </React.Fragment>
                ) : (
                  <h4 className="tlp-title text-center">
                    Name Your Automation{" "}
                  </h4>
                )}
                <div className="form-contain">
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Skill Name</span>
                      <input
                        type="text"
                        name="SKILL_NAME"
                        placeholder="Enter Skill Name"
                        value={this.state.SKILL_NAME}
                        onChange={(e) => this.onFieldChange(e)}
                        onBlur={(e) => this.checkField()}
                      />
                      {this.state.isError ? (
                        <label className="error text-danger">
                          Enter Skill Name
                        </label>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Description</span>
                      <textarea
                        name="SKILL_DESCRIPTION"
                        placeholder="Enter Description"
                        spellcheck="false"
                        value={this.state.SKILL_DESCRIPTION}
                        onChange={(e) => this.onFieldChange(e)}
                        onBlur={(e) => this.checkField()}
                      ></textarea>
                      {this.state.isErrorDescription ? (
                        <label className="error text-danger">
                          Enter Skill Description
                        </label>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
                {this.state.isRecording === false ? (
                  <React.Fragment>
                    {this.state.isLoading ? (
                      <button className="btn btn-primary">
                        <div class="sp sp-circle text-light"></div>
                      </button>
                    ) : (
                      <button
                        className="btn btn-primary"
                        onClick={() => this.handleSubmit()}
                      >
                        Next <img src={backArrow} />
                      </button>
                    )}
                  </React.Fragment>
                ) : (
                  <React.Fragment>
                    {this.state.stopRecording ? (
                      <button className="btn btn-primary" data-dismiss="modal">
                        <div class="sp sp-circle text-light"></div>
                      </button>
                    ) : (
                      <button
                        className="btn btn-primary"
                        onClick={() => this.onStopRecord()}
                        data-backdrop="false"
                      >
                        Stop <img src={backArrow} />
                      </button>
                    )}
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
        </div>

        <div id="recordModal-bulk" class="rc-modal modal fade" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                onClick={() => {
                  this.toggleFileViewBack();
                  this.setState({
                    SKILL_NAME: "",
                    SKILL_DESCRIPTION: "",
                    TEMPLATE: "",
                    isRecording: false,
                    SKILL_ID: null,
                    isLoading: false,
                    stopRecording: false,
                    sheetUrl: null,
                    sheetName: null,
                    sheetRange: null,
                    uploadedFileName: "",
                    toogleFileView: false,
                    isErrorDescription: false,
                    isError: false,
                  });
                }}
              >
                {" "}
                ×
              </button>
              <div class="modal-body">
                <div className="rc-modal-icon">
                  <img src={dataLoading} alt="placeholder" />
                </div>
                {this.state.toogleFileView === true ? (
                  <React.Fragment>
                    <h4 className="tlp-title text-center">
                      Spreadsheet Details{" "}
                    </h4>
                  </React.Fragment>
                ) : (
                  <h4 className="tlp-title text-center">
                    Name Your Automation{" "}
                  </h4>
                )}

                <div className="form-contain" id="skillInputFields">
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Skill Name</span>
                      <input
                        type="text"
                        name="SKILL_NAME"
                        placeholder="Enter Skill Name"
                        value={this.state.SKILL_NAME}
                        onChange={(e) => this.onFieldChange(e)}
                        onBlur={(e) => this.checkField()}
                      />
                      {this.state.isError === true ? (
                        <label className="error text-danger">
                          Enter Skill Name
                        </label>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Description</span>
                      <textarea
                        name="SKILL_DESCRIPTION"
                        placeholder="Enter Description"
                        spellcheck="false"
                        value={this.state.SKILL_DESCRIPTION}
                        onChange={(e) => this.onFieldChange(e)}
                        onBlur={(e) => this.checkField()}
                      ></textarea>
                      {this.state.isErrorDescription === true ? (
                        <label className="error text-danger">
                          Enter Skill Description
                        </label>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>

                  <React.Fragment>
                    <button
                      className="btn btn-primary"
                      onClick={(e) => this.toggleFileView()}
                    >
                      Next <img src={backArrow} />
                    </button>
                  </React.Fragment>
                </div>

                <div className="form-contain" id="skillFileFields">
                  {/* <div className="frm-block">
                    <input
                      type="file"
                      name="excel-sheet"
                      placeholder="Please choose your excel sheel"
                      onChange={(e) => this.addFile(e)}
                    />
                  </div>
                  or */}
                  <div className="frm-block">
                    <div className="upload-btn-wrapper upload-browse">
                      <button class="btn btn-browse btn-custom">
                        <img src={browseIcon} />{" "}
                        {this.state.uploadedFileName
                          ? this.state.uploadedFileName
                          : "Browse file"}
                      </button>
                      <input
                        id="excelFile"
                        type="file"
                        name="excel-sheet"
                        placeholder="Please choose your excel sheet"
                        onChange={(e) => this.addFile(e)}
                      />
                    </div>
                  </div>
                  <div className="or-text or-block text-secondary">OR</div>

                  <div className="frm-block">
                    <div className="ip-tl-label">
                      <span className="tl-label">Paste URL</span>
                      <input
                        type="text"
                        name="pasteUrl"
                        placeholder="Enter URL"
                        spellcheck="false"
                        defaultValue={
                          this.state.sheetUrl ? this.state.sheetUrl : ""
                        }
                        onChange={(e) => {
                          this.addFileUrl(e);
                        }}
                      ></input>
                    </div>
                  </div>
                  <div className="frm-col">
                    <div className="frm-block">
                      <div className="ip-tl-label">
                        <span className="tl-label">Sheet Name</span>
                        <input
                          type="text"
                          name="sheetName"
                          placeholder="Enter Sheet Name"
                          spellcheck="false"
                          defaultvalue={this.state.sheetName}
                          onChange={(e) => this.onFieldChange(e)}
                        ></input>
                      </div>
                    </div>
                    {/* <div className="frm-block col-md-6 paddr-0">
                      <div className="ip-tl-label">
                        <span className="tl-label">Sheet Range</span>
                        <input
                          type="text"
                          name="sheetRange"
                          placeholder="Enter"
                          spellcheck="false"
                          value={this.state.sheetRange}
                          onChange={(e) => this.onFieldChange(e)}
                        ></input>
                      </div>
                    </div> */}
                  </div>

                  <div
                    className="instruct-block"
                    style={{ backgroundImage: `url(${mask})` }}
                  >
                    <h5>Getting Started</h5>
                    <ul className="ist-block">
                      <li>
                        <span>01</span>
                        <p>
                          Browse and upload your spreadsheet from local drive or
                          paste the URL of your online spreadsheet.
                        </p>
                      </li>
                      <li>
                        <span>02</span>
                        <p>
                          Currently, Super Assistant does not accept password
                          protected spreadsheets.
                        </p>
                      </li>
                      <li>
                        <span>03</span>
                        <p>
                          Super Assistant considers the first row of the
                          spreadsheet as column headings. Do ensure to have
                          headings for every column.
                        </p>
                      </li>
                      <li>
                        <span>04</span>
                        <p>
                          At least one row of data is needed in the spreadsheet
                          for creating the skill.
                        </p>
                      </li>
                      <li>
                        <span>05</span>
                        <p>
                          Sheet Name is case sensitive. It must match with the
                          sheet name in the spreadsheet.
                        </p>
                      </li>
                      <li>
                        <span>06</span>
                        <p>
                          Super Assistant can be trained by entering one row of
                          data into the web app, using the unique SHOW feature.
                        </p>
                      </li>
                      <li>
                        <span>07</span>
                        <p>
                          On Mapper Screen, connect spreadsheet column names
                          with the corresponding web app data fields.
                        </p>
                      </li>
                    </ul>
                    {/* <div className="play-instruct">
                      <img src={playBtn} />
                    </div> */}

                    <div className="bulb-instruct">
                      <img src={bulbIcon} />
                    </div>
                  </div>

                  {this.state.isRecording === true ? null : (
                    <div className="rc-btn-flex">
                      <React.Fragment>
                        <button
                          style={{ marginRight: 30 }}
                          className="btn btn-link"
                          onClick={(e) => this.toggleFileViewBack()}
                        >
                          <img className="back" src={blackArrow} /> Back
                        </button>
                      </React.Fragment>

                      <React.Fragment>
                        {this.state.isLoading ? (
                          <button className="btn btn-primary">
                            <div class="sp sp-circle text-light"></div>
                          </button>
                        ) : (
                          <button
                            className="btn btn-primary"
                            onClick={() => this.handleSubmit()}
                          >
                            Start Now <img src={backArrow} />
                          </button>
                        )}
                      </React.Fragment>
                    </div>
                  )}
                </div>

                {this.state.isRecording === false ? null : (
                  <div>
                    <React.Fragment>
                      {this.state.stopRecording ? (
                        <button
                          className="btn btn-primary"
                          data-dismiss="modal"
                        >
                          <div class="sp sp-circle text-light"></div>
                        </button>
                      ) : (
                        <button
                          className="btn btn-primary"
                          onClick={() => this.onStopRecord()}
                          data-backdrop="false"
                        >
                          Stop <img src={backArrow} />
                        </button>
                      )}
                    </React.Fragment>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Invite Members Modal */}
        {/* <InviteModal /> */}

        {/* View More Modal */}
        <div id="viewModal" class="view-modal modal fade" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <button type="button" class="close" data-dismiss="modal">
                {" "}
                ×
              </button>
              <div class="modal-body">
                <div className="tlp-icon">
                  <img src={automation} />
                </div>
                <div className="tp-content view-content">
                  <h4 className="">User Documentation</h4>
                  <p className="tlp-tex-1">
                    <strong>
                      Auto-generate visual document guides instantly by showing
                      your workflow Lorem Ipsum is simply dummy text of the
                      printing and typesetting industry. Lorem Ipsum has been
                      the industry’s standard dummy text ever since the 1500s
                    </strong>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Request Access Modal */}

        <div id="reqAccessModal" class="rc-modal modal fade" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                onClick={() =>
                  this.setState({
                    requestTemplate: "",
                  })
                }
              >
                {" "}
                ×
              </button>
              <div class="modal-body">
                <div className="rc-modal-icon">
                  {this.state.requestTemplate ===
                    "Data download for MIS reporting" && <img src={mis} />}

                  {this.state.requestTemplate ===
                    "Survey to collect inputs" && <img src={survey} />}

                  {this.state.requestTemplate === "Chat support" && (
                    <img src={chatSupport} />
                  )}

                  {this.state.requestTemplate ===
                    "Document extraction and data entry" && (
                    <img src={extraction} />
                  )}

                  {this.state.requestTemplate === "Approval workflow" && (
                    <img src={approval} />
                  )}

                  {this.state.requestTemplate === "Guided eCommerce" && (
                    <img src={ecommerce} />
                  )}

                  {this.state.requestTemplate === "Web scraping" && (
                    <img src={webScraping} />
                  )}

                  {this.state.requestTemplate === "Email support" && (
                    <img src={emailSupport} />
                  )}

                  {this.state.requestTemplate === "File format conversion" && (
                    <img src={fileFormat} />
                  )}

                  {this.state.requestTemplate === "WhatsApp support" && (
                    <img src={whatsapp} />
                  )}
                  {this.state.requestTemplate === "Messenger support" && (
                    <img src={messenger} />
                  )}
                  {this.state.requestTemplate === "Voice support" && (
                    <img src={voiceSupport} />
                  )}
                </div>
                <div className="req-template-msg ">
                  Thank you for showing interest in{" "}
                  <strong>{this.state.requestTemplate}</strong> Super automation
                  template to enable your team to be productive and creative at
                  work.
                  <br /> Our friendly Customer Success team will get in touch to
                  assist you with the onboarding.
                  <br />
                  Please click on 'Request Access' to confirm.
                  <br />
                </div>
              </div>
              <button
                className="btn btn-primary"
                data-backdrop="false"
                data-dismiss="modal"
                onClick={() => {
                  this.sendAccessReq();
                }}
              >
                Request Access
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer,
});
export default compose(
  withRouter,
  connect(mapStateToProps, {
    createDraftSkill,
    notify,
    startRecord,
    stopRecord,
    changeActiveTab,
    addMemberToOrganization,
    sendRequestAccess,
    getSheetHeaders,
  })
)(CreateTemplate);
