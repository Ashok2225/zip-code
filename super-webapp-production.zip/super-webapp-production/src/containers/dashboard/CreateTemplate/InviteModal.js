import React, { Component } from "react";
import { notify } from "../../../redux/actions/snack";
import { addMemberToOrganization } from "../../../redux/actions/organizationAction";
import $ from "jquery";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { getUsersOfAnOrganization } from "../../../redux/actions/organizationAction";

export class InviteModal extends Component {
  state = {
    name: "",
    email: "",
    roleId: "",
    isSendingInvite: false,
  };
  validateEmail = (email) => {
    return email.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };
  roleChange = (e) => {
    this.setState({ roleId: e.target.value });
  };
  submitInvite = async () => {
    this.setState({ isSendingInvite: true });
    const organization_id =
      this.props.organizationReducer.currentOrganization.id;

    if (
      this.state.email != this.props?.userReducer?.user?.email &&
      this.state.name != "" &&
      this.validateEmail(this.state.email) &&
      this.state.roleId !== ""
    ) {
      await this.props.addMemberToOrganization({
        email: this.state.email,
        name: this.state.name,
        organization_id: organization_id?.toString(),
        role_id: this.state.roleId,
      });
      $(".close").click();
      this.setState({
        isSendingInvite: false,
        email: "",
        name: "",
        roleId: "",
      });
      this.props.getUsersOfAnOrganization(organization_id);
    } else {
      this.setState({ isSendingInvite: false });
      if (this.state.email === "") {
        this.props.notify("error", "Please Enter Email");
      } else if (this.state.name === "") {
        this.props.notify("error", "Please Enter Name");
      } else {
        this.props.notify("error", "Please select role");
      }
    }
  };
  render() {
    return (
      <div
        id="inviteModal"
        class="modal fade crt-skill"
        role="dialog"
        data-backdrop="static"
        data-keyboard="false"
      >
        <div class="modal-dialog">
          <div class="modal-content crt-content">
            <div class="modal-header">
              <button
                type="button"
                class="close"
                data-dismiss="modal"
                onClick={() =>
                  this.setState({
                    name: "",
                    email: "",
                    roleId: "",
                  })
                }
              >
                &times;
              </button>
              <h4 class="modal-title"> Invite Team Member</h4>
            </div>
            <div class="modal-body">
              <form class="form-contain" action="javascript:void(0)">
                <div class="frm-block">
                  <div className="ip-tl-label">
                    <span className="tl-label">Email Address</span>
                    <input
                      type="email"
                      name="email"
                      placeholder="Enter Email"
                      onChange={(e) => this.handleChange(e)}
                      value={this.state.email}
                    />
                  </div>
                </div>
                <div class="frm-block">
                  <div className="ip-tl-label">
                    <span className="tl-label">Name</span>
                    <input
                      type="text"
                      name="name"
                      placeholder="Enter Name"
                      value={this.state.name}
                      onChange={(e) => this.handleChange(e)}
                    />
                  </div>
                </div>
                <div class="frm-block">
                  <div className="ip-tl-label">
                    <label className="d-block text-dark">Assign role</label>
                    <span
                      className={
                        this.state.roleId === "2"
                          ? "badge badge-pill badge-primary-light cursor-pointer"
                          : "badge badge-pill badge-light cursor-pointer"
                      }
                      onClick={() => this.setState({ roleId: "2" })}
                    >
                      Admin
                    </span>
                    <span
                      className={
                        this.state.roleId === "3"
                          ? " badge badge-pill badge-primary-light cursor-pointer"
                          : "badge badge-pill badge-light cursor-pointer1"
                      }
                      onClick={() => this.setState({ roleId: "3" })}
                    >
                      View & Edit
                    </span>
                    <span
                      className={
                        this.state.roleId === "1"
                          ? " badge badge-pill badge-primary-light cursor-pointer"
                          : "badge badge-pill badge-light cursor-pointer1"
                      }
                      onClick={(e) => this.setState({ roleId: "1" })}
                    >
                      View Only
                    </span>
                  </div>
                </div>
                <div class="frm-btns">
                  <button
                    class="btn-outline"
                    data-dismiss="modal"
                    onClick={() =>
                      this.setState({
                        name: "",
                        email: "",
                        roleId: "",
                      })
                    }
                  >
                    Cancel
                  </button>
                  <button
                    className="primary-btn text-center"
                    onClick={() => this.submitInvite()}
                  >
                    {this.state.isSendingInvite ? (
                      <div class="sp sp-circle text-light"></div>
                    ) : (
                      "Invite"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer,
});
export default compose(
  withRouter,
  connect(mapStateToProps, {
    notify,

    getUsersOfAnOrganization,
    addMemberToOrganization,
  })
)(InviteModal);
