import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { notify } from "../../../components/Snack";
import { changeActiveTab } from "../../../redux/actions/skill";
import {
  getAllTemplates,
  deleteTemplate,
} from "../../../redux/actions/template";
import dataLoading from "../../../images/template-img/data-loading.png";
import { createDraftSkill } from "../../../redux/actions/skill";
import $ from "jquery";

const TemplateCard = () => {
  const [SKILL_NAME, setSkillName] = useState("");
  const [SKILL_DESCRIPTION, setSkillDescription] = useState("");
  const [TemplateName, setTemplateName] = useState("");

  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [deleteSelection, setDeleteSelection] = useState(null);
  const [tempIcon, setTempIcon] = useState(null);

  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const templateReducer = useSelector((state) => state.templateReducer);
  const user = useSelector((state) => state.userReducer);

  const handleSubmit = async () => {
    setIsLoading(true);
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));

    if (SKILL_NAME.trim() !== "" && SKILL_DESCRIPTION.trim() !== "") {
      let skill = {
        TEMPLATE: TemplateName,
        SKILL_NAME: SKILL_NAME,
        SKILL_DESCRIPTION: SKILL_DESCRIPTION,
        USER_ID: user?.user?.user_id,
        TYPE: "regularSkill",
        organisationId: getOrgDetails ? getOrgDetails.id : null,
        status: "self",
        USER_EMAIL: user?.user?.email,
      };

      const createSkill = await dispatch(createDraftSkill(skill, () => {}));
      if (createSkill) {
        setIsLoading(false);
        dispatch(notify("success", "Skill created successfully"));
        $(".modal-backdrop").hide();

        history.push(`/dashboard/skills/viewSkill/${createSkill.data.data.id}`);

        changeActiveTab("Draft");
      } else {
        setIsLoading(false);
        dispatch(notify("error", "Something went wrong "));
      }
    } else {
      setIsLoading(false);
      dispatch(notify("error", "All Fields are mandatory "));
    }
  };

  const onFieldChange = (e) => {
    if (e.target.name === "SKILL_NAME") {
      setSkillName(e.target.value);
    }
    if (e.target.name === "SKILL_DESCRIPTION") {
      setSkillDescription(e.target.value);
    }
  };

  useEffect(() => {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
    const orgId = getOrgDetails ? getOrgDetails.id : null;
    if (orgId !== null) {
      dispatch(getAllTemplates(orgId));
    }
  }, []);

  const deleteTemplateCard = async (id) => {
    await dispatch(deleteTemplate(id));
    setDeleteSelection(null);
    dispatch(getAllTemplates());
  };
  const displayTemplateCard = (loc) => {
    switch (loc) {
      case "/dashboard/create":
        return registeredTemplate();
      case "/dashboard/createYourTemplate":
        return allTemplate();
    }
  };

  const registeredTemplate = () => {
    return (
      <React.Fragment>
        {templateReducer?.allTemplates
          .filter((t, i) => t.status === "registered")
          .map((t, i) => (
            <div className="col-md-4" key={i}>
              <div
                className="tpb-outer"
                data-toggle="modal"
                onClick={(e) => {
                  setTemplateName(t.template_name);
                  setTempIcon(t.template_img_url);
                }}
                data-target="#createSkillModal"
              >
                <div className="tlp-icon">
                  <img
                    src={t.template_img_url ? t.template_img_url : dataLoading}
                  />
                </div>
                <div className="tp-content">
                  <h4 className="tlp-title"> {t.template_name}</h4>
                  <p className="tlp-text">{t.template_description}</p>
                  <a
                    class="more-text"
                    href="javascript:void(0)"
                    data-toggle="popover"
                    data-html="true"
                    data-trigger="hover"
                    data-placement="auto right"
                    data-content={t.template_description}
                  >
                    More
                  </a>
                </div>
              </div>
            </div>
          ))}
      </React.Fragment>
    );
  };

  const allTemplate = () => {
    return (
      <React.Fragment>
        {templateReducer?.allTemplates.map((t, i) => (
          <div className="col-md-4" key={i}>
            <div className="tpb-outer">
              <button
                class="btn-close-tmp"
                data-toggle="modal"
                data-target="#myCustomDeleteTemplate"
                onClick={() => {
                  setDeleteSelection(t.id);
                }}
              >
                {" "}
                ×
              </button>
              <div
                className="tlp-icon"
                onClick={(e) =>
                  history.push(`/dashboard/configureYourTemplate/${t.id}`)
                }
              >
                <img
                  src={t.template_img_url ? t.template_img_url : dataLoading}
                />
              </div>
              <div
                className="tp-content"
                onClick={(e) =>
                  history.push(`/dashboard/configureYourTemplate/${t.id}`)
                }
              >
                <h4 className="tlp-title"> {t.template_name}</h4>
                <p className="tlp-text">{t.template_description}</p>
                <a
                  class="more-text"
                  href="javascript:void(0)"
                  data-toggle="popover"
                  data-html="true"
                  data-trigger="hover"
                  data-placement="auto right"
                  data-content={t.template_description}
                >
                  More
                </a>
              </div>
            </div>
          </div>
        ))}
      </React.Fragment>
    );
  };

  return (
    <div>
      {displayTemplateCard(location?.pathname)}

      <div id="createSkillModal" class="rc-modal modal fade" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              onClick={() => {
                setSkillDescription("");
                setSkillName("");
                setTemplateName("");
              }}
            >
              {" "}
              ×
            </button>
            <div class="modal-body">
              <div className="rc-modal-icon">
                {tempIcon ? <img src={tempIcon} /> : <img src={dataLoading} />}
              </div>

              <h4 className="tlp-title text-center">Name Your Automation </h4>
              <div className="form-contain">
                <div className="frm-block">
                  <div className="ip-tl-label">
                    <span className="tl-label">Skill Name</span>
                    <input
                      type="text"
                      name="SKILL_NAME"
                      placeholder="Enter Skill Name"
                      value={SKILL_NAME}
                      onChange={(e) => onFieldChange(e)}
                    />
                  </div>
                </div>
                <div className="frm-block">
                  <div className="ip-tl-label">
                    <span className="tl-label">Description</span>
                    <textarea
                      name="SKILL_DESCRIPTION"
                      placeholder="Enter Description"
                      spellcheck="false"
                      value={SKILL_DESCRIPTION}
                      onChange={(e) => onFieldChange(e)}
                    ></textarea>
                  </div>
                </div>
              </div>
              <React.Fragment>
                {isLoading ? (
                  <button className="btn btn-primary">
                    <div class="sp sp-circle text-light"></div>
                  </button>
                ) : (
                  <button
                    className="btn btn-primary"
                    onClick={() => handleSubmit()}
                  >
                    Done
                  </button>
                )}
              </React.Fragment>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade crt-skill"
        id="myCustomDeleteTemplate"
        role="dialog"
      >
        <div className="modal-dialog modal-sm">
          <div className="modal-content crt-content">
            <div className="modal-header">
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                onClick={() => {
                  setDeleteSelection(null);
                }}
              >
                &times;
              </button>
              <h4 className="modal-title">Delete Template</h4>
            </div>
            <div className="modal-body">
              <div className="form-contain">
                <div className="frm-block">
                  <p className="md-text">
                    Are you sure you want to delete this template?
                  </p>
                </div>
                <div className="frm-btns">
                  <button
                    className="btn-outline"
                    data-dismiss="modal"
                    onClick={() => {
                      setDeleteSelection(null);
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      deleteTemplateCard(deleteSelection);
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;
