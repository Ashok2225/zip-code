import React, { useState } from "react";
import browseIcon from "../../../images/modal-icons/upload-icon.png";
import {
  createTemplate,
  getAllTemplates,
} from "../../../redux/actions/template";
import { useDispatch, useSelector } from "react-redux";
import { getFileUrl } from "../../../redux/actions/fileUpload";
import { notify } from "../../../components/Snack";
import $ from "jquery";

const TemplateModal = () => {
  const dispatch = useDispatch();
  const [template_name, setTemplateName] = useState("");
  const [template_description, setTemplateDescription] = useState("");
  const [template_data, setTemplateData] = useState([]);
  const [template_file_url, setTemplateFileUrl] = useState(null);
  const [template_img_url, setTemplateImageUrl] = useState(null);

  const [isLoading, setIsLoading] = useState(false);
  const [fileName, setFileName] = useState("");
  const [isLoadingFile, setIsLoadingFile] = useState(false);

  const handleCreate = async () => {
    setIsLoading(true);
    let templateInfo = {
      template_name,
      template_data,
      template_description,
      template_file_url,
      template_img_url,
    };

    if (
      template_name.trim() !== "" &&
      template_description.trim() !== "" &&
      template_img_url !== null
    ) {
      const response = await dispatch(createTemplate(templateInfo));
      if (response?.data?.data) {
        setIsLoading(false);
        setTemplateFileUrl(null);
        setTemplateData([]);
        setTemplateDescription("");
        setTemplateName("");
        setFileName("");
        setTemplateImageUrl(null);
        dispatch(getAllTemplates());
        $(".close").click();
      } else {
        dispatch(notify("error", `'${response?.data?.error}'`));
        setIsLoading(false);
      }
    } else {
      dispatch(notify("error", "All Fields are mandatory!"));
      setIsLoading(false);
    }
  };

  const addFile = async (file) => {
    console.log("here");
    setIsLoadingFile(true);
    if (file?.name) {
      setFileName(file.name);
      const _fileData = await dispatch(getFileUrl(file));
      if (_fileData) {
        setTemplateImageUrl(_fileData);
        setIsLoadingFile(false);
      } else {
        setIsLoadingFile(false);
      }
    } else {
      setIsLoadingFile(false);
    }
  };
  return (
    <div id="viewCreateTemplate" class="rc-modal modal fade" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <button
            type="button"
            class="close"
            data-dismiss="modal"
            onClick={() => {
              setTemplateFileUrl(null);
              setTemplateData([]);
              setTemplateDescription("");
              setTemplateName("");
              setFileName("");
              setTemplateImageUrl(null);
            }}
          >
            {" "}
            ×
          </button>
          <div class="modal-body">
            <h4 className="tlp-title text-center">Name Your Template </h4>
            {template_img_url ? (
              <div className="rc-modal-icon">
                <img src={template_img_url} />
              </div>
            ) : (
              ""
            )}

            <div className="form-contain">
              <div className="frm-block">
                <div className="ip-tl-label">
                  <span className="tl-label">Template Name</span>
                  <input
                    type="text"
                    name="template_name"
                    placeholder="Enter Template Name"
                    value={template_name}
                    onChange={(e) => setTemplateName(e.target.value)}
                  />
                </div>
              </div>
              <div className="frm-block">
                <div className="ip-tl-label">
                  <span className="tl-label">Template Description</span>
                  <textarea
                    name="template_description"
                    placeholder="Enter Description"
                    spellcheck="false"
                    value={template_description}
                    onChange={(e) => setTemplateDescription(e.target.value)}
                  ></textarea>
                </div>
              </div>

              {/* <div className="frm-block" style={{ marginTop: "-20px" }}>
                <div className="ip-tl-label upload-btn-wrapper upload-browse">
                  <button class="btn btn-browse btn-custom">
                    <img src={browseIcon} />{" "}
                    {fileName ? fileName : "Browse file"}
                  </button>
                  <input
                    id="json_file"
                    type="file"
                    name="json_file"
                    placeholder="Please choose your json file"
                    onChange={(e) => addFile(e.target.files[0])}
                  />
                </div>
              </div> */}

              <div className="frm-block" style={{ marginTop: "-20px" }}>
                <div className="ip-tl-label upload-btn-wrapper upload-browse">
                  {isLoadingFile ? (
                    <button class="btn btn-browse btn-custom">
                      <img src={browseIcon} />{" "}
                      <div class="sp sp-circle text-light"></div>
                    </button>
                  ) : (
                    <button class="btn btn-browse btn-custom">
                      <img src={browseIcon} />{" "}
                      {fileName ? fileName : "Browse Template Icon"}
                    </button>
                  )}

                  <input
                    id="img"
                    type="file"
                    name="img"
                    accept="image/*"
                    placeholder="Please choose template icon"
                    onChange={(e) => addFile(e.target.files[0])}
                  />
                </div>
              </div>
            </div>
            {isLoading ? (
              <button className="btn btn-primary">
                <div class="sp sp-circle text-light"></div>
              </button>
            ) : (
              <button
                className="btn btn-primary"
                onClick={(e) => handleCreate()}
                disabled={isLoadingFile ? "disabled" : ""}
              >
                Submit
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateModal;
