import React from "react";
// import automation from "../../../images/template-img/automation-icon.png";
import rpaIcon from "../../../images/template-img/rpa.png";
import nlpIcon from "../../../images/template-img/nlp.png";
import modelerIcon from "../../../images/template-img/approval-workflow.png";
import walkthrough from "../../../images/template-img/walkthrough-icon.png";

const Platforms = () => {
  return (
    <div className="template-flex plt-page">
      <div className="template-box scrollable">
        <div class="tp-title flex-title">
          <h3>Platform</h3>
        </div>
        <div className="row temp-center-flex">
          <div className="col-md-8">
            <div className="row left-plt">
              <div className="col-md-12 plt-box">
                <div className="tpb-outer">
                  <div className="tlp-icon">
                    <img src={rpaIcon} />
                  </div>
                  <div className="tp-content">
                    <h4 className="tlp-title"> RPA Studio</h4>
                    <p className="tlp-text">
                      RPA Studio is a complete solution for application
                      integration and automation of third-party applications,
                      and business IT processes.
                    </p>
                    <a
                      href={
                        "https://digitamize-my.sharepoint.com/personal/vj_techforce_ai/_layouts/15/download.aspx?SourceUrl=%2Fpersonal%2Fvj%5Ftechforce%5Fai%2FDocuments%2FDigitamize%2FTechforce%2Eai%2FProduct%2FSuper%20App%2Ftechforce%2Eai%2Dstudio%2Dinstall%2Dv2%2E3%2E3%2Ezip"
                      }
                      target="_blank"
                      className="btn btn-default use-button"
                    >
                      Use Now
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-md-12 plt-box">
                <div className="tpb-outer">
                  <div className="tlp-icon">
                    <img src={walkthrough} className="tlp-80-img" />
                  </div>
                  <div className="tp-content">
                    <h4 className="tlp-title">OCR Trainer</h4>
                    <p className="tlp-text">
                      Computer Vision-based OCR technology for extracting data
                      from unstructured documents like scanned images, PDF
                      documents etc.
                    </p>
                    <a
                      href={"javascript:void(0)"}
                      taget="_blank"
                      class="btn btn-default use-button btn-disabled"
                    >
                      Use Now
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-md-12 plt-box">
                <div className="tpb-outer mb-0">
                  <div className="tlp-icon">
                    <img src={nlpIcon} />
                  </div>
                  <div className="tp-content">
                    <h4 className="tlp-title"> NLP Trainer</h4>
                    <p className="tlp-text">
                      Natural Language Processing for understanding intent and
                      entities from any document and conversation.
                    </p>
                    <a
                      href={"https://super-nlp.development.techforce.ai"}
                      target="_blank"
                      class="btn btn-default use-button"
                    >
                      Use Now
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="row right-plt">
              <div className="col-md-12">
                <div className="tpb-outer plt-box-white">
                  <div className="tlp-icon">
                    <img src={modelerIcon} />
                  </div>
                  <div className="tp-content">
                    <h4 className="tlp-title">Super Modeler</h4>
                    <p className="tlp-text">
                      Intelligent process management for collaborating with and
                      learning from human colleagues. It is built with a
                      'human-in-the-loop' approach for handling approvals.
                    </p>
                    <a
                      href={"https://supermodeler.techforce.ai/"}
                      target="_blank"
                      class="btn btn-default use-button"
                    >
                      Use Now
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Platforms;
