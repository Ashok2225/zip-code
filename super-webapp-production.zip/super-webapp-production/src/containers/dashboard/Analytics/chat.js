import React, { Component } from "react";
import axios from "axios";
import * as _ from "underscore";
import Moment from "moment";

import { Url } from './url'

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: false,
      text: "Chart.js Bar Chart",
    },
  },
};

class Chat extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newcontent: [],
    };
  }
  componentDidMount = async () => {
    // const instance = axios.create({
    //   baseURL: Url.ApiUrl,
    //   // baseURL: "https://superappbot.development.techforce.ai/ecs/analytics/",
    //   headers: {
    //     "Content-Type": "application/json",
    //   },
    // });

    // const newcontent = await instance.post(`newcontent`, {
    //   start_date: "2022-01-11",
    //   end_date:  Moment().format("YYYY-MM-DD"),
    // });
    // if (newcontent.status) {
    //   this.setState({
    //     newcontent: newcontent.data.data,
    //   });
    // }

    // console.log("cost data2", this.state.newcontent);
  };

  componentDidUpdate(prevProps) {


    if (this.props.newcontent != prevProps.newcontent) {

      this.setState({newcontent:this.props.newcontent})
    }
  }

  render() {
    let labelList = [];

    let IMPORT_SPREADSHEET_COUNT = [];
    let USER_DOC_COUNT = [];
    let WALK_SKILL_COUNT = [];
    let WEB_AUTOMATION_COUNT = [];
    let USER_ONBOARD_COUNT = [];

    if (this.state.newcontent && this.state.newcontent.length > 0) {
      labelList = _.pluck(this.state.newcontent, "created_month");
      IMPORT_SPREADSHEET_COUNT = _.pluck(this.state.newcontent, "import_spreadsheet_count");
      USER_DOC_COUNT = _.pluck(this.state.newcontent, "user_doc_count");
      WALK_SKILL_COUNT = _.pluck(this.state.newcontent, "walk_skill_count");
      
      USER_ONBOARD_COUNT=_.pluck(this.state.newcontent, "user_onboard_count");
      WEB_AUTOMATION_COUNT = _.pluck(
        this.state.newcontent,
        "web_automation_count"
      );
     
    }
    const labels = labelList;
    const data = {
      labels,
      datasets: [
        {
          label: "Import Data from Spreadsheet to Web App",
          data: IMPORT_SPREADSHEET_COUNT,
          backgroundColor: "#fc030f",
        },
        {
          label: "User Documentation",
          data: USER_DOC_COUNT,
          backgroundColor: "#3b273d",
        },
        {
          label: "In-App Walkthrough",
          data: WALK_SKILL_COUNT,
          backgroundColor: "#8a7967",
        },
        {
          label: "Web Automation",
          data: WEB_AUTOMATION_COUNT,
          backgroundColor: "#00a4e4",
        },
        {
          label: "User Onboarding",
          data: USER_ONBOARD_COUNT,
          backgroundColor: "#f47721",
        },
      ],
    };

    return <Bar options={options} data={data} />;
  }
}
export default Chat;
