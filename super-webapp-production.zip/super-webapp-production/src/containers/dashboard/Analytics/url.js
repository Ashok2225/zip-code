export const Url = {
  ApiUrl: "https://superappbot.development.techforce.ai/ecs/analytics/",
  ApiUrl1: "http://localhost:5000/analytics//",
};

export default Url;
