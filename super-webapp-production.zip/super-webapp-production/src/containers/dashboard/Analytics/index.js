import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";

import axios from "axios";
import Chat from "./chat";
import LineGraph from "./Utilisation";
import CostGraph from "./cost";
import Header from "./header";
import Moment from "moment";
import { Url } from "./url";
import "./assets/css/index.css";
import moment from "moment";

import helper from "./assets/img/c-icon-2.png";
import onboard from "./assets/img/c-icon-1.png";
import refered from "./assets/img/c-icon-3.png";
import creator from "./assets/img/c-icon-4.png";

import trophy from "./assets/img/topicon.png";
import $, { data } from "jquery";
import { updateAnalyticsRecord } from "../../../redux/actions/analytics";

export class Analytics extends Component {
  constructor(props) {
    super(props);
    this.state = {
      topMetrics: [],
      topcreatorsList: [],
      efforts: [],
      newcontent: [],
      utilization: [],
      processFlowData: [],
      customStartDate: null,
      customEndDate: null,
      isCustomDate: false,
      newcontent: [],
      utilization: [],
      efforts: [],
      hoursSaved: 0,
      noOfSkillsExecuted: 0,
    };
  }

  componentDidMount = async () => {
    var startDate = new Date();
    var endDate = new Date();
    endDate.setDate(endDate.getDate() + 1);
    startDate.setDate(startDate.getDate() - 7);

    if (this.props.match.params.id != "admin")
      await this.fetchData(
        this.formatDate(startDate),
        this.formatDate(endDate),
        this.props.match.params.id
      );
    else {
      await this.fetchData(
        this.formatDate(startDate),
        this.formatDate(endDate)
      );
    }
  };

  fetchData = async (start = null, end = null, orgId = null) => {
    var payload = {
      start_date: start == null ? "2022-01-11" : start,
      end_date: end == null ? Moment().format("YYYY-MM-DD") : end,
      orgId,
    };

    const instance = axios.create({
      baseURL: process.env.REACT_APP_ECS_HOST_URL + "/analytics/",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const dashboardCards = await instance.post(`topmetrics`, payload);
    const topcreatorsList = await instance.post(`topcreators`, {
      start_date: start == null ? "2022-01-11" : start,
      end_date: end == null ? Moment().format("YYYY-MM-DD") : end,
      orgId,
    });

    console.log("data", dashboardCards.data.data);
    if (dashboardCards.status) {
      this.setState({
        topMetrics: dashboardCards.data.data,
      });
      this.props.updateAnalyticsRecord(dashboardCards.data);
    } else {
      this.setState({
        topMetrics: [],
      });
    }
    if (topcreatorsList.status) {
      this.setState({
        topcreatorsList: topcreatorsList.data.data,
      });
    }
    const newcontent = await instance.post(`newcontent`, payload);
    if (newcontent.status) {
      this.setState({
        newcontent: newcontent.data.data,
      });
    }

    const utilization = await instance.post(`utilization`, payload);

    if (utilization.status) {
      this.setState({
        utilization: utilization.data.data,
      });
    } else {
      this.setState({
        utilization: [],
      });
    }

    const efforts = await instance.post(`efforts`, payload);

    if (efforts.status) {
      this.setState({
        efforts: efforts.data.data,
      });
    } else {
      this.setState({
        efforts: [],
      });
    }
    const result = await instance.post(`hoursSaved`, payload);

    if (result.status) {
      this.setState({
        hoursSaved: result.data.data.timeSavedInHours,
        noOfSkillsExecuted: result.data.data.noOfSkillsExecuted,
      });
    } else {
      this.setState({
        hoursSaved: 0,
      });
    }

    // const instance2 = axios.create({
    //    baseURL: Url.ApiUrl, //"http://localhost:5000/analytics/",
    //   headers: {
    //     "Content-Type": "application/json",
    //   },
    // });

    // const efforts = await instance2.post(`processFlowDetails`, {
    //   start_date: "2022-01-11",
    //   end_date: "2022-03-15",
    // });

    // if (efforts.status) {
    //   sessionStorage.setItem("flowData", JSON.stringify(efforts.data.data));
    //   this.setState({
    //     processFlowData: efforts.data.data,
    //   });
    // } else {
    //   this.setState({
    //     processFlowData: [],
    //   });
    // }

    // console.log("final data", this.state.topMetrics);
    // console.log("final data1", this.state.topcreatorsList);
    // console.log("final data2", this.state.efforts);
    // console.log("final data3", this.state.newcontent);
    // console.log("final data4", this.state.utilization);
  };

  formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  onDateChange = (e) => {
    var d = new Date();
    var end = new Date();
    var endDate = end.setDate(end.getDate() + 1);

    if (e.target.value == "custom") {
      this.setState({ isCustomDate: true });
    } else {
      this.setState({ isCustomDate: false });
      if (e.target.value == 7) {
        d.setDate(d.getDate() - 7);
      } else {
        d.setMonth(d.getMonth() - e.target.value);
      }
      var orgId = this.props.match.params.id;
      this.fetchData(
        this.formatDate(d),
        this.formatDate(endDate),
        orgId != "admin" ? orgId : null
      );
    }
  };

  fetchCustomData = () => {
    var orgId = this.props.match.params.id;

    var end = new Date(this.state.customEndDate);
    var endDate = end.setDate(end.getDate() + 2);

    this.fetchData(
      this.state.customStartDate,
      this.formatDate(endDate),
      orgId != "admin" ? orgId : null
    );
  };

  redirectToViewPeople = (location) => {
    this.props.history.push(
      "/settings/myprofile-settings/viewPeople/" + location
    );
  };

  render() {
    const isAdmin = this.props.match.params.id == "admin" ? true : false;
    return (
      // <div className="wrapper dbnew">
      //     <div className="wrap">
      //         <Header></Header>

      <div className="contentarea">
        <div className="topTitleArea">
          <div className="title-btn">
            <div className="title-select">
              <h2>Dashboard</h2>
              <select
                onChange={(e) => {
                  this.onDateChange(e);
                }}
                name="cars"
                id="cars"
              >
                <option value="select">Select</option>
                <option selected="selected" value="7">
                  Last week
                </option>
                <option value="1">Last 1 months</option>
                <option value="3">Last 3 months</option>
                <option value="6">Last 6 months</option>
                <option value="custom">Custom</option>
              </select>
            </div>
            <button
              className="btn btn-primary"
              onClick={() => {
                this.props.history.push("/dashboard/snippetCode");
              }}
            >
              Skill Snippets
            </button>
          </div>

          {this.state.isCustomDate ? (
            <div className="custom-date">
              <span>Start date : </span>
              <input
                type="date"
                max={moment().format("YYYY-MM-DD")}
                onChange={(e) => {
                  this.setState({ customStartDate: e.target.value });
                }}
              ></input>
              <span>End date : </span>
              <input
                type="date"
                max={moment().format("YYYY-MM-DD")}
                onChange={(e) => {
                  this.setState({ customEndDate: e.target.value });
                }}
              ></input>

              <button
                className="btn btn-primary"
                onClick={() => {
                  this.fetchCustomData();
                }}
              >
                Fetch Analytics
              </button>
            </div>
          ) : null}
        </div>
        {/* <div className="spinner">
                            <i className="fa fa-cog"></i>
                        </div> */}
        <div className="scrollbar">
          <div className="scrollbarInner">
            <div className="listboxSec">
              {isAdmin ? (
                <>
                  <div className="lbCol col-md-3">
                    <img src={onboard} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? parseInt(this.state.topMetrics[0].user_doc_count) +
                            parseInt(
                              this.state.topMetrics[0].walk_skill_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].import_spreadsheet_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].web_automation_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].user_onboard_count
                            )
                          : 0}
                      </h1>
                      <p> Skills Created/Added</p>
                    </div>
                  </div>
                  <div className="lbCol col-md-3">
                    <img src={helper} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? this.state.noOfSkillsExecuted
                          : 0}
                      </h1>

                      <p>Skill Executions </p>
                    </div>
                  </div>
                  <div className="lbCol col-md-3">
                    <img src={creator} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? this.state.topMetrics[0].creator_count
                          : 0}
                      </h1>

                      <p>Creators</p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="lbCol col-md-3">
                    <img src={onboard} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? parseInt(this.state.topMetrics[0].user_doc_count) +
                            parseInt(
                              this.state.topMetrics[0].walk_skill_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].import_spreadsheet_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].web_automation_count
                            ) +
                            parseInt(
                              this.state.topMetrics[0].user_onboard_count
                            )
                          : 0}
                      </h1>
                      <p> Skills Created/Added</p>
                    </div>
                  </div>
                  <div className="lbCol col-md-3">
                    <img src={helper} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? this.state.noOfSkillsExecuted
                          : 0}
                      </h1>

                      <p>Skill Executions </p>
                    </div>
                  </div>
                  <div className="lbCol col-md-3">
                    <img src={creator} />
                    <div className="lbcolInner">
                      <h1>
                        {this.state.topMetrics &&
                        this.state.topMetrics.length > 0
                          ? this.state.topMetrics[0].creator_count
                          : 0}
                      </h1>

                      <p>Creators</p>
                    </div>
                  </div>
                </>
              )}

              {/* <div className="lbCol">
                                        <img src={refered} />
                                        <div className="lbcolInner">
                                            <h1>
                                                {this.state.topMetrics &&
                                                    this.state.topMetrics.length > 0
                                                    ? this.state.topMetrics[0].notes_count
                                                    : 0}
                                            </h1>

                                            <p>Notes Referred </p>
                                        </div>
                                    </div> */}

              <div className="lbCol hoursave  col-md-3">
                <div className="lbcolInner">
                  <h1>{this.state.hoursSaved}</h1>
                  <p>Hours Saved</p>
                </div>
              </div>
            </div>
            {isAdmin ? (
              <div className="listboxSec">
                <div
                  className="lbCol col-md-3"
                  onClick={() => this.redirectToViewPeople(1)}
                >
                  <img src={onboard} />
                  <div className="lbcolInner">
                    <h1>
                      {this.state.topMetrics && this.state.topMetrics.length > 0
                        ? this.state.topMetrics[1].user_count
                        : 0}
                    </h1>
                    <p>Users Signed Up</p>
                  </div>
                </div>
                <div
                  className="lbCol col-md-3"
                  onClick={() => this.redirectToViewPeople(2)}
                >
                  <img src={onboard} />
                  <div className="lbcolInner">
                    <h1>
                      {this.state.topMetrics && this.state.topMetrics.length > 0
                        ? this.state.topMetrics[2].installed_dep
                        : 0}
                    </h1>
                    <p>Users Installed Dependencies</p>
                  </div>
                </div>
                <div
                  className="lbCol col-md-3"
                  onClick={() => this.redirectToViewPeople(3)}
                >
                  <img src={onboard} />
                  <div className="lbcolInner">
                    <h1>
                      {this.state.topMetrics && this.state.topMetrics.length > 0
                        ? this.state.topMetrics[3].users_skills_used
                        : 0}
                    </h1>
                    <p>Skill Executions</p>
                  </div>
                </div>
                <div
                  className="lbCol col-md-3"
                  style={{ width: "20%" }}
                  onClick={() => this.redirectToViewPeople(4)}
                >
                  <img src={onboard} />
                  <div className="lbcolInner">
                    <h1>
                      {this.state.topMetrics && this.state.topMetrics.length > 0
                        ? this.state.topMetrics[4].drafts_count
                        : 0}
                    </h1>
                    <p> Skills Created/Added</p>
                  </div>
                </div>
              </div>
            ) : null}
            <div className="boxsecN flex-stretch">
              <div className="boxW71 boxbg">
                <div className="titleB">
                  <h4>New Content Created</h4>
                </div>
                <div className="grapcol">
                  <Chat newcontent={this.state.newcontent}></Chat>
                  {/* <img src="/assets/img/grap1.jpg" width="100%" /> */}
                </div>
              </div>
              <div className="boxW27 boxbg">
                <div className="titleB">
                  <h4>
                    {/* <img
                                            src="/assets/img/topicon.png"
                                            width="16"
                                            height="16"
                                        />{" "} */}
                    <img src={trophy} style={{ width: "16px" }} />
                    &nbsp;Top Creators
                  </h4>
                </div>

                <div className="toplist">
                  <div className="scrollbar">
                    {this.state.topcreatorsList &&
                    this.state.topcreatorsList.length > 0 ? (
                      <ul>
                        {this.state.topcreatorsList &&
                          this.state.topcreatorsList.map((item) => (
                            <li ky={item.rn}>
                              <div className="tcimg">
                                {item.profile_img ? (
                                  <img
                                    src={`${item.profile_img}`}
                                    width="30"
                                    height="30"
                                  />
                                ) : (
                                  <div className="userIconText">
                                    <span>
                                      {item?.user_name
                                        ? item?.user_name?.slice(0, 2)
                                        : item?.email?.slice(0, 2)}
                                    </span>
                                  </div>
                                )}
                                {/* <img
                                                                    src={`${item.profile_img}`}
                                                                    width="30"
                                                                    height="30"
                                                                    /> */}
                                <h3
                                  title={
                                    item?.user_name ? item?.user_name : item?.email
                                  }
                                >
                                  {item?.user_name ? item?.user_name : item?.email}
                                </h3>
                              </div>

                              <div className="tcaction">
                                <span>{item.skill_count}</span>
                                <i>{item.rn}</i>

                                <img
                                  src="/assets/img/tc-mark-1.png"
                                  width="13"
                                  height="17"
                                />
                              </div>
                            </li>
                          ))}
                      </ul>
                    ) : (
                      <h5 className="text-center">No Data Found</h5>
                    )}
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="boxsecN">
                            <div className="boxW50 boxbg">
                                <div className="titleB">
                                    <h4>Utilisation</h4>
                                </div>
                                <div className="grapcol">
                                    <LineGraph utilization={this.state.utilization}></LineGraph>

                                    <Utilisation></Utilisation>
                                    <img src="/assets/img/grap2.jpg" width="100%" />
                                </div>
                            </div>
                            <div className="boxW50 boxbg rt">
                                <div className="titleB">
                                    <h4>Efforts & Cost Saved</h4>
                                </div>
                                <div className="grapcol">
                                    <CostGraph efforts={this.state.efforts}></CostGraph>

                                    <img src="/assets/img/grap3.jpg" width="100%" />
                                </div>
                            </div>
                        </div> */}
          </div>
        </div>
      </div>
      //     </div>
      // </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    updateAnalyticsRecord,
  })
)(Analytics);
