import React, { Component } from "react";
import { connect } from "react-redux";
import SideBar from "./components/SideBar";
import { Switch, Route, withRouter } from "react-router-dom";
import TrainingChatBot from "./components/TainingChatBot";
import Chat from "../../chat";
import { compose } from "redux";
import { getKeycloackRefreshToken } from "../../../redux/actions/auth";
import Loader from "../../../components/loader";
import {
  setMessage,
  clearMessages,
  setReadyState,
  setHistoryLimit,
} from "../../../redux/actions/chatActions";
import {
  getUserSkills,
  searchMySKills,
  deleteMySkill,
  getSkillsFromStore,
  getUserHelperSkills,
  getDraftSkills,
  clearDraft,
  deleteDraftSkill,
  getSession,
} from "../../../redux/actions/skill";
import { SocketManager } from "../../../ws";
import HelperEdit from "../skillStore/components/HelperEdit";
import MyPublishedSkills from "./components/MyPublishedSkills";
import MyDraftSkills from "./components/MyDraftSkills";
import SearchResults from "./components/SearchResults";
import FlowScreen from "./components/FlowScreen";
import DownloadPdf from "../../../components/downloadPdf";
import AdvanceDataMapper from "./components/FlowScreen/components/FlowDiagram/AdvanceDataMapper";
import ApiInfoModal from "./components/ApiInfoModal";

class MySkills extends Component {
  constructor(props) {
    super(props);
    this.state = {
      enableChat: false,
      activeSkillName: null,
      loader: false,
      page: 1,
      showHistory: false,
    };
  }

  componentDidMount() {
    // this.props.getUserSkills();
    // this.props.getUserHelperSkills();
    // this.props.getSkillsFromStore();
    // this.props.getDraftSkills();
    this.triggerSkill();
    this.props.getSession();
  }

  triggerSkill = () => {
    if (this.props.location.state) {
      const { skill } = this.props.location.state;
      this.chatSkill(skill);
    }
  };

  chatSkill = async (skill) => {
    if (skill.SKILL_NAME !== this.state.activeSkillName) {
      this.props.setHistoryLimit({ lt: 1, gt: 0, limit: 20 });
      let uuid = `${this.props.userReducer.user.sub}-${skill.SKILL_NAME.replace(
        / /g,
        "_"
      )}`;
      // window.chatSocket.switchConnection(uuid);
      this.props.clearMessages();
      this.props.setReadyState(false);
      this.setState({
        showHistory: true,
        enableChat: true,
        activeSkillName: skill.SKILL_NAME,
        loader: false,
      });
    } else {
      let _message = { text: skill.SKILL_NAME };
      _message = window.chatSocket.finalPayload(
        _message,
        false,
        await getKeycloackRefreshToken(),
        "",
        true
      );
      if (this.props.chatReducer.ready) {
        this.setState({ showHistory: false });
        this.props.setMessage(_message);
        window.chatSocket.conn.send(_message);
      }
    }
  };

  componentWillUnmount() {
    let uuid = this.props?.userReducer?.user?.sub;
    // Check Chat socket connection switching
    if (uuid) {
      // window.chatSocket.switchConnection(uuid);
    }
  }

  startOver = async () => {
    this.setState({ enableChat: true });
    let _message = { text: this.state.activeSkillName, start_over: true };
    _message = window.chatSocket.finalPayload(
      _message,
      false,
      await getKeycloackRefreshToken(),
      "",
      true
    );
    if (this.props.chatReducer.ready) {
      this.props.setMessage(_message);
      window.chatSocket.conn.send(_message);
    }
  };

  deleteDraftSkill = async (e, id) => {
    let skillId = this.props.skillReducer.helper
      ? this.props.skillReducer.helper.id
      : "";
    if (skillId !== "") {
      const deleteDraft = await this.props.deleteDraftSkill(skillId);
      if (deleteDraft) {
        this.props.clearDraft();

        this.props.history.push(window.location.pathname);
      }
    }
  };

  render() {
    let { enableChat, skillName, loader, showHistory } = this.state;
    return (
      <div className="align-row">
        <ApiInfoModal />
        {/* <SideBar {...this.props} chatSkill={this.chatSkill} /> */}

        {loader ? (
          <>
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </>
        ) : enableChat ? (
          <Chat
            skillName={skillName}
            startOver={this.startOver}
            showHistory={showHistory}
          />
        ) : (
          <Switch>
            <Route
              path="/dashboard/skills/published"
              render={() => <MyPublishedSkills chatSkill={this.chatSkill} />}
            />
            <Route
              path="/dashboard/skills/draft"
              render={() => <MyDraftSkills />}
            />
            <Route
              path="/dashboard/skills/search/:id"
              render={() => <SearchResults />}
            />
            <Route
              path="/dashboard/skills/trainSkill/:id"
              render={() => <TrainingChatBot />}
            />

            <Route
              path="/dashboard/skills/viewSkill/:id"
              render={() => <FlowScreen />}
            />

            <Route
              path="/dashboard/skills/exportSkill/:id"
              render={() => <DownloadPdf />}
            />

            <Route
              path="/dashboard/skills/mapYourData"
              render={() => <AdvanceDataMapper />}
            />
          </Switch>
        )}
        {/* Draft Delete Modal */}
        <div className="modal fade qa-modal1" id="myDeleteModal" role="dialog">
          <div className="modal-dialog modal-sm">
            <div className="modal-content share-modal">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <h3 className="qa-modal-title">Delete</h3>
                <div>
                  <h5>Please confirm delete action.</h5>
                </div>

                <div className="frm-btns fb-right">
                  <button className="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      this.deleteDraftSkill();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  chatReducer: state.chatReducer,
});
export default compose(
  withRouter,
  connect(mapStateToProps, {
    getUserSkills,
    searchMySKills,
    deleteMySkill,
    getSkillsFromStore,
    getUserHelperSkills,
    setMessage,
    getDraftSkills,
    setMessage,
    clearMessages,
    setReadyState,
    setHistoryLimit,
    deleteDraftSkill,
    clearDraft,
    getSession,
  })
)(MySkills);
