import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox, Dropdown } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";

const ConfigS3ConnectForm = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
 

  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          [
            "branch",
            "condition",
            "loop",
            "loop-nodes",
            "try",
            "try-catch-node"
          ].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();

    //   obj.Region = values?.Region;
      obj.accessKey = values.accessKey;
      obj.secretKey = values.secretKey;
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form className="" form={form} initialValues={nodeData}>
            <div>
              <Form form={form} initialValues={nodeData}>
                {/* <Form.Item
                  name="Region"
                  label="Region"
                  rules={[{ required: true }]}
                >
                  <Input />
                </Form.Item> */}

                <Form.Item
                  name="accessKey"
                  label="Access Key"
                  rules={[{ required: true }]}
                >
                  <Input />
                </Form.Item>

                <Form.Item
                  name="secretKey"
                  label="Secret Key"
                  rules={[{ required: true }]}
                >
                  <Input />
                </Form.Item>
              </Form>
            </div>
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Connects to AWS S3 bucket.</li>
      </ul>
    </div>
  );
};

export default ConfigS3ConnectForm;
