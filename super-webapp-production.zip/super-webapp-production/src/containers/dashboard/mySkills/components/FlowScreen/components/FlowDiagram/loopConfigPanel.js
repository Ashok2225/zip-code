import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Switch } from "antd";
import Mapper from "./DataMapperModal";
import AdvanceDataMapper from './AdvanceDataMapper'
import { store } from "../../../../../../../redux";
import {
  setAdvancedConfigPanel,
  setDraft,
} from "../../../../../../../redux/actions/skill";
const { Option } = Select;

const LoopConfigForm = () => {
  let {
    selectedNode: node,
    datasetVariables,
    nodes,
  } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [iterationParams, setIterationParams] = useState(null);
  const [advancedConfig, setAdvancedConfig] = useState(false);
  const [form] = Form.useForm();
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      const dataSet = datasetVariables.filter(
        (i) => i.id === values.dataSourceId
      )[0];
      nodes = findAndUpdate(nodes, nodeData.id, {
        data: { ...dataSet, ...nodeData.data, ...values, advancedConfig },
      });
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: {
            ...trainDraft.RAW_DATA,
            actions: nodes,
          },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error", error);
    }
  };

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  useEffect(() => {}, [datasetVariables]);

  useEffect(() => {
    setNodeData(node);
    setIterationParams(node?.data?.iterationParams);
    setAdvancedConfig(node?.data?.advancedConfig);
  }, [node]);

  const toggleAdvancedPanel = (checked) => {
    setAdvancedConfig(checked);
  };

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData.data} layout={"vertical"}>
            Show advanced config:{" "}
            <Switch
              size="small"
              checked={advancedConfig}
              onChange={toggleAdvancedPanel}
            />
            {advancedConfig ? (
              <>
                <Form.Item
                  name="indexVar"
                  label="Enter index variable"
                  rules={[{ required: true }]}
                >
                  <Input></Input>
                </Form.Item>

                <Form.Item
                  name="startIndex"
                  label="Enter start index (eg: 0)"
                  rules={[{ required: true }]}
                >
                  <Input></Input>
                </Form.Item>

                <Form.Item
                  name="range"
                  label="Enter FOR-LOOP range"
                  rules={[{ required: true }]}
                >
                  <Input></Input>
                </Form.Item>
              </>
            ) : (
              <>
                <Form.Item
                  name="dataSourceId"
                  label=" Select dataset source"
                  rules={[{ required: true }]}
                >
                  <Select style={{ width: 120 }}>
                    {datasetVariables.map((ele, i) => {
                      return (
                        <Option
                          className="custom-select"
                          key={i}
                          value={ele.id}
                        >
                          <p>
                            {ele.label}
                            <span
                              style={{
                                fontSize: 10,
                                marginLeft: 10,
                                padding: 5,
                                backgroundColor: "#d9f7ef",
                                color: "#00aa80",
                              }}
                            >
                              {ele.kind}
                            </span>
                          </p>
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>

                <Form.Item
                  name="iterationParams"
                  label="Iterate over row/ columns or both"
                  rules={[{ required: true }]}
                >
                  <Select
                    style={{ width: 120 }}
                    onChange={(e) => setIterationParams(e)}
                  >
                    <Option className="custom-select" value="row">
                      Row
                    </Option>
                    <Option className="custom-select" value="column">
                      Column
                    </Option>
                    <Option className="custom-select" value="row-column">
                      {" "}
                      Row & Column both
                    </Option>
                  </Select>
                </Form.Item>

                {iterationParams && iterationParams == "row" ? (
                  <>
                    <Form.Item
                      name="rowNumber"
                      label="Row number or row index"
                      rules={[{ required: true }]}
                    >
                      <Input
                        type="number"
                        defaultValue={node?.data?.rowNumber}
                      />
                    </Form.Item>
                  </>
                ) : null}

                {iterationParams && iterationParams == "column" ? (
                  <>
                    <Form.Item
                      name="columnAddress"
                      label="Column address eg(A, B, C)"
                      rules={[{ required: true }]}
                    >
                      <Input defaultValue={node?.data?.columnAddress} />
                    </Form.Item>
                  </>
                ) : null}
              </>
            )}
          </Form>

          {node.data && !advancedConfig ? (
            <div style={{ margin: "10px 0px" }}>
              {/* <Mapper nodeData={node.data} nodes={nodes} id={node.id} /> */}
              <AdvanceDataMapper nodeData={node.data} nodes={nodes} id={node.id} close={cancel} />
            </div>
          ) : null}

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Iterate over a given dataset for a defined number of times</li>
      </ul>
    </div>
  );
};

export default LoopConfigForm;
