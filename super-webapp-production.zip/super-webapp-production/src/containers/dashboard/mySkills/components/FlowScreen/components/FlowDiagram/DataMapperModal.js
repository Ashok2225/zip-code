import React from "react";
import { Button, Modal } from "antd";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  updateSkillVariables,
  changeActiveTab,
  getSheetHeaders,
  updateFormatedData,
  setDraft,
  getDraftSkillsById,
  toogleDataMapper,
} from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import Zoom from "react-medium-image-zoom";
import LeaderLine from "react-leader-line";
import $ from "jquery";
import infoIcon from "../../../../../../../images/info-new.png";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

const DataMapperModal = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const skill = useSelector((state) => state.skillReducer);
  const showMapper = useSelector(
    (state) => state.skillReducer.toogleDataMapper
  );

  const [headers, setSheetHeaders] = useState([]);
  const [varData, setVarData] = useState({});
  const [lines, setLines] = useState([]);
  const [saveMapper, setSaveMapper] = useState(false);
  const [mappingIndex, setMappingIndex] = useState({});
  const [verboseMapping, setverboseMapping] = useState(new Map());
  const [mapping, setMapping] = useState(new Map());
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [nodeData, setNodeData] = useState(null);
  const [nodeId, setNodeId] = useState(null);

  let [nodes, setNodes] = useState([]);

  useEffect(() => {
    setSheetHeaders(skill?.headers);
    setVarData(skill?.trainDraft?.FORMATED_DATA?.variables);
  }, [skill?.headers, skill?.trainDraft?.FORMATED_DATA]);

  useEffect(() => {
    setNodeData(props.nodeData);
    setNodes(props.nodes);
    setNodeId(props.id);
    dispatch(
      getSheetHeaders(
        props.nodeData.excelSheetUrl,
        props.nodeData.excelSheetName
      )
    );
  }, []);
  useEffect(() => {
    drawLines();
  }, [showMapper]);

  const drawLines = () => {
    var arr = [];
    let indexes = nodeData?.index;
    let mappings = nodeData?.mapping;
    let verboses = nodeData?.verbose;

    if (indexes) {
      setTimeout(() => {
        for (const [key, value] of Object.entries(indexes)) {
          let line = formingLines(key, value);
          arr.push({ key: key, value: value, line: line });
        }
        setLines(arr);
      }, 500);
      const filteredArr = lines.reduce((acc, current) => {
        const x = acc.find((item) => item.key == current.key);
        if (!x) {
          return acc.concat([current]);
        } else {
          return acc;
        }
      }, []);

      let uniqueMappings = new Map();
      let uniqueVerboseMapping = new Map();

      for (const [key, value] of Object.entries(indexes)) {
        uniqueMappings.set(key, value);
      }

      for (const [key, value] of Object.entries(verboses)) {
        uniqueVerboseMapping.set(key, value);
      }
      setMapping(uniqueMappings);
      setverboseMapping(uniqueVerboseMapping);
      setMappingIndex(mappings);
      setLines(filteredArr);
    }
  };

  const formingLines = (destination_id, target_id) => {
    return new LeaderLine(
      document.querySelector("#start-1" + destination_id),
      document.querySelector("#end-1" + target_id),
      {
        color: "#1d262e",
        // dash: {len: 4, gap: 4},
        size: 1,
        startPlug: "disc",
        startPlugColor: "#ffb5b5",
        startPlugSize: 3,
        endPlug: "disc",
        endPlugColor: "#4b97ff",
        endPlugSize: 3,
      }
    );
  };

  const deleteLineFunction = (data, index) => {
    let mappingsArr = new Map();
    let verboseMappingArr = new Map();

    verboseMappingArr.clear();
    mapping.forEach((line, val) => {
      if (val != index) {
        mappingsArr.set(val, line);
      }
    });

    for (let [k, v] of mappingsArr) {
      skill?.trainDraft?.FORMATED_DATA?.variables &&
        Object.keys(skill.trainDraft.FORMATED_DATA.variables).map(
          (data, inde) => {
            if (v == inde) {
              verboseMappingArr.set(
                skill.trainDraft.FORMATED_DATA.variables[data].name,
                headers[k]
              );
            }
          }
        );
    }

    let mappingIndex2 = {};
    for (let [k, v] of verboseMappingArr) {
      headers?.map((da, io) => {
        if (v == da) {
          mappingIndex2[k] = { name: v, index: io };
        }
      });
    }
    let array = [];
    lines?.forEach((val) => {
      if (val.key == index) {
        val.line.remove();
        setLines(
          lines.splice(
            lines.findIndex((a) => a.key == val.key),
            1
          )
        );
      }
    });

    setMapping(mappingsArr);
    setverboseMapping(verboseMappingArr);
    setMappingIndex(mappingIndex2);
    setLines(lines);
  };

  const handleIgnore = () => {
    lines.forEach((val) => {
      val.line.remove();
    });
    mapping.clear();
    verboseMapping.clear();
    setMappingIndex({});
    setverboseMapping(verboseMapping);
    setMappingIndex(mappingIndex);
    setLines([]);
  };

  const dragStart = (e, index, key) => {
    e.dataTransfer.setData("id", index);
    e.dataTransfer.setData("key", key);
  };

  const drop = (e, index, value) => {
    let source_id = e.dataTransfer.getData("id");
    let key = e.dataTransfer.getData("key");
    let target_id = index;
    let arr = [];

    mapping.set(source_id, target_id);
    verboseMapping.set(value, key);
    mappingIndex[value] = { name: key, index: source_id };
    setMapping(mapping);
    setverboseMapping(verboseMapping);
    setMappingIndex(mappingIndex);

    lines.forEach((item) => {
      arr.push({ key: item.key, value: item.value, line: item.line });
    });

    setTimeout(() => {
      mapping.forEach((_val, _key) => {
        let line = formingLines(_key, _val);
        arr.push({ key: _key, value: _val, line: line });
      });
      setLines(arr);
    }, 100);

    const filteredArr = lines.reduce((acc, current) => {
      const x = acc.find((item) => item.key == current.key);
      if (!x) {
        return acc.concat([current]);
      } else {
        return acc;
      }
    }, []);

    setLines(filteredArr);
  };

  const removeLines = () => {
    $(".leader-line").hide();
  };

  const showModal = async () => {
    setIsModalVisible(true);
    dispatch(toogleDataMapper(showMapper == true ? false : true));
  };

  const handleOk = () => {
    // setIsModalVisible(false);
    handleBulkSubmit();
  };

  const handleCancel = () => {
    dispatch(toogleDataMapper(showMapper === false));
    $(".leader-line").hide();
    setIsModalVisible(false);
    $(".leader-line").hide();

    // handleIgnore();
  };

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const saveFlow = async (skill, actions) => {
    var rawData = {
      ...skill?.RAW_DATA,
      actions: actions,
    };
    var status = skill.status;
    let skillName = skill.SKILL_NAME;
    let updatedData = { status, skillName, rawData, itemId: skill.id };
    await dispatch(updateFormatedData(updatedData));
    setSaveMapper(false);
    dispatch(notify("success", "Saved successfully"));
    $(".leader-line").hide();
    history.push(window.location.pathname);
  };

  const handleBulkSubmit = async () => {
    setSaveMapper(true);

    let payload = Object.fromEntries(verboseMapping);
    let _payload = Object.fromEntries(mapping);
    let draft = skill?.trainDraft;
    if (Boolean(Object.keys(payload).length)) {
      let data = {
        verbose: payload,
        index: _payload,
        mapping: mappingIndex,
      };

      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      nodes = findAndUpdate(nodes, nodeId, {
        data: { ...nodeData, ...data },
      });
      dispatch(
        setDraft({
          ...draft,
          RAW_DATA: {
            ...draft.RAW_DATA,
            actions: nodes,
          },
        })
      );
      await saveFlow(draft, nodes);
    } else {
      setSaveMapper(false);

      dispatch(
        notify("error", "Make sure source and target fields are mapped")
      );
    }
  };

  return (
    <div>
      <Button type="primary" onClick={showModal}>
        Open Mapper
      </Button>
      <Modal
        title="Data Mapper"
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <Button className="btn-outline" key="back" onClick={handleIgnore}>
            Clear
          </Button>,

          <Button
            className="primary-btn text-center"
            key="submit"
            onClick={handleOk}
          >
            {saveMapper ? <div class="sp sp-circle text-light"></div> : "Save"}
          </Button>,
        ]}
      >
        <div className="excel-params">
          <div className="source-params">
            <h6 className="mp-title">Source Parameters</h6>

            {skill?.headers?.map((data, index) => (
              <div className="dm-item" key={index}>
                <button
                  className="dm-link-disconnect"
                  type="button"
                  onClick={() => deleteLineFunction(data, index)}
                >
                  &times;
                </button>
                <div
                  className="dm-list-item-1"
                  id={"start-1" + index}
                  draggable="true"
                  onDragStart={(e) => {
                    dragStart(e, index, data);
                  }}
                >
                  {data}
                </div>
              </div>
            ))}
          </div>
          <div className="target-params">
            <h6 className="mp-title">Target Parameters</h6>
            {varData &&
              Object.values(varData)
                .sort((a, b) => a.number - b.number)
                .map((data, index) => (
                  <div className="dm-item-2" key={index}>
                    <div
                      className="dm-list-item-2"
                      id={"end-1" + index}
                      onDrop={(e) => {
                        drop(e, index, data.name);
                      }}
                      onDragOver={(e) => {
                        e.preventDefault();
                      }}
                    >
                      {data.name}
                    </div>
                    <button
                      className="btn-link dm-info"
                      type="button"
                      data-toggle="dropdown"
                    >
                      <img src={infoIcon} alt="" />
                      <div className="popup-img">
                        <Zoom>
                          <img
                            alt="preview"
                            src={
                              skill?.trainDraft?.FORMATED_DATA?.actions[data.id]
                                ?.pageScreenshot
                            }
                          />
                        </Zoom>
                      </div>
                    </button>
                  </div>
                ))}
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default DataMapperModal;
