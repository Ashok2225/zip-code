import React from "react";

const TemplateName = (props) => {
  return <div>{getTemplateName(props.TEMPLATE)}</div>;
};

const getTemplateName = (temp) => {
  switch (temp) {
    case "Import Data from Spreadsheet to Web App":
      return <span>Template : Import Data from Spreadsheet to Web App</span>;
    case "In-App Walkthrough":
      return <span>Template : In-App Walkthrough</span>;
    case "UserDocumentation":
      return <span>Template : User Documentation </span>;
    case "UserOnboarding":
      return <span>Template : User Onboarding</span>;

    case "WebAutomation":
      return <span>Template : Web Automation</span>;
    default:
      return <span>Template : {temp}</span>;
  }
};

export default TemplateName;
