import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Radio, Input, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";

const KeyboardShortcutConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("");
  const [selector, setSelector] = useState("");
  const [keyValue, setkeyValue] = useState("");
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleChange = async (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData.selector = e.target.value;
    setSelector(e.target.value);
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const selectorChange = async (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData.keyValue = e.target.value;
    setkeyValue(e.target.value);
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      obj.actionType = "KEY_STROKES";
      obj.selector = values.selector ? values.selector : "";
      obj.keyValue = values.keyValue ? values.keyValue : "";
      obj.value = values.value ? values.value : "";
      obj.ctrl = values.ctrl ? values.ctrl : false;
      obj.win =  values.win ? values.win : false;
      obj.alt = values.alt ? values.alt : false;
      obj.shift = values.shift ? values.shift : false;
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <p>Keyboard ShortCuts</p>
            <div className="shortcut-box">
            <Form.Item
              name="ctrl"
              valuePropName="checked"
            >
              <Checkbox>Ctrl</Checkbox>
            </Form.Item>
            <Form.Item
              name="win"
              valuePropName="checked"
            >
              <Checkbox>Win</Checkbox>
            </Form.Item>
            <Form.Item
              name="alt"
              valuePropName="checked"
            >
              <Checkbox>Alt</Checkbox>
            </Form.Item>
            <Form.Item
              name="shift"
              valuePropName="checked"
            >
              <Checkbox>Shift</Checkbox>
            </Form.Item>
            </div>
            <Form.Item
              name="selector"
              rules={[{ required: true }]}
            >
              <Radio.Group
                onChange={(e) => handleChange(e, "folder")}
                checked={nodeData.folder}
              >
                <Radio value={"keys"}>Standard Keys</Radio>
                <Radio value={"custom"}>Custom Keys</Radio>
              </Radio.Group>
            </Form.Item>
            {selector === "keys" || nodeData?.selector === "keys" ? (
              <Form.Item
                name="keyValue"
              >
                <select
                  className="ant-input"
                  style={{ padding: "10px" }}
                  onChange={(e) => selectorChange(e, "keyValue")}
                >
                  <option>Please Select any key</option>
                  <option>F1</option>
                  <option>F2</option>
                  <option>F3</option>
                  <option>F4</option>
                  <option>F5</option>
                  <option>F6</option>
                  <option>F7</option>
                  <option>F8</option>
                  <option>F9</option>
                  <option>F10</option>
                  <option>F11</option>
                  <option>F12</option>
                  <option>Enter</option>
                  <option>Tab</option>
                  <option>Delete</option>
                  <option>Escape</option>
                  <option>BackSpace</option>
                  <option>Up</option>
                  <option>Down</option>
                  <option>Right</option>
                  <option>Left</option>
                  <option>End</option>
                  <option>Cmd</option>
                  <option>Insert</option>
                  <option>Space</option>
                  <option>Page Up</option>
                  <option>Page Down</option>
                  <option>Home</option>
                </select>
              </Form.Item>
            ) : <Form.Item
              name="value"
              label="Text"
              help="Eg: s, d, Hello World, {enter}, {Tab 5} OR `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>}
          </Form>
          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Displays the given statement(s) in the log file.</li>
      </ul>
    </div >
  );
};
export default KeyboardShortcutConfig;
