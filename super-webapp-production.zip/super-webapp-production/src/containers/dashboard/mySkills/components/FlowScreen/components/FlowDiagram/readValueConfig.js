import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import captureXpathIcon from "../../../../../../../images/capture-xpath.png";

const ReadValueConfigForm = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };
  const handleSubmit = async () => {
    try {
      let obj = {};
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      obj.readFromElement = values.readFromElement;
      obj.readToVariable = values.readToVariable;
      obj.numberOnly = nodeData.numberOnly ? nodeData.numberOnly : false;

      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );

      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  const xPathHandler = (evt) => {
    const xPath = evt.detail.xPath;
    form.setFieldsValue({
      readFromElement: xPath,
    });
  };

  const captureXpath = (nodeId) => {
    window?.chrome?.runtime.sendMessage(process.env.REACT_APP_CHROME_TAB_ID, {
      type: "captureXPath",
      nodeId: nodeId,
    });
  };

  useEffect(() => {
    document.addEventListener("capturedXPath", xPathHandler);
    return () => {
      console.log("[Unmounting]");
      document.removeEventListener("capturedXPath", xPathHandler, true);
    };
  }, []);

  useEffect(() => {
    setNodeData(node);
  }, [node]);

  const handleChange = (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["numberOnly"] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };
  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <div>
              <p>
                Select Source Field Or
                <Button
                  className="capture-btn"
                  onClick={() => {
                    captureXpath(nodeData.id);
                  }}
                  icon={
                    <img
                      style={{ margin: "0px 10px 0px 0px" }}
                      src={captureXpathIcon}
                    ></img>
                  }
                >
                  {" "}
                  Capture Field{" "}
                </Button>
              </p>
            </div>

            <Form.Item
              name="readFromElement"
              label="Copy Value From"
              rules={[{ required: true }]}
            >
              <Input defaultValue={node.readFromElement} />
            </Form.Item>
            <Form.Item>
              <Checkbox
                onChange={(e) => handleChange(e)}
                checked={nodeData?.numberOnly}
              >
                {" "}
                Extract Number Only{" "}
              </Checkbox>
            </Form.Item>
            {/* <div className="ant-col ant-form-item-label">
              <label
                for="readFromElement"
                class="ant-form-item-required"
                title="Copy Value From"
              >
                Copy Value From
              </label>
              <Checkbox
                onChange={(e) => handleChange(e)}
                checked={nodeData?.numberOnly}
              >
                {" "}
                Extract Number Only{" "}
              </Checkbox>
              
            </div> */}

            <Form.Item
              name="readToVariable"
              label=" Paste Into (Variable)"
              rules={[{ required: true }]}
            >
              <Input defaultValue={node.readToVariable} />
            </Form.Item>
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>
          Reads data from a specified web page source and copies it into a
          pre-defined destination field
        </li>
      </ul>
    </div>
  );
};

export default ReadValueConfigForm;
