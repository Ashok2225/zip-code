import React from "react";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  updateSkillVariables,
  changeActiveTab,
} from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import Zoom from "react-medium-image-zoom";
import LeaderLine from "react-leader-line";
import $ from "jquery";
import infoIcon from "../../../../../../../images/info-new.png";

const DataMapperModal = () => {
  const dispatch = useDispatch();
  const skill = useSelector((state) => state.skillReducer);
  const currentTab = useSelector(
    (state) => state.skillReducer.toogleDataMapper
  );

  const [headers, setSheetHeaders] = useState([]);
  const [varData, setVarData] = useState({});
  const [lines, setLines] = useState([]);
  const [saveMapper, setSaveMapper] = useState(false);

  const [mappingIndex, setMappingIndex] = useState({});

  const [verboseMapping, setverboseMapping] = useState(new Map());

  const [mapping, setMapping] = useState(new Map());
  // const varData = skill?.trainDraft?.FORMATED_DATA?.variables;

  useEffect(() => {
    drawLines();
  }, [currentTab]);

  useEffect(() => {
    
    setSheetHeaders(skill?.headers);
    setVarData(skill?.trainDraft?.FORMATED_DATA?.variables);
  }, [skill?.headers, skill?.trainDraft?.FORMATED_DATA]);

  const handleBulkSubmit = async () => {
    setSaveMapper(true);
    let payload = Object.fromEntries(verboseMapping);
    let _payload = Object.fromEntries(mapping);
    let id = skill?.trainDraft?.id;
    if (Boolean(Object.keys(payload).length)) {
      let data = {
        skillId: id,
        sheetVariables: {
          verbose: payload,
          index: _payload,
          mapping: mappingIndex,
        },
      };
      const res = await dispatch(updateSkillVariables(data));
      setSaveMapper(false);
    } else {
      setSaveMapper(false);

      dispatch(
        notify("error", "Make sure source and target fields are mapped")
      );
    }
  };

  const drawLines = () => {
    var arr = [];
    let indexes =
      skill?.trainDraft?.RAW_DATA?.excelData?.sheetDataMapping?.index;
    let mappings =
      skill?.trainDraft?.RAW_DATA?.excelData?.sheetDataMapping?.mapping;
    let verboses =
      skill?.trainDraft?.RAW_DATA?.excelData?.sheetDataMapping?.verbose;

    if (indexes) {
      setTimeout(() => {
        for (const [key, value] of Object.entries(indexes)) {
          let line = formingLines(key, value);
          arr.push({ key: key, value: value, line: line });
        }
        setLines(arr);
      }, 500);
      const filteredArr = lines.reduce((acc, current) => {
        const x = acc.find((item) => item.key == current.key);
        if (!x) {
          return acc.concat([current]);
        } else {
          return acc;
        }
      }, []);

      let uniqueMappings = new Map();
      let uniqueVerboseMapping = new Map();

      for (const [key, value] of Object.entries(indexes)) {
        uniqueMappings.set(key, value);
      }

      for (const [key, value] of Object.entries(verboses)) {
        uniqueVerboseMapping.set(key, value);
      }
      setMapping(uniqueMappings);
      setverboseMapping(uniqueVerboseMapping);
      setMappingIndex(mappings);
      setLines(filteredArr);
    }
  };

  const formingLines = (destination_id, target_id) => {
    return new LeaderLine(
      document.querySelector("#start" + destination_id),
      document.querySelector("#end" + target_id),
      {
        color: "#1d262e",
        // dash: {len: 4, gap: 4},
        size: 1,
        startPlug: "disc",
        startPlugColor: "#ffb5b5",
        startPlugSize: 3,
        endPlug: "disc",
        endPlugColor: "#4b97ff",
        endPlugSize: 3,
      }
    );
  };

  const deleteLineFunction = (data, index) => {
    let mappingsArr = new Map();
    let verboseMappingArr = new Map();

    verboseMappingArr.clear();
    mapping.forEach((line, val) => {
      if (val != index) {
        mappingsArr.set(val, line);
      }
    });

    for (let [k, v] of mappingsArr) {
      skill?.trainDraft?.FORMATED_DATA?.variables &&
        Object.keys(skill.trainDraft.FORMATED_DATA.variables).map(
          (data, inde) => {
            if (v == inde) {
              verboseMappingArr.set(
                skill.trainDraft.FORMATED_DATA.variables[data].name,
                headers[k]
              );
            }
          }
        );
    }

    let mappingIndex2 = {};
    for (let [k, v] of verboseMappingArr) {
      headers?.map((da, io) => {
        if (v == da) {
          mappingIndex2[k] = { name: v, index: io };
        }
      });
    }
    let array = [];
    lines?.forEach((val) => {
      if (val.key == index) {
        val.line.remove();
        setLines(
          lines.splice(
            lines.findIndex((a) => a.key == val.key),
            1
          )
        );
      }
    });
    setMapping(mappingsArr);
    setverboseMapping(verboseMappingArr);
    setMappingIndex(mappingIndex2);
    setLines(lines);
  };

  const handleIgnore = () => {
    lines.forEach((val) => {
      val.line.remove();
    });
    mapping.clear();
    verboseMapping.clear();
    setMappingIndex({});
    setverboseMapping(verboseMapping);
    setMappingIndex(mappingIndex);
    setLines([]);
  };

  const dragStart = (e, index, key) => {
    e.dataTransfer.setData("id", index);
    e.dataTransfer.setData("key", key);
  };

  const drop = (e, index, value) => {
    let source_id = e.dataTransfer.getData("id");
    let key = e.dataTransfer.getData("key");
    let target_id = index;
    let arr = [];

    mapping.set(source_id, target_id)
    verboseMapping.set(value, key)
    mappingIndex[value] = { name: key, index: source_id };
    setMapping(mapping);
    setverboseMapping(verboseMapping);
    setMappingIndex(mappingIndex);

    lines.forEach((item) => {
      arr.push({ key: item.key, value: item.value, line: item.line });
    });

    setTimeout(() => {
      mapping.forEach((_val, _key) => {
        let line = formingLines(_key, _val);
        arr.push({ key: _key, value: _val, line: line });
      });
      setLines(arr);
    }, 100);

    const filteredArr = lines.reduce((acc, current) => {
      const x = acc.find((item) => item.key == current.key);
      if (!x) {
        return acc.concat([current]);
      } else {
        return acc;
      }
    }, []);

    setLines(filteredArr);
  };

  const removeLines = () => {
    // lines &&
    //   lines.forEach((i) => {
    //     i.line.remove();
    //   });
    $(".leader-line").hide();
  };

  return (
    <div
      className="modal crt-skill fade"
      id="myRpaMapModalExcel"
      role="dialog"
      data-backdrop="static"
      data-keyboard="false"
    >
      <div className="modal-dialog modal-md">
        <div className="modal-content crt-content">
          <button
            onClick={(e) => removeLines(lines)}
            type="button"
            className="close"
            data-dismiss="modal"
          >
            &times;
          </button>
          <div className="modal-body">
            <div className="form-contain-1">
              <h1 className="text-center">Data Mapper </h1>
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="" style={{ marginBottom: 20 }}>
                  <div className="excel-params">
                    <div className="source-params">
                      <h5 className="mp-title">Source Parameters</h5>

                      {skill?.headers?.map((data, index) => (
                        <div className="dm-item" key={index}>
                          <button
                            className="dm-link-disconnect"
                            type="button"
                            onClick={() => deleteLineFunction(data, index)}
                          >
                            &times;
                          </button>
                          <div
                            className="dm-list-item-1"
                            id={"start" + index}
                            draggable="true"
                            onDragStart={(e) => {
                              dragStart(e, index, data);
                            }}
                          >
                            {data}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="target-params">
                      <h5 className="mp-title">Target Parameters</h5>
                      {varData &&
                        Object.values(varData)
                          .sort((a, b) => a.number - b.number)
                          .map((data, index) => (
                            <div className="dm-item-2" key={index}>
                              <div
                                className="dm-list-item-2"
                                id={"end" + index}
                                onDrop={(e) => {
                                  drop(e, index, data.name);
                                }}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                }}
                              >
                                {data.name}
                              </div>
                              <button
                                className="btn-link dm-info"
                                type="button"
                                data-toggle="dropdown"
                              >
                                <img src={infoIcon} alt="" />
                                <div className="popup-img">
                                  <Zoom>
                                    <img
                                      alt="preview"
                                      src={
                                        skill?.trainDraft?.FORMATED_DATA
                                          ?.actions[data.id]?.pageScreenshot
                                      }
                                    />
                                  </Zoom>
                                </div>
                              </button>
                            </div>
                          ))}
                    </div>
                  </div>
                </div>
                <div className="frm-btns">
                  <button
                    className="btn-outline"
                    onClick={() => handleIgnore()}
                  >
                    Clear
                  </button>
                  {saveMapper ? (
                    <button className="primary-btn">
                      <div class="sp sp-circle text-light"></div>
                    </button>
                  ) : (
                    <span
                      onClick={() => handleBulkSubmit()}
                      className="primary-btn"
                    >
                      Save
                    </span>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataMapperModal;
