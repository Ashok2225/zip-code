import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox, DatePicker } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import captureXpathIcon from "../../../../../../../images/capture-xpath.png";
import { v4 as uuid } from "uuid";
import moment from "moment"

import TextField from '@material-ui/core/TextField'
const { Option } = Select;

const FilesFoldersConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("readfile");
  const [form] = Form.useForm();


  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();

      if (actionType === "READFILE") {
        // nodes.forEach((item, i) => {
        //   if (item.id === nodeData.id) {
        //     item.actionType = "READFILE";
        //     item["filePath"] = values.filePath;
        //     item["variable"] = values.variable;
        //   }
        // });

        nodeData.actionType = "READFILE";
        nodeData["filePath"] = values.filePath;
        nodeData["variable"] = values.variable;


      } else if (actionType === "WRITEFILE") {
        // nodes.forEach((item, i) => {
        //   if (item.id === nodeData.id) {
        //     item.actionType = "WRITEFILE";
        //     item["filePath"] = values.filePath;
        //     item["content"] = values.content;
        //     item["skip"] = values.skip;
        //   }
        // });

        nodeData.actionType = "WRITEFILE";
        nodeData["filePath"] = values.filePath;
        nodeData["content"] = values.content;
        nodeData["skip"] = values.skip;
      }
      else if (actionType === "COPYFILESFOLDERS_ACTION") {


        nodeData.actionType = "COPYFILESFOLDERS_ACTION";
        nodeData["sourcePath"] = values.sourcePath;
        nodeData["destinationPath"] = values.destinationPath;
        nodeData["skip"] = values.skip;
        nodeData["mode"] = values.mode;
        nodeData["subType2"] = values.subType2;
      }

      else if (actionType === "DELETEFILESFOLDERS_ACTION") {


        nodeData.actionType = "DELETEFILESFOLDERS_ACTION";
        nodeData["filePath"] = values.filePath;
       
        nodeData["subType2"] = values.subType2;
      }

      else if (actionType === "GETFOLDERCONSTANTS") {


        nodeData.actionType = "GETFOLDERCONSTANTS";
        nodeData["filePath"] = values.filePath;
        nodeData["variable"] = values.variable;
        nodeData["ifCondition"] = values.ifCondition;
        nodeData["filter"] = values.filter;
        // nodeData["fromDateVar"] = values.fromDateVar;
        // nodeData["toDateVar"] = values.toDateVar;
      }

      else if (actionType === "unzipfiles") {


        nodeData.actionType = "unzipfiles";
        nodeData["sourcePath"] = values.sourcePath
        nodeData["destinationPath"] = values.destinationPath
        nodeData["skip"] = values.skip

      }


      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );

      cancel();
    } catch (error) {
      console.log("form error: ", error.toString());
    }
  };

  const handleTypeChange = (e) => {
    setActionType(e.target.value);
  };

  const onCheckChange = (e) => {

    e.preventDefault()

    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["ifDateModified"] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );

  }

  const onRadioChange = (e) => {

    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["dates"] = e.target.value;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );


  }

  const onGetContentsTypeChange = (e) => {


    setNodeData({ ...nodeData, ifCondition: e.target.value });

  }

  const onUnzipOptionChange = (e) => {

    setNodeData({ ...nodeData, extractToSameLocation: e.target.checked })


  }

  const handleDateChange = (e) => {
    setNodeData({ ...nodeData, [e.target.name]: e.target.value.split("/").reverse().join("/") });
  }

  const renderActionFields = (type) => {
    console.log(nodeData)
    switch (type) {
      case "READFILE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="variable"
              label="Variable to capture file content"
              rules={[{ required: true }]}
              help="Eg: variableName"
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "WRITEFILE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="content"
              label="Content to write"
              rules={[{ required: true }]}
              help="Eg: hello or `variableName`"
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="skip"
              label="If file exists?"
              rules={[{ required: true }]}
            >
              <Radio.Group>
                <Radio value={"overwite"}>Overwrite</Radio>
                <Radio value={"append"}>Append</Radio>
              </Radio.Group>
            </Form.Item>
          </div>
        );

      case "COPYFILESFOLDERS_ACTION":
        return (
          <div>
            <Form.Item
              name="subType2"
              label="Target"
              rules={[{ required: true }]}
            >
              <Radio.Group>
                <Radio value={"file"}>File</Radio>
                <Radio value={"folder"}>Folder</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item
              name="sourcePath"
              label="Source Path"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="destinationPath"
              label="Destination Path"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="mode"
              label="Mode"
              rules={[{ required: true }]}
            >
              <Radio.Group>
                <Radio value={"copy"}>Copy</Radio>
                <Radio value={"move"}>Move</Radio>
              </Radio.Group>
            </Form.Item>

            <Form.Item
              name="skip"
              label="If exists?"
              rules={[{ required: true }]}
            >
              <Radio.Group>
                <Radio value={"overwite"}>Overwrite</Radio>
                <Radio value={"skip"}>Skip</Radio>
              </Radio.Group>
            </Form.Item>
          </div>
        );


      case "GETFOLDERCONSTANTS":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="Folder Path"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variable"
              label="Variable to capture Folder Contents"
              rules={[{ required: true }]}
              help="Eg: variableName"
            >
              <Input />
            </Form.Item>


            <Form.Item
              name="ifCondition"
              label="Which contents to List?"
              rules={[{ required: true }]}

            >
              <Radio.Group>
                <Radio onChange={onGetContentsTypeChange} value={"files"}>Files</Radio>
                <Radio onChange={onGetContentsTypeChange} value={"folders"}>Folders</Radio>
              </Radio.Group>
            </Form.Item>



            {nodeData.ifCondition == "files" ?
              <Form.Item
                name="filter"
                label="Filter Criteria"
                // rules={[{ required: true }]}
                help="Eg *.pdf or *.txt"
              >
                <Input />
              </Form.Item>

              : ""}




            <Checkbox checked={nodeData.ifDateModified} onChange={onCheckChange} >Date Modified</Checkbox>

            {nodeData.ifDateModified ?

              <>

                <Form.Item
                  name="dates"
                 
                  rules={[{ required: true }]}

                >
                  <Radio.Group>
                    <Radio onChange={onRadioChange} value={"dynamic"}>Dynamic</Radio>
                    <Radio onChange={onRadioChange} value={"static"}>Static</Radio>
                  </Radio.Group>
                </Form.Item>


                {nodeData.dates == "dynamic" ?
                  <>
                    <Form.Item
                      name="fromDateVar"
                      label="From Date"
                      help="Eg: `varFromDate`, Date must be in yyyy-MM-dd format"
                      rules={[{ required: true }]}
                    >
                      <Input />
                    </Form.Item>

                    <Form.Item
                      name="toDateVar"
                      label="TO Date"
                      help="Eg: `varToDate`, Date must be in yyyy-MM-dd format"
                      rules={[{ required: true }]}
                    >
                      <Input />
                    </Form.Item>

                  </>


                  :
                  <>
                    <div><TextField
                      id="datetime-local"
                      name="fromDate"
                      label="From Date"
                      type="date"
                      value={nodeData.fromDate}
                      onChange={(e) => handleDateChange(e)}
                      className=""
                      InputLabelProps={{
                        shrink: true,
                      }}
                    /><TextField
                        style={{ marginLeft: "20px" }}
                        id="datetime-local"
                        name="toDate"
                        value={nodeData.toDate}
                        label="To Date"
                        type="date"
                        onChange={(e) => handleDateChange(e)}
                        className=""
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </div>
                    {/* <DatePicker  value={moment(nodeData.toDateVar)}/> */}

                  </>


                }
              </>




              : null}



          </div>
        );

      case "DELETEFILESFOLDERS_ACTION":
        return (
          <div>
            <Form.Item
              name="subType2"
              label="Target"
              rules={[{ required: true }]}
            >
              <Radio.Group>
                <Radio value={"file"}>File</Radio>
                <Radio value={"folder"}>Folder</Radio>
              </Radio.Group>
            </Form.Item>

            <Form.Item
              name="filePath"
              label="Path"
              rules={[{ required: true }]}
              help="Eg: C:\Users\text.txt or `variableName`"
            >
              <Input />
            </Form.Item>



          </div>
        );

      case "unzipfiles": return (


        <div>
          {nodeData ? (
            <div>



              <Form form={form} initialValues={nodeData}>


                <Form.Item
                  name="sourcePath"
                  label="Source File To Extract"
                  rules={[{ required: true }]}
                  help="Eg `variablename` or text.zip"
                >
                  <Input defaultValue={node.sourcePath} />
                </Form.Item>



                <Form.Item
                  name="extractToSameLocation"
                  valuePropName="checked"
                >
                  <Checkbox onChange={onUnzipOptionChange}>Extract To Same Location</Checkbox>
                </Form.Item>

                {nodeData.extractToSameLocation ? null :

                  <Form.Item
                    name="destinationPath"
                    label="Destination Folder"
                    rules={[{ required: true }]}
                    help="Eg `variablename` or text.zip"
                  >
                    <Input defaultValue={nodeData.destinationPath} />
                  </Form.Item>
                }



                <Form.Item
                  name="skip"
                  label="If folder with the same name as of zip file exists?"
                  rules={[{ required: true }]}

                >
                  <Radio.Group >
                    <Radio value={"overwite"}>Overwrite</Radio>
                    <Radio value={"skip"}>Skip</Radio>
                  </Radio.Group>
                </Form.Item>
              </Form>


            </div>
          ) : null}
        </div>

      )



      default: return null
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);



  return (
    <div>
      {nodeData ? (
        <div>
          <Form className="" form={form} initialValues={nodeData}>
            <div className="ant-row ant-form-item">
              <label className="ant-form-item-required">
                Select action type
              </label>
              <div className="ant-col ant-form-item-control">
                <select
                  className="ant-input"
                  style={{ padding: "10px" }}
                  value={actionType}
                  onChange={(e) => handleTypeChange(e)}
                >
                  <option>Select</option>
                  <option value="READFILE">Read From File</option>
                  <option value="WRITEFILE">Write to a File</option>
                  <option value="COPYFILESFOLDERS_ACTION">Copy File/Folder</option>
                  <option value="GETFOLDERCONSTANTS">Get Folder Contents</option>
                  <option value="DELETEFILESFOLDERS_ACTION">Delete File/Folder</option>
                  <option value="unzipfiles">Unzip Files</option>
                </select>
              </div>
            </div>

            {renderActionFields(actionType)}
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
      {(() => {
        if (actionType === "READFILE") {
          return (
            <li>Reads the content from the file at specified file path.</li>
          )
        } else if (actionType === "WRITEFILE") {
          return (
            <li>Appends or overwrites the given value to the file at specified file path.</li>
          )
        } else if (actionType === "COPYFILESFOLDERS_ACTION") {
          return (
            <li>Copies or moves files/folders from source to the destination paths specified.</li>
          )
        } else if (actionType === "GETFOLDERCONSTANTS") {
          return (
            <li>Lists the folder contents from the specified folder path.</li>
          )
        } else if (actionType === "DELETEFILESFOLDERS_ACTION") {
          return (
            <li>Deletes the File/Folder from the specified path.</li>
          )
        } else if (actionType === "unzipfiles") {
          return (
            <li>Extracts the contents from the zipped source file to the destination folder specified.</li>
          )
        }
        else {
          return (
            <li>Performs various actions on the files and folders available on your desktop.</li>
          )
          }
      })()}
    </ul>

    </div>
  );
};

export default FilesFoldersConfig;
