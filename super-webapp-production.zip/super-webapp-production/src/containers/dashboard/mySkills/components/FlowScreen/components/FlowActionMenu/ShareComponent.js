import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams, useLocation, useHistory } from "react-router-dom";
import axios from "axios";
import {
  FacebookIcon,
  WhatsappIcon,
  TwitterIcon,
  LinkedinIcon,
  FacebookShareButton,
  LinkedinShareButton,
  TwitterShareButton,
  WhatsappShareButton,
} from "react-share";
import { notify } from "../../../../../../../redux/actions/snack";
import shareIcon from "../../../../../../../images/shareIcon.png";
const ShareComponent = () => {
  const params = useParams();
  const location = useLocation();
  const dispatch = useDispatch();
  const skill = useSelector((state) => state.skillReducer.trainDraft);
  const loading = useSelector((state) => state.skillReducer.loading);

  const getSharePath = () => {
    if (skill?.TEMPLATE === "UserDocumentation") {
      return process.env.REACT_APP_WEB_APP_URL?.concat(
        `/dashboard/skills/exportSkill/${params.id}`
      );
    } else {
      return process.env.REACT_APP_WEB_APP_URL?.concat(location.pathname);
    }
  };

  const actualShareUrl = getSharePath();

  const [shortLink, setShortLink] = useState("");
  useEffect(() => {
    let getShare = true;
    if (getShare) {
      getShortUrl();
    }
    return () => {
      getShare = false;
    };
  }, [skill]);

  const getShortUrl = async () => {
    const getLink = await axios.get(
      `https://api.shrtco.de/v2/shorten?url=${actualShareUrl}`
    );
    setShortLink(getLink?.data?.result?.full_short_link);
  };

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(shortLink);
      dispatch(notify("success", "URL copied to clipboard"));
    } catch (err) {
      dispatch(notify("error", "Failed to copy Share URL"));
      console.error("Failed to copy: ", err);
    }
  };
  const shareModal = () => {
    return (
      <div
        id="shareModal"
        class="modal fade crt-skill"
        role="dialog"
        data-backdrop="static"
        data-keyboard="false"
      >
        <div class="modal-dialog ">
          <div class="modal-content crt-content ">
            <div className="modal-header">
              <h4 className="modal-title">Share </h4>

              <button type="button" class="close" data-dismiss="modal">
                ×
              </button>
            </div>

            <div class="modal-body">
              {/* Social Share Buttons */}
              <div className="form-contain text-center">
                <div className="flex-social">
                  <FacebookShareButton
                    url={shortLink}
                    quote={"abc"}
                    hashtag={skill?.SKILL_NAME}
                    description={skill?.description}
                    className=""
                  >
                    <FacebookIcon size={32} round />
                  </FacebookShareButton>

                  <LinkedinShareButton
                    url={shortLink}
                    title={skill?.SKILL_NAME}
                    summary={skill?.description}
                    className=""
                  >
                    <LinkedinIcon size={32} round />
                  </LinkedinShareButton>

                  <WhatsappShareButton
                    url={shortLink}
                    title={skill?.SKILL_NAME}
                    separator={skill?.description}
                    className=""
                  >
                    <WhatsappIcon size={32} round />
                  </WhatsappShareButton>

                  <TwitterShareButton
                    url={shortLink}
                    title={skill?.SKILL_NAME}
                    className=""
                  >
                    <TwitterIcon size={32} round />
                  </TwitterShareButton>
                </div>

                {/* Copy to Clipboard option */}
                <div>
                  <button
                    className="btn btn-primary"
                    onClick={() => copyText()}
                  >
                    Copy to clipboard
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <React.Fragment>
      {shareModal()}

      {skill?.TEMPLATE === "UserDocumentation" ? (
        <button
          className="sm-btn"
          data-toggle="modal"
          data-target="#shareModal"
          disabled={skill?.RAW_DATA?.actions?.length ? "" : "disable"}
        >
          <img src={shareIcon} />
          <span>Share</span>
        </button>
      ) : (
        <>
          {skill?.status === "approved" ? (
            <>
              <button
                className="sm-btn"
                data-toggle="modal"
                data-target="#shareModal"
              >
                <img src={shareIcon} />
                <span>Share</span>
              </button>
            </>
          ) : null}
        </>
      )}
    </React.Fragment>
  );
};

export default ShareComponent;
