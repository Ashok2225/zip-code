import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import CodeEditor from "@uiw/react-textarea-code-editor";

const TechnologyConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("");
  const [code, setCode] = useState("");
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();

      obj.actionType = "TECHNOLOGY";
      obj.key = "javascript";
      obj.label = "javascript";
      obj.code = code;
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
    setCode(node?.code);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <Form.Item name="code" label="Code" rules={[{ required: true }]}>
              {/* <Input /> */}
              <CodeEditor
                value={code}
                language="js"
                placeholder="Please enter JS code."
                onChange={(evn) => setCode(evn.target.value)}
                padding={15}
                style={{
                  fontSize: 12,
                  backgroundColor: "#f5f5f5",
                  fontFamily:
                    "ui-monospace,SFMono-Regular,SF Mono,Consolas,Liberation Mono,Menlo,monospace",
                }}
              />
            </Form.Item>
          </Form>
          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Encapsulates java script code blocks.</li>
      </ul>
    </div>
  );
};
export default TechnologyConfig;
