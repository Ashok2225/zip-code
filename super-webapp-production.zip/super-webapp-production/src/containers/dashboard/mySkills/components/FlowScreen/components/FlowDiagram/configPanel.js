import React, { useContext, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import captureXpathIcon from "../../../../../../../images/capture-xpath.png";

import Zoom from "react-medium-image-zoom";

const { Option } = Select;

const ConfigForm = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();

  const [editManual, setEditManual] = useState(false);
  const [nodeData, setNodeData] = useState(null);
  const [flowVar, setFlowVar] = useState([]);
  const [form] = Form.useForm();
  const skill = useSelector((state) => state.skillReducer.trainDraft);

  const toggleField = () => {
    setEditManual(!editManual);
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      nodes = findAndUpdate(nodes, nodeData.id, { data: values });
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: nodes },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  const xPathHandler = (evt) => {
    const xPath = evt.detail.xPath;
    form.setFieldsValue({
      actual: xPath,
    });
  };

  const captureXpath = (nodeId) => {
    toggleField();
    window?.chrome?.runtime.sendMessage(process.env.REACT_APP_CHROME_TAB_ID, {
      type: "captureXPath",
      nodeId: nodeId,
    });
  };

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          [
            "branch",
            "condition",
            "loop",
            "loop-nodes",
            "try",
            "try-catch-node",
          ].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  useEffect(() => {
    document.addEventListener('capturedXPath', xPathHandler)
    return (() => {
      console.log('[Unmounting]')
      document.removeEventListener('capturedXPath', xPathHandler, true)
    })
  }, [])

  useEffect(() => {
    setNodeData(node);
  }, [node]);

  useEffect(() => {
    if (skill?.FORMATED_DATA?.variables) {
      mergeVar(skill?.FORMATED_DATA?.variables);
    }
  }, [skill?.FORMATED_DATA?.variables]);

  const mergeVar = (allVar) => {
    let _mergedData = [];
    Object.entries(allVar).forEach(([key, value]) => {
      _mergedData.push(value);
    });
    if (flowVariables.length > 0) {
      _mergedData.map((ele) => {
        flowVariables.map((f) => {
          if (ele.id === f.id) {
            ele["xPath"] = f.xPath;
          }
          return;
        });
      });
    }
    setFlowVar(_mergedData);
  };
  const handleChange = (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["numberOnly"] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData.data}>
            <div>
              <p>
                Select Source Field Or{" "}
                {editManual ? (
                  <a
                    onClick={() => {
                      toggleField();
                    }}
                  >
                    {" "}
                    Select from Dropdpwn{" "}
                  </a>
                ) : (
                  <Button
                    className="capture-btn"
                    onClick={() => {
                      captureXpath(nodeData.id);
                    }}
                    icon={
                      <img
                        style={{ margin: "0px 10px 0px 0px" }}
                        src={captureXpathIcon}
                      ></img>
                    }
                  >
                    {" "}
                    Capture Field{" "}
                  </Button>
                )}
              </p>
            </div>
            <div class="ant-col ant-form-item-label">
              <label
                for="actual"
                class="ant-form-item-required"
                title=" Source"
              >
                {" "}
                Source
              </label>
              <Checkbox
                onChange={(e) => handleChange(e)}
                checked={nodeData?.numberOnly}
              >
                {" "}
                Extract Number Only{" "}
              </Checkbox>
            </div>
            {!editManual ? (
              <Form.Item
                name="actual"
                // label=" Source"
                rules={[{ required: true }]}
              >
                <Select style={{ width: 120 }}>
                  {flowVar.map((ele, i) => {
                    return (
                      <Option
                        className="custom-select"
                        key={i}
                        value={
                          ele.xPath
                            ? ele.xPath
                            : ele.defaultValue
                            ? ele.defaultValue
                            : "`" + ele.name + "`"
                        }
                      >
                        <p>{ele.name}</p>
                        <Zoom>
                          <div className="img-thumb">
                            <img src={ele?.pageScreenshot} />
                          </div>
                        </Zoom>
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            ) : (
              <Form.Item
                name="actual"
                // label=" Source"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
            )}

            <Form.Item
              name="operators"
              label="Condition"
              rules={[{ required: true }]}
            >
              <Select style={{ width: 120 }}>
                <Option value="equal">Equal to</Option>
                <Option value="not-equal">Not Equal to</Option>
                <Option value="greater-than">Greater than</Option>
                <Option value="less-than">Less than</Option>
                <Option value="greater-than-or-equal">
                  Greater than or Equal to
                </Option>
                <Option value="less-than-or-equal">
                  Less than or Equal to
                </Option>
                <Option value="contains">Contains</Option>
                <Option value="not-contains"> Does not Contains</Option>
              </Select>
            </Form.Item>

            <Form.Item
              name="expected"
              label="Target Value"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Add a branched IF/ELSE condition to the skill</li>
      </ul>
    </div>
  );
};

export default ConfigForm;
