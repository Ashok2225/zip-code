import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import captureXpathIcon from "../../../../../../../images/capture-xpath.png";

const ReadTableConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };
  const handleSubmit = async () => {
    try {
      let obj = {};
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      obj.colName = values.colName;
      obj.variableName = values.variableName;
      obj.xpath = values.xpath;
      obj.iframe_name = values.iframe_name;

      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );

      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  const xPathHandler = (evt) => {
    const xPath = evt.detail.xPath;
    form.setFieldsValue({
      xpath: xPath,
    });
  };

  const captureXpath = (nodeId) => {
    window?.chrome?.runtime.sendMessage(process.env.REACT_APP_CHROME_TAB_ID, {
      type: "captureXPath",
      nodeId: nodeId,
    });
  };

  useEffect(() => {
    document.addEventListener("capturedXPath", xPathHandler);
    return () => {
      console.log("[Unmounting]");
      document.removeEventListener("capturedXPath", xPathHandler, true);
    };
  }, []);

  useEffect(() => {
    setNodeData(node);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <div>
              <p>
                <Button
                  className="capture-btn"
                  onClick={() => {
                    captureXpath(nodeData.id);
                  }}
                  icon={
                    <img
                      style={{ margin: "0px 10px 0px 0px" }}
                      src={captureXpathIcon}
                    ></img>
                  }
                >
                  {" "}
                  Capture Table{" "}
                </Button>
              </p>
            </div>
              <Form.Item
              name="xpath"
              label="Table xpath"
              rules={[{ required: true }]}
            >
              <Input defaultValue={nodeData.xpath} />
            </Form.Item>
            <Form.Item
              name="iframe_name"
              label="IFrame name if table is in IFrame"
              help="Eg: mainFrame"
            >
              <Input defaultValue={nodeData.iframe_name} />
            </Form.Item>
            <Form.Item
              name="colName"
              label="Column Name"
              help="Eg: District"
              rules={[{ required: true }]}
            >
              <Input defaultValue={nodeData.colName} />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="VariableName"
              rules={[{ required: true }]}
            >
              <Input defaultValue={nodeData.variableName} />
            </Form.Item>
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Reads column data from a specified table and inputs into a list type variable.</li>
      </ul>
    </div>
  );
};

export default ReadTableConfig;