import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox, Dropdown } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import TextArea from "antd/lib/input/TextArea";
import { action } from "../../../../../CreateTemplateStudio/components/TemplateMapper/ManageActions";

const SendMailConfigForm = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [currentAction, setCurrentAction] = useState({});
  const [actionType, setActionType] = useState("");
  const [folder, setFolder] = useState("");

  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleTypeChange = (e) => {
    if (e.target.value === "SEND_OUTLOOK_MAIL") {
      //nodeData[""] = [{ key: "", value: "" }]
      setCurrentAction(nodeData);
    }

    if (e.target.value === "OUTLOOK_GET_MAIL") {
      //nodeData[""] = []
      setCurrentAction(nodeData);
    }
    if (e.target.value === "SAVE_ATTACHMENT") {
      setCurrentAction(nodeData);
    }
    setActionType(e.target.value);
  };

  const handleGetFolder = async (e) => {
    const values = await form.validateFields();
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["folder"] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleMarkAsRead = (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData["markAsRead"] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleChange = async (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData.folder = e.target.value;
    setFolder(e.target.value);
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleMailType = (e) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData.mailType = e.target.value;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      if (actionType === "SEND_OUTLOOK_MAIL") {
        //nodeData.actionType = "SEND_OUTLOOK_MAIL";
        obj.actionType = "SEND_OUTLOOK_MAIL";
        obj.cc = values.cc ? values.cc : "";
        obj.body = values.body ? values.body : "";
        obj.bcc = values.bcc ? values.bcc : "";
        obj.subject = values.subject ? values.subject : "";
        obj.to = values.to ? values.to : "";
        obj.attachments = values.attachments ? values.attachments : "";
        nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
        let newActions = findAndUpdate(nodes, nodeData.id, obj);
        store.dispatch(
          setDraft({
            ...trainDraft,
            RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
          })
        );
        cancel();
      } else if (actionType === "OUTLOOK_GET_MAIL") {
        obj.actionType = "OUTLOOK_GET_MAIL";
        obj.key = "getMail";
        obj.label = "Get Outlook Mail";
        obj.description = "";
        obj.unRead = values.unRead ? values.unRead : "";
        obj.moveTo = values.moveTo ? values.moveTo : "";
        obj.top = values.top ? values.top : "";
        obj.folder = values.folder ? values.folder : "";
        obj.variableName = values.variableName ? values.variableName : "";
        obj.custom = values.custom ? values.custom : "";
        // nodeData["folder"] = values.folder;
        // nodeData["variableName"] = values.variableName;
        nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
        let newActions = findAndUpdate(nodes, nodeData.id, obj);
        store.dispatch(
          setDraft({
            ...trainDraft,
            RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
          })
        );
        cancel();
      } else if (actionType === "SAVE_ATTACHMENT") {
        obj.actionType = "SAVE_ATTACHMENT";
        obj.filePath = values.filePath;
        obj.mailObject = values.mailObject;
        obj.label = "Save Attachment";
        obj.description = "";
        nodeData["mailType"] = nodeData.mailType
          ? nodeData.mailType
          : "outlook";
        nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
        let newActions = findAndUpdate(nodes, nodeData.id, obj);
        store.dispatch(
          setDraft({
            ...trainDraft,
            RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
          })
        );
        cancel();
      }
    } catch (error) {
      console.log("form error");
    }
  };
  const renderActionFields = (type) => {
    switch (type) {
      case "SEND_OUTLOOK_MAIL":
        return (
          <div>
            <Form form={form} initialValues={nodeData}>
              <Form.Item name="to" label="To" rules={[{ required: true }]}>
                <Input />
              </Form.Item>

              <Form.Item name="cc" label="CC">
                <Input />
              </Form.Item>

              <Form.Item name="bcc" label="BCC">
                <Input />
              </Form.Item>

              <Form.Item
                name="subject"
                label="Subject"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>

              <Form.Item name="body" label="Body" rules={[{ required: true }]}>
                <TextArea />
              </Form.Item>

              <Form.Item
                name="attachments"
                label="Attachments"
                help="Eg: D:\myFolder\test.csv"
              >
                <Input />
              </Form.Item>
            </Form>
          </div>
        );
      case "OUTLOOK_GET_MAIL":
        return (
          <div>
            <Form.Item
              name="folder"
              label="Folder"
              rules={[{ required: true }]}
            >
              <Radio.Group
                onChange={(e) => handleChange(e, "folder")}
                checked={nodeData.folder}
              >
                <Radio value={"Inbox"}>Inbox</Radio>
                <Radio value={"Sent Items"}>Sent Items</Radio>
                <Radio value={"custom"}>Custom</Radio>
                <Radio value={"Deleted Items"}>Deleted Items</Radio>
              </Radio.Group>
            </Form.Item>
            {folder === "custom" || nodeData?.folder === "custom" ? (
              <Form.Item
                name="custom"
                label="Custom"
                help="Eg: Folder Name"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
            ) : null}
            <Form.Item name="unRead" label="UnRead" help="Eg: true or false">
              <Input />
            </Form.Item>
            <Checkbox
              onChange={(e) => handleMarkAsRead(e, "markAsRead")}
              checked={nodeData.markAsRead}
              rules={[{ required: true }]}
            >
              {" "}
              Mark as Read{" "}
            </Checkbox>

            <Form.Item
              name="moveTo"
              label="Move to Folder"
              help="Eg: Customer1"
            >
              <Input />
            </Form.Item>

            <Form.Item
              rules={[{ required: true }]}
              name="top"
              label="Top"
              help="Eg: 10 or 25"
            >
              <Input />
            </Form.Item>

            <Form.Item
              rules={[{ required: true }]}
              name="variableName"
              label="Enter Variable Name"
            >
              <Input />
            </Form.Item>
          </div>
        );
      case "SAVE_ATTACHMENT":
        return (
          <div>
            Save Attachment
            <Form.Item>
              <Radio.Group
                defaultValue={nodeData.mailType ? nodeData.mailType : "outlook"}
                onChange={(e) => handleMailType(e, "mailType")}
                checked={nodeData.mailType}
              >
                <Radio value={"outlook"}>Outlook</Radio>
                <Radio value={"Imap/pop3"}>IMAP/POP3</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item
              rules={[{ required: true }]}
              name="filePath"
              label="Folder Path to Save Attachment"
              help="Eg: D:\myFolder `variableName`"
            >
              <Input />
            </Form.Item>
            <Form.Item
              rules={[{ required: true }]}
              name="mailObject"
              label="Mail Object"
              help="Eg: mail[index]"
            >
              <Input />
            </Form.Item>
          </div>
        );
    }
  };
  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form className="" form={form} initialValues={nodeData}>
            <div className="ant-row ant-form-item">
              <label className="ant-form-item-required">
                Select action type
              </label>
              <div className="ant-col ant-form-item-control">
                <select
                  className="ant-input"
                  style={{ padding: "10px" }}
                  value={actionType}
                  onChange={(e) => handleTypeChange(e)}
                >
                  <option>Select</option>
                  <option value="SEND_OUTLOOK_MAIL">Send Outlook Mail</option>
                  <option value="OUTLOOK_GET_MAIL">Get Outlook Mail</option>
                  <option value="SAVE_ATTACHMENT">Save Attachment</option>
                </select>
              </div>
            </div>

            {renderActionFields(actionType)}
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        {(() => {
          if (actionType === "SEND_OUTLOOK_MAIL") {
            return (
              <li>
                Sends email from an outlook mailbox based on the given
                parameters.
              </li>
            );
          } else if (actionType === "OUTLOOK_GET_MAIL") {
            return (
              <li>
                Reads email from an outlook mailbox based on the given filter
                parameters.
              </li>
            );
          } else if (actionType === "SAVE_ATTACHMENT") {
            return (
              <li>Stores an outlook email attachment to the given folder.</li>
            );
          } else {
            return <li>Performs various actions on Outlook email.</li>;
          }
        })()}
      </ul>
    </div>
  );
};

export default SendMailConfigForm;
