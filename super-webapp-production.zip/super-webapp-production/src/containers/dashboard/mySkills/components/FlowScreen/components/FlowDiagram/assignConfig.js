import React, { useContext, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import captureXpathIcon from "../../../../../../../images/capture-xpath.png";
import { Dropdown, Menu, Space } from "antd";
import { DownOutlined, SmileOutlined } from "@ant-design/icons";

import { Radio } from "antd";

const { Option } = Select;

const AssignConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [varType, setVarType] = useState("");
  const [assignType, setAssignType] = useState("");
  const [flowVar, setFlowVar] = useState([]);
  const [varName, setVarName] = useState("");

  const skill = useSelector((state) => state.skillReducer.trainDraft);

  const [form] = Form.useForm();
  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      nodeData["variable1"] = values.varName ? values.varName : varName;
      nodeData["formatType "] = nodeData.formatType;
      nodeData["varType"] = varType;
      if (nodeData.formatType == "text") {
        nodeData["variable2"] = values.variable2;
      } else if (nodeData.formatType == "expression") {
        nodeData["variable2"] = values.variable2;
      } else if (nodeData.formatType == "variable") {
        nodeData["variable2"] = "`" + values.variable2 + "`";
      } else if (nodeData.formatType === "stringf") {
        nodeData["variable2"] = values.variable2;
        nodeData["substr1"] = values.substr1 ? values.substr1 : "";
        nodeData["substr2"] = values.substr2 ? values.substr2 : "";
        nodeData["split1"] = values.split1 ? values.split1 : "";
        nodeData["split2"] = values.split2 ? values.split2 : "";
        nodeData["custom"] = "";
        nodeData["replace1"] = values.replace1 ? values.replace1 : "";
        nodeData["replace2"] = values.replace2 ? values.replace2 : "";
        nodeData["match"] = values.match ? values.match : "";
        nodeData["stringMethod"] = nodeData.stringMethod;
      } else if (nodeData.formatType === "datef") {
        nodeData["variable"] = values.variable;
        nodeData["dateFormat"] = values.dateFormat;
        nodeData["selectedDay"] = nodeData.selectedDay;
      }

      let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  const handlSelectVar = (varId) => {
    let value = flowVar.filter((i) => i.id === varId);
    let _variableName = value[0]?.name;
    let _variableType = value[0]?.type;
    setNodeData({ ...nodeData, variable1: _variableName });
    setVarType(_variableType);
    setVarName(_variableName);
  };
  const handleDrop = (value) => {
    setVarType(value);
  };

  const onRadioChange = (e) => {
    setNodeData({ ...nodeData, formatType: e.target.value });
  };
  const onRadioChangeAssignOption = (e) => {
    setNodeData({ ...nodeData, useVar: e.target.value });
  };

  const handleAssignChange = (e) => {
    setNodeData({ ...nodeData, varName: e.target.value });
  };

  const handleStringFormatChange = (value) => {
    setNodeData({ ...nodeData, stringMethod: value });
  };

  const handleDateChange = (value) => {
    setNodeData({ ...nodeData, selectedDay: value });
  };

  const getViewOnSourceType = (type) => {
    switch (type) {
      case "stringf":
        return (
          <React.Fragment>
            <div className="string-format">
              <div
                className="string-format-options"
                style={{ margin: "10px 0px" }}
              >
                <Select
                  className="ant-dt-drop"
                  style={{
                    width: "100%",
                  }}
                  onChange={handleStringFormatChange}
                  defaultValue={nodeData.stringMethod}
                >
                  <Option value="">Select Format</Option>
                  {stringFormatOptions.map((option, index) => (
                    <Option key={index} value={option.key}>
                      {option.label}
                    </Option>
                  ))}
                </Select>
              </div>
            </div>

            {getInputFormatView(nodeData.stringMethod)}
          </React.Fragment>
        );
      case "datef":
        return (
          <React.Fragment>
            <div className="string-format">
              <div
                className="string-format-options"
                style={{ margin: "10px 0px" }}
              >
                <Select
                  className="ant-dt-drop"
                  style={{
                    width: "100%",
                  }}
                  onChange={handleDateChange}
                  defaultValue={nodeData.selectedDay}
                >
                  <Option value="">Select Date</Option>
                  <Option value={-1}>Yesterday</Option>
                  <Option value={0}>
                    <em>Today</em>
                  </Option>
                  <Option value={1}>Tomorrow</Option>
                  <Option value={"wsd"}>Week Start Date</Option>
                  <Option value={"msd"}>Month Start Date</Option>
                  <Option value={"qsd"}>Quarter Start Date</Option>
                  <Option value={"ytd"}>Year Start Date</Option>
                </Select>
              </div>
            </div>
            <Form.Item
              name="dateFormat"
              rules={[{ required: true }]}
              help="Eg {dd}/{MM}/{yyyy}"
            >
              <Input />
            </Form.Item>
            <div style={{ margin: "15px" }}>
              <p className="headings">
                Date formats<i>(Case Sensitive):</i>
              </p>
              <table style={{ margin: "15px" }}>
                <tbody>
                  <tr>
                    <td>d</td>
                    <td>Day of the month without leading zero (1 – 31)</td>
                  </tr>
                  <tr>
                    <td>dd</td>
                    <td>Day of the month with leading zero (01 – 31)</td>
                  </tr>
                  <tr>
                    <td>ddd</td>
                    <td>Abbreviated name for the day of the week (e.g. Mon)</td>
                  </tr>
                  <tr>
                    <td>dddd</td>
                    <td>Full name for the day of the week (e.g. Monday)</td>
                  </tr>
                  <tr>
                    <td>M</td>
                    <td>Month without leading zero (1 – 12)</td>
                  </tr>
                  <tr>
                    <td>MM</td>
                    <td>Month with leading zero (01 – 12)</td>
                  </tr>
                  <tr>
                    <td>MMM</td>
                    <td>Abbreviated month name (e.g. Jan)</td>
                  </tr>
                  <tr>
                    <td>MMMM</td>
                    <td>Full month name (e.g. January)</td>
                  </tr>
                  <tr>
                    <td>y</td>
                    <td>Year without century, without leading zero (0 – 99)</td>
                  </tr>
                  <tr>
                    <td>yy</td>
                    <td>Year without century, with leading zero (00 – 99)</td>
                  </tr>
                  <tr>
                    <td>yyyy</td>
                    <td>Year with century. For example: 2005</td>
                  </tr>
                </tbody>
              </table>
              <p className="headings">
                Time formats<i>(Case Sensitive):</i>
              </p>
              <table>
                <tbody>
                  <tr>
                    <td>h</td>
                    <td>Hours without leading zero; 12-hour format (1 – 12)</td>
                  </tr>
                  <tr>
                    <td>hh</td>
                    <td>Hours with leading zero; 12-hour format (01 – 12)</td>
                  </tr>
                  <tr>
                    <td>H</td>
                    <td>Hours without leading zero; 24-hour format (0 – 23)</td>
                  </tr>
                  <tr>
                    <td>HH</td>
                    <td>Hours with leading zero; 24-hour format (00 – 23)</td>
                  </tr>
                  <tr>
                    <td>m</td>
                    <td>Minutes without leading zero (0 – 59)</td>
                  </tr>
                  <tr>
                    <td>mm</td>
                    <td>Minutes with leading zero (00 – 59)</td>
                  </tr>
                  <tr>
                    <td>s</td>
                    <td>Seconds without leading zero (0 – 59)</td>
                  </tr>
                  <tr>
                    <td>ss</td>
                    <td>Seconds with leading zero (00 – 59)</td>
                  </tr>
                  <tr>
                    <td>t</td>
                    <td>
                      Single character time marker, such as A or P (depends on
                      locale)
                    </td>
                  </tr>
                  <tr>
                    <td>tt</td>
                    <td>
                      Multi-character time marker, such as AM or PM (depends on
                      locale)
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </React.Fragment>
        );
      case "variable":
        return (
          <Form.Item
            name="variable2"
            rules={[{ required: true }]}
            help="Eg variablename or Hello world"
          >
            <Input />
          </Form.Item>
        );
      case "text":
        return (
          <Form.Item
            name="variable2"
            rules={[{ required: true }]}
            help="Eg variablename or Hello world"
          >
            <Input />
          </Form.Item>
        );
      case "expression":
        return (
          <Form.Item
            name="variable2"
            rules={[{ required: true }]}
            help="Eg variablename or Hello world"
          >
            <Input />
          </Form.Item>
        );
    }
  };

  useEffect(() => {
    setNodeData(node);
    setVarType(node.varType);
  }, [node]);

  useEffect(() => {
    mergeVar(skill?.FORMATED_DATA?.variables);
  }, [skill?.FORMATED_DATA?.variables]);

  const mergeVar = (allVar) => {
    let _mergedData = [];
    allVar &&
      Object.entries(allVar).forEach(([key, value]) => {
        _mergedData.push(value);
      });
    if (flowVariables.length > 0) {
      _mergedData.map((ele) => {
        flowVariables?.map((f) => {
          if (ele.id === f.id) {
            ele["xPath"] = f.xPath;
          }
          return;
        });
      });
    }
    setFlowVar(_mergedData);
  };

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <div style={{ marginBottom: "15px" }}>
              <Radio.Group
                onChange={onRadioChangeAssignOption}
                defaultValue={nodeData?.useVar}
              >
                <Radio value="createVar">create variable</Radio>
                <Radio value="useVar">Use variable</Radio>
              </Radio.Group>
              {nodeData?.useVar === "useVar" ? (
                <React.Fragment>
                  <Select
                    className="ant-dt-drop"
                    style={{
                      width: "100%",
                    }}
                    onChange={handlSelectVar}
                    defaultValue={varName ? varName : nodeData?.variable1}
                  >
                    {flowVar?.map((ele, i) => {
                      return (
                        <Option
                          className="custom-select"
                          key={i}
                          value={ele.id}
                        >
                          <p>{ele.name}</p>
                        </Option>
                      );
                    })}
                  </Select>
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <Select
                    className="ant-dt-drop"
                    style={{
                      width: "100%",
                    }}
                    onChange={handleDrop}
                    defaultValue={nodeData.varType}
                  >
                    <Option value="">Select Type</Option>
                    <Option value="number">number</Option>
                    <Option value="string">string</Option>
                    <Option value="list">list</Option>
                    <Option value="dataTable">dataTable</Option>
                  </Select>
                </React.Fragment>
              )}
            </div>
            {nodeData?.useVar === "useVar" ? null : (
              <React.Fragment>
                <Form.Item
                  name="varName"
                  label="Assign"
                  rules={[{ required: true }]}
                  help="Eg variablename"
                  onChange={handleAssignChange}
                >
                  <Input defaultValue={node.variable1} />
                </Form.Item>
              </React.Fragment>
            )}

            <p style={{ textAlign: "center" }}>=</p>

            <div style={{ marginBottom: "15px" }}>
              <Radio.Group
                onChange={onRadioChange}
                defaultValue={nodeData.formatType}
              >
                <Radio value="text">Text</Radio>
                <Radio value="variable">Variable</Radio>
                <Radio value="expression">Expression</Radio>
                <Radio value="stringf">String</Radio>
                <Radio value="datef">Date</Radio>
              </Radio.Group>
            </div>

            {getViewOnSourceType(nodeData.formatType)}
          </Form>

          <div className="drawer-btns">
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        {(() => {
          if (varType === "number") {
            return (
              <li>
                Assign a number type value(s) to respective skill field(s).
              </li>
            );
          } else if (varType === "string") {
            return (
              <li>
                Assign a string type value(s) to respective skill field(s).
              </li>
            );
          } else if (varType === "list") {
            return (
              <li>Assign a list type value(s) to respective skill field(s).</li>
            );
          } else if (varType === "dataTable") {
            return (
              <li>
                Assign a dataTable type value(s) to respective skill field(s).
              </li>
            );
          } else if (varType === "") {
            return <li>Assigns value(s) to respective skill field(s).</li>;
          } else {
            return null;
          }
        })()}
      </ul>
    </div>
  );
};

const getInputFormatView = (type) => {
  switch (type) {
    case "substring":
      return (
        <React.Fragment>
          <Form.Item
            name="substr1"
            label="Start Index"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>

          <Form.Item name="substr2" label="End Index (Optional)">
            <Input />
          </Form.Item>
          <Form.Item
            name="variable2"
            rules={[{ required: true }]}
            help="Eg variablename"
          >
            <Input />
          </Form.Item>
        </React.Fragment>
      );

    case "replace":
      return (
        <React.Fragment>
          <Form.Item
            name="replace1"
            label="String or regular expression"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name="replace2"
            label="String to be replaced"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="variable2"
            label="Variable Name"
            rules={[{ required: true }]}
            help="Eg variablename "
          >
            <Input />
          </Form.Item>
        </React.Fragment>
      );

    case "match":
      return (
        <React.Fragment>
          <Form.Item
            name="match"
            label="Your Regular Expression Pattern"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="variable2"
            label="Variable Name"
            rules={[{ required: true }]}
            help="Eg variablename "
          >
            <Input />
          </Form.Item>
        </React.Fragment>
      );

    case "split":
      return (
        <React.Fragment>
          <Form.Item
            name="split1"
            label="String or regular expression"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>

          <Form.Item name="split2" label="limit (Optional)">
            <Input />
          </Form.Item>
          <Form.Item
            name="variable2"
            label="Variable Name"
            rules={[{ required: true }]}
            help="Eg variablename "
          >
            <Input />
          </Form.Item>
        </React.Fragment>
      );

    default:
      return (
        <React.Fragment>
          <Form.Item
            name="variable2"
            label="Variable Name"
            rules={[{ required: true }]}
            help="Eg variablename "
          >
            <Input />
          </Form.Item>
        </React.Fragment>
      );
  }
};

const stringFormatOptions = [
  {
    label: "Sub String",
    key: "substring",
    description:
      "The substring() method returns the part of the string between the start and end indexes, or to the end of the string.",
  },
  {
    label: "Replace",
    key: "replace",
    description:
      "The replace() method returns a new string with some or all matches of a pattern replaced by a replacement. The pattern can be a string or a RegExp, and the replacement can be a string or a function to be called for each match. If pattern is a string, only the first occurrence will be replaced.",
  },
  {
    label: "Match",
    key: "match",
    description:
      "The match() method retrieves the result of matching a string against a regular expression.",
  },
  {
    label: "Split",
    key: "split",
    description:
      "The split() method splits a String object into an array of strings by separating the string into substrings, using a specified separator string to determine where to make each split.",
  },
  {
    label: "Trim",
    key: "trim",
    description:
      "The trim() method removes whitespace from both ends of a string. Whitespace in this context is all the whitespace characters (space, tab, no-break space, etc.) and all the line terminator characters (LF, CR, etc.).",
  },
  {
    label: "ToUpperCase",
    key: "toUpperCase",
    description:
      "The toUpperCase() method converts the specified to string to upper case (LF, CR, etc.).",
  },
  {
    label: "ToLowerCase",
    key: "toLowerCase",
    description:
      "The toLowerCase() method convets the specified string into lower case.",
  },
];

export default AssignConfig;
