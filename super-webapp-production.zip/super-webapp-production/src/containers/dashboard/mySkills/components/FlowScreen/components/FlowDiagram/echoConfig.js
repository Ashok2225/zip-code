import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import { values } from "underscore";

const EchoConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("");
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleChange = async (e) => {
    const values = await form.validateFields();
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData.selector = e.target.value;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      obj.actionType = "ECHO";
      obj.key = "echo";
      obj.label = "Echo";
      obj.string = values.string ? values.string : "";
      obj.variable = values.variable ? values.variable : "";
      obj.custom = values.custom ? values.custom : "";
      nodeData["selector"] = values.selector;
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <Form.Item
              name="selector"
              label="Echo"
              rules={[{ required: true }]}>
              <Radio.Group
                onChange={(e) => handleChange(e, "selector")}
                checked={nodeData.selector}
              >
                <Radio value={"string"}>String</Radio>
                <Radio value={"variable"}>Variable</Radio>
                <Radio value={"custom"}>Custom</Radio>
              </Radio.Group>
            </Form.Item>
            {nodeData.selector === "string" ?
              <Form.Item
                name="string"
                label="Text"
                help="Eg: Hello World"
              >
                <Input />
              </Form.Item> : nodeData.selector === "variable" ?
                <Form.Item
                  name="variable"
                  label="Variable Name"
                  help="Eg: Hello World OR `variableName`"
                >
                  <Input />
                </Form.Item> : nodeData.selector === "custom" ?
                  <Form.Item
                    name="custom"
                    label="Expression"
                    help="Eg: Hello World OR `variableName`"
                  >
                    <Input />
                  </Form.Item> : null}
          </Form>
          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
      <li>Displays the given statement(s) in the log file.</li>
      </ul>
    </div>
  );
};
export default EchoConfig;
