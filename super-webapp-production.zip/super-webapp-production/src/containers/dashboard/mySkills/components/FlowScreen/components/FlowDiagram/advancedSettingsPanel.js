import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Button, Input, Checkbox } from "antd";
import $ from "jquery";

import {
  setSecret,
  addGetSecretAction,
} from "../../../../../../../redux/actions/azure";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import imageIcon from "../../../../../../../images/image-pic.png";
import { getFileUrl } from "../../../../../../../redux/actions/fileUpload";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";

let url = null;
const AdvancedConfigForm = ({
  data,
  updateConfig,
  addGetSecretAction: add,
}) => {
  // const [form] = Form.useForm();
  const [fieldData, setFieldData] = useState({
    record: null,
    mandatory_fields: [],
    optional_fields: [],
    default_values: [],
  });
  const skill = useSelector((state) => state.skillReducer.trainDraft);

  const [errors, setErrors] = useState({});
  const [secretCheck, setSecretCheck] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setFieldData(data);
    try {
      if (data.record.textType === "secret") {
        setSecretCheck(true);
      }
    } catch (err) {}
  }, [data]);

  const validateFields = (fields, requiredFields) => {
    let errors = {};
    requiredFields.forEach((i) => {
      if (!Boolean(fields[i].length)) {
        errors[i] = true;
      }
    });
    return errors;
  };

  const findAndUpdate = (arr, id, payload) => {
    console.log(arr, "dsdhg");
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          [
            "branch",
            "condition",
            "loop",
            "loop-nodes",
            "try",
            "try-catch-node",
          ].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    console.log("here");
    let {
      skillReducer: { trainDraft },
    } = store.getState();
    let result;
    setIsLoading(true);
    if (secretCheck) {
      result = await storeInVault(data.record.text);

      trainDraft = result?.draft;
    }
    let payload = {};
    let form = $("#advanceConfigPanel");
    let _formData = form.serializeArray();
    _formData.forEach((i) => (payload[i.name] = i.value));
    Object.assign(payload, result?._secretKey);
    let errors = validateFields(payload, [...data.mandatory_fields]);
    if (!$.isEmptyObject(errors)) {
      setErrors(errors);
      setIsLoading(false);
    } else {
      if (url !== null) {
        payload.imgSelector = url;
      }
      let newActions = findAndUpdate(
        trainDraft?.RAW_DATA?.actions,
        fieldData?.record?.id,
        payload
      );

      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      updateConfig(payload, data.record.id);
    }
  };

  const storeInVault = async (secretValue) => {
    const result = await setSecret(secretValue);
    if (result.status) {
      let _secretKey = {
        text: `\`${result.data.secretName}\``,
        textType: "secret",
      };

      let draft = add(data.record.id, result.data.secretName);
      return { _secretKey, draft };
    }
  };

  return (
    <div>
      <form id="advanceConfigPanel">
        {fieldData.mandatory_fields.map((field, index) => {
          return (
            <div
              key={`${field}-${fieldData.record.id}`}
              style={{ marginBottom: 15 }}
            >
              <div className="ant-form-item-label">
                <label>
                  {field.toUpperCase()} <span style={{ color: "red" }}>*</span>{" "}
                </label>
                {field == "text" ? (
                  <Checkbox
                    checked={secretCheck}
                    disabled={secretCheck === true}
                    onChange={(e) => setSecretCheck(e.target.checked)}
                  >
                    Store in Vault
                  </Checkbox>
                ) : null}
              </div>
              <Input
                name={field}
                label={field.toUpperCase()}
                defaultValue={fieldData?.record?.[field]}
                disabled={fieldData?.record?.textType === "secret"}
              ></Input>
              {errors[field] ? (
                <span style={{ color: "red", fontSize: 12 }}>
                  {" "}
                  {field} field is mandatory *
                </span>
              ) : null}
            </div>
          );
        })}

        {fieldData.optional_fields.map((field, index) => {
          return (
            <div
              key={`${field}-${fieldData.record.id}`}
              style={{ marginBottom: 15 }}
            >
              <div className="ant-form-item-label">
                <label>{field.toUpperCase()} </label>
              </div>
              <Input
                name={field}
                label={field.toUpperCase()}
                defaultValue={fieldData?.record?.[field]}
              ></Input>
              {errors[field] ? (
                <span style={{ color: "red", fontSize: 12 }}>
                  {" "}
                  {field} is mandatory *
                </span>
              ) : null}
            </div>
          );
        })}

        {fieldData.default_values.map((field, index) => {
          return (
            <div
              key={`${field}-${fieldData.record.id}`}
              style={{ marginBottom: 15 }}
            >
              <div className="ant-form-item-label">
                <label>{field.toUpperCase()} </label>
              </div>
              <Input
                name={field}
                label={field.toUpperCase()}
                defaultValue={fieldData?.record?.[field]}
              ></Input>
              {errors[field] ? (
                <span style={{ color: "red", fontSize: 12 }}>
                  {" "}
                  {field} is mandatory *
                </span>
              ) : null}
            </div>
          );
        })}
        {fieldData.record?.origin ? (
          <div className="rth-upload">
            <div className="upload-btn-wrapper">
              <button class="btn btn-rth-upload">
                <img src={imageIcon} />
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    updateImage(e.target.files[0]);
                  }}
                ></input>
              </button>
            </div>
          </div>
        ) : (
          ""
        )}
      </form>

      <div>
        <Button type="primary" onClick={handleSubmit}>
          {isLoading ? <div class="sp sp-circle text-light"></div> : "Save"}
        </Button>
      </div>
    </div>
  );
};

const updateImage = async (file) => {
  url = await store.dispatch(getFileUrl(file));
};

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    addGetSecretAction,
  })
)(AdvancedConfigForm);
