import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import { colorcodes } from "../../../../../../../utility/colorCodes";
import { v4 as uuid } from "uuid";
import DeleteIcon from "@material-ui/icons/Delete";
import IconButton from "@material-ui/core/IconButton";

const { Option } = Select;

const ExcelConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("readfile");
  const [form] = Form.useForm();
  const [getRangeOptions, setGetRangeOptions] = useState({
    excludeHeaders: false,
    values: false,
    textFormat: false,
  });

  //  const [nodeData, setNodeData] = useState({});

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      
      if (actionType === "OPEN_SPREADSHEET") {
        nodeData.actionType = "OPEN_SPREADSHEET";
        nodeData["filePath"] = values.filePath;
      } else if (actionType === "GET_SHEET_NAMES") {
        nodeData.actionType = "GET_SHEET_NAMES";
        nodeData["filePath"] = values.filePath;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "GET_COLUMN") {
        nodeData.actionType = "GET_COLUMN";
        nodeData["filePath"] = values.filePath;
        nodeData["variableName"] = values.variableName;
        nodeData["sheetName"] = values.sheetName;
        nodeData["columnAddress"] = values.columnAddress;
      } else if (actionType === "HIDE_COLUMN") {
        nodeData.actionType = "HIDE_COLUMN";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["columnAddress"] = values.columnAddress;
      } else if (actionType === "DELETE_COLUMN") {
        nodeData.actionType = "DELETE_COLUMN";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["columnAddress"] = values.columnAddress;
      } else if (actionType === "GET_ROW") {
        nodeData.actionType = "GET_ROW";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["rowNumber"] = values.rowNumber;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "DELETE_ROW") {
        nodeData.actionType = "DELETE_ROW";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["rowNumber"] = values.rowNumber;
      } else if (actionType === "GET_CELL") {
        nodeData.actionType = "GET_CELL";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["cellAddress"] = values.cellAddress;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "GET_CELL_COLOR") {
        nodeData.actionType = "GET_CELL_COLOR";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["cellAddress"] = values.cellAddress;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "WRITE_CELL") {
       
        nodeData.actionType = "WRITE_CELL";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["cellAddress"] = values.cellAddress;
        nodeData["cellValue"] = values.cellValue;
      } else if (actionType === "GET_RANGE") {
        nodeData.actionType = "GET_RANGE";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["range"] = values.range;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "WRITE_RANGE") {
        nodeData.actionType = "WRITE_RANGE";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["range"] = values.range;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "APPEND_RANGE") {
       
        nodeData.actionType = "APPEND_RANGE";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;
       
        nodeData["sheetName"] = values.sheetName;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "REFRESH_EXCEL") {
        nodeData.actionType = "REFRESH_EXCEL";
        nodeData["filePath"] = values.filePath;
      } else if (actionType === "DELETE_RANGE") {
        nodeData.actionType = "DELETE_RANGE";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["range"] = values.range;
      } else if (actionType === "GET_CELL_FORMULA") {
        nodeData.actionType = "GET_CELL_FORMULA";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["cellAddress"] = values.cellAddress;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "SET_RANGE_COLOR") {
        nodeData.actionType = "SET_RANGE_COLOR";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["range"] = values.range;
        nodeData["color"] = values.color;
      } else if (actionType === "CONVERT_XLSX") {
        nodeData.actionType = "CONVERT_XLSX";
        nodeData["sourcePath"] = values.sourcePath;

        nodeData["fileName"] = values.fileName;
        nodeData["range"] = values.range;
      } else if (actionType === "INSERT_COLUMN") {
        nodeData.actionType = "INSERT_COLUMN";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["noColumns"] = values.noColumns;
        nodeData["position"] = values.position;
      } else if (actionType === "CREATE_EXCEL") {
        nodeData.actionType = "CREATE_EXCEL";
        nodeData["filePath"] = values.filePath;

        nodeData["fileName"] = values.fileName;
      } else if (actionType === "FILTER_COLUMNS") {
        nodeData.actionType = "FILTER_COLUMNS";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;
       
        nodeData["sheetName"] = values.sheetName;
        nodeData["variableName"] = values.variableName;
      } else if (actionType === "CREATE_PIVOT_TABLE") {
        nodeData.actionType = "CREATE_PIVOT_TABLE";
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["tableRange"] = values.tableRange;
        nodeData["sheetTitle"] = values.sheetTitle;

        nodeData["pivotTable"] = nodeData.pivotTable;
      }

      else if (actionType === "SORT_EXCEL_COLUMN") {
        nodeData.actionType = "SORT_EXCEL_COLUMN";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["columnAddress"] = values.columnAddress;
        nodeData["variableName"] = values.variableName;

      }
       
      else if (actionType === "VLOOK_UP") {
        nodeData.actionType = "VLOOK_UP";
        if(values.filePath.match(/\\\\/)){
          values.filePath = values.filePath
        }
        else {
          var replacedfilePath = String.raw`${values.filePath}`.replace(/\\/g,"\\\\");
          values.filePath = replacedfilePath
        }
        nodeData["filePath"] = values.filePath;

        nodeData["sheetName"] = values.sheetName;
        nodeData["columnAddress"] = values.columnAddress;
        nodeData["columnIndex"] = values.columnIndex;
        nodeData["variableName"] = values.variableName;

      }


      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );

      cancel();
    } catch (error) {
      console.log("form error: ", error.toString());
    }
  };

  const handleTypeChange = (e) => {
    if (e.target.value === "FILTER_COLUMNS") {
      nodeData["filters"] = [{ key: "", value: "" }];
      setNodeData(nodeData);
    }

    if (e.target.value === "CREATE_PIVOT_TABLE") {
      nodeData["pivotTable"] = [];
      setNodeData(nodeData);
    }
    setActionType(e.target.value);
  };

  const handleGetRangeChecks = (e, checkKey) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    nodeData[checkKey] = e.target.checked;
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    let newActions = findAndUpdate(nodes, nodeData.id, nodeData);

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
      })
    );
  };

  const deleteFilter = (index) => {
    let { filters } = nodeData;
    filters.splice(index, 1);

    setNodeData({ ...nodeData, filters: filters });
  };

  const addFilter = (filters) => {
    filters.push({ key: "", value: "" });
    setNodeData({ ...nodeData, filters: filters });
  };

  const handleChangeFilter = (e, index, filters) => {
    filters[index] = {
      ...filters[index],
      [e.target.name]: e.target.value,
    };




    setNodeData({ ...nodeData, filters: filters });
  };

  const pivotHandleChange = (e, id) => {
    let { pivotTable } = nodeData;
    if (pivotTable && pivotTable.length > 0) {
      let table = pivotTable.map((row) => {
        if (row.id === id) {
          return {
            ...row,
            [e.target.name]: e.target.value,
          };
        } else {
          return row;
        }
      });
      setNodeData({ ...nodeData, pivotTable: table });
    }
  };

  const addClick = (e) => {
    e.preventDefault();
    let { pivotTable } = nodeData;
    let table = [
      ...pivotTable,
      { id: uuid(), name: "", type: "ROW", function: "sum" },
    ];
    setNodeData({ ...nodeData, pivotTable: table });
  };

  const removeClick = (e) => {
    e.preventDefault();
    let { pivotTable } = nodeData;
    if (pivotTable && pivotTable.length > 0) {
      pivotTable.pop();
      setNodeData({ ...nodeData, pivotTable: pivotTable });
    }
  };


  const onRadioChange = (e) => {


    setNodeData({ ...nodeData, sortType: e.target.value })


  }

  const renderActionFields = (type) => {
    switch (type) {
      case "OPEN_SPREADSHEET":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx "
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_SHEET_NAMES":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );
      case "GET_COLUMN":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="columnAddress"
              label="Column Address or Number"
              help="Eg: A or B or 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_ROW":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="rowNumber"
              label="Row Number"
              help="Eg: 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_CELL":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="cellAddress"
              label="Cell Address"
              help="Eg: A1 or B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "WRITE_CELL":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="cellAddress"
              label="Cell Address"
              help="Eg: A1 or B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="cellValue"
              label="Cell Value"
              help="Eg: NewYork or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "DELETE_ROW":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="rowNumber"
              label="Row Number"
              help="Eg: 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "HIDE_COLUMN":
      case "DELETE_COLUMN":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="columnAddress"
              label="Column Address or Number"
              help="Eg: A or B or 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_RANGE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="range"
              label="Range"
              help="Eg: A1:B2 or `variableName`"
            // rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Checkbox
              onChange={(e) => handleGetRangeChecks(e, "excludeHeaders")}
              checked={nodeData.excludeHeaders}
            >
              {" "}
              Exclude Headers
            </Checkbox>
            <Checkbox
              onChange={(e) => handleGetRangeChecks(e, "values")}
              checked={nodeData.values}
            >
              {" "}
              Values
            </Checkbox>
            <Checkbox
              onChange={(e) => handleGetRangeChecks(e, "textFormat")}
              checked={nodeData.textFormat}
            >
              {" "}
              Text Format
            </Checkbox>
            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "FILTER_COLUMNS":
        const { filters } = nodeData;

        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Checkbox
              onChange={(e) =>
                setNodeData({
                  ...nodeData,
                  includeHeaders: e.target.checked,
                })
              }
              checked={nodeData.includeHeaders}
            >
              {" "}
              Include Headers
            </Checkbox>
            <div>
              {filters
                ? filters.map((obj, index) => (
                  <div style={{ display: "flex" }}>
                    <Input
                      margin="dense"
                      variant="outlined"
                      name="key"
                      placeholder="Column Name"
                      value={obj.key}
                      onChange={(e) => handleChangeFilter(e, index, filters)}
                    />
                    <Input
                      margin="dense"
                      variant="outlined"
                      name="value"
                      placeholder="Value"
                      value={obj.value}
                      onChange={(e) => handleChangeFilter(e, index, filters)}
                    />
                    <IconButton
                      aria-label="Delete"
                      onClick={(e) => deleteFilter(index)}
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </div>
                ))
                : null}

              <Button
                onClick={(e) => addFilter(filters)}
                variant="outlined"
                color="primary"
              >
                Add
              </Button>
            </div>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "WRITE_RANGE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="range"
              label="Range"
              help="Eg: A1:B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "APPEND_RANGE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "REFRESH_EXCEL":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "DELETE_RANGE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="range"
              label="Range"
              help="Eg: A1:B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_CELL_COLOR":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="cellAddress"
              label="Cell Address"
              help="Eg: A1 or B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "GET_CELL_FORMULA":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="cellAddress"
              label="Cell Address"
              help="Eg: A1 or B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "SET_RANGE_COLOR":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="range"
              label="Range"
              help="Eg: A1:B2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item name="color" label="Color" rules={[{ required: true }]}>
              <Select
                // defaultValue=""
                style={{
                  width: 120,
                }}
              >
                {colorcodes.map((item) => (
                  <Option value={item.code}>{item.name}</Option>
                ))}
              </Select>
            </Form.Item>
          </div>
        );

      case "CONVERT_XLSX":
        return (
          <div>
            <Form.Item
              name="sourcePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="fileName"
              label="Destination File Path"
              help="Eg: D:\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

      case "INSERT_COLUMN":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="noColumns"
              label="No of Columns"
              help="Eg: 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="position"
              label="Position"
              help="Eg: 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );


      case "SORT_EXCEL_COLUMN":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="sheetName"
              label="Sheet Name"
              help="Eg:Book or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="columnAddress"
              label="Column Address"
              help="Eg: A or B or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="sortType"
              // label="Which contents to List?"
              rules={[{ required: true }]}

            >
              <Radio.Group>
                <Radio onChange={onRadioChange} value={"ascending"}>Ascending</Radio>
                <Radio onChange={onRadioChange} value={"descending"}>Descending</Radio>
              </Radio.Group>
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              help="Eg: variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>


          </div>
        );



      case "CREATE_EXCEL":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="fileName"
              label="File Name"
              help="Eg: D:\text.xlsx or variableName"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );

        case "VLOOK_UP":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="File Path (Include file name with extension)"
              help="Eg: D:\\NewFile.xlsx or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="sheetName"
              label="Enter Sheet Name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="columnAddress"
              label="Column Address or Number"
              help="Eg: A or B or 1 or 2 or `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="columnIndex"
              label="Column Index"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="variableName"
              label="Variable Name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
          </div>
        );


      case "CREATE_PIVOT_TABLE":
        return (
          <div>
            <Form.Item
              name="filePath"
              label="Enter Full Path"
              help="please give variable name as `variableName`"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="sheetName"
              label="Enter Sheet Name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="tableRange"
              label="Table Range (Optional)"
              help="Eg: R1C1:R5C3 (in this R=Row ,C= Column)"
            // rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              name="sheetTitle"
              label="Sheet Title(Optional)"
            // rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <div>
              <table style={{ width: "100%" }}>
                <tbody>
                  <tr>
                    <th>HeaderNames</th>
                    <th>HeaderAreas</th>
                    <th>Function</th>
                  </tr>

                  {nodeData.pivotTable &&
                    nodeData.pivotTable.length > 0 &&
                    nodeData.pivotTable.map((row, index) => {
                      return (
                        <tr key={index}>
                          <td>
                            <input
                              style={{ height: "20px", width: "120px" }}
                              name="name"
                              value={row.name}
                              onChange={(e) => pivotHandleChange(e, row.id)}
                            />
                          </td>
                          <td>
                            <select
                              name="type"
                              value={row.type}
                              onChange={(e) => pivotHandleChange(e, row.id)}
                            >
                              <option value="ROW">As Row</option>
                              <option value="COLUMN">As Column</option>
                              <option value="VALUES">As Values</option>
                            </select>
                          </td>
                          <td>
                            {row.type === "VALUES" ? (
                              <select
                                name="function"
                                value={row.function}
                                onChange={(e) => pivotHandleChange(e, row.id)}
                              >
                                <option value="sum">Sum</option>
                                <option value="count">Count</option>
                                <option value="max">Max</option>
                                <option value="min">Min</option>
                              </select>
                            ) : (
                              <select
                                name="function"
                                value={row.function}
                                onChange={(e) => pivotHandleChange(e, row.id)}
                                disabled
                              >
                                <option value="">None</option>
                              </select>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
                <tfoot>
                  <tr>
                    <td>
                      <button
                        style={{ margin: "8px" }}
                        onClick={(e) => addClick(e)}
                      >
                        add
                      </button>
                      <button
                        style={{ margin: "8px" }}
                        onClick={(e) => removeClick(e)}
                      >
                        remove
                      </button>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form className="" form={form} initialValues={nodeData}>
            <div className="ant-row ant-form-item">
              <label className="ant-form-item-required">
                Select action type
              </label>
              <div className="ant-col ant-form-item-control">
                <select
                  className="ant-input"
                  style={{ padding: "10px" }}
                  value={actionType}
                  onChange={(e) => handleTypeChange(e)}
                >
                  <option>Select</option>
                  {/* <option value="OPEN_SPREADSHEET">Open Spread Sheet</option> */}
                  <option value="GET_SHEET_NAMES">Get SheetNames</option>
                  <option value="GET_COLUMN">Get Column</option>
                  <option value="HIDE_COLUMN">Hide Column</option>
                  <option value="DELETE_COLUMN">Delete Column</option>
                  <option value="GET_ROW">Get Row</option>
                  <option value="DELETE_ROW">Delete Row</option>
                  <option value="GET_CELL">Get Cell</option>
                  <option value="WRITE_CELL">Write Cell</option>
                  <option value="GET_RANGE">Get Range</option>
                  <option value="WRITE_RANGE">Write Range</option>
                  <option value="APPEND_RANGE">Append Range</option>
                  <option value="FILTER_COLUMNS">Filter Columns</option>
                  <option value="GET_CELL_COLOR">Get Cell Color</option>
                  <option value="REFRESH_EXCEL">Refresh Excel</option>
                  <option value="GET_CELL_FORMULA">Get Cell Formula</option>
                  <option value="SET_RANGE_COLOR">Set Range Color</option>
                  <option value="DELETE_RANGE">Delete Range</option>
                  <option value="CONVERT_XLSX">Convert To XLSX</option>
                  <option value="INSERT_COLUMN">Insert Column</option>
                  <option value="CREATE_EXCEL">Create Excel</option>
                  {/* <option value="CREATE_PIVOT_TABLE">Create Pivot Table</option> */}
                  <option value="SORT_EXCEL_COLUMN">Sort Excel Data</option>
                  <option value="VLOOK_UP">Vlook Up</option>
                </select>
              </div>
            </div>

            {renderActionFields(actionType)}
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        {(() => {
          if (actionType === "GET_SHEET_NAMES") {
            return (
              <li>Returns a list of all the sheet names in the given workbook, ordered by their index.</li>
            )
          } else if (actionType === "GET_COLUMN") {
            return (
              <li>Reads values from the specified column.</li>
            )
          } else if (actionType === "HIDE_COLUMN") {
            return (
              <li>Hides the specified column from the spreadsheet.</li>
            )
          } else if (actionType === "DELETE_COLUMN") {
            return (
              <li>Deletes the specified column from the spreadsheet.</li>
            )
          } else if (actionType === "GET_ROW") {
            return (
              <li>Reads values from the specified row.</li>
            )
          } else if (actionType === "DELETE_ROW") {
            return (
              <li>Deletes the specified row from the spreadsheet.</li>
            )
          } else if (actionType === "GET_CELL") {
            return (
              <li>Reads values from the specified cell.</li>
            )
          } else if (actionType === "WRITE_CELL") {
            return (
              <li>Writes values to the specified cell.</li>
            )
          } else if (actionType === "GET_RANGE") {
            return (
              <li>Reads values from the specified sheet range and stores it in a dataTable.</li>
            )
          } else if (actionType === "WRITE_RANGE") {
            return (
              <li>Writes values from the specified dataTable into the spreadsheet.</li>
            )
          } else if (actionType === "APPEND_RANGE") {
            return (
              <li>Adds the value from the specified dataTable at the end of the given excel sheet.</li>
            )
          } else if (actionType === "FILTER_COLUMNS") {
            return (
              <li>Filters the excel data based on the column conditions.</li>
            )
          } else if (actionType === "GET_CELL_COLOR") {
            return (
              <li>Reads the colour of the specified excel cell.</li>
            )
          } else if (actionType === "REFRESH_EXCEL") {
            return (
              <li>Refresh the excel file at the given path.</li>
            )
          } else if (actionType === "GET_CELL_FORMULA") {
            return (
              <li>Reads the formula of the specified excel cell.</li>
            )
          } else if (actionType === "SET_RANGE_COLOR") {
            return (
              <li>Sets the given colour to the specified range.</li>
            )
          } else if (actionType === "DELETE_RANGE") {
            return (
              <li>Deletes the specified rannge from the spreadsheet.</li>
            )
          } else if (actionType === "CONVERT_XLSX") {
            return (
              <li>Converts the given csv or xls file formats into xlsx files format.</li>
            )
          } else if (actionType === "INSERT_COLUMN") {
            return (
              <li>Inserts a column in the specified position.</li>
            )
          } else {
            return (
              <li>Performs various actions on the excel file located at the given path.</li>
            )
          }
        })()}
      </ul>
    </div>

  );
};

export default ExcelConfig;
