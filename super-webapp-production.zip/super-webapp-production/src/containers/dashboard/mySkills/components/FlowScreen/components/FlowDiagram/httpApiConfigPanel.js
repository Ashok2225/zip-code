
import {
    Table, TableBody, TableCell, TableHead, TableRow,
    TextField, Select, OutlinedInput, MenuItem, Checkbox, CheckBoxOutlineBlankIcon,
    CheckBoxIcon, FormGroup, FormControlLabel, FormControl, FormLabel, Button, IconButton, InputAdornment
} from '@material-ui/core'
import PictureAsPdfSharp from '@material-ui/icons/FileCopy';

import { BuilderContext, useDrawer } from "react-flow-builder";
import React, { useContext, useEffect, useState } from "react";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
import { Button as AntdButton } from "antd";


const HttpApiConfigPanel = () => {
    let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
    const { closeDrawer: cancel } = useDrawer();
    const [currentAction, setCurrentAction] = useState(

        {


            "actionType": "HTTP",
            "label": "HTTP API",
            "key": "httpapi",

            "reqBody": "{\n}",
            "method": "GET",
            "body": true,
            "url": "sds",
            "headers": false,
            "apiHeaders": [
                {
                    "id": 1,
                    "headerKey": "Content-Type",
                    "headerValue": "application/json",
                    "keyId": 1.1
                }
            ],
            "variableName": "",
            "instruction": "api_config = { method:'POST', header:[\"Content-Type:application/json\"],body:{}}\napi sds\necho api_result\necho api_json",

            "description": "API call to sds with Content-Type:application/json",
            "apiFileAttachments": "C:/Users/nithi/Desktop/Yogender_June_2022.pdf",
            "status": true,
            "attachments": false
        }
    )

    // const [reqBody, setReqBody] = useState([]);
    // const [apiFileAttachments, setApiFileAttachments] = useState();
    // const [method, setMethod] = useState("GET");
    // const [body, setBody] = useState(false);
    // const [headers, setHeaders] = useState(false)
    // const [attachments,setAttachments]=useState(false)
    // const [apiHeaders, setApiHeaders] = useState([
    //     {
    //         "id": 1,
    //         "headerKey": "Content-Type",
    //         "headerValue": "application/json",
    //         "keyId": 1.1
    //     }
    // ]);

    // const [url, setUrl] = useState();


    const findAndUpdate = (arr, id, payload) => {
        let found = arr.findIndex((i) => i.id == id);
        if (found > -1) {
            arr[found] = { ...arr[found], ...payload };
        } else {
            arr.forEach((element) => {
                if (["branch", "condition","loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)) {
                    findAndUpdate(element.children, id, payload);
                }
            });
        }
        return arr;
    };


    const submit = () => {
        try {

            let {
                skillReducer: { trainDraft },
            } = store.getState();
            nodes = nodes.filter((i) => !(i.isStart || i.isEnd));


            let newActions = findAndUpdate(nodes, currentAction.id, currentAction);
            store.dispatch(
                setDraft({
                    ...trainDraft,
                    RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
                })
            );

            cancel();
        } catch (error) {
            console.log("form error");
        }
    }

    useEffect(() => {
        setCurrentAction(node);
    }, [node]);

    const isValidJson = (reqBody) => {
        try {
            let jsonMsg = JSON.parse(reqBody)
            return {
                msg: 'Valid Json !!',
                color: 'green'
            }
        } catch (e) {
            return {
                msg: 'Invalid Json format.',
                color: 'red'
            }
        }
    }

    const handleChangeCheckbody = (e, body) => {

        if (!body) {

            setCurrentAction({ ...currentAction, reqBody: '' })
        }

        setCurrentAction({ ...currentAction, [e.target.name]: !body })


    }

    const apiHeadersChange = (event, inputObj) => {


        let { apiHeaders } = currentAction
        if (event.target.name === 'headerValue') {
            setCurrentAction({
                ...currentAction,
                apiHeaders: apiHeaders.map(obj => {
                    if (obj.id === inputObj.id) {
                        return {
                            ...obj,
                            headerValue: event.target.value
                        }
                    }
                    else { return obj }
                })
            })
            //action.editHttpAPI({apiHeaders: apiHeaders.map(row=>{if(row.id==inputObj.id)return{...row,[event.target.name]:event.target.value}})})
        } else {
            setCurrentAction({
                ...currentAction,
                apiHeaders: apiHeaders.map(obj => {
                    if (obj.id === inputObj.id) {
                        return {
                            ...obj,
                            headerKey: event.target.value
                        }
                    }
                    else { return obj }
                })
            })
            //action.editHttpAPI({apiHeaders: apiHeaders.map(row=>{if(row.id==inputObj.id)return{...row,[event.target.name]:event.target.value}})})

        }
    }


    const removeHeader = (e, inputObj) => {

        let { apiHeaders } = currentAction

        apiHeaders = apiHeaders.filter(row => row.id != inputObj.id)

        apiHeaders.forEach((header, index) => { header['id'] = index + 1; header['keyId'] = index + 1 })
        setCurrentAction({ ...currentAction, apiHeaders: apiHeaders })
        // if(apiHeaders.length === 1){
        //   console.log("entered in if if if if if if-----");

        //    action.editHttpAPI({headers : false})
        // }
    }
    const addHeader = (e) => {

        let { apiHeaders } = currentAction

        setCurrentAction({ ...currentAction, apiHeaders: [...apiHeaders, { id: apiHeaders.length + 1, headerKey: "", headerValue: "", keyId: apiHeaders.length + 1 }] })

    }

    const handleChange = (event) => {

        // 
        // actions.editHttpAPI({[event.target.name]: event.target.value,body: false,reqBody: ''})
        if (event.target.name === 'method') {
            setCurrentAction({ ...currentAction, [event.target.name]: event.target.value, body: false, reqBody: '' })
        }
        setCurrentAction({ ...currentAction, [event.target.name]: event.target.value })
    }

    const handleChangeCheckheaders = (e, headers) => {


        if (!headers) {
            setCurrentAction({ ...currentAction, apiHeaders: [{ id: 1, headerKey: 'Content-Type', headerValue: 'application/json', keyId: 1.1 }] })
        }

        setCurrentAction({ ...currentAction, [e.target.name]: !headers })
    }

    const handleChangeFiles = (e) => {

        if (e.target.files) {
            
            var path = (window.URL || window.webkitURL).createObjectURL(e.target.files[0]);
            console.log('path', path);
            setCurrentAction({ ...currentAction, [e.target.name]: path })
        }
        else {
            setCurrentAction({ ...currentAction, [e.target.name]: e.target.value })
        }
    }



    let { label, apiFileAttachments, reqBody, method, body, attachments, headers, url, apiHeaders } = currentAction
    let bodyComponent, attachmentComponent, bodytextBox, newRow, isDisabled, msgFormat = null;
    let methods = [{ label: 'GET', id: 'GET' }, { label: 'POST', id: 'POST' }, { label: 'PUT', id: 'PUT' }, { label: 'DELETE', id: 'DELETE' }]

    apiHeaders.forEach(obj => {
        if (obj.headerKey.length && obj.headerValue.length) {
            isDisabled = false
        } else {
            isDisabled = true
        }
    })

    if (reqBody && body) {
        let jsonMsg = isValidJson(reqBody)
        msgFormat = <label style={{ color: `${jsonMsg.color}`, fontSize: '15px' }}>
            {jsonMsg.msg}
        </label>
    }
    if (method === 'PUT' || method === 'POST' || method === 'DELETE') {
        bodyComponent = <div> <FormControlLabel
            control={
                <Checkbox
                    name="body"
                    checked={body}
                    value={body}
                    onChange={(e) => handleChangeCheckbody(e, body)}
                    color="primary" />
            }
            label="Payload"
        />
            <FormControlLabel
                control={
                    <Checkbox
                        name="attachments"
                        checked={attachments}
                        value={attachments}
                        onChange={(e) => handleChangeCheckbody(e, attachments)}
                        color="primary" />
                }
                label="Attachments"
            />
        </div>
    }
    if (body) {
        bodytextBox = <textarea style={{ width: '300px', height: '160px' }} name='reqBody' value={reqBody} onChange={(e) => handleChange(e)} />
    }
    if (attachments) {
        attachmentComponent =
            <div className="config-panel-textfield">
                <TextField
                    id="outlined-adornment-password"
                    variant="outlined"
                    type="text"
                    label="Add attachment"
                    value={apiFileAttachments ? apiFileAttachments : ""}
                    name="apiFileAttachments"
                    helperText="Eg: D:\NewFile.txt"
                    onChange={(e) => handleChangeFiles(e)}
                    fullWidth
                    InputProps={{
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton >
                                    <span style={{ width: "25px", height: "25px" }}>
                                        <label htmlFor="files"><span><PictureAsPdfSharp /></span></label>
                                        <input
                                            id="files"
                                            type="file"
                                            name="apiFileAttachments"
                                            style={{ visibility: 'hidden', height: 0, width: 0 }}
                                            onChange={(e) => handleChangeFiles(e)}
                                        />
                                    </span>
                                </IconButton>
                            </InputAdornment>
                        ),
                    }}
                />
            </div>

    }
    if (headers) {
        newRow = <TableRow>
            {
                apiHeaders.map((obj, index) => (
                    <div style={{ display: 'flex' }}>
                        <TextField
                            key={index}
                            id='outlined-full-width'
                            name="headerKey"
                            label="Key"
                            margin="dense"
                            variant="outlined"
                            style={{ width: "25%", marginRight: "3%" }}
                            value={obj.headerKey}
                            /* InputProps={{
                            //   readOnly: obj.id === 1 ? true : false,
                            }}*/
                            onChange={(e) => apiHeadersChange(e, obj)}

                        />
                        <div className="config-panel-textfield">
                            <TextField
                                key={obj.keyId}
                                id="outlined-full-width"
                                name="headerValue"
                                label="Value"
                                margin="dense"
                                variant="outlined"
                                value={obj.headerValue}
                                /*  InputProps={{
                                      readOnly: obj.id === 1 ? true : false,
                                  }}*/
                                onChange={(e) => apiHeadersChange(e, obj)}
                            />
                        </div>
                        <Button style={{ height: " 43px", marginTop: "9px", marginLeft: "1%" }} variant="outlined" color="red" onClick={e => removeHeader(e, obj)}>
                            -
                        </Button>
                        <Button style={{ height: " 43px", marginTop: "9px", marginLeft: "1%" }} variant="outlined" color="primary" disabled={isDisabled} onClick={e => addHeader(e)}>
                            +
                        </Button>
                    </div>
                ))
            }

        </TableRow>
    }
    return (
        <div style={{ padding: "15px" }} className="http-root">

            <div style={{ backgroundColor: "#f2f2f2", height: "35px" }} >
                <p style={{ paddingTop: "9px", paddingLeft: "9px" }}> HTTP Request</p>
            </div>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell style={{ display: 'flex' }}>
                            <Select style={{ height: "43px", marginTop: "9px", marginRight: "5px", marginLeft: "-25px" }}
                                name="method"
                                value={method}
                                onChange={(e) => handleChange(e)}
                                input={
                                    <OutlinedInput
                                        labelWidth={0}
                                        name="method"
                                        id="outlined-condition-simple"
                                    />
                                }
                            >
                                {
                                    methods.map((method, index) => <MenuItem key={index} value={method.id}>{method.label}</MenuItem>)
                                }
                            </Select>
                            <TextField
                                id="outlined-full-width"
                                name="url"
                                label="URL"
                                margin="dense"
                                fullWidth
                                variant="outlined"
                                helperText="Eg: http://localhost:8080/deployment/create"
                                value={url}
                                onChange={(e) => handleChange(e)}
                                inputProps={{ style: { fontSize: 15 } }} // font size of input text
                                InputLabelProps={{ style: { fontSize: 15 } }} // font size of input label
                            />
                        </TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>
                            <FormGroup row>
                                {bodyComponent}
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            name="headers"
                                            checked={headers}
                                            onChange={(e) => handleChangeCheckheaders(e, headers)}
                                            value={headers}
                                            color="primary" />
                                    }
                                    label="Headers"
                                />
                            </FormGroup>
                        </TableCell>
                    </TableRow>
                    {newRow}
                    {bodytextBox}
                    {attachmentComponent}
                </TableHead>
            </Table>
            {msgFormat}
            <div><p style={{ color: "darkgray" }}>Note: API result will be stored in:
                "api_result" variable if response type is String,
                "api_json" variable if response type is json</p></div>

            <div>
                <AntdButton onClick={cancel}> Cancel </AntdButton>
                <AntdButton type="primary" onClick={submit}>
                    Save
                </AntdButton>
            </div>
            <ul className="note-list">
            <li>Performs HTTP operations on the specified REST API</li>
            </ul>

        </div>

    )

}

export default HttpApiConfigPanel