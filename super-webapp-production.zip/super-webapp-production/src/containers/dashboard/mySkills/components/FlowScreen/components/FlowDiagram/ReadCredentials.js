import React, { useContext, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox, Dropdown } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";
const { Option } = Select;
const ReadCredentialsConfigForm = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [flowVar, setFlowVar] = useState([]);
  const skill = useSelector((state) => state.skillReducer.trainDraft);

  useEffect(() => {
    mergeVar(skill?.FORMATED_DATA?.variables);
  }, [skill?.FORMATED_DATA?.variables]);

  const mergeVar = (allVar) => {
    let _mergedData = [];

    Object.entries(allVar).forEach(([key, value]) => {
      _mergedData.push(value);
    });
    if (flowVariables.length > 0) {
      _mergedData.map((ele) => {
        flowVariables.map((f) => {
          if (ele.id === f.id) {
            ele["xPath"] = f.xPath;
          }
          return;
        });
      });
    }
    setFlowVar(_mergedData);
  };

  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          [
            "branch",
            "condition",
            "loop",
            "loop-nodes",
            "try",
            "try-catch-node",
          ].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();

      obj.CredName = values?.CredName;
      obj.UserName = values?.UserName;
      obj.Password = values?.Password;

      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={nodeData}>
            <Form.Item
              name="CredName"
              label="Credential Name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="UserName"
              label="UserName"
              rules={[{ required: true }]}
            >
              <Select style={{ width: 120 }}>
                {flowVar?.map((ele, i) => {
                  return (
                    <Option className="custom-select" key={i} value={ele.name}>
                      <p>{ele.name}</p>
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>

            <Form.Item
              name="Password"
              label="Password"
              rules={[{ required: true }]}
            >
              <Select style={{ width: 120 }}>
                {flowVar?.map((ele, i) => {
                  return (
                    <Option className="custom-select" key={i} value={ele.name}>
                      <p>{ele.name}</p>
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Reads credentials from windows credential manager</li>
      </ul>
    </div>
  );
};

export default ReadCredentialsConfigForm;
