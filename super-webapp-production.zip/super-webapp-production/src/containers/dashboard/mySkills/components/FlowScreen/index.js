import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import FlowActionMenu from "./components/FlowActionMenu/FlowActionMenu";
import { getDraftSkillsById } from "../../../../../redux/actions/skill";
import {
  getSheetHeaders,
  getSession,
} from "../../../../../redux/actions/skill";
import { getAutomationBuildLogs } from "../../../../../redux/actions/logs";
import DataMapperModal from "./components/FlowActionMenu/DataMapperModal";
import PlayModalWebAuto from "./components/FlowActionMenu/PlayModalWebAuto";
import BottomBar from "./components/BottomBar";
import Flow from "./components/FlowDiagram";
import Loader from "../../../../../components/loader";
import TemplateInstructions from "../../../../../components/templateInstructions";

class FlowScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount = () => {
    this.trainYourSkill();
    // this.props.getSession();
  };

  trainYourSkill = async () => {
    const trainSkillId = this.props.match.params.id;
    const trainSkill = await this.props.getDraftSkillsById(trainSkillId);
  };

  render() {
    return (
      <React.Fragment>
        <div className="fw-screen">
          <DataMapperModal />
          <PlayModalWebAuto />
          <div className="chat-col-skill">
            <FlowActionMenu getUpdated={this.trainYourSkill} />
            <Flow></Flow>
            <TemplateInstructions
              state={this.props?.skillReducer?.trainDraft?.TEMPLATE}
            />
            <BottomBar />
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkillsById,
    getSheetHeaders,
    getSession,
    getAutomationBuildLogs,
  })
)(FlowScreen);
