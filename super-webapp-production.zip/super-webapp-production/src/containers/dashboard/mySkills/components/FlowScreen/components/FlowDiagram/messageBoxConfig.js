import React, { useContext, useEffect, useState } from "react";
import { BuilderContext, useDrawer } from "react-flow-builder";
import { Form, Button, Input, Select, Radio, Checkbox } from "antd";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";

const MessageBoxConfig = () => {
  let { selectedNode: node, flowVariables, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null);
  const [actionType, setActionType] = useState("");
  const [form] = Form.useForm();

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (["branch", "condition","loop", "loop-nodes", "try", "try-catch-node"].includes(element.type)) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let obj = {};
      let {
        skillReducer: { trainDraft },
      } = store.getState();
      obj.actionType = "MESSAGE_BOX";
      obj.key = "msgbox";
      obj.label = "Message Box";
      obj.message = values.message ? values.message : "";
      obj.timeout = values.timeout ? values.timeout : "";
      nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
      let newActions = findAndUpdate(nodes, nodeData.id, obj);
      store.dispatch(
        setDraft({
          ...trainDraft,
          RAW_DATA: { ...trainDraft.RAW_DATA, actions: newActions },
        })
      );
      cancel();
    } catch (error) {
      console.log("form error");
    }
  };

  useEffect(() => {
    setNodeData(node);
    setActionType(node.actionType);
  }, [node]);

  return (
    <div>
      {nodeData ? (
        <div>
          <p>
            Message Box
            <Form form={form} initialValues={nodeData}>  
            <Form.Item
                name="message"
                label="Message"
                help="Eg: Hello World OR `variableName`"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>

              <Form.Item
                name="timeout"
                label="Timeout"
                help="Eg: 5sec OR `variableName`"
              >
                <Input />
              </Form.Item> 
            </Form>
          </p>
          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
        <li>Displays the given text message(s) in a pop up. Optionally, set a time duration for the pop up in seconds.</li>
      </ul>
    </div>
  );
};
export default MessageBoxConfig;
