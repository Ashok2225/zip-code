import React from "react";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  updateSkillVariables,
  getSession,
  executeFlow,
} from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import infoIcon from "../../../../../../../images/info-new.png";
import $ from "jquery";

import Zoom from "react-medium-image-zoom";

const PlayModalWebAuto = () => {
  const dispatch = useDispatch();
  const skill = useSelector((state) => state.skillReducer);
  const userDeviceId = useSelector((state) => state.skillReducer.draftSession);

  const varData = skill?.trainDraft?.FORMATED_DATA?.variables;

  const history = useHistory();
  const [isLoadingNewVar, setIsLoadingNewVar] = useState(false);

  const resetVarData = () => {
    history.push(window.location.pathname);
  };

  const runFlow = async () => {
    setIsLoadingNewVar(true);
    let payload = {};
    // const deviceId = await dispatch(getSession());
    // console.log(deviceId, "gdg");
    let form = $("#editVariables");
    let _formData = form.serializeArray();
    _formData.forEach((i) => (payload[i.name] = i.value));

    let data = {
      deviceId: userDeviceId,
      skillId: skill?.trainDraft?.id,
      variables: payload,
    };
    const flowResponse = await dispatch(executeFlow(data));
    if (flowResponse.status) {
      setIsLoadingNewVar(false);
    }
  };
  return (
    <div
      className="modal crt-skill fade"
      id="myWebAutomationPlayModal"
      role="dialog"
    >
      <div className="modal-dialog">
        <div className="modal-content crt-content">
          <div class="modal-header">
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              onClick={() => {
                resetVarData();
              }}
            >
              &times;
            </button>
            <h4 className="modal-title text-center">Review Data </h4>
          </div>
          <div className="modal-body">
            <form id="editVariables" className="form-contain editVariables">
              {varData &&
                Object.values(varData)
                  .sort((a, b) => a.number - b.number)
                  .map((data, index) => (
                    <div className="frm-block md-flex-input" key={index}>
                      <div className="ip-tl-label">
                        <span className="tl-label" for={data.id}>
                          {data.name}
                          {/* {data.name} */}
                          <button
                            className="btn-link dm-info fixed-info"
                            type="button"
                            data-toggle="dropdown"
                          >
                            <img src={infoIcon} alt="" />
                            <div className="popup-img">
                              <Zoom>
                                <img
                                  alt=""
                                  src={
                                    skill?.trainDraft?.FORMATED_DATA?.actions[
                                      data.id
                                    ]?.pageScreenshot
                                  }
                                />
                              </Zoom>
                            </div>
                          </button>
                        </span>

                        <input
                          type="text"
                          id={index}
                          name={data.name}
                          defaultValue={data.defaultValue}
                        ></input>
                      </div>
                    </div>
                  ))}
              <div className="frm-btns">
                <button
                  className="btn-outline"
                  data-dismiss="modal"
                  onClick={() => {
                    resetVarData();
                  }}
                >
                  Ignore
                </button>
                {isLoadingNewVar ? (
                  <button className="primary-btn">
                    <div class="sp sp-circle text-light"></div>
                  </button>
                ) : (
                  <span className="primary-btn"
                    onClick={() => runFlow()}
                    data-dismiss="modal">
                    Submit
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayModalWebAuto;
