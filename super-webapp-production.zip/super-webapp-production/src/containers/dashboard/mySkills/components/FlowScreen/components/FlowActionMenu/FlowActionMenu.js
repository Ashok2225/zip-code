import React from "react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import Counter from "../../../../../../../components/counter";
import editIcon from "../../../../../../../images/edit-icon.png";
import refresh from "../../../../../../../images/training/refresh.png";
import sendwhite from "../../../../../../../images/training/send-white.png";
import saveimg from "../../../../../../../images/doc-input.png";
import playIcon from "../../../../../../../images/training/play.png";
import checkStatus from "../../../../../../../images/check-status.svg";
import closeStatus from "../../../../../../../images/close-status.svg";
import progressStatus from "../../../../../../../images/progress-status.svg";
import { PDFDownloadLink } from "@react-pdf/renderer";
import MyDocument from "../../../../../../../components/document";
import {
  updateFormatedData,
  publishHelperSkill,
  startRecord,
  stopRecord,
  getDraftSkillsById,
  getSession,
  toogleDataMapper,
  startTimer,
  setLoading,
} from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import TemplateName from "./TemplateName";
import { v4 as uuid } from "uuid";
import PlayModal from "./PlayModal";
import ShareComponent from "./ShareComponent";
import { Radio } from "antd";

const FlowActionMenu = (props) => {
  const [isEditingSkillName, setIsEditingSkillName] = useState(false);
  const [skillName, setSkillName] = useState("");
  const [isFlowActionsEnabled, setIsFlowActionEnabled] = useState(false);
  const [isFlowPublishing, setIsFlowPublishing] = useState("");
  const [isFlowPublishingSkillHub, setIsFlowPublishingSkillHub] = useState("");

  // const [startTimer, setStartTimer] = useState(false);
  const [excelSheetUrl, setExcelSheetUrl] = useState("");
  const [isSavingFlow, setIsSavingFlow] = useState(false);
  const [onboardUrl, setOnboardUrl] = useState(false);
  const skill = useSelector((state) => state.skillReducer.trainDraft);
  const currentTeam = JSON.parse(localStorage.getItem("orgDetails"));
  const userDeviceId = useSelector((state) => state.skillReducer.draftSession);
  const showMapper = useSelector(
    (state) => state.skillReducer.toogleDataMapper
  );

  const isRecord = useSelector((state) => state.skillReducer.isRecording);
  const isTimerEnabled = useSelector((state) => state.skillReducer.startTimer);
  const userRole = useSelector(
    (state) => state.organizationReducer.currentOrgUser.role_id
  );

  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    if (skill && skill.RAW_DATA?.actions?.length) {
      setIsFlowActionEnabled(true);
    } else {
      setIsFlowActionEnabled(false);
    }
  }, [skill?.RAW_DATA?.actions]);
  useEffect(() => {
    if (
      skill?.RAW_DATA?.excelData?.url &&
      skill?.RAW_DATA?.excelData?.sheetName
    ) {
      setExcelSheetUrl(skill?.RAW_DATA?.excelData?.url);
    }
  }, [skill?.RAW_DATA?.excelData]);

  useEffect(() => {
    setOnboardUrl(skill?.onboarding_url);
  }, [skill?.onboarding_url]);

  const changeSkillName = (name) => {
    setIsEditingSkillName(false);
    const updateName = { itemId: skill.id, skillName: name };
    const res = dispatch(updateFormatedData(updateName));
  };

  const publishSkill = async (data) => {
    if (onboardUrl === null) {
      dispatch(notify("error", "Please select option"));
    } else {
      setIsFlowPublishingSkillHub(true);
      if (data.status !== null) {
        const publishHelper = await dispatch(
          publishHelperSkill(skill.id, {
            ...skill,
            status: "pending",
            TYPE: "SkillHub",
            onboarding_url: onboardUrl ? onboardUrl : skill.onboarding_url,
          })
        );
        setIsFlowPublishingSkillHub(false);

        dispatch(notify("success", "Success!"));
        history.push(window.location.path);
      } else {
        setIsFlowPublishingSkillHub(false);
        dispatch(notify("error", "Already Published!"));
      }
    }
  };

  const publishTemplate = async (itemId) => {
    setIsFlowPublishing(true);
    var rawData;
    rawData = {
      ...skill?.RAW_DATA,
      actions: skill?.RAW_DATA?.actions,
    };

    let status = "published";

    let skillName = skill?.SKILL_NAME;
    let updatedData = { status, skillName, rawData, itemId };
    const updateHelper = await dispatch(updateFormatedData(updatedData));

    if (updateHelper) {
      setIsFlowPublishing(false);

      dispatch(notify("success", " Updated and published successfully!"));
      history.push(window.location.path);
    } else {
      setIsFlowPublishing(false);

      dispatch(notify("error", " Something went wrong.Failed to update!"));
    }
  };

  const startTimerRec = (skillId, nodeId = null) => {
    dispatch(startTimer(true));
    // setStartTimer(true);
    dispatch(notify("success", "Please wait for the Show process to start"));
    setTimeout(() => {
      reTrain(skillId, nodeId);
    }, 5000);
  };

  const reTrain = async (skillId, nodeId = null) => {
    let markerIndex = 0;
    let data = { skillId, markerIndex, nodeId };
    const startData = await dispatch(startRecord(data));
    // if (startData) {
    //   setStartTimer(false);
    // } else {
    //   setStartTimer(false);
    // }
  };

  const onStopRecord = async () => {
    // setStartTimer(false);
    dispatch(setLoading(true));
    dispatch(startTimer(false));

    let data = {
      deviceId: userDeviceId,
      skillId: skill.id,
      nodeId: isRecord?.nodeId,
    };
    const stopData = await dispatch(stopRecord(data));
    if (stopData.status === true) {
      await delay(8000);
      const getUpdatedData = await dispatch(getDraftSkillsById(skill.id));
      let updatedResult = getUpdatedData?.data?.data?.RAW_DATA?.actions;
      if (updatedResult?.length === 0) {
        await delay(5000);
        await dispatch(getDraftSkillsById(skill.id));
      }
    }
  };

  const delay = (duration) =>
    new Promise((resolve) => setTimeout(resolve, duration));

  const saveDraft = async () => {
    setIsSavingFlow(true);
    try {
      var rawData;
      var TYPE;
      var itemId = skill?.id;
      rawData = {
        ...skill?.RAW_DATA,
        actions: skill?.RAW_DATA?.actions,
      };
      var status;
      if (skill?.status === "approved") {
        status = "pending";
        TYPE = "regularSkill";
      } else {
        status = skill?.status;
        TYPE = "regularSkill";
      }
      let skillName = skill?.SKILL_NAME;
      let updatedData = { status, skillName, rawData, itemId, TYPE };
      const updateHelper = await dispatch(updateFormatedData(updatedData));
      if (updateHelper) {
        setIsSavingFlow(false);

        dispatch(notify("success", "Updated Succesfully"));
      }
    } catch (err) {
      setIsSavingFlow(false);

      dispatch(notify("err", "Failed to update!"));
    }
  };

  const onRadioChange = (e) => {
    setOnboardUrl(e.target.value);
  };

  return (
    <React.Fragment>
      <div className="flex-title rt-flex-title">
        <div className="cts-title">
          {/* SKILL initials */}
          <div className="cts-ico">
            <span>
              {skill?.SKILL_NAME
                ? skill?.SKILL_NAME?.toUpperCase().charAt(0)
                : null}
            </span>
          </div>

          {/* Skill Name */}

          <div className="cts-title-subt">
            <div class="title-edit-skill">
              {isEditingSkillName ? (
                <input
                  name="skillName"
                  placeholder="Enter Skill Name"
                  defaultValue={skill?.SKILL_NAME}
                  onBlur={(e) => changeSkillName(e.target.value)}
                ></input>
              ) : (
                <p>{skill?.SKILL_NAME}</p>
              )}
              {userRole === "1" ? null : (
                <div
                  className="edit-btn"
                  tooltip="edit skill name"
                  onClick={(e) => setIsEditingSkillName(true)}
                >
                  <img src={editIcon} />
                </div>
              )}
            </div>

            {/* Template Name */}
            {<TemplateName {...skill} />}
          </div>
        </div>

        {/* Template options  */}
        <div className="rt-btns">
          {/* ---------Share Option----------- */}
          <ShareComponent />
          {/* ---------Play option---------- */}

          <PlayModal />

          {/* Play with Dropdown */}
          {/* <div className="device-dropdown dropdown">
            <button
              className="sm-btn play-btn"
              type="button"
              data-toggle="dropdown"
            >
              <img src={playIcon} alt="" />
              <span>Play</span>
            </button>
            <div className="dropdown-menu">
              <ul class="list-group">
                {devices.length > 0 ? (
                  devices.map((i, index) => {
                    return (
                      <li class="list-group-item" key={index}>
                        <div className="dc-list">
                          <div className="dc-label">
                            <div className="dc-icon">
                              <img src={deviceIcon} />
                            </div>
                            <div className="dc-text">
                              <p>DESKTOP-J98CEEH</p>
                              <span>Arvind Patel</span>
                            </div>
                          </div>
                          <div className="check-dc selected">
                            <img src={checkIcon} />
                          </div>
                        </div>
                      </li>
                    );
                  })
                ) : (
                  <li class="list-group-item">
                     No linked devices found
                  </li>
                )}
              </ul>
            </div>
          </div> */}

          {/* Save button */}

          {!process.env.REACT_APP_TEMPLATES_DISABLE_UPDATE.includes(
            skill?.id
          ) && parseInt(skill?.organizationId) === currentTeam?.id ? (
            <>
              {isSavingFlow ? (
                <button className="sm-btn">
                  <div class="sp sp-circle text-light"></div>
                </button>
              ) : (
                <>
                  {userRole === "1" ? null : (
                    <button
                      className="sm-btn"
                      disabled={isFlowActionsEnabled ? "" : "disabled"}
                      onClick={() => saveDraft()}
                    >
                      <img src={saveimg} alt="" />

                      <span>Save</span>
                    </button>
                  )}
                </>
              )}
            </>
          ) : null}

          {/* ----------Retrain option---------- */}

          {parseInt(skill?.organizationId) === currentTeam.id ? (
            <React.Fragment>
              {userRole === "1" ? null : (
                <>
                  {["UserDocumentation", "In-App Walkthrough"].includes(
                    skill?.TEMPLATE
                  ) ? (
                    <React.Fragment>
                      {skill?.RAW_DATA?.actions?.length > 0 && (
                        <button
                          className="sm-btn"
                          data-toggle="modal"
                          data-target="#mySkillRetrainModal"
                          disabled={
                            isRecord.status === true ? "disabled" : null
                          }
                        >
                          <img src={refresh} alt="" />
                          <span>Reshow</span>
                        </button>
                      )}
                      {skill?.RAW_DATA?.actions?.length === 0 && (
                        <button
                          className="sm-btn"
                          onClick={() => {
                            startTimerRec(skill.id);
                          }}
                          disabled={
                            isRecord.status === true ? "disabled" : null
                          }
                        >
                          <img src={refresh} alt="" />
                          <span>Show</span>
                        </button>
                      )}
                    </React.Fragment>
                  ) : null}
                </>
              )}

              {/* -------Start Recording option------- */}
              {isTimerEnabled === true ? (
                <>
                  <button
                    className="btn btn-danger btn-sm btn-stop-train"
                    style={{
                      backgroundColor: "#ff3333",
                      color: "#fff",
                      borderColor: "#ff3333",
                      borderRadius: "3px",
                    }}
                    onClick={(e) => onStopRecord()}
                  >
                    {isRecord.status === true ? (
                      <span>Stop Show</span>
                    ) : (
                      <div>
                        <Counter />
                      </div>
                    )}
                  </button>
                </>
              ) : (
                ""
              )}

              {/* -------Publish User Documentation------------- */}
              {/* {["UserDocumentation", "WebAutomation", "Automation"].includes(
            skill.TEMPLATE
          ) ? (
           
          ) : null} */}

              {/* <React.Fragment>
                {userRole === "1" ? null : (
                  <>
                    {skill?.status === "published" ? (
                      <>
                        <button className="sm-btn" disabled={"disable"}>
                          <img src={saveimg} alt="" />

                          <span>Published</span>
                        </button>
                      </>
                    ) : (
                      <>
                        {isFlowPublishing ? (
                          <button className="sm-btn">
                            <div class="sp sp-circle text-light"></div>
                          </button>
                        ) : (
                          <button
                            className="sm-btn"
                            disabled={isFlowActionsEnabled ? "" : "disable"}
                            onClick={() => publishTemplate(skill.id)}
                          >
                            <img src={saveimg} alt="" />

                            <span>Publish</span>
                          </button>
                        )}
                      </>
                    )}
                  </>
                )}
              </React.Fragment> */}

              {/* -------Pdf Download option----------- */}
              {skill.TEMPLATE === "UserDocumentation" && (
                <>
                  {isFlowActionsEnabled ? (
                    <div class="dropdown publish-dropdown export-dropdown">
                      <button
                        class="sm-btn"
                        type="button"
                        data-toggle="dropdown"
                      >
                        <img src={sendwhite} style={{ filter: "invert(1)" }} alt="" />
                        <span>Export As</span>
                        {/* <span class="caret"></span> */}
                      </button>
                      <ul class="dropdown-menu">
                        <li>
                          <a
                            href={`${process.env.REACT_APP_BOT_SERVICE_URL}/document?id=${skill.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            HTML URL
                          </a>
                        </li>
                        <li>
                          <PDFDownloadLink
                            document={
                              skill ? (
                                <MyDocument key={skill.id} props={skill} />
                              ) : null
                            }
                            fileName={skill?.SKILL_NAME}
                          >
                            {({ blob, url, loading, error }) =>
                              error ? (
                                <a disabled={"disable"}>Dowload Pdf</a>
                              ) : (
                                <>
                                  <a style={{ color: "#333" }}>PDF</a>
                                </>
                              )
                            }
                          </PDFDownloadLink>
                          {/* <a href="#">View as PDF</a> */}
                        </li>
                      </ul>
                    </div>
                  ) : (
                      <button
                        className="sm-btn"
                        disabled
                        style={{ cursor: "not-allowed" }}
                      >
                        <img src={sendwhite}  style={{ filter: "invert(1)" }}alt="" />
                        <span>Export As</span>
                      </button>
                  )}
                </>
              )}
              {/* ------Publish option for in app walkthrough-------- */}

              {userRole === "1" ? null : (
                <>
                  {" "}
                  {["UserDocumentation"].includes(skill.TEMPLATE) ? null : (
                    <React.Fragment>
                      <React.Fragment>
                        {isFlowPublishingSkillHub ? (
                          <button className="btn btn-approve">
                            {" "}
                            <div class="sp sp-circle text-light"></div>
                          </button>
                        ) : (
                          <React.Fragment>
                            <div class="dropdown publish-dropdown export-dropdown">
                              <button className="sm-btn" data-toggle="dropdown">
                                {isFlowPublishing ? (
                                  <>
                                    {" "}
                                    <div class="sp sp-circle text-light"></div>
                                  </>
                                ) : (
                                  <>
                                    <img src={saveimg} alt="" />

                                    <span>Publish</span>
                                  </>
                                )}
                              </button>
                              <ul class="dropdown-menu dropdown-menu-right">
                                <li
                                  class={
                                    skill?.status === "approved"
                                      ? "disabled"
                                      : ""
                                  }
                                >
                                  {skill?.status === "approved" ? (
                                    <a>To Team</a>
                                  ) : (
                                    <a
                                      onClick={() => publishTemplate(skill?.id)}
                                    >
                                      To Team
                                    </a>
                                  )}
                                </li>
                                <li
                                  class={isFlowActionsEnabled ? "" : "disabled"}
                                >
                                  {isFlowActionsEnabled ? (
                                    <a
                                      data-toggle="modal"
                                      data-target="#publishModal"
                                    >
                                      To Super Skill Hub
                                    </a>
                                  ) : (
                                    <a>To Super Skill Hub</a>
                                  )}
                                </li>
                              </ul>
                            </div>
                          </React.Fragment>
                        )}

                        {/* -------------------------SKILL STATUS---------------------> */}
                        {skill.status !== "self" ? (
                          <React.Fragment>
                            <div className="publish-status">
                              <div
                                className={
                                  skill?.status === "published"
                                    ? "status-success"
                                    : "status-success hidden"
                                }
                              >
                                <fieldset>
                                  <legend>Success</legend>
                                  <div className="status-p">
                                    <div
                                      className="stp-icon"
                                      style={{ backgroundColor: "#c9fff0" }}
                                    >
                                      <img src={checkStatus} />
                                    </div>
                                    <p>Published To Team</p>
                                  </div>
                                </fieldset>
                              </div>
                              <div
                                className={
                                  skill?.status === "approved"
                                    ? "status-success"
                                    : "status-success hidden"
                                }
                              >
                                <fieldset>
                                  <legend>Published to skill hub</legend>
                                  <div className="status-p">
                                    <div
                                      className="stp-icon"
                                      style={{ backgroundColor: "#c9fff0" }}
                                    >
                                      <img src={checkStatus} />
                                    </div>
                                    <p>Approved</p>
                                  </div>
                                </fieldset>
                              </div>
                              <div
                                className={
                                  skill?.status === "declined"
                                    ? "status-error"
                                    : "status-error hidden"
                                }
                              >
                                <fieldset>
                                  <legend>Published to skill hub</legend>
                                  <div className="status-p">
                                    <div
                                      className="stp-icon"
                                      style={{ backgroundColor: "#ffebeb" }}
                                    >
                                      <img src={closeStatus} />
                                    </div>
                                    <p>Declined</p>
                                  </div>
                                </fieldset>
                              </div>
                              <div
                                className={
                                  skill?.status === "pending"
                                    ? "status-progress"
                                    : "status-progress hidden"
                                }
                              >
                                <fieldset>
                                  <legend>Published to skill hub</legend>
                                  <div className="status-p">
                                    <div
                                      className="stp-icon"
                                      style={{ backgroundColor: "#d0e4ff" }}
                                    >
                                      <img src={progressStatus} />
                                    </div>
                                    <p>Waiting for approval</p>
                                  </div>
                                </fieldset>
                              </div>
                            </div>
                          </React.Fragment>
                        ) : null}
                      </React.Fragment>
                    </React.Fragment>
                  )}
                </>
              )}
            </React.Fragment>
          ) : null}

          {/* ---------Mapper Option---------- */}
          {/* Moved inside for-loop action block */}
          {/* {skill.TEMPLATE === "Import Data from Spreadsheet to Web App" ? (
            <React.Fragment>
              <button
                data-toggle="modal"
                data-target={
                  !excelSheetUrl ? "#myRpaMapModal" : "#myRpaMapModalExcel"
                }
                className="sm-btn"
                disabled={
                  skill && skill.RAW_DATA && skill.RAW_DATA.actions
                    ? ""
                    : "disable"
                }
                onClick={() =>
                  dispatch(toogleDataMapper(showMapper == true ? false : true))
                }
              >
                <img src={refresh} alt="" />
                <span>Mapper</span>
              </button>
            </React.Fragment>
          ) : null} */}
        </div>
      </div>

      {/* Retrain Modal */}

      <div
        className="modal fade crt-skill"
        id="mySkillRetrainModal"
        role="dialog"
      >
        <div className="modal-dialog modal-sm">
          <div className="modal-content crt-content">
            <div className="modal-header">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <h4 className="modal-title">Reshow Skill</h4>
            </div>
            <div className="modal-body">
              <div className="form-contain">
                <div className="frm-block">
                  <p className="md-text">
                    Reshow removes all the steps in the skill and starts
                    capturing steps freshly. Do you want to proceed?
                  </p>
                </div>
                <div className="frm-btns">
                  <button className="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      startTimerRec(skill.id);
                    }}
                  >
                    {skill?.RAW_DATA?.actions ? "Proceed" : "Start Show"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        id="publishModal"
        class="modal fade crt-skill"
        role="dialog"
        data-backdrop="static"
        data-keyboard="false"
      >
        <div class="modal-dialog ">
          <div class="modal-content crt-content ">
            <div className="modal-header">
              <h4 className="modal-title">Publish To Super Skill Hub </h4>

              <button type="button" class="close" data-dismiss="modal">
                ×
              </button>
            </div>

            <div class="modal-body">
              <div className="form-contain text-center">
                <p>
                  {" "}
                  Prompt user for the application URL during skill onboarding?
                </p>
                <div className="flex-social">
                  <div style={{ marginBottom: "15px" }}>
                    <Radio.Group onChange={onRadioChange} value={onboardUrl}>
                      <Radio value={true}>Yes</Radio>
                      <Radio value={false}>No</Radio>
                    </Radio.Group>
                  </div>
                </div>

                <div>
                  <button
                    className="btn btn-primary"
                    onClick={() => {
                      publishSkill(skill);
                    }}
                    data-dismiss="modal"
                  >
                    Publish
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};
export default FlowActionMenu;
