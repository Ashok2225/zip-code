// import React, { Component } from "react";
import "antd/dist/antd.css";
import { connect } from "react-redux";
import { Edit, AllInclusive, Storage, ReportProblem } from "@material-ui/icons";
import { Button, Modal, Switch } from "antd";

import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { v4 as uuid } from "uuid";
import {
  setDraft,
  startRecord,
  updateFormatedData,
  setAdvancedConfigPanel,
  updateDraftSkill,
  startTimer,
  closeAdvancedConfigPanel,
} from "../../../../../../../redux/actions/skill";

import { ADDABLE_SKILL_TYPES } from "../../../../../../../redux/constants/skillConstants";
import settingIcon from "../../../../../../../images/branching/setting-icon.svg";
import recordIcon from "../../../../../../../images/branching/record.svg";
import assertIcon from "../../../../../../../images/branching/assert.svg";
import waitIcon from "../../../../../../../images/branching/wait.svg";
import stopIcon from "../../../../../../../images/branching/stop.svg";
import branchIcon from "../../../../../../../images/branching/branching.svg";
import imageIcon from "../../../../../../../images/image-pic.png";
import playWhite from "../../../../../../../images/play-white.png";
import Loader from "../../../../../../../components/loader";
import readIcon from "../../../../../../../images/branching/readIcon.png";
import filesandfolders from "../../../../../../../images/branching/files.png";
import outlookIcon from "../../../../../../../images/branching/outlook-icon.png";
import outlookImage from "../../../../../../../images/branching/outlook-image.png";
import webAutomationIcon from "../../../../../../../images/template-img/web-automation.png";
import automationIcon from "../../../../../../../images/template-img/automation-icon.png";
import folderIcon from "../../../../../../../images/template-img/MIS.png";
import assign from "../../../../../../../images/assign.png";
import httpApi from "../../../../../../../images/httpApi.png";
import httpApiIcon from "../../../../../../../images/httpApiIcon.png";
import assignIcon from "../../../../../../../images/assignIcon.png";
import InvokeSkillIcon from "../../../../../../../images/InvokeSkillIcon.png";
import InvokeSkillImg from "../../../../../../../images/InvokeSkillImg.png";
import todoIcon from "../../../../../../../images/todo-icon.png";
import excelIcon from "../../../../../../../images/excel-action.png";
import automation from "../../../../../../../images/template-img/data-loading.png";
import echoIcon from "../../../../../../../images/branching/echoIcon.png";
import messageBoxIcon from "../../../../../../../images/branching/messageBoxIcon.png";
import echoImage from "../../../../../../../images/branching/echo-image.png";
import messageBoxImage from "../../../../../../../images/branching/messageBox-image.png";
import kbdIcon from "../../../../../../../images/kbdIcon.png";
import kpIcon from "../../../../../../../images/kpIcon.png";
import javascriptImage from "../../../../../../../images/branching/javascriptImage.png";
import javascriptIcon from "../../../../../../../images/branching/javascriptIcon.png";
import imgEditIcon from "../../../../../../../images/edit-white.svg";
import breakIcon from "../../../../../../../images/break.png";
import continueIcon from "../../../../../../../images/continue.png";
import openAppIcon from "../../../../../../../images/branching/open-app.svg";
import openAppImage from "../../../../../../../images/branching/open-app-ill.svg";
import closeAppIcon from "../../../../../../../images/branching/close-app.svg";
import closeAppImage from "../../../../../../../images/branching/close-app-ill.svg";
import switchAppIcon from "../../../../../../../images/branching/switch-app.svg";
import switchAppImage from "../../../../../../../images/branching/switch-app-ill.svg";
import s3FileDownloadIcon from "../../../../../../../images/s3-file-download.png";
import s3ConnectIcon from "../../../../../../../images/s3-connect.png";
import s3Download from "../../../../../../../images/s3-file-download-illustration.png";
import s3Connect from "../../../../../../../images/AWS-S3-Connect.png";
import s3Archive from "../../../../../../../images/s3-archive-illustration.png";
import s3ArchiveIcon from "../../../../../../../images/s3-archive.png";
import readCred from "../../../../../../../images/read-illustration.png";
import readCredIcon from "../../../../../../../images/read-icon.svg";
import readTable from "../../../../../../../images/table-illustration.png";
import readTableIcon from "../../../../../../../images/table-icon.png";
import keyboardshortCutIcon from "../../../../../../../images/keyboard-shortcut.png";
import keyboardshortCut from "../../../../../../../images/keyboard-illustration.png";
import closeFileIcon from "../../../../../../../images/closefile-icon.png";
import closeFile from "../../../../../../../images/closefile-illustration.png";

import Zoom from "react-medium-image-zoom";
// import Blur from 'react-blur'

import "tui-image-editor/dist/tui-image-editor.css";
import ImageEditor from "@toast-ui/react-image-editor";

import FlowBuilder, {
  NodeContext,
  BuilderContext,
  buildFlatNodes,
  buildTreeNodes,
} from "react-flow-builder";

import _ from "lodash";
import $ from "jquery";

import { store } from "../../../../../../../redux";
import ConfigPanel from "./configPanel";
import AdvancedSettingsPanel from "./advancedSettingsPanel";
import LoopConfigPanel from "./loopConfigPanel";
import VariablesPanel from "./variablesPanel";
import ReadValueConfig from "./readValueConfig";
import FilesFoldersConfig from "./FilesFoldersConfig";
import ExcelConfig from "./ExcelConfig";
import MessageBoxConfig from "./messageBoxConfig";
import SendMailConfigForm from "./mailConfig";
import ConfigDataSet from "./configureDataSet";
import { Select, Drawer } from "antd";
import HttpApiConfig from "./httpApiConfigPanel";
import AssignConfig from "./assignConfig";
import InvokeSkillConfigForm from "./invokeSkillConfig";
import ToDoSkillConfigForm from "./toDoSkillConfig";
import {
  getFileUrl,
  updateFileUrl,
} from "../../../../../../../redux/actions/fileUpload";
import EchoConfig from "./echoConfig";
import TechnologyConfig from "./TechnologyConfig";
import OpenAppConfig from "./OpenAppConfig";
import CloseAppConfig from "./CloseAppConfig";
import SwitchAppConfig from "./SwitchAppConfig";
import ConfigS3 from "./ConfigS3";
import ConfigS3Download from "./ConfigS3Download";
import ConfigS3Archive from "./ConfigS3Archive";
import ConfigReadCredentials from "./ReadCredentials";
import ReadTableConfig from "./ReadTableConfig";
import CloseFileConfig from "./CloseFileConfig";
import KeyboardShortcutConfig from "./KeyboardShortcutConfig";
const { Option } = Select;

const imageEditor = React.createRef();

const TEMPLATE_WITH_LOOP_RESTRICTION = [
  "User Documentation",
  "Web Automation",
  "In-App Walkthrough",
  "User Onboarding",
];

const MAPPPABLE_ACTIONS = ["read", "READFILE", "data-set"];

const LoopStartDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div>
      <div className={`stop-node delay-node rt-block-full`}>
        {/* <span style={{ fontSize: 12, fontWeight: 'bold' }}> Description: </span> */}
        <div className="delay-flex">
          <div
            className="stepIconBlock"
            style={{ backgroundColor: "#eff1ff", borderColor: "#9f64ff" }}
          >
            <AllInclusive style={{ color: "#9f64ff" }} />
          </div>
          <div className="delay-text">
            <h4 className="node-titles">Loop start</h4>
          </div>
        </div>
      </div>
    </div>
  );
};

const TryCatchDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div>
      {node.name == "Error Handle" ? (
        <div className={`stop-node delay-node rt-block-full`}>
          <div className="delay-flex">
            <div
              className="stepIconBlock"
              style={{ backgroundColor: "#f4c6c6", borderColor: "#ff0000" }}
            >
              {node.name == "Error Handle" ? (
                <ReportProblem style={{ color: "#ff0000" }} />
              ) : null}
            </div>

            <div className="delay-text">
              <h4 className="node-titles">{node.name}</h4>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

const AddDataSetNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#00CD9D", backgroundColor: "#b2f7e6" }}
            >
              <Storage
                style={{
                  width: "12px",
                  borderColor: "#00CD9D",
                  backgroundColor: "#b2f7e6",
                  color: "#00CD9D",
                }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Dataset</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={folderIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const AddS3Node = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img style={{ width: "12px" }} src={s3ConnectIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 Connect</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Connect} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const AddS3ArchiveNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#173bff", backgroundColor: "#eff1ff" }}
            >
              <img style={{ width: "12px" }} src={s3ArchiveIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 Archive</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Archive} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const AddS3DownloadNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#1d262e", backgroundColor: "#ebebeb" }}
            >
              <img style={{ width: "12px" }} src={s3FileDownloadIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 File Download</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Download} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const ReadCredentialsNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
            >
              <img style={{ width: "12px" }} src={readCredIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>Read Credentials</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={readCred} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const StartNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className="start-node">
      <div className="rt-block rt-start">
        <div
          className="rtb-ico"
          style={{
            backgroundColor: "#02ce9d",
            cursor: "default",
          }}
        >
          <img src={playWhite} alt="" />
        </div>
        <div className="rtb-text">
          <p>Start</p>
        </div>
      </div>
    </div>
  );
};

const EndNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className="end-node">
      <div className="rt-block rt-end">
        <div
          className="rtb-ico"
          style={{
            backgroundColor: "#ff3333",
            cursor: "default",
          }}
        >
          <span className="circle"></span>
        </div>
        <div className="rtb-text">
          <p>End</p>
        </div>
      </div>
    </div>
  );
};

const NodeDisplay = () => {
  const node = useContext(NodeContext);
  const { skillTemplate, skillType } = useContext(BuilderContext);
  const [selectedImage, setSelectedImage] = useState("");
  const skill = useSelector((state) => state.skillReducer.trainDraft);
  const currentTeam = JSON.parse(localStorage.getItem("orgDetails"));
  const userRole = useSelector(
    (state) => state.organizationReducer.currentOrgUser.role_id
  );
  const [imageUrl, setImageUrl] = useState(null);
  useEffect(() => {
    if (selectedImage) {
      setImageUrl(URL.createObjectURL(selectedImage));
    }
  }, [selectedImage]);

  const removeSaveImageButton = () => {
    const elements = document.getElementsByClassName(
      "tui-image-editor-download-btn"
    );
    while (elements.length > 0) elements[0].remove();
  };

  // Modal Start
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setTimeout(() => {
      removeSaveImageButton();
      const imageEditorInstance = imageEditor.current.getInstance();
      imageEditorInstance.ui.shape.options.fill = "#ffbb3b";
    });
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const saveMaskedImage = async (id, imageFileName) => {
    setLoadingMaskedImage(true);
    const imageEditorInstance = imageEditor.current.getInstance();
    const imageUrl = imageEditorInstance.toDataURL();
    await updateImageAfterMask(imageUrl, id, imageFileName);
    setIsModalOpen(false);
    setLoadingMaskedImage(false);
  };

  const myThme = {};

  const [loadingMaskedImage, setLoadingMaskedImage] = useState(false);
  return (
    <>
      {node.name === "show" || node.name === "train" ? (
        <div className="rt-block-full recording-block">
          <div className="rcd-icon">
            <img src={recordIcon} />
          </div>
          <div className="rcd-text">
            <h4>Show</h4>
            <p> Click on Start button to initiate Web/Desktop show process</p>
            <div className="rth-tooltip">
              {node.description ? (
                <span style={{ fontSize: 12, fontWeight: "400" }}>
                  {node.description}
                </span>
              ) : null}{" "}
            </div>
          </div>
          <button className="rcd-btn" onClick={() => startRecording(node)}>
            <p>Start</p>
            <div
              className="stepIconBlock"
              style={{ backgroundColor: "#fff3ea", borderColor: "#ff7007" }}
            >
              <img src={recordIcon} />
            </div>
          </button>
        </div>
      ) : (
        <div
          className={`rt-block-full other-node ${
            node.configuring ? "node-configuring" : ""
          } ${node.validateStatusError ? "node-status-error" : ""}`}
        >
          <div className="rth-title">
            <div className="tl-cont">
              <div className="rth-tooltip">
                <div className="flex-rth-title">
                  <p> Tooltip: </p>
                  {parseInt(skill?.organizationId) === currentTeam?.id ? (
                    <Edit onClick={() => $(`#${node.id}`).toggle()} />
                  ) : null}
                </div>
                <span style={{ fontSize: 12, fontWeight: "400" }}>
                  {node.description}
                </span>
                <div
                  id={`${node.id}`}
                  style={{ display: "none" }}
                  className="rth-tooltip"
                >
                  <textarea
                    placeholder="Type Something..."
                    defaultValue={node.description}
                    onBlur={(e) => updateDescription(e.target.value, node.id)}
                  ></textarea>
                  <div className="rth-upload">
                    <div className="upload-btn-wrapper">
                      <button class="btn btn-rth-upload">
                        <img src={imageIcon} />
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            setSelectedImage(e.target.files[0]);
                            updateImage(e.target.files[0], node.id);
                          }}
                        ></input>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="rtb-screenshot">
            {node.image ? (
              <div className="img-preview-thumb">
                <img src={node.image} />
              </div>
            ) : null}
            <div className="check-mask">
              {/* <input type="checkbox" id="mask" name="mask" />
              <label for="mask">Mask Image</label> */}
              <Button type="primary" onClick={showModal}>
                <img src={imgEditIcon} />
              </Button>
            </div>
            <Modal
              className="image-editor-modal"
              title="Image Editor"
              footer={null}
              open={isModalOpen}
              onCancel={handleCancel}
              width={1000}
              centered
            >
              {loadingMaskedImage ? (
                <div id="saveMaskedImageButton">
                  <button className="btn btn-primary">
                    <div class="sp sp-circle text-light"></div>
                  </button>
                </div>
              ) : (
                <div id="saveMaskedImageButton">
                  <button
                    className="btn  btn-primary"
                    onClick={() =>
                      saveMaskedImage(node.id, node.pageScreenshot)
                    }
                  >
                    Mask Image
                  </button>
                </div>
              )}

              <ImageEditor
                includeUI={{
                  loadImage: {
                    path: selectedImage ? imageUrl : node.pageScreenshot,
                    name: "pageScreenshot",
                  },
                  // theme: myTheme,
                  menu: ["shape"],
                  shape: ["rectangle"],
                  initMenu: "shape",
                  uiSize: {
                    width: "100%",
                    height: "700px",
                  },
                  menuBarPosition: "bottom",
                }}
                cssMaxHeight={650}
                cssMaxWidth={800}
                selectionStyle={{
                  cornerSize: 10,
                  rotatingPointOffset: 70,
                }}
                usageStatistics={false}
                ref={imageEditor}
              />
            </Modal>
            <Zoom>
              <img
                src={selectedImage ? imageUrl : node.pageScreenshot}
                alt="pageScreenshot"
              />
            </Zoom>
          </div>
          {skillTemplate === "In-App Walkthrough" &&
          parseInt(skill?.organizationId) === currentTeam?.id ? (
            <div class="step-position">
              <div class="manual-step active">
                <div class="ch-switch">
                  <input
                    class="tgl tgl-light"
                    name="isManualStep"
                    id={`${node.id}-mn-step`}
                    type="checkbox"
                    onChange={(e) => toggleManualBtn(e, node.id)}
                    defaultChecked={node.isManualStep ? true : false}
                  />
                  <label class="tgl-btn" for={`${node.id}-mn-step`}></label>
                </div>
                <span class="mn-small-text">Manual Step</span>
              </div>
              {node.isManualStep ? (
                <>
                  <div class="next-btn-mn">
                    <div class="mn-radio">
                      <div class="mnr-item">
                        <input
                          type="radio"
                          id={`${node.id}-yes`}
                          name={node.id}
                          value={true}
                          checked={node.displayNextBtn === true}
                          onChange={(e) =>
                            handleNextButtonChange(e.target, "yes", node.id)
                          }
                        />
                        <label for={`${node.id}-yes`}>Yes</label>
                      </div>
                      <div class="mnr-item">
                        <input
                          type="radio"
                          id={`${node.id}-no`}
                          name={node.id}
                          value={false}
                          checked={node.displayNextBtn === false}
                          onChange={(e) =>
                            handleNextButtonChange(e.target, "no", node.id)
                          }
                        />
                        <label for={`${node.id}-no`}>No</label>
                      </div>
                    </div>
                    <span class="mn-small-text">Display Next Button?</span>
                  </div>
                  <div className="antDropdown">
                    <Select
                      labelInValue
                      defaultValue={node.position ? node.position : "Auto"}
                      style={{
                        width: 75,
                        textAlign: "center",
                      }}
                      onChange={(e) => handleChange(e, node.id)}
                    >
                      <Option value="auto">Auto</Option>
                      <Option value="left">Left</Option>
                      <Option value="right">Right</Option>
                      <Option value="top">Top</Option>
                      <Option value="bottom">Bottom</Option>
                    </Select>
                    <span className="mn-small-text">Position</span>
                  </div>
                </>
              ) : null}
            </div>
          ) : null}

          {userRole === "1" ? null : (
            <span
              className="setting-icon"
              onClick={() => openAdvancedPanel(node.id)}
            >
              Settings <img src={settingIcon} />
            </span>
          )}
        </div>
      )}
    </>
  );
};

const ConditionNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div
      className={`rt-block-full condition-node ${
        false ? "node-configuring" : ""
      } ${true ? "node-status-error" : ""}`}
    >
      <div className="rotate-content">
        <h4 className="node-titles">{node.name}</h4>
      </div>
    </div>
  );
};

const StopNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
        >
          <img src={stopIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.name}</h4>
        </div>
      </div>
    </div>
  );
};

const CloseTabNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
        >
          <img src={closeAppIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.name}</h4>
        </div>
      </div>
    </div>
  );
};

const AssertNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div
      className={`assert-block ${false ? "node-configuring" : ""} ${
        true ? "node-status-error" : ""
      }`}
    >
      <div className="rotate-content">
        <h4 className="node-titles">{node.name}</h4>
      </div>
    </div>
  );
};

const DelayNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      {/* <span style={{ fontSize: 12, fontWeight: 'bold' }}> Description: </span> */}
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={waitIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
          <Edit onClick={() => $(`#${node.id}`).toggle()} />
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      >
        <input
          defaultValue={node.time}
          onBlur={(e) => updateTime(e.target.value, node.id)}
        ></input>
      </div>
    </div>
  );
};

const BreakNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={breakIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      ></div>
    </div>
  );
};

const ContinueNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={continueIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      ></div>
    </div>
  );
};

const ReadValueNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div className="tl-cont-ico" style={{ borderColor: "#411bbe" }}>
              <img src={readIcon} style={{ width: "14px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Read</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img
          src={automationIcon}
          alt="pageScreenshot"
          style={{ width: "70%" }}
        />
      </div>
    </div>
  );
};

const MailIntegrationNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div className="tl-cont-ico">
              <img src={outlookIcon} style={{ width: "30px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Outlook Mail</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={outlookImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const FilesNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img src={filesandfolders} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Files / Folders</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={folderIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const SecretNodeDisplay = () => {
  const node = useContext(NodeContext);
  return <div>{null}</div>;
};

const ExcelNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      {/* <span style={{ fontSize: 12, fontWeight: 'bold' }}> Description: </span> */}
      {/* <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={filesandfolders} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
          <Edit onClick={() => $(`#${node.id}`).toggle()} />
        </div>
      </div> */}
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img src={excelIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Excel Actions</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={automation} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const HttpApiNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
            >
              <img src={httpApi} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Service Call</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={httpApiIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const EchoNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              // style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
              style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img
                src={echoIcon}
                // style={{ width: "12px" }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Echo</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={echoImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const TechnologyNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#e6b921", backgroundColor: "#fff2c4" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={javascriptIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Javascript</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={javascriptImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const OpenAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#9f64ff", backgroundColor: "#f2eaff" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={openAppIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Open App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={openAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const CloseAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={closeAppIcon} style={{ width: "10px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Close App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={closeAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const SwitchAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#02b6ce", backgroundColor: "#edfdff" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={switchAppIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Switch App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={switchAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const MessageBoxNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              // style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
              style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img
                src={messageBoxIcon}
                // style={{ width: "12px" }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Message Box</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={messageBoxImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const AssignNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={assign} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Assign</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={assignIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const InvokeSkillNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={InvokeSkillIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              {node?.skillName ? (
                <p>{`Invoke Skill - ${node.skillName}`}</p>
              ) : (
                <p>{`Invoke Skill`}</p>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={InvokeSkillImg} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const ToDoSkillNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={todoIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              {node?.skillName ? (
                <p>{`To Do - ${node.skillName}`}</p>
              ) : (
                <p>{`To Do`}</p>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      {/* <div className="rtb-screenshot filled-bg">
        <img src={InvokeSkillImg} alt="pageScreenshot" />
      </div> */}
    </div>
  );
};

const ReadTableNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
            >
              <img src={readTableIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Read Table</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={readTable} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const CloseFileNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
            >
              <img src={closeFileIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Close File</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={closeFile} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const KeyboardShortcutNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundgColor : "#f2eaff" ,  borderColor : "#9f64ff" }}
            >
              <img src={keyboardshortCutIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Keyboard ShortCuts</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={keyboardshortCut} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const startRecording = (node) => {
  store.dispatch(startTimer(true));
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let payload = {
    skillId: trainDraft.id,
    markerIndex: 0,
    nodeId: node.id,
  };
  store.dispatch(startRecord(payload));
};

const updateTime = (value, id) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    time: value,
    description: `Wait ${value} Seconds`,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
  $(`#${id}`).toggle();
};

const updateDescription = (value, id) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    description: value,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
  $(`#${id}`).toggle();
};

const updateImage = async (file, id) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let url = await store.dispatch(getFileUrl(file));
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    pageScreenshot: url,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
  $(`#${id}`).toggle();
};

function dataURItoBlob(dataURI) {
  var binary = atob(dataURI.split(",")[1]);
  var array = [];
  for (var i = 0; i < binary.length; i++) {
    array.push(binary.charCodeAt(i));
  }
  return new Blob([new Uint8Array(array)], { type: "image/png" });
}

const updateImageAfterMask = async (file, id, imageFileName) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();

  file = dataURItoBlob(file);
  file.lastModifiedDate = new Date();
  imageFileName = imageFileName.split("image/")[1];
  let url = await store.dispatch(updateFileUrl(file, imageFileName));
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    pageScreenshot: url,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
  $(`#${id}`).toggle();
};

let registerNodes = [
  {
    type: "start",
    name: "start",
    actionType: "start",
    displayComponent: StartNodeDisplay,
    isStart: true,
    addableNodeTypes: ["try"],
  },
  {
    type: "end",
    name: "end",
    actionType: "end",
    displayComponent: EndNodeDisplay,
    isEnd: true,
  },
  {
    type: "record",
    name: "show",
    actionType: "record",
    displayComponent: NodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff3ea", borderColor: "#ff7007" }}
      >
        <img src={recordIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "continue",
    name: "continue",
    actionType: "continue",
    displayComponent: ContinueNodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={continueIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "break",
    name: "break",
    actionType: "break",
    displayComponent: BreakNodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={breakIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "wait",
    name: "wait",
    actionType: "wait",
    displayComponent: DelayNodeDisplay,
    configComponent: null,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
      >
        <img src={waitIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "read",
    name: "read",
    actionType: "read",
    displayComponent: ReadValueNodeDisplay,
    configComponent: ReadValueConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eff1ff", borderColor: "#411bbd" }}
      >
        <img src={readIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "filesandfolders",
    name: "Files/Folders",
    actionType: "readfile",
    displayComponent: FilesNodeDisplay,
    configComponent: FilesFoldersConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={filesandfolders} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "excel",
    name: "Excel",
    actionType: "OPEN_SPREADSHEET",
    displayComponent: ExcelNodeDisplay,
    configComponent: ExcelConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={excelIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "echo",
    name: "Echo",
    actionType: "ECHO",
    displayComponent: EchoNodeDisplay,
    configComponent: EchoConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        // style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
        style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={echoIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "TECHNOLOGY",
    name: "Javascript",
    actionType: "TECHNOLOGY",
    displayComponent: TechnologyNodeDisplay,
    configComponent: TechnologyConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={javascriptIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "OPENAPP",
    name: "Open App",
    actionType: "OPENAPP",
    displayComponent: OpenAppNodeDisplay,
    configComponent: OpenAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={openAppIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "CLOSEAPP",
    name: "Close App",
    actionType: "CLOSEAPP",
    displayComponent: CloseAppNodeDisplay,
    configComponent: CloseAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={closeAppIcon} style={{ width: "10px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "SWITCHAPP",
    name: "Switch App",
    actionType: "SWITCHAPP",
    displayComponent: SwitchAppNodeDisplay,
    configComponent: SwitchAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={switchAppIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "messagebox",
    name: "Message Box",
    actionType: "MESSAGE_BOX",
    displayComponent: MessageBoxNodeDisplay,
    configComponent: MessageBoxConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        // style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
        style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={messageBoxIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "httpapi",
    name: "Service Call",
    actionType: "httpapi",
    displayComponent: HttpApiNodeDisplay,
    configComponent: HttpApiConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe5fe", borderColor: "#ff07f5" }}
      >
        <img src={httpApi} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "assign",
    name: "Assign",
    actionType: "assign",
    displayComponent: AssignNodeDisplay,
    configComponent: AssignConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={assign} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "GET_AZURESECRET",
    name: "Get Secret",
    actionType: "GET_AZURESECRET",
    displayComponent: SecretNodeDisplay,
    configComponent: null,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={assign} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "sendMail",
    name: "Outlook Mail",
    actionType: "sendMail",
    displayComponent: MailIntegrationNodeDisplay,
    configComponent: SendMailConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#deeef9", borderColor: "#0D75BB" }}
      >
        <img src={outlookIcon} style={{ width: "24px", maxWidth: "initial" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "invokeSkill",
    name: "Invoke Skill",
    actionType: "invokeSkill",
    displayComponent: InvokeSkillNodeDisplay,
    configComponent: InvokeSkillConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff", borderColor: "#000" }}
      >
        <img
          src={InvokeSkillIcon}
          style={{ width: "12px", maxWidth: "initial" }}
        />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "toDoSkill",
    name: "Add a ToDo",
    actionType: "toDoSkill",
    displayComponent: ToDoSkillNodeDisplay,
    configComponent: ToDoSkillConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={todoIcon} style={{ width: "12px", maxWidth: "initial" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "condition",
    name: "condition",
    actionType: "condition",
    displayComponent: ConditionNodeDisplay,
    configComponent: ConfigPanel,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    configTitle: "Configure Condition",
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "stop",
    name: "stop",
    displayComponent: StopNodeDisplay,
    actionType: "stop",
    configComponent: null,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img src={stopIcon} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "loop",
    name: "loop",
    conditionNodeType: "loop-nodes",
    actionType: "loop",
    addConditionIcon: null,
    configComponent: null,
    conditionMaxNum: 1,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "loop-nodes",
    name: "loop-nodes",
    displayComponent: LoopStartDisplay,
    actionType: "loopStart",
    configComponent: LoopConfigPanel,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "data-set",
    name: "Add Dataset",
    actionType: "addDataSet",
    displayComponent: AddDataSetNode,
    configComponent: ConfigDataSet,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#b2f7e6", borderColor: "#00CD9D" }}
      >
        <Storage style={{ color: "#00CD9D" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_CONNECT",
    name: "S3 Connect",
    actionType: "S3_CONNECT",
    displayComponent: AddS3Node,
    configComponent: ConfigS3,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: " #ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={s3ConnectIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_FILE_ARCHIVE",
    name: "S3 File Archive",
    actionType: "S3_FILE_ARCHIVE",
    displayComponent: AddS3ArchiveNode,
    configComponent: ConfigS3Archive,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: " #ffe3ce", borderColor: " #173bff" }}
      >
        <img src={s3ArchiveIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_FILE_DOWNLOAD",
    name: "S3 File Download",
    actionType: "S3_FILE_DOWNLOAD",
    displayComponent: AddS3DownloadNode,
    configComponent: ConfigS3Download,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ebebeb", borderColor: "#1d262e" }}
      >
        <img style={{ width: "12px" }} src={s3FileDownloadIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "READ_CREDENTIALS",
    name: "Read Credentials",
    actionType: "READ_CREDENTIALS",
    displayComponent: ReadCredentialsNode,
    configComponent: ConfigReadCredentials,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img style={{ width: "12px" }} src={readCredIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "READ_TABLE",
    name: "Read Table",
    actionType: "READ_TABLE",
    displayComponent: ReadTableNodeDisplay,
    configComponent: ReadTableConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
      >
        <img src={readTableIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "CLOSE",
    name: "Close File",
    actionType: "CLOSE",
    displayComponent: CloseFileNodeDisplay,
    configComponent: CloseFileConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img src={closeFileIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "KEY_STROKES",
    name: "Keyboard ShortCuts",
    actionType: "KEY_STROKES",
    displayComponent: KeyboardShortcutNodeDisplay,
    configComponent: KeyboardShortcutConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundgColor : "#f2eaff" ,  borderColor : "#9f64ff"  }}
      >
        <img src={keyboardshortCutIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "branch",
    name: "branch",
    actionType: "branch",
    conditionNodeType: "condition",
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
      >
        <img src={branchIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "closetab",
    name: "Close Tab",
    displayComponent: CloseTabNodeDisplay ,
    actionType: "closetab",
    configComponent: null,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img src={closeAppIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "try",
    name: "try",
    conditionNodeType: "try-catch-node",
    actionType: "try",
    addConditionIcon: null,
    configComponent: null,
    conditionMaxNum: 1,
    customRemove: true,
    className: "try-catch-parent try-catch-parent-verbose",
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "try-catch-node",
    name: "try-catch-node",
    className: "try-catch-node try-catch-node-verbose",
    displayComponent: TryCatchDisplay,
    actionType: "try-catch-node",
    customRemove: true,
    configComponent: null,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
];

const findAndUpdate = (arr, id, payload) => {
  let found = arr.findIndex((i) => i.id == id);
  if (found > -1) {
    arr[found] = { ...arr[found], ...payload };
  } else {
    arr.forEach((element) => {
      if (
        [
          "branch",
          "condition",
          "loop",
          "loop-nodes",
          "try",
          "try-catch-node",
        ].includes(element.type)
      ) {
        findAndUpdate(element.children, id, payload);
      }
    });
  }
  return arr;
};

const findEle = (arr, id) => {
  let result;
  arr.some(
    (child) =>
      (child.id === id && (result = child)) ||
      (result = findEle(child.children || [], id))
  );
  return result;
};

const findAndRemove = (arr, id) => {
  let found = arr.findIndex((i) => i.id === id);
  if (found > -1) {
    arr.splice(found, 1);
  } else {
    arr.forEach((element) => {
      if (
        [
          "branch",
          "condition",
          "loop",
          "loop-nodes",
          "try",
          "try-catch-node",
        ].includes(element.type)
      ) {
        findAndRemove(element.children, id);
      }
    });
  }
  return arr;
};

const handleChange = (value, nodeId) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, nodeId, {
    position: value.value,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
};

const handleNextButtonChange = (e, type, id) => {
  let val = type === "yes" && e.checked;
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    displayNextBtn: val,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
};

const toggleManualBtn = (e, id) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
    isManualStep: e.target.checked,
  });
  store.dispatch(
    setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
  );
};

const saveAdvancedConfig = (values, id, shouldClose = true) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  if (values?.imgSelector) {
    let actions = findAndUpdate(trainDraft?.RAW_DATA?.actions, id, {
      pageScreenshot: values.imgSelector,
    });
    store.dispatch(
      setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions } })
    );
  }

  let formatData = trainDraft.FORMATED_DATA;
  formatData.actions[id] = { ...formatData.actions[id], ...values };
  store.dispatch(setDraft({ ...trainDraft, FORMATED_DATA: formatData }));
  store.dispatch(
    updateDraftSkill(trainDraft.id, {
      ...trainDraft,
      FORMATED_DATA: formatData,
    })
  );
  // store.dispatch(closeAdvancedConfigPanel());
};

const openAdvancedPanel = (id) => {
  let {
    skillReducer: { trainDraft },
  } = store.getState();
  let formatedData = trainDraft.FORMATED_DATA.actions[id];
  store.dispatch(
    setAdvancedConfigPanel({ ...formatedData, panelVisible: true })
  );
};

const getNode = (type, child = false) => {
  return {
    id: uuid(),
    type: type,
    name: type,
    actionType: type,
    children: child ? [] : undefined,
    isStart: type === "start",
    isEnd: type === "end",
  };
};

const getWaitNode = (time) => {
  return {
    actionType: "wait",
    label: "Wait",
    key: "wait",
    time: time,
    allowNesting: false,
    description: `Wait ${time} Seconds`,
    status: true,
    breakpoint: false,
    instruction: "wait 1",
  };
};

const getContinueNode = () => {
  return {
    actionType: "continue",
    label: "Statements",
    key: "continue",
    allowNesting: false,
    statement: "continue",
    variableName: "",
    instruction: "continue",
    status: true,
    breakpoint: false,
    description: "Continue",
  };
};

const getBreakNode = () => {
  return {
    actionType: "break",
    label: "Statements",
    key: "break",
    allowNesting: false,
    statement: "break",
    variableName: "",
    instruction: "break",
    status: true,
    breakpoint: false,
    description: "Break",
  };
};
const getCloseTabNode = () => {
  return {
    actionType: "closetab",
    label: "Close Tab",
    key: "closetab",
    allowNesting: false,
    statement: "closetab",
    variableName: "",
    instruction: "closetab",
    status: true,
    breakpoint: false,
    description: "closetab",
  };
};

const getLoopNodes = () => {
  return {
    actionType: "loop",
    label: "Loop",
    key: "loop",
    allowNesting: false,
    description: `Loop`,
    status: true,
    breakpoint: false,
    children: [
      {
        actionType: "wait",
        label: "Wait",
        key: "wait",
        time: 1,
        allowNesting: false,
        description: `Wait ${1} Seconds`,
        status: true,
        breakpoint: false,
        instruction: "wait 1",
      },
    ],
  };
};

const getReadNode = () => {
  return {
    actionType: "read",
    label: "read",
    key: "read",
    status: true,
    readFromElement: "",
    readToVariable: "",
    instruction: "",
  };
};

const getExcelActionNode = () => {
  return {
    actionType: "OPEN_SPREADSHEET",
    label: "Excel",
    key: "excel",
    instruction: "",
    description: "",
    status: true,
  };
};

const getFilesAndFolderNode = () => {
  return {
    actionType: "READFILE",
    label: "Files/Folders",
    key: "filesandfolders",
    instruction: "",
    description: "",
    ifCondition: "files",
    dates: "static",
    extractToSameLocation: false,
    status: true,
  };
};

const getHttpApiNode = () => {
  return {
    actionType: "HTTP",
    label: "HTTP API",
    key: "httpapi",

    reqBody: "",
    method: "GET",
    body: false,
    url: "",
    headers: false,
    apiHeaders: [
      {
        id: 1,
        headerKey: "Content-Type",
        headerValue: "application/json",
        keyId: 1.1,
      },
    ],
    variableName: "",
    instruction:
      "api_config = { method:'POST', header:[\"Content-Type:application/json\"],body:{}}\napi sds\necho api_result\necho api_json",

    description: "API call to sds with Content-Type:application/json",
    apiFileAttachments: "",
    status: true,
    attachments: false,
  };
};

const getAssignNode = () => {
  return {
    actionType: "ASSIGN",
    label: "Assign",
    key: "assign",
    description: "",
  };
};

const connectS3Node = () => {
  return {
    actionType: "S3_CONNECT",
    label: "S3 Connection",
    key: "s3connection",
    description: "",
    allowNesting: false,
    accessKey: "",
    secretKey: "",
    status: true,
    breakpoint: false,
    instruction: "Connect to S3",
    description: "Connect to AWS S3",
  };
};
const downloadS3Node = () => {
  return {
    actionType: "S3_FILE_DOWNLOAD",
    label: "Download File",
    key: "s3downloadfile",
    description: "",
    allowNesting: false,
    bucketName: "",
    folderPath: "",
    keyName: "",
    status: true,
    breakpoint: false,
    instruction: "download s3 file",
    description: "Download file from AWS S3",
    Region: "", //(mandate)
    Archive: false, //(optional)
    ArchiveToBucketName: "", //(optional)
    ArchiveKeyName: "", //(optional)
  };
};

const connectS3ArchiveNode = () => {
  return {
    actionType: "S3_FILE_ARCHIVE",
    label: "Archive File",
    key: "s3archivefile",
    description: "",
    allowNesting: false,
    status: true,
    sourceBucketName: "", //(mandate)
    sourceKeyName: "", //(mandate)
    breakpoint: false,
    instruction: "archive s3 file",
    description: "archive s3 file",
    Region: "", //(mandate)
    destinationBucketName: "", //(mandate)
    destinationKeyName: "", //(optional)
  };
};
const getSendMailNode = () => {
  return {
    actionType: "sendOutlookMail",
    label: "sendOutlookMail",
    key: "sendOutlookMail",
    subActions: [],
    allowNesting: true,
    // to: "",
    // subject: "",
    // body: "",
    // cc: "",
    // bcc: "",
    // attachments: "",
    api: "http://localhost:8002/api/v1/sendMail",
    description: "",
    status: true,
    breakpoint: false,
    instruction: "",
  };
};

const getInvokeSkillNode = () => {
  return {
    actionType: "invokeSkill",
    label: "invokeSkill",
    key: "invokeSkill",
    status: true,
    description: "",
    instruction: "",
    skillId: "",
    skillName: "",
  };
};
const getToDoSkillNode = () => {
  return {
    actionType: "invokeSkill",
    label: "invokeSkill",
    key: "invokeSkill",
    status: true,
    description: "",
    instruction: "",
    skillId: "",
    skillName: "",
  };
};
const readCredentialsNode = () => {
  return {
    actionType: "READ_CREDENTIALS",
    label: "Read Credentials",
    key: "ReadCredentials",
    allowNesting: false,
    CredName: "",
    variable: "",
    UserName: "",
    Password: "",
    variableName: "",
    instruction: "",
    status: true,
    description: "read credentials",
    newdescription: "read credentials",
  };
};
const readTableNode = () => {
  return {
    actionType: "READ_TABLE",
    label: "Read Table",
    key: "readtable",
    subActions: [],
    allowNesting: false,
    description: "",
    variableName: "",
    instruction: "",
    iframe_name: "",
    status: true,
    breakpoint: false,
  };
};
const closeFileNode = () => {
  return {
    actionType: "CLOSE",
    label: "Close File",
    key: "close",
    description: "",
    instruction: "",
    status: true,
    breakpoint: false,
  };
};
const keyboardShortcutNode = () => {
  return {
    actionType: "KEY_STROKES",
    label: "Keyboard ShortCuts",
    key: "keyboardshortcuts",
    description: "",
    instruction: "",
    status: true,
    breakpoint: false,
  };
};
const getChildBlockData = (action) => {
  let _checkDesktopAction = action?.map((c) => {
    if (
      [
        "branch",
        "condition",
        "loop",
        "loop-nodes",
        "try",
        "try-catch-node",
      ].includes(c.type)
    ) {
      if (c.type === "branch") {
        c.actionType = "branch";
      }
      getChildBlockData(c.children);
    }
    if (c.actionType === "kbd") {
      c["pageScreenshot"] = kbdIcon;
    }
    if (c.actionType === "kp") {
      c["pageScreenshot"] = kpIcon;
    }
  });
  return _checkDesktopAction;
};

const getRearrangedData = (actions) => {
  let temp = [];
  temp.push(getNode("start"));
  actions.forEach((a, i) => {
    if (a.actionType === "try") {
      getChildBlockData(a.children[0].children);
      getChildBlockData(a.children[1].children);

      // temp.push(a);
    }
    if (a.nodeId && a.kind === "branch") {
      getChildBlockData(a?.children[0]?.children);
      getChildBlockData(a?.children[1]?.children);

      // temp.push(a);
    } else if (!a.type) {
      a.type = a.actionType;
      temp.push(a);
    } else if (a.actionType === "kbd") {
      a["pageScreenshot"] = kbdIcon;
      temp.push(a);
    } else if (a.actionType === "kp") {
      a["pageScreenshot"] = kpIcon;
      temp.push(a);
    } else {
      temp.push(a);
    }
  });
  temp.push(getNode("end"));
  return temp;
};

const flatten = (arr, _arr) => {
  arr.forEach((i) => {
    if (
      [
        "branch",
        "condition",
        "loop",
        "loop-nodes",
        "try",
        "try-catch-node",
      ].includes(i.type)
    ) {
      _arr.push(i);
      flatten(i.children, _arr);
    } else {
      _arr.push(i);
    }
  });
  return _arr;
};

const findDiff = (arr1, arr2, type) => {
  let obj1, obj2, diff;
  if (arr1.length !== arr2.length) {
    diff = _.differenceWith(arr2, arr1, _.isEqual).filter(
      (i) => i.type === type
    )[0];
  } else {
    obj1 = flatten(arr1, []);
    obj2 = flatten(arr2, []);
    diff = _.differenceWith(obj2, obj1, _.isEqual).filter(
      (i) => i.type === type
    )[0];
    diff = findEle(arr2, diff.id);
  }
  return diff;
};

const getFlowVars = (actions) => {
  let vars = actions
    .filter((i) => i.xPath && i.actionType !== "click")
    .map((i) => {
      return {
        xPath: i.xPath,
        pageScreenshot: i.pageScreenshot,
        name: i.name,
        value: i.value,
        id: i.id,
      };
    });
  return vars;
};

const getDataSetChildVars = (actions, childVar) => {
  actions.forEach((action) => {
    if (
      [
        "branch",
        "condition",
        "loop",
        "loop-nodes",
        "try",
        "try-catch-node",
      ].includes(action.type)
    ) {
      getDataSetChildVars(action?.children, childVar);
    }
    if (action.type === "data-set") {
      let _datavar = {
        id: action.id,
        ...action.data,
      };
      childVar.push(_datavar);
    }
  });
  return childVar;
};

const getDatasetVars = (actions) => {
  let _allVar = [];
  actions.forEach((action) => {
    if (
      [
        "branch",
        "condition",
        "loop",
        "loop-nodes",
        "try",
        "try-catch-node",
      ].includes(action.type)
    ) {
      let childData = getDataSetChildVars(action?.children, []);
      _allVar = _allVar.concat(childData);
    }
    if (action.type === "data-set") {
      let _datavar = {
        id: action.id,
        ...action.data,
      };
      _allVar.push(_datavar);
    }
  });

  return _allVar;
};

const getGlobalVars = (actions) => {
  let vars = actions
    .filter((i) => MAPPPABLE_ACTIONS.includes(i.actionType || i.type))
    .map((i) => {
      return {
        id: i.id,
        name: i.name,
        variable: i.variable || i.readToVariable,
      };
    });
  return vars;
};

const saveFlow = (skill, actions) => {
  var rawData = {
    ...skill?.RAW_DATA,
    actions: actions,
  };
  var status = skill.status;
  let skillName = skill.SKILL_NAME;
  let updatedData = { status, skillName, rawData, itemId: skill.id };
  store.dispatch(updateFormatedData(updatedData));
};

const NodeForm = () => {
  const dispatch = useDispatch();
  const [nodes, setNodes] = useState([]);
  const [customClassName, setCustomClassName] = useState("");
  const [flowVars, setFlowVars] = useState([]);
  const [datasetVars, setDatasetVars] = useState([]);
  const [globalVars, setGlobalVars] = useState({});

  const [loader, setLoader] = useState(false);
  let [validNodes, setValidNodes] = useState(registerNodes);
  const [showConfigPanel, setShowConfigPanel] = useState(false);
  const [showVariablesPanel, setShowVariablesPanel] = useState(false);
  const [verboseView, setVerboseView] = useState(false);
  const skill = useSelector((state) => state.skillReducer.trainDraft);
  const loading = useSelector((state) => state.skillReducer.loading);
  const currentTeam = JSON.parse(localStorage.getItem("orgDetails"));
  const userRole = useSelector(
    (state) => state.organizationReducer.currentOrgUser.role_id
  );
  const advancedConfigPanel = useSelector(
    (state) => state.skillReducer.advancedConfigPanel
  );

  useEffect(() => {
    let _actions = _.cloneDeep(skill?.RAW_DATA?.actions);
    let actions = getRearrangedData(_actions || []);
    let vars = getFlowVars(_actions || []);
    getGlobalVars(_actions || []);
    setNodes(actions);
    if (vars.length !== flowVars.length) {
      setFlowVars(vars);
    }
    setValidNodes(getValidNodes(skill?.TEMPLATE));
    setDatasetVars(getDatasetVars(_actions || []));
  }, [skill]);

  useEffect(() => {
    let visible = advancedConfigPanel?.record?.panelVisible;
    setShowConfigPanel(visible);
  }, [advancedConfigPanel]);

  useEffect(() => {
    setLoader(loading);
  }, [loading]);

  const getValidNodes = (template) => {
    if (TEMPLATE_WITH_LOOP_RESTRICTION.includes(template)) {
      setCustomClassName("");
      return registerNodes.filter(
        (i) => !["loop", "loop-nodes"].includes(i.type)
      );
    } else {
      setCustomClassName("flow-builder-for-loop");
      return registerNodes;
      // return registerNodes.filter((i) => !["GET_AZURESECRET"].includes(i.type));
    }
  };

  const handleChange = (_nodes, e) => {
    let diff = {};
    switch (e) {
      case "init-builder":
        setNodes(_nodes);
        break;
      case "click-node":
      case "close-drawer":
        break;
      case "add-node__record":
      case "node__record":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        saveFlow(skill, _nodes);
        break;
      case "add-node__branch":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        _nodes.forEach((i) => {
          if (i.type === "branch") {
            i.nodeId = i.id;
            i.kind = "branch";
          }
        });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        saveFlow(skill, _nodes);

        break;
      case "add-node__wait":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "wait");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getWaitNode("1") });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__loop":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "loop");
        diff.actionType = "loop";
        diff.children.pop();
        diff.children[0].actionType = "loop-nodes";
        setCustomClassName("flow-builder-for-loop");
        _nodes = findAndUpdate(_nodes, diff.id, { ...diff });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__try":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "try");
        diff.actionType = "try";
        diff.children[0].name = "Action Flow";
        diff.children[1].name = "Error Handle";
        _nodes = findAndUpdate(_nodes, diff.id, { ...diff });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__try-catch-node":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "try-catch-node");
        _nodes = findAndRemove(_nodes, diff.id);
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__loop-nodes":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "loop-nodes");
        _nodes = findAndRemove(_nodes, diff.id);
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__continue":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "continue");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getContinueNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__break":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "break");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getBreakNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__closetab":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "closetab");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getCloseTabNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__read":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "read");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getReadNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__filesandfolders":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "filesandfolders");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getFilesAndFolderNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__excel":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "excel");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getExcelActionNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__httpapi":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "httpapi");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getHttpApiNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__assign":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "assign");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getAssignNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__sendMail":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "sendMail");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getSendMailNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__invokeSkill":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "invokeSkill");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getInvokeSkillNode() });

        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__toDoSkill":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "toDoSkill");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getToDoSkillNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__S3_FILE_DOWNLOAD":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "S3_FILE_DOWNLOAD");
        _nodes = findAndUpdate(_nodes, diff.id, { ...downloadS3Node() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__S3_CONNECT":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "S3_CONNECT");
        _nodes = findAndUpdate(_nodes, diff.id, { ...connectS3Node() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__S3_FILE_ARCHIVE":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "S3_FILE_ARCHIVE");
        _nodes = findAndUpdate(_nodes, diff.id, { ...connectS3ArchiveNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;

      case "add-node__READ_CREDENTIALS":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "READ_CREDENTIALS");
        _nodes = findAndUpdate(_nodes, diff.id, { ...readCredentialsNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
      case "add-node__READ_TABLE":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "READ_TABLE");
        _nodes = findAndUpdate(_nodes, diff.id, { ...readTableNode() });
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
        break;
        case "add-node__CLOSE":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "CLOSE");
          _nodes = findAndUpdate(_nodes, diff.id, { ...closeFileNode() });
          dispatch(
            setDraft({
              ...skill,
              RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
            })
          );
          break;
          case "add-node__KEY_STROKES":
            _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
            diff = findDiff(skill?.RAW_DATA?.actions, _nodes, "KEY_STROKES");
            _nodes = findAndUpdate(_nodes, diff.id, { ...keyboardShortcutNode() });
            dispatch(
              setDraft({
                ...skill,
                RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
              })
            );
            break;

      default:
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        dispatch(
          setDraft({
            ...skill,
            RAW_DATA: { ...skill.RAW_DATA, actions: _nodes },
          })
        );
    }
  };

  const closeDrawer = () => {
    dispatch(closeAdvancedConfigPanel());
    setShowConfigPanel(false);
  };

  const closeVariablePanel = () => {
    setShowVariablesPanel(false);
  };

  const toggleVerboseView = () => {
    let hasVerboseClass = $(".try-catch-node").hasClass(
      "try-catch-node-verbose"
    );
    if (hasVerboseClass) {
      $(".try-catch-node").removeClass("try-catch-node-verbose");
      $(".try-catch-parent").removeClass("try-catch-parent-verbose");
    } else {
      $(".try-catch-node").addClass("try-catch-node-verbose");
      $(".try-catch-parent").addClass("try-catch-parent-verbose");
    }
    setVerboseView(!verboseView);
  };

  return (
    <>
      <Drawer
        title="Advanced Settings"
        placement="right"
        width={400}
        onClose={() => closeDrawer()}
        visible={showConfigPanel}
      >
        {showConfigPanel ? (
          <AdvancedSettingsPanel
            data={advancedConfigPanel}
            updateConfig={saveAdvancedConfig}
          />
        ) : null}
      </Drawer>

      <Drawer
        title="Flow variables"
        placement="right"
        width={700}
        onClose={() => closeVariablePanel()}
        visible={showVariablesPanel}
      >
        <VariablesPanel variables={skill?.RAW_DATA?.variables} />
      </Drawer>

      <div style={{ position: "relative" }}>
        <button
          style={{
            backgroundColor: "#fff",
            padding: "10px 20px",
            position: "absolute",
            borderRadius: 2,
            left: "2%",
            zIndex: 1,
          }}
          onClick={() => setShowVariablesPanel(true)}
        >
          Variables
        </button>

        {nodes[1]?.type == "try" ? (
          <Switch
            checkedChildren="Verbose View"
            unCheckedChildren="Verbose View Off"
            defaultChecked={false}
            onChange={() => toggleVerboseView()}
            style={{
              left: "2%",
              zIndex: 1,
              top: 55,
            }}
          />
        ) : null}
      </div>

      {loading ? (
        <Loader
          styles={{ width: "80px", margin: "auto" }}
          root={{ display: "flex" }}
        />
      ) : (
        <FlowBuilder
          className={`outer-drag scrollable ${customClassName}`}
          nodes={nodes}
          onChange={handleChange}
          registerNodes={validNodes}
          zoomTool
          skillTemplate={skill?.TEMPLATE}
          skillType={skill?.TYPE}
          flowVariables={flowVars}
          datasetVariables={datasetVars}
          // readonly={parseInt(skill?.organizationId) !== currentTeam?.id}
          readonly={userRole === "1"}
          backgroundColor={"#F2F5F6"}
        />
      )}
    </>
  );
};

export default connect(null, {})(NodeForm);
