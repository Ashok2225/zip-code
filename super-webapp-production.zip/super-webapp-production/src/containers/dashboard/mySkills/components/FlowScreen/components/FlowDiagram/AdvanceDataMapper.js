import React, { useState, useEffect } from "react";
import { Button, Modal, Drawer, Form, Input, Popover } from "antd";
import { useDispatch, useSelector } from "react-redux";

import { ReactSortable } from "react-sortablejs";
import Zoom from "react-medium-image-zoom";
import {
  setDraft,
  getSheetHeaders,
  updateFormatedData,
} from "../../../../../../../redux/actions/skill";

import fxIcon from "../../../../../../../images/fx-svg.png";
import infoIcon from "../../../../../../../images/info-new.png";
import { notify } from "../../../../../../../redux/actions/snack";
import {
  DeleteTwoTone,
} from "@ant-design/icons"
const sortableOptions2 = {
  group: {
    name: "shared",
    pull: "clone",
    // put: false
  },
  animation: 150,
  // sort: false,
};

const sortableOptions = {
  group: {
    name: "shared",
  },
  animation: 150,
  ghostClass: "ghost",
  fallbackOnBody: true,
  swapThreshold: 0.65,
  // sort: false,
  // draggable: ".item",
};



export default function AdvanceDataMapper(props) {
  const [open, setOpen] = useState(false);
  const [headers, setSheetHeaders] = useState([]);
  const [varData, setVarData] = useState([]);
  const [mapping, setMapping] = useState([]);
  const [nodeId, setNodeId] = useState(null);
  const [nodeData, setNodeData] = useState(null);

  let [nodes, setNodes] = useState([]);
  const dispatch = useDispatch();

  //Drawer toggle class
  const skill = useSelector((state) => state.skillReducer);

  useEffect(() => {
    setSheetHeaders(skill?.headers);
    generateVariableList(
      skill?.trainDraft?.FORMATED_DATA?.variables,
      nodeData?.mappingV2
    );
    generateMapping(skill?.headers, nodeData?.mappingV2);
  }, [skill?.headers, skill?.trainDraft?.FORMATED_DATA]);

  useEffect(() => {
    setNodeData(props.nodeData);
    setNodes(props.nodes);
    setNodeId(props.id);
    dispatch(
      getSheetHeaders(
        props.nodeData.excelSheetUrl,
        props.nodeData.excelSheetName
      )
    );
  }, []);

  const generateMapping = (headers, mapping) => {
    let tmp = [];
    if (!mapping) {
      varData.forEach((item, index) => {
        tmp.push({ id: "", name: "", index });
      });
      setMapping(tmp);
    } else {
      setMapping(mapping);
    }
  };

  const generateVariableList = (variables, mapping) => {
    let tmp = [];
    let vars = Object.values(variables);
    if (mapping) {
      mapping = mapping.filter((i) => i.name !== "");
      vars.forEach((i) => {
        let found = mapping.find((ele) => i.name == ele.name);
        if (!found) {
          tmp.push(i);
        }
      });
      setVarData(tmp);
    } else {
      setVarData(vars);
    }
  };

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex((i) => i.id == id);
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload };
    } else {
      arr.forEach((element) => {
        if (
          ["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)
        ) {
          findAndUpdate(element.children, id, payload);
        }
      });
    }
    return arr;
  };

  const reArrangeMapping = (arr) => {
    let tmp = [];
    console.log(arr);
    headers.forEach((item, index) => {
      if (arr[index]) {
        tmp.push(arr[index]);
      } else {
        tmp.push({ id: "", name: "" });
      }
    });
    setMapping(tmp);
  };

  const reArrangeVariableList = (arr) => {
    let tmp = arr.filter((i) => i.name != "");
    setVarData(tmp);
  };

  const saveFlow = async (actions) => {
    let { trainDraft } = skill;

    var rawData = {
      ...trainDraft.RAW_DATA,
      actions: actions,
    };
    var status = trainDraft.status;
    let skillName = trainDraft.SKILL_NAME;
    let updatedData = { status, skillName, rawData, itemId: trainDraft.id };
    await dispatch(updateFormatedData(updatedData));
    dispatch(notify("success", "Saved successfully"));
  };

  const saveMapping = async () => {
    let { trainDraft } = skill;

    let data = {
      mappingV2: mapping,
    };
    nodes = nodes.filter((i) => !(i.isStart || i.isEnd));
    nodes = findAndUpdate(nodes, nodeId, {
      data: { ...nodeData, ...data },
    });
    dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: {
          ...trainDraft.RAW_DATA,
          actions: nodes,
        },
      })
    );
    await saveFlow(nodes);
    setOpen(false);
    props.close();
  };

  const _close = () => {
    setOpen(false);
    props.close();
  };

  const _drag = (e, data) => {
    e.dataTransfer.setData("key", JSON.stringify(data));
  };

  const _drop = (e, index) => {
    let data = JSON.parse(e.dataTransfer.getData("key"));
    let _var = varData[index];
    mapping[index] = { ...data, varId: _var.id, varName: _var.name };
    setMapping([...mapping]);
  };

  const removeMapping = (index) => {
    mapping[index] = { id: "", name: "", index }
    console.log(index)
    setMapping([...mapping]);
  }

  const popContent = (data) => {
    return (
      <div className="popover-img">
      <Zoom>
        <img 
          alt="preview"
          src={
            skill?.trainDraft?.FORMATED_DATA?.actions[
              data.id
            ]?.pageScreenshot
          }
        />
      </Zoom>
      {/* {console.log(data)} */}
    </div>
    )
  }

  return (
    <>
      <div
        className="modal-btn"
      // style={{ padding: "50px", textAlign: "center" }}
      >
        <Button type="primary" onClick={() => setOpen(true)}>
          Data Mapper
        </Button>
      </div>

      <Modal
        title=""
        centered
        open={open}
        onOk={() => saveMapping()}
        onCancel={() => _close()}
        className="fw-modal"
        okText="Done"
      >
        <div className="mapper-advanced mp-block">
          <div className="tp-title mp-title">
            <h2>Data Mapper</h2>
            <h3>Map by dragging against variables </h3>
          </div>
          <div className="scrollable mp-scrollable">
            <div className="mp-outer d-flex">
              <div className="src-mp-box mp-box">
                <ul className="mpr-list">
                  {varData.map((params, index) => (
                    <li className="mpr-list-item" key={index}>
                      <span>{params.name}</span>
                      {params.name === "" ? null : (
                        <>
                        {skill?.trainDraft?.FORMATED_DATA?.actions[params.id]
                            ?.pageScreenshot ? (
                        <Popover placement="right" content={popContent(params)} arrowPointAtCenter>
                          <button
                            className="btn-link dm-info"
                            type="button"
                            data-toggle="dropdown"
                          >
                            <img
                              src={infoIcon}
                              alt=""
                              style={{ marginLeft: 10 }}
                            />
                            {/* {skill?.trainDraft?.FORMATED_DATA?.actions[params.id]
                            ?.pageScreenshot ? (
                            <div className="popup-img">
                              <Zoom>
                                <img
                                  alt="preview"
                                  src={
                                    skill?.trainDraft?.FORMATED_DATA?.actions[
                                      params.id
                                    ]?.pageScreenshot
                                  }
                                />
                              </Zoom>
                            </div>
                          ) : null} */}
                          </button>
                        </Popover>
                        ) : null}
                        </>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
              {/* // Transformation functions */}
              {/* <div className="mp-control">
                <div className="fx-control" onClick={showDrawer}>
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
                <div className="fx-control">
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
                <div className="fx-control">
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
                <div className="fx-control">
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
                <div className="fx-control">
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
                <div className="fx-control">
                  <span className="fx-icon">
                    <img src={fxIcon} />
                  </span>
                </div>
              </div> */}
              <div className="trg-mp-box mp-box">
                {/* <ReactSortable
                  list={mapping}
                  setList={reArrangeMapping}
                  {...sortableOptions}
                > */}
                {mapping.map((item, index) => (
                  <div
                    className="drag-block"
                    key={index}
                    onDrop={(e) => _drop(e, index)}
                    onDragOver={(e) => e.preventDefault()}
                    draggable={item.name !== ""}
                    onDragStart={(e) => _drag(e, item)}
                  >
                    <div className="drag-place">
                      {item.name === "" ? null : (
                        <div className="drg-item">{item.name}</div>
                      )}
                      <div className="drag-content">
                        {item.name === "" ? null : (
                          <button
                            className="btn-link dm-info"
                            type="button"
                            data-toggle="dropdown"
                          >
                            <DeleteTwoTone onClick={(e) => removeMapping(index)} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {/* </ReactSortable> */}
              </div>
              <div className="mp-box default-list scrollable">
                {/* <ReactSortable
                  list={varData}
                  setList={reArrangeVariableList}
                  {...sortableOptions2}
                > */}
                {headers.map((item1, index) => (
                  <div
                    className="drag-block"
                    key={index}
                    onDragStart={(e) =>
                      _drag(e, { name: item1, varIndex: index })
                    }
                    draggable="true"
                  >
                    <div className="drag-place">
                      <button className="btn btn-default">{item1}</button>
                      <div className="drag-content"></div>
                    </div>
                  </div>
                ))}
                {/* </ReactSortable> */}
              </div>
            </div>
          </div>
        </div>
        {/* <Drawer title="Basic Drawer" placement="right" onClose={onClose} open={drawerOpen}>
        <Form>
          <Form.Item label="Field A" required tooltip="This is a required field">
            <Input placeholder="input placeholder" />
          </Form.Item>
          <Form.Item label="Field B">
            <Input placeholder="input placeholder" />
          </Form.Item>
          <Form.Item label="Field C">
            <Input placeholder="input placeholder" />
          </Form.Item>
          <Button type="primary" size="large">
            Done
          </Button>
        </Form>
      </Drawer> */}
        <div className="custom-drawer">
          <h3 className="cd-title">Date Mapper Function</h3>
          <Form>
            <Form.Item
              label="Field A"
              required
              tooltip="This is a required field"
            >
              <Input placeholder="input placeholder" />
            </Form.Item>
            <Form.Item label="Field B">
              <Input placeholder="input placeholder" />
            </Form.Item>
            <Form.Item label="Field C">
              <Input placeholder="input placeholder" />
            </Form.Item>
            <div className="fix-btn">
              <Button type="primary" size="large">
                Done
              </Button>
            </div>
          </Form>
        </div>
      </Modal>
    </>
  );
}
