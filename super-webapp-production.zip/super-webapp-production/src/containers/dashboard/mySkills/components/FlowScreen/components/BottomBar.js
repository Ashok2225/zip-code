// import React, { Component } from "react";
import React, { useEffect, useState, useRef } from "react";
import { Table } from "antd";
import qs from "qs";
import { useSelector, useDispatch } from "react-redux";
import closeRed from "../../../../../../images/branching/close-red.svg";
import { getAutomationBuildLogs } from "../../../../../../redux/actions/logs";
import moment from "moment";
import CopyToClipboard from "react-copy-to-clipboard";
import { Space, Tag, Button, Tooltip, Divider, Input } from "antd";
import Highlighter from "react-highlight-words";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  ExclamationCircleOutlined,
  MinusCircleOutlined,
  SyncOutlined,
  DownloadOutlined,
  CopyOutlined,
  LoadingOutlined,
  ReloadOutlined,
  SearchOutlined,
} from "@ant-design/icons";

const BottomBar = () => {
  const dispatch = useDispatch();
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const searchInput = useRef(null);

  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
  const handleReset = (clearFilters) => {
    clearFilters();
    setSearchText("");
  };

  const [data, setData] = useState();
  const [loading, setLoading] = useState(false);
  const [showLogs, setShowLogs] = useState(false);
  const [tableParams, setTableParams] = useState({
    pagination: {
      current: 1,
      pageSize: 10,
      position: ["bottomCenter"],
    },
  });

  const getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
      close,
    }) => (
      <div
        style={{
          padding: 8,
        }}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
          style={{
            marginBottom: 8,
            display: "block",
          }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{
              width: 90,
            }}
          >
            Search
          </Button>
          <Button
            onClick={() => clearFilters && handleReset(clearFilters)}
            size="small"
            style={{
              width: 90,
            }}
          >
            Reset
          </Button>
          {/* <Button
            type="link"
            size="small"
            onClick={() => {
              confirm({
                closeDropdown: false,
              });
              setSearchText(selectedKeys[0]);
              setSearchedColumn(dataIndex);
            }}
          >
            Filter
          </Button> */}
          <Button
            type="link"
            size="small"
            onClick={() => {
              close();
            }}
          >
            close
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined
        style={{
          fontSize: "16px",
          color: filtered ? "#1890ff" : undefined,
        }}
      />
    ),
    onFilter: (value, record) => {
      let val = false;
      dataIndex.forEach((i) => {
        if(typeof record[i] == 'string') {
          val = val || record[i].toString().toLowerCase().includes(value.trim().toLowerCase());
        } else if(typeof record[i] == 'object' && record[i]) {
          val = val || JSON.stringify(record[i]).toLowerCase().includes(value.trim().toLowerCase());
        }
      });
      return val;
    },

    onFilterDropdownOpenChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{
            backgroundColor: "#ffc069",
            padding: 0,
          }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });

  const columns = [
    {
      title: "Instance ID",
      dataIndex: "uuid",
      key: "uuid",
      // render: (text) => <div style={{ fontWeight: 300 }}>{text} </div>,
      width: "30%",
      ...getColumnSearchProps(["uuid", "meta_data"]),
    },

    {
      title: (
        <Space align="end" split={<Divider type="vertical" />}>
          Status
          <Button
            size={"small"}
            type="primary"
            className="ant-btn-refresh"
            style={{ borderRadius: 3, fontSize: 10 }}
            loading={loading}
            icon={<ReloadOutlined />}
            onClick={() => fetchData()}
          >
            Refresh
          </Button>
        </Space>
      ),
      dataIndex: "status",
      key: "status",
      width: "25%",
      render: (tag) => {
        let color = "#02CE9D";
        let icon = null;
        if (tag === "errored") {
          color = "red";
          icon = <CloseCircleOutlined />;
        } else if (tag === "completed") {
          color = "green";
          icon = <CheckCircleOutlined />;
        } else if (tag === "started") {
          color = "geekblue";
          icon = <SyncOutlined spin />;
        }
        return (
          <Tag
            color={color}
            key={tag}
            icon={icon}
            style={{ borderRadius: 3, fontSize: 11 }}
          >
            {tag.toUpperCase()}
          </Tag>
        );
      },
      filters: [
        {
          text: "errored",
          value: "errored",
        },
        {
          text: "completed",
          value: "completed",
        },
        {
          text: "started",
          value: "started",
        },
      ],
      onFilter: (value, record) => record.status.startsWith(value),
      filterSearch: true,
      // width: '40%',
    },
    {
      title: "Created At",
      dataIndex: "created_at",
      key: "created_at",
      width: "20%",
      render: (date) => moment(date).format("MM-DD-YYYY, h:mm:ss a"),
    },

    {
      title: "Action",
      key: "action",
      width: "15%",
      render: (_, record, index) => {
        {
          if (record.status == "started") {
            return (
              <Tooltip
                placement="top"
                title={"No log preview available"}
                color="#141414"
                overlayStyle={{ borderRadius: 3 }}
              >
                <Button
                  disabled={true}
                  type="primary"
                  icon={<DownloadOutlined color={"#02CE9D"} />}
                  size={"small"}
                />
              </Tooltip>
            );
          } else {
            return (
              <Space size="middle">
                <Tooltip
                  placement="top"
                  title={"Download logs"}
                  color="#141414"
                  overlayStyle={{ borderRadius: 3 }}
                >
                  <Button
                    icon={<DownloadOutlined style={{ color: "#fff" }} />}
                    size={"small"}
                    target="_blank"
                    style={{ backgroundColor: "#02CE9D" }}
                    href={`${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/automation/logs/${record.uuid}.txt`}
                  />
                </Tooltip>

                {index == 0 ? (
                  <Tooltip
                    placement="top"
                    title={"Copy Log Path"}
                    color="#141414"
                    overlayStyle={{ borderRadius: 3 }}
                  >
                    <CopyToClipboard text={logPath}>
                      <Button
                        type="primary"
                        icon={<CopyOutlined color={"#02CE9D"} />}
                        size={"small"}
                      />
                    </CopyToClipboard>
                  </Tooltip>
                ) : null}
              </Space>
            );
          }
        }
      },
    },
  ];

  const skill = useSelector((state) => state.skillReducer.trainDraft);
  const logData = useSelector((state) => state.logsReducer);
  const logPath = `%temp%/${skill.id}`;

  const fetchData = () => {
    setLoading(true);
    dispatch(
      getAutomationBuildLogs(skill.id, {
        page: tableParams.pagination.current,
        pageSize: tableParams.pagination.pageSize,
        filters: tableParams.filters,
      })
    );
  };

  useEffect(() => {
    fetchData();
  }, [JSON.stringify(tableParams)]);

  useEffect(() => {
    setLoading(false);
    setData(logData?.automationBuildLogs || []);
    setTableParams({
      ...tableParams,
      pagination: {
        ...tableParams.pagination,
        total: logData?.total || 10,
      },
    });
  }, [logData]);

  const handleTableChange = (pagination, filters, sorter) => {
    console.log(pagination, filters, sorter);
    setTableParams({
      pagination,
      filters,
      ...sorter,
    });
    if (pagination.pageSize !== tableParams.pagination?.pageSize) {
      setData([]);
    }
  };
  return (
    <div>
      {skill?.TEMPLATE === "UserDocumentation" ? null : (
        <div className="bd-outer">
          <ul className="nav nav-tabs bd-option">
            <li
              onClick={(e) => {
                setShowLogs(true);
              }}
              className={1 == "isLogsView" ? "active" : ""}
            >
              <a data-toggle="tab" href="#c">
                Audit Trail
              </a>
            </li>
          </ul>
          <div className="tab-content">
            <div id="a" className="tab-pane fade in active"></div>
            <div id="b" className="tab-pane fade in active"></div>
            <div id="c" className="tab-pane fade in active"></div>
          </div>
        </div>
      )}
      {showLogs ? (
        <div className="logs-view">
          <div
            className="prt-close"
            onClick={() => {
              setShowLogs(false);
            }}
          >
            <img src={closeRed} alt="" />
          </div>
          <Table
            scroll={{ y: 350 }}
            columns={columns}
            rowKey={(record) => record.uuid}
            dataSource={data}
            pagination={tableParams.pagination}
            loading={loading}
            onChange={handleTableChange}
            expandable={{
              expandedRowRender: (record) => (
                <div style={{}}>
                  <p
                    style={{
                      fontFamily: "inherit",
                      color: "#252525",
                      fontWeight: 300,
                    }}
                  >
                    {" "}
                    JSON parameters passed for automation
                  </p>
                  <pre
                    style={{
                      padding: "5px 15px",
                      width: "35%",
                      fontSize: 12,
                      fontFamily: "monospace",
                      border: "none",
                      backgroundColor: "#EEEEEE",
                    }}
                  >
                    <code>{JSON.stringify(record.meta_data, 2, 2)}</code>
                  </pre>
                </div>
              ),
              rowExpandable: (record) => Boolean(record.meta_data),
            }}
          />
        </div>
      ) : null}
    </div>
  );
};
export default BottomBar;
