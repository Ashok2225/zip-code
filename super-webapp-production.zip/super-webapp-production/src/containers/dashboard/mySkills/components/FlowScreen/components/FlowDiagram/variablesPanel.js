import React, { useContext, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { BuilderContext, useDrawer } from "react-flow-builder";
import {
  Form,
  Button,
  Input,
  Select,
  Checkbox,
  Alert,
  Empty,
  Space,
} from "antd";
import {
  DeleteTwoTone,
  PlusOutlined,
  MinusCircleOutlined,
} from "@ant-design/icons";
import { store } from "../../../../../../../redux";
import { setDraft } from "../../../../../../../redux/actions/skill";

const { Option } = Select;

const VariableForm = (props) => {
  let [variables, setVariables] = useState([]);
  const onFinish = (values) => {
    let {
      skillReducer: { trainDraft },
    } = store.getState();

    store.dispatch(
      setDraft({
        ...trainDraft,
        RAW_DATA: { ...trainDraft.RAW_DATA, variables: [...variables] },
      })
    );
  };

  useEffect(() => {
    setVariables([...(props.variables || [])]);
  }, [props]);


  const _add = () => {
    let ele = {name: "", value: "", dataType: ""}
    variables.push(ele)
    setVariables([...variables])
  }

  const _remove = (index) => {
    variables.splice(index,1)
    setVariables([...variables])
  }

  const _update = (index,field,value) => {
    variables[index][field] = value
    setVariables([...variables])
  }

  return (
    <>
      <Form
        name="dynamic_form_nest_item"
        onFinish={onFinish}
        autoComplete="off"
      >
        <Form.List name="variables">
          {(_fields, { add, remove }) => (
            <>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  margin: "5px 0px",
                  justifyContent: "end",
                }}
              >
                <Form.Item style={{ width: 100 }}>
                  <Button
                    type="secondary"
                    style={{
                      backgroundColor: "#3FA9FF",
                      color: "#fff",
                      borderRadius: 3,
                    }}
                    htmlType="submit"
                  >
                    Save
                  </Button>
                </Form.Item>

                <Form.Item style={{ width: 60 }}>
                  <Button
                    shape="circle"
                    type="secondary"
                    style={{
                      backgroundColor: "#3FA9FF",
                      color: "#fff",
                      marginRight: 15,
                    }}
                    onClick={() => _add()}
                  >
                    +
                  </Button>
                </Form.Item>
              </div>

              {variables.length > 0 ? (
                <div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-around",
                    }}
                  >
                    <h6 style={{ width: 150 }}>Variable name</h6>
                    <h6 style={{ width: 150 }}>Data Type</h6>
                    <h6 style={{ width: 250 }}>Value</h6>
                  </div>
                  {variables.map((item, index) => (
                    <Space
                      key={index}
                      style={{
                        display: "flex",
                        marginBottom: 8,
                        flexDirection: "row",
                        justifyContent: "space-around",
                      }}
                      align="baseline"
                    >
                      <Form.Item
                        initialValue={item.name}
                        fieldKey={index}
                        isListField={true}
                        name={[index, "name"]}
                        style={{ width: 150 }}
                        rules={[
                          { required: true, message: "Missing variable name" },
                        ]}
                        onBlur={(e) => _update(index, "name", e.target.value)}
                      >
                        <Input placeholder="Enter Variable name" />
                      </Form.Item>

                      <Form.Item
                        isListField={true}
                        fieldKey={index}
                        name={[index,"dataType"]}
                        initialValue={item.dataType}
                        style={{ width: 150 }}
                        rules={[
                          { required: true, message: "Missing datatype name" },
                        ]}
                       

                      >
                        <Select style={{ width: 120 }}  onChange={(value) =>_update(index, "dataType",value)}>
                          <Option value="number">Number</Option>
                          <Option value="string">String</Option>
                          <Option value="secure">Secure</Option>
                          <Option value="list">List</Option>
                          <Option value="dataTable">Data Table</Option>
                        </Select>
                      </Form.Item>

                      <Form.Item
                        initialValue={item.value}
                        isListField={true}
                        fieldKey={index}
                        name={[index,"value"]}
                        style={{ width: 250 }}
                        // rules={[
                        //   { required: true, message: "Missing variable value" },
                        // ]}
                        onBlur={(e) => _update(index, "value", e.target.value)}

                      >
                        <Input placeholder="Enter Value" />
                      </Form.Item>

                      <DeleteTwoTone onClick={() => _remove(index)} />
                    </Space>
                  ))}
                </div>
              ) : (
                <>
                  <Empty
                    image="https://gw.alipayobjects.com/zos/antfincdn/ZHrcdLPrvN/empty.svg"
                    imageStyle={{
                      height: 60,
                    }}
                    description={
                      <span>
                        <a onClick={() => _add()}>Create new</a> variables
                      </span>
                    }
                  ></Empty>
                </>
              )}
            </>
          )}
        </Form.List>
      </Form>
    </>
  );
};

export default VariableForm;
