import React, { useContext, useEffect, useState } from 'react';
import { BuilderContext, NodeContext, useDrawer } from 'react-flow-builder';

import { Form, Button, Input, Select, Upload } from 'antd';
import axios from 'axios';
import { read, utils } from "xlsx";

import { store } from '../../../../../../../redux'
import {
  setDraft,
} from "../../../../../../../redux/actions/skill";
import { getKeycloackToken } from "../../../../../../../redux/actions/auth";


const { Option } = Select;
const DataSources = [
  {
    "kind": "excel-sheet",
    "label": "Excel Sheet"
  },
  {
    "kind": "csv-file",
    "label": "CSV file",
  },
  {
    "kind": "sql-db",
    "label": "SQL Database",
  },
  {
    "kind": "json",
    "label": "JSON array",
  }
]

const ConfigDataSet = () => {
  let { selectedNode: node, nodes } = useContext(BuilderContext);
  const { closeDrawer: cancel } = useDrawer();
  const [nodeData, setNodeData] = useState(null)
  const [dataSetKind, setDataSetKind] = useState("")
  const [sheetNames, setSheetNames] = useState([])
  const [excelSheetUrl, setExcelSheetUrl] = useState("")
  const [workBook, setWorkBook] = useState({})
  const [rowCount, setRowCount] = useState(0);
  const [columnCount, setColumnCount] = useState(0);
  const [form] = Form.useForm();

  useEffect(() => {
    setNodeData(node)
    setDataSetKind(node?.data?.kind || "")
  }, [node])

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      let { skillReducer: { trainDraft } } = store.getState()
      nodes = nodes.filter(i => !(i.isStart || i.isEnd))
      nodes = findAndUpdate(nodes, nodeData.id, { data: { ...values, rowCount, columnCount } })
      store.dispatch(setDraft({ ...trainDraft, RAW_DATA: { ...trainDraft.RAW_DATA, actions: nodes } }));
      cancel()
    } catch (error) {
      console.log('form error', error)
    }
  };

  const uploadFile = async (file, kind) => {
    try {
      let token = await getKeycloackToken();
      var _data = new FormData();
      _data.append("file", file);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload/xl-sheet`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: _data,
      };
      const {
        data: {
          data: { url },
        },
      } = await axios(config);
      form.setFieldsValue({'excelSheetUrl': url})
      analyzeDataSet({ url }, kind)
    } catch (e) {
      console.log(e)
    }
  }

  const findAndUpdate = (arr, id, payload) => {
    let found = arr.findIndex(i => i.id == id)
    if (found > -1) {
      arr[found] = { ...arr[found], ...payload }
    } else {
      arr.forEach(element => {
        if (['branch', 'condition', 'loop', 'loop-nodes',  'try',
            'try-catch-node'].includes(element.type)) {
          findAndUpdate(element.children, id, payload)
        }
      });
    }
    return arr
  }

  const calculateRowAndColumns = (kind, params) => {
    if (kind === 'excel-sheet') {
      let data = utils.sheet_to_json(workBook.Sheets[params.sheetName]);
      setRowCount(data.length)
      setColumnCount(Object.keys(data[0]).length)
    }
  }

  const renderExcelConfig = (kind) => {
    return (
      <div style={{ marginTop: 10 }}>



        <div className="frm-block">
          <div className="upload-btn-wrapper upload-browse">
            <button class="btn btn-browse btn-custom">
              Browse file
            </button>
            <Input
              id="excelFile"
              type="file"
              name="excel-sheet"
              placeholder="Please choose your excel sheet"
              onChange={(e) => uploadFile(e.target.files[0], 'excel-sheet')}
            />
          </div>
        </div>



        <Form.Item
          name="excelSheetUrl"
          label="Excel Sheet URL"
          rules={[{ required: true }]}
        >
          <Input onBlur={e => analyzeDataSet({ url: e.target.value }, kind)} />
        </Form.Item>

        <Form.Item
          name="excelSheetName"
          label="Excel Sheet Name"
          rules={[{ required: true }]}
        >
          <Select style={{ width: 120 }}
            onChange={e => calculateRowAndColumns(kind, { sheetName: e, workBook })}
          >
            {sheetNames.map((ele, i) => {
              return (
                <Option
                  className="custom-select"
                  key={i}
                  value={ele}
                >
                  <p>{ele}</p>
                </Option>
              );
            })}
          </Select>
        </Form.Item>
      </ div>
    )
  }

  const renderCsvConfig = (kind) => {
    return (
      <div style={{ marginTop: 10 }}>
        <Form.Item
          name="csvPath"
          label="CSV file path or URL"
          rules={[{ required: true }]}
        >
          <Input onBlur={e => analyzeDataSet({ path: e.target.value }, kind)} />
        </Form.Item>
      </ div>
    )
  }

  const handleExcelSheet = async (params) => {
    let url;
    try {
      let _urlObj = new URL(params.url);
      if (_urlObj.hostname.match("google.com")) {
        url = _urlObj.href.replace("/edit", "/export?format=csv");
      } else {
        url = params.url;
      }
      let { data } = await axios.get(url, { responseType: "arraybuffer" });
      var file = new Blob([data], { type: "application/vnd.ms-excel" });
      let workBook = await read(await file.arrayBuffer(), { type: "array" });
      setSheetNames(workBook.SheetNames)
      setWorkBook(workBook)
    }
    catch (e) {
      console.log(e)
    }
  }

  const handleCSVFile = async (params) => {
    setRowCount(5)
    setColumnCount(5)
  }

  const analyzeDataSet = (params, kind) => {
    switch (kind) {
      case "excel-sheet": return handleExcelSheet(params)
      case "csf-file": return handleCSVFile(params)
      default: return null
    }
  }


  const renderDatasetParams = (kind) => {
    switch (kind) {
      case "excel-sheet": return renderExcelConfig(kind)
      case "csv-file": return renderCsvConfig(kind)
      default: return <> <p> Choose a kind of dataset from above to continue</p> </>
    }
  }


  return (
    <div>
      {nodeData ? (
        <div>
          <Form form={form} initialValues={node.data} layout={'vertical'}>
            <Form.Item
              name="label"
              label="Give a unique name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="kind"
              label=" Select dataset source"
              rules={[{ required: true }]}
            >
              <Select style={{ width: 120 }}
                onChange={(e) => setDataSetKind(e)}
              >
                {DataSources.map((ele, i) => {
                  return (
                    <Option
                      className="custom-select"
                      key={i}
                      value={ele.kind}
                    >
                      <p>{ele.label}</p>
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
            {renderDatasetParams(dataSetKind)}
          </Form>

          <div>
            <Button onClick={cancel}> Cancel </Button>
            <Button type="primary" onClick={handleSubmit}>
              Save
            </Button>
          </div>
        </div>
      ) : null}
      <ul className="note-list">
     <li>Add a dataset into the skill</li>
   </ul>
    </div>
  );
};

export default ConfigDataSet;