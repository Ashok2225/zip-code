import React from "react";

import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  executeFlow,
  updateDraftSkill,
  changeActiveTab,
  updateFormatedData,
  getDraftSkillsById,
  getSheetHeaders,
} from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import $ from "jquery";
import playIcon from "../../../../../../../images/training/play.png";
import runningIcon from "../../../../../../../images/brands/Progress.gif";
import { getKeycloackToken } from "../../../../../../../redux/actions/auth";
import deviceIcon from "../../../../../../../images/laptop-icon.svg";
import checkIcon from "../../../../../../../images/check-filled.png";
import axios from "axios";

const TEMPLATE_WITH_LOOP_RESTRICTION = [
  "User Documentation",
  "Web Automation",
  "In-App Walkthrough",
  "User Onboarding",
];

const PlayModal = () => {
  const dispatch = useDispatch();
  const skill = useSelector((state) => state.skillReducer);
  const devices = useSelector((state) => state.skillReducer.devices);
  const userDeviceId = useSelector((state) => state.skillReducer.draftSession);

  const history = useHistory();
  const [isLoadingNewVar, setIsLoadingNewVar] = useState(false);
  const [isFlowActionsEnabled, setIsFlowActionEnabled] = useState(false);
  const [isFlowRunning, setisFlowRunning] = useState("");
  const [excelSheetName, setExcelSheetName] = useState("");
  const [excelSheetUrl, setExcelSheetUrl] = useState("");
  const [sheetRange, setSheetRange] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState("");

  useEffect(() => {
    if (skill && skill?.trainDraft?.RAW_DATA?.actions?.length) {
      setIsFlowActionEnabled(true);
    }

    if (
      skill?.trainDraft?.RAW_DATA?.excelData?.url &&
      skill?.trainDraft?.RAW_DATA?.excelData?.sheetName
    ) {
      setExcelSheetUrl(skill?.trainDraft?.RAW_DATA?.excelData?.url);
      setExcelSheetName(skill?.trainDraft?.RAW_DATA?.excelData?.sheetName);
    }
    return () => {
      // do something on component unmount
    };
  }, [skill?.trainDraft?.RAW_DATA]);

  const togglePlayPopover = () => {
    $("#play-popover").toggle();
  };

  const addFile = async (e) => {
    try {
      let token = await getKeycloackToken();
      var _data = new FormData();
      _data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload/xl-sheet`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: _data,
      };
      const {
        data: {
          data: { url },
        },
      } = await axios(config);
      setExcelSheetUrl(url);
      setUploadedFileName(e.target.files[0].name);
    } catch (e) {
      dispatch(notify("error", "Something went wrong"));
    }
  };

  const play = async (deviceId) => {
    if (skill.unsavedChanges) {
      window.jQuery("#saveFlow").modal({ show: true });
    } else {
      setisFlowRunning(true);

      var data = {
        deviceId: deviceId,
        skillId: skill?.trainDraft?.id,
        bulk: !TEMPLATE_WITH_LOOP_RESTRICTION.includes(
          skill?.trainDraft?.TEMPLATE
        ),
      };
      if (deviceId) {
        const playSkill = await dispatch(executeFlow(data));
        setisFlowRunning(false);
      } else {
        dispatch(
          notify(
            "error",
            "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
          )
        );
        setisFlowRunning(false);
      }
    }
  };

  const updateSheetVariables = async () => {
    let update = false;
    let skillData = skill?.trainDraft;
    if (sheetRange) {
      skillData["RAW_DATA"].excelData.range = sheetRange;
      skillData["FORMATED_DATA"].excelData.range = sheetRange;
      update = true;
    }

    if (excelSheetUrl) {
      skillData["RAW_DATA"].excelData.url = excelSheetUrl;
      skillData["FORMATED_DATA"].excelData.url = excelSheetUrl;
      update = true;
    }
    if (update) {
      await dispatch(
        updateDraftSkill(skillData.id, {
          ...skillData,
        })
      );
      dispatch(getSheetHeaders(excelSheetUrl, excelSheetName));
    }
  };

  const saveFlow = () => {
    var rawData = {
      ...skill?.trainDraft?.RAW_DATA,
      actions: skill?.trainDraft?.RAW_DATA?.actions,
    };
    var status = skill?.trainDraft?.status;
    let skillName = skill?.trainDraft?.SKILL_NAME;
    let updatedData = {
      status,
      skillName,
      rawData,
      itemId: skill?.trainDraft?.id,
    };
    dispatch(updateFormatedData(updatedData));
  };

  const discardChanges = () => {
    dispatch(getDraftSkillsById(skill?.trainDraft?.id));
  };

  const getPlayModal = (temp) => {
    switch (temp) {
      case "Import Data from Spreadsheet to Web App":
        // return automationModal();
        return defaultPlayModal();
      case "In-App Walkthrough":
        return defaultPlayModal();
      case "UserDocumentation":
        return null;
      case "UserOnboarding":
        return defaultPlayModal();
      case "WebAutomation":
        return webAutomationModal();
      default:
        return defaultPlayModal();
    }
  };

  const automationModal = () => {
    return (
      <div className="play-popover">
        {" "}
        <button
          className="sm-btn play-btn"
          onClick={() => togglePlayPopover()}
          disabled={
            skill?.trainDraft?.RAW_DATA?.actions.length ? "" : "disable"
          }
        >
          <img src={playIcon} alt="" />
          <span>Play</span>
        </button>
        <div className="pd-block" id="play-popover">
          <div className="upload-btn-wrapper">
            <button class="btn btn-upload btn-primary">
              {uploadedFileName ? uploadedFileName : " Upload your file Here"}
            </button>
            <input type="file" onChange={addFile}></input>
          </div>
          <div className="or-text text-secondary">OR</div>
          <div className="input-flex">
            <div className="ip-tl-label">
              <span className="tl-label">URL</span>
              <input
                type="text"
                placeholder="Enter URL"
                name="filePublicURL"
                defaultValue={excelSheetUrl}
                onChange={(e) => setExcelSheetUrl(e.target.value)}
              ></input>
            </div>
          </div>
          <div className="input-flex">
            <div className="ip-tl-label">
              <span className="tl-label">Sheet Range</span>
              <input
                type="text"
                name="sheetRange"
                placeholder="Enter Sheet Range"
                spellcheck="false"
                defaultValue={skill?.trainDraft?.RAW_DATA?.excelData?.range}
                onChange={(e) => setSheetRange(e.target.value)}
              ></input>
            </div>
          </div>

          <div className="play-drop-footer">
            <button
              className="btn btn-sm btn-danger"
              onClick={togglePlayPopover}
            >
              Cancel
            </button>
            {isFlowRunning ? (
              <div className="center-loader">
                <button className="sm-btn">
                  <div class="sp sp-circle text-light"></div>
                </button>
              </div>
            ) : (
              <button
                className="btn btn-sm btn-primary"
                disabled={
                  skill?.trainDraft?.RAW_DATA?.actions?.length ? "" : "disable"
                }
                onClick={() => play(skill.TEMPLATE)}
                data-dismiss="modal"
              >
                Play
              </button>
            )}
          </div>
        </div>{" "}
      </div>
    );
  };
  const defaultPlayModal = () => {
    return (
      <React.Fragment>
        {isFlowRunning ? (
          <div
            key="Play"
            style={{
              margin: "0.5%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <img
              src={runningIcon}
              alt="Logo"
              width={35}
              height={35}
              style={{ display: "block", margin: "auto" }}
            />
          </div>
        ) : (
          // <button
          //   className="sm-btn play-btn"
          //   disabled={
          //     skill?.trainDraft?.RAW_DATA?.actions.length ? "" : "disable"
          //   }
          //   onClick={() => play(skill?.trainDraft?.TEMPLATE)}
          // >
          //   <img src={playIcon} alt="" />
          //   <span>Play</span>
          // </button>

          <div className="device-dropdown dropdown">
            <button
              className="sm-btn play-btn"
              type="button"
              data-toggle="dropdown"
              disabled={
                skill?.trainDraft?.RAW_DATA?.actions.length ? "" : "disable"
              }
            >
              <img src={playIcon} alt="" />
              <span>Play</span>
            </button>
            <div className="dropdown-menu">
              <ul class="list-group">
                {devices?.length > 0 ? (
                  devices?.map((i, index) => {
                    return (
                      <li
                        class="list-group-item"
                        key={index}
                        onClick={() => play(i.id)}
                        style={{ cursor: "pointer" }}
                      >
                        <div className="dc-list">
                          <div className="dc-label">
                            <div className="dc-icon">
                              <img src={deviceIcon} />
                            </div>
                            <div className="dc-text">
                              <p>{i.session_name}</p>
                              <span>{i.user_email}</span>
                            </div>
                          </div>
                          {/* <div className="check-dc selected">
                            <img src={checkIcon} />
                          </div> */}
                        </div>
                      </li>
                    );
                  })
                ) : (
                  <li class="list-group-item">No linked devices found</li>
                )}
              </ul>
            </div>
          </div>
        )}
      </React.Fragment>
    );
  };
  const webAutomationModal = () => {
    return (
      <button
        className="sm-btn play-btn"
        disabled={skill?.trainDraft?.RAW_DATA?.actions ? "" : "disable"}
        data-toggle="modal"
        data-target="#myWebAutomationPlayModal"
      >
        <img src={playIcon} alt="" />
        <span>Play</span>
      </button>
    );
  };

  return (
    <React.Fragment>
      {getPlayModal(skill?.trainDraft?.TEMPLATE)}
      <div className="modal fade qa-modal1" id="saveFlow" role="dialog">
        <div className="modal-dialog modal-sm">
          <div className="modal-content share-modal">
            <button type="button" className="close" data-dismiss="modal">
              &times;
            </button>
            <div className="modal-body">
              <h3 className="qa-modal-title">Save</h3>
              <div>
                <h5>
                  You have unsaved data. Do you want to save before proceeding?
                </h5>
              </div>

              <div className="frm-btns fb-right">
                <button
                  className="btn-outline"
                  data-dismiss="modal"
                  onClick={() => {
                    discardChanges();
                  }}
                >
                  Discard
                </button>
                <button
                  className="primary-btn"
                  data-dismiss="modal"
                  onClick={() => {
                    saveFlow();
                  }}
                >
                  save
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default PlayModal;
