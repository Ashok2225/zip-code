import React, { Component } from "react";

import {
  getUserSkills,
  searchMySKills,
  deleteMySkill,
  getSkillsFromStore,
  createDraftSkill,
  getDraftSkillsById,
  startRecord,
  stopRecord,
} from "../../../../../redux/actions/skill";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import recordimg from "../../../../../images/record.png";
import Loader from "../../../../../components/loader";
import NotFound from "../../../../../components/notFound";

class TrainingChatBot extends Component {
  state = {
    currentSkillArea: [],
    loadingDraft: true,
    isRecording: false,
    notFound: false,
  };

  componentDidMount = () => {
    this.trainYourSkill();
  };

  trainYourSkill = async () => {
    const trainSkillId = this.props.match.params.id;

    const trainSkill = await this.props.getDraftSkillsById(trainSkillId);
    if (trainSkill) {
      this.setState({
        currentSkillArea: trainSkill.data.data,
        loadingDraft: false,
      });
    } else {
      this.setState({
        notFound: true,
        loadingDraft: false,
      });
    }
  };

  onStartRecord = async () => {
    let markerIndex = 0;
    let skillId = this.props.match.params.id;
    let data = { skillId, markerIndex };
    const startData = this.props.startRecord(data);
    // const startData = this.props.startRecord(this.props.match.params.id);
    if (startData) {
      this.setState({
        isRecording: true,
      });
    }
  };

  onStopRecord = () => {
    let data = {
      deviceId: this.props.skillReducer.draftSession,
      skillId: this.props.match.params.id,
    };
    const stopData = this.props.stopRecord(data);
    if (stopData) {
      this.setState({
        isRecording: false,
      });
      const trainedData = this.trainYourSkill();
      this.props.history.push(`/dashboard/skills/viewSkill/${data.skillId}`);
    }
  };

  render() {
    return (
      <React.Fragment>
        {this.state.notFound === true ? (
          <React.Fragment>
            <NotFound />
          </React.Fragment>
        ) : (
          <React.Fragment>
            <div className="fw-screen">
              <div class="chat-col-skill">
                <div class="cts-title">
                  <div class="cts-ico">
                    <span>
                      {this.state.currentSkillArea.SKILL_NAME
                        ? this.state.currentSkillArea.SKILL_NAME.toUpperCase().charAt(
                            0
                          )
                        : ""}
                    </span>
                  </div>
                  <p>{this.state.currentSkillArea.SKILL_NAME}</p>
                </div>
                {this.state.loadingDraft ? (
                  <>
                    <Loader
                      styles={{ width: "80px", margin: "auto" }}
                      root={{ display: "flex" }}
                    />
                  </>
                ) : (
                  <>
                    <div class="rc-center">
                      <div class="rc-content">
                        <img src={recordimg} alt="" />
                        <p>
                          Please show what task you want to automate
                          <br></br>using recording feature
                        </p>
                        {this.state.isRecording ? (
                          <span
                            class="start-rc-btn"
                            onClick={(e) => {
                              this.onStopRecord(e);
                            }}
                          >
                            Stop Training
                          </span>
                        ) : (
                          <span
                            class="start-rc-btn"
                            onClick={(e) => {
                              this.onStartRecord(e);
                            }}
                          >
                            Start Training
                          </span>
                        )}
                        {/* <span class="start-rc-btn" onClick={(e) => { this.onStartRecord(e) }}>Start Training</span> */}
                      </div>
                    </div>{" "}
                  </>
                )}
              </div>
            </div>
          </React.Fragment>
        )}
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getUserSkills,
    searchMySKills,
    deleteMySkill,
    getSkillsFromStore,
    getDraftSkillsById,
    createDraftSkill,
    startRecord,
    stopRecord,
  })
)(TrainingChatBot);
