/*global chrome*/
import React, { Component } from "react";
import $ from "jquery";
import searchicon from "../../../../../images/serach-black.png";
import closeicon from "../../../../../images/close.png";
import menu_toggle from "../../../../../images/menu-side.png";
import searchDrop from "../../../../../images/search-drop.png";
import Loader from "../../../../../components/loader";
import EmptyLoader from "../../../../../components/emptyLoader";
import docicon from "../../../../../images/doc-icon.png";

import MySKillItem from "../MySkillItem";
import MyDraftItem from "../MyDraftItem";
import MyHelperItem from "../MyHelperItem";

import {
  getUserSkills,
  searchMySKills,
  deleteMySkill,
  getSkillsFromStore,
  getDraftSkills,
  createDraftSkill,
  deleteDraftSkill,
  clearDraft,
} from "../../../../../redux/actions/skill";
import { notify } from "../../../../../redux/actions/snack";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import {
  changeSkillAreaView,
  changeActiveTab,
} from "../../../../../redux/actions/skill";
import { ReactNotifications, Store } from "react-notifications-component";
import "react-notifications-component/dist/theme.css";
import helperIcon from "../../../../../images/helper-Icon.png";
import AutomationIcon from "../../../../../images/automationIcon.png";
import getColors from "../../../../../components/colors";
import MyDocumentFlow from "../MyDocumentFlow";
class SideBar extends Component {
  state = {
    curr_msg: {},
    open: false,
    skills: [],
    isLoading: true,
    colors: ["#0250ce", "#f54747", "#33d0b7", "#ffa933", "#21b8dd", "#8a5fff"],
    searchItem: "",
    minMode: false,
    SKILL_NAME: "",
    SKILL_DESCRIPTION: "",
    TEMPLATE: "",
    template_value: "Select Template",
    searchTerm: "",
    isSearchActive: false,
  };

  componentDidMount = () => {
    const userSkill = this.props.skillReducer.my_skills;

    if (userSkill) {
      this.setState({
        isLoading: false,
      });
    }
  };

  shrinkSidebar = () => {
    this.setState({
      minMode: !this.state.minMode,
    });
  };

  searchSkill = (e) => {
    this.setState({
      searchTerm: e.target.value,
    });
  };

  handleSubmit = async () => {
    const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));

    $(".property-panel").removeClass("open-prt");
    $(".rt-btns").removeClass("marg-300");
    if (this.state.SKILL_NAME != "" && this.state.SKILL_DESCRIPTION != "") {
      let skill = {
        ...this.state,
        SKILL_NAME: this.state.SKILL_NAME.split(" ").join("-"),
        USER_ID: this.props.userReducer.user_id,
        TYPE: "regularSkill",
        organisationId: getOrgDetails ? getOrgDetails.id : null,
      };

      if (this.state.SKILL_NAME.trim() === "") {
        this.props.notify("error", "Please enter skill name");
      } else {
        const createSkill = await this.props.createDraftSkill(skill, () => {
          this.setState({
            SKILL_NAME: "",
            SKILL_DESCRIPTION: "",
            TEMPLATE: "",
            template_value: "Select Template",
            TYPE: "",
          });
          $(".skill").removeClass("active");
          $("#first").addClass("active");
        });
        if (createSkill) {
          this.props.history.push(
            `/dashboard/skills/trainSkill/${createSkill.data.data.id}`
          );
        }
      }
    } else {
      this.props.notify("error", "Please fill all the mandatory fields");
    }
  };
  onFieldChange = (e) => {
    //console.log(e)
    this.setState({ [e.target.name]: e.target.value });
  };
  onTemplateChange = (e) => {
    this.setState({ TEMPLATE: e.target.value });
  };

  deleteDraftSkill = async (e, id) => {
    let skillId = this.props.skillReducer.helper
      ? this.props.skillReducer.helper.id
      : "";
    if (skillId !== "") {
      const deleteDraft = await this.props.deleteDraftSkill(skillId);
      if (deleteDraft) {
        if (this.props.skillReducer.isActive === "draft") {
          // this.props.getDraftSkills();
          this.props.clearDraft();
          this.props.history.push("/dashboard/skills");
        } else {
          this.props.getUserHelperSkills(1);
        }
      }
    }
  };

  returnPrebuildskills(skills) {
    let final_template = [];
    if (skills.length != 0) {
      for (var i = 0; i < (skills.length >= 2 ? 2 : skills.length); i++) {
        let template = (
          <div
            className="tl-block"
            onClick={() => {
              this.props.history.push(
                "/dashboard/skill-store/automation-skills"
              );
            }}
          >
            <div className="tl-icon">
              <div
                className="cts-avatar"
                style={{
                  backgroundColor:
                    this.state.colors[parseInt(Math.random() * 6)],
                }}
              >
                <img src={AutomationIcon} alt="" />
                {/* {skills[i].skill_name.substring(0, 2).toUpperCase()} */}
              </div>
            </div>
            <div className="tl-cont">
              <p>{skills[i].skill_name}</p>
              <span>2 min required for training</span>
            </div>
          </div>
        );
        final_template.push(template);
      }
    }

    return final_template;
  }

  chatSkill = (skill) => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (response) {
            this.props.chatSkill(skill);
          } else {
            this.notificationPopUp();
          }
        }
      );
    } catch (error) {
      this.notificationPopUp();
      console.log("error ", error);
    }
  };

  notificationPopUp() {
    Store.addNotification({
      title: "Note: ",
      message:
        "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before creating/using skills.",
      type: "warning",
      insert: "top",
      container: "top-right",
      dismiss: {
        duration: 5000,
        onScreen: true,
      },
    });
    window.setTimeout(function () {
      window.open(
        `https://chrome.google.com/webstore/detail/techforce-ide-extension/${process.env.REACT_APP_CHROME_TAB_ID}`,
        "_blank"
      );
    }, 5000);
  }

  trainANewSkill = () => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            this.notificationPopUp();
          }
        }
      );
    } catch (error) {
      this.notificationPopUp();
      console.log("error ", error);
    }
  };

  render() {
    return (
      <React.Fragment>
        <div className={this.state.minMode ? "task-list minibar" : "task-list"}>
          <ReactNotifications />
          <div className="flex-title">
            <h3 className="title">My Skills</h3>

            <div
              className={`ls-sidebar ${
                this.state.isSearchActive ? "active" : ""
              }`}
            >
              <input
                type="text"
                placeholder="search"
                value={this.state.searchTerm ? this.state.searchTerm : ""}
                onChange={(e) => this.searchSkill(e)}
              />

              <div className="ls-icons">
                <button
                  className="ls-close"
                  onClick={() =>
                    this.setState({ searchTerm: "", isSearchActive: false })
                  }
                >
                  <img src={closeicon} alt="" />
                </button>
              </div>
            </div>

            <div className="icon-list">
              <div
                className="src-icon"
                onClick={() => this.setState({ isSearchActive: true })}
              >
                <img src={searchicon} alt="" />
              </div>
              <div
                className="collapse-menu"
                onClick={() => this.shrinkSidebar()}
              >
                <img src={menu_toggle} alt="" />
              </div>
            </div>
          </div>

          {/* Search Box */}
          {/* <div className="sb-search">
          <input
            type="text"
            placeholder="Search Skill"
            value={this.state.searchTerm ? this.state.searchTerm : ""}
            onChange={(e) => this.searchSkill(e)}
          />
        </div> */}
          <div className="task-block">
            <div className="tl-list">
              <div className="tabs-skill">
                <ul className="nav nav-tabs">
                  <li
                    className={
                      this.props.skillReducer.isActive === "published"
                        ? "active"
                        : ""
                    }
                  >
                    <a
                      data-toggle="tab"
                      href="#published"
                      onClick={() => this.props.changeActiveTab("published")}
                    >
                      {this.state.minMode ? "PS" : "Published Skills"}
                    </a>
                  </li>
                  {process.env.REACT_APP_SHOWDRAFT === "true" ? (
                    <li
                      className={
                        this.props.skillReducer.isActive === "draft"
                          ? "active"
                          : ""
                      }
                    >
                      <a
                        data-toggle="tab"
                        href="#drafts"
                        onClick={() => this.props.changeActiveTab("draft")}
                      >
                        {this.state.minMode ? "DS" : "Draft Skills"}
                      </a>
                    </li>
                  ) : (
                    ""
                  )}
                </ul>
                <div className="tab-content tbc-skill scrollable">
                  <div
                    id="published"
                    className={`tab-pane fade ${
                      this.props.skillReducer.isActive === "published"
                        ? "in active"
                        : ""
                    } `}
                  >
                    <div className="scrollable skill-list-scroll">
                      {this.props.skillReducer.isLoading ? (
                        <Loader
                          styles={{ width: "50px", margin: "auto" }}
                          root={{ display: "flex" }}
                        />
                      ) : this.props.skillReducer.my_skills.length +
                          this.props.skillReducer.userHelper.length ===
                        0 ? (
                        <EmptyLoader message="No Skills found" />
                      ) : (
                        this.props.skillReducer.my_skills
                          .filter((item, i) => {
                            if (this.state.searchTerm === "") {
                              return item;
                            } else if (
                              item.SKILL_NAME !== null &&
                              item.SKILL_NAME.toLowerCase().includes(
                                this.state.searchTerm.toLocaleLowerCase()
                              )
                            ) {
                              return item;
                            }
                          })
                          .map((item, key) => (
                            <MySKillItem
                              {...this.props}
                              deleteMySkill={this.deleteMySkill}
                              chatSkill={this.chatSkill}
                              updateSkill={this.updateSkill}
                              color={getColors(item.SKILL_NAME)}
                              key={key}
                              skills={item}
                            />
                          ))
                      )}

                      {/* MyHelper Item */}
                      {this.props.skillReducer.isLoading
                        ? ""
                        : this.props.skillReducer.userHelper.length === 0
                        ? ""
                        : this.props.skillReducer.userHelper.length > 0 &&
                          this.props.skillReducer.userHelper
                            .filter((item, i) => {
                              if (this.state.searchTerm === "") {
                                return item;
                              } else if (
                                item.SKILL_NAME !== null &&
                                item.SKILL_NAME.toLowerCase().includes(
                                  this.state.searchTerm.toLocaleLowerCase()
                                )
                              ) {
                                return item;
                              }
                            })
                            .map((skill, index) => (
                              <React.Fragment>
                                <MyHelperItem
                                  color={getColors(skill.SKILL_NAME)}
                                  key={index}
                                  skill={skill}
                                  {...this.props}
                                  deleteDraftSkill={this.deleteDraftSkill}
                                />
                              </React.Fragment>
                            ))}

                      {/* My Document Flow */}
                      {this.props.skillReducer.isLoading
                        ? ""
                        : this.props.skillReducer.draft_skills.length === 0
                        ? ""
                        : this.props.skillReducer.draft_skills
                            .filter((item, i) => {
                              if (this.state.searchTerm === "") {
                                if (item.status === "published") {
                                  return item;
                                }
                              } else if (
                                item.SKILL_NAME !== null &&
                                item.SKILL_NAME.toLowerCase().includes(
                                  this.state.searchTerm.toLocaleLowerCase()
                                )
                              ) {
                                return item;
                              }
                            })
                            .map((skill, index) => (
                              <React.Fragment>
                                <MyDocumentFlow
                                  color={getColors(skill.SKILL_NAME)}
                                  key={index}
                                  skill={skill}
                                  {...this.props}
                                  deleteDraftSkill={this.deleteDraftSkill}
                                />
                              </React.Fragment>
                            ))}
                    </div>
                  </div>

                  {process.env.REACT_APP_SHOWDRAFT === "true" ? (
                    <div
                      id="drafts"
                      className={`tab-pane fade ${
                        this.props.skillReducer.isActive === "draft"
                          ? "in active"
                          : ""
                      } `}
                    >
                      <div className="scrollable skill-list-scroll">
                        {this.props.skillReducer.isLoading ? (
                          <Loader
                            styles={{ width: "50px", margin: "auto" }}
                            root={{ display: "flex" }}
                          />
                        ) : this.props.skillReducer.draft_skills.length == 0 ? (
                          <EmptyLoader message="No Draft Skills found" />
                        ) : (
                          this.props.skillReducer.draft_skills
                            .filter((item, i) => {
                              if (this.state.searchTerm === "") {
                                if (item.status !== "published") {
                                  return item;
                                }
                              } else if (
                                item.SKILL_NAME !== null &&
                                item.SKILL_NAME.toLowerCase().includes(
                                  this.state.searchTerm.toLocaleLowerCase()
                                )
                              ) {
                                return item;
                              }
                            })
                            .map((skill, index) => (
                              <React.Fragment>
                                <MyDraftItem
                                  color={getColors(skill.SKILL_NAME)}
                                  key={index}
                                  skill={skill}
                                  {...this.props}
                                  deleteDraftSkill={this.deleteDraftSkill}
                                />
                              </React.Fragment>
                            ))
                        )}
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>

              {/* <span className="divider"></span> */}
              {/* <p className="small-title">
                {this.state.minMode ? "S" : "Suggested Skills"}
              </p>
              <div className="scrollable suggest-list-scroll">
                {this.props.skillReducer.skills.length == 0 ? (
                  <EmptyLoader styles={{ width: "90px" }} />
                ) : (
                  this.returnPrebuildskills(this.props.skillReducer.skills)
                )}
              </div> */}
              {process.env.REACT_APP_SHOWMYTASK === "true" ? (
                <button
                  className={
                    this.state.minMode
                      ? "outline-new filled-btn btn-addSkill"
                      : "outline-new filled-btn "
                  }
                  data-toggle="modal"
                  data-target="#mydraftModal"
                >
                  {this.state.minMode ? "+" : "+ Train a New Skill"}
                </button>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
        {/* Create Draft modal */}
        <div className="modal crt-skill fade" id="mydraftModal" role="dialog">
          <div className="modal-dialog modal-md">
            <div className="modal-content crt-content">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <div className="form-contain">
                  <h1>Create a new skill</h1>
                  <form onSubmit={(e) => e.preventDefault()}>
                    <div className="frm-block">
                      <label>
                        Skill Name <span style={{ color: "red" }}>*</span>
                      </label>
                      <input
                        value={this.state.SKILL_NAME}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") e.preventDefault();
                        }}
                        type="text"
                        name="SKILL_NAME"
                        onChange={(e) => this.onFieldChange(e)}
                        placeholder="Enter"
                      />
                    </div>
                    <div className="frm-block">
                      <label>
                        Descriptions <span style={{ color: "red" }}>*</span>
                      </label>
                      <textarea
                        value={this.state.SKILL_DESCRIPTION}
                        name="SKILL_DESCRIPTION"
                        onChange={(e) => this.onFieldChange(e)}
                        placeholder="Enter"
                      ></textarea>
                    </div>

                    <div
                      className="frm-block"
                      onChange={(e) => this.onTemplateChange(e)}
                    >
                      <label>From Template</label>
                      <div class="temp-input">
                        <input
                          type="radio"
                          value=" Conversational based input and act on a web application"
                          name="Template"
                        />{" "}
                        {""}
                        Conversational based input and act on a web application
                      </div>
                      <div class="temp-input">
                        <input
                          type="radio"
                          value=" Bulk input and act on a web application"
                          name="Template"
                        />{" "}
                        {""}
                        Bulk input and act on a web application
                      </div>
                    </div>

                    <div className="frm-btns">
                      <button className="btn-outline" data-dismiss="modal">
                        Cancel
                      </button>
                      <span
                        onClick={() => this.handleSubmit()}
                        className="primary-btn"
                        data-dismiss="modal"
                      >
                        Done
                      </span>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Delete modal */}
        <div className="modal fade qa-modal1" id="myDeleteModal" role="dialog">
          <div className="modal-dialog modal-sm">
            <div className="modal-content share-modal">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <h3 className="qa-modal-title">Delete</h3>
                <div>
                  <h5>Please confirm delete action.</h5>
                </div>

                <div className="frm-btns fb-right">
                  <button className="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      this.deleteDraftSkill();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    notify,
    getUserSkills,
    searchMySKills,
    deleteMySkill,
    getSkillsFromStore,
    getDraftSkills,
    createDraftSkill,
    changeSkillAreaView,
    deleteDraftSkill,
    changeActiveTab,
    clearDraft,
  })
)(SideBar);
