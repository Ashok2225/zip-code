import React, { Component } from "react";
import { connect } from "react-redux";
import {
    searchDraft
} from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import DraftItem from "./MyDraftItem";
import EmptyLoader from "../../../../components/emptyLoader";
import Loader from "../../../../components/loader";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../redux/actions/snack";
import backArrow from "../../../../images/back-arrow.png";


class SearchResults extends Component {
    constructor() {
        super();
        this.state = {
            skills: [],
            page: 1,
            skillPageInfo: null,
            pageSize: 10,
            hasMore: true,
            searchItem: null,
            isSearching: true,
            activeSearch: "",
            isScrolling: false
        };
    }

    openConfigure = (item) => {
        this.props.addSkillToUser(item);
    };
    componentDidMount() {
        this.getSearchResults();
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.page !== this.state.page) {
            this.getSearchResults();
        }
    }

    getSearchResults = async () => {
        var query = this.props.match.params.id.split("=")[1];
        var skillType = this.props.match.params.id.split("?")[0];
        try {
            if (skillType === "draft") {
                let page = this.state.page;

                let data = { page, query };
                const res = await this.props.searchDraft(data);
                if (res && res.results) {
                    this.setState({
                        skills: this.state.skills.concat(res.results),
                        skillPageInfo: res.pageInfo,
                        isSearching: false,
                        activeSearch: "draft",
                        isScrolling: false
                    });
                } else {
                    this.setState({
                        hasMore: false,
                        isSearching: false,
                        isScrolling: false
                    });
                }

            } else {
                this.props.notify("error", "Something went wrong");
                this.setState({
                    isSearching: false,
                    isScrolling: false
                });
            }
        } catch (err) {
            console.log("error: ", err.toString())
            this.props.notify("error", "Something went wrong");
            this.setState({
                isSearching: false,
                isScrolling: false
            });
        }
    };

    fetchData() {
        this.setState({ isScrolling: true });
        try {
            if (this.state.skillPageInfo.length < 10) {
                this.setState({
                    hasMore: false,
                });
            } else {
                this.setState({
                    page: this.state.page + 1,
                });
            }
        } catch (err) {
            console.log(err)
            this.setState({
                hasMore: false
            });
            this.props.notify("error", "Failed to refresh");
        }
    }

    backtoggle() {
        this.props.history.goBack();
    }

    render() {
        return (
            <React.Fragment>
                <div className="store-search-page">
                    <div class="knb-title">
                        <div class="back-title">
                            <button
                                class="back-qa"
                                onClick={() => {
                                    this.backtoggle();
                                }}
                            >
                                <img src={backArrow} alt={backArrow} />
                            </button>
                        </div>
                        <p class="kn-title" style={{ flex: 1 }}>
                            Back to Search
                        </p>
                        <div class="btn-right"></div>
                    </div>
                    <div className="task-col">
                        <div className="title-btn">
                            <h1 className="title">Search Results</h1>
                        </div>
                        <div id="scrollableDiv" className="scrollable tl-scroll">
                            {this.state.isSearching ? (
                                <div class="empty-view">
                                    <Loader
                                        styles={{ width: "80px", margin: "auto" }}
                                        root={{ display: "flex" }}
                                    />
                                </div>
                            ) : (
                                <div>
                                    {this.state && !this.state.skills.length ? (
                                        <div>
                                            <EmptyLoader
                                                style={{ width: "30%" }}
                                                message="No Result found"
                                            />
                                            <p style={{ textAlign: "center" }}>No Result found</p>
                                        </div>
                                    ) : (
                                        <>
                                            {this.state.activeSearch === "draft" && (
                                                <>
                                                    <InfiniteScroll
                                                        dataLength={this.state.skills.length}
                                                        next={this.fetchData.bind(this)}
                                                        hasMore={this.state.hasMore}
                                                        scrollableTarget="scrollableDiv"
                                                        loader={
                                                            this.state.isScrolling ? (
                                                                <Loader
                                                                    styles={{ width: "80px", margin: "auto" }}
                                                                    root={{ display: "flex" }}
                                                                />
                                                            ) : (
                                                                ""
                                                            )
                                                        }
                                                        endMessage={
                                                            this.state.skills.length == 0 ? (
                                                                <p
                                                                    className="loading-end"
                                                                    style={{ textAlign: "center" }}
                                                                >
                                                                    <b>No Result Found</b>
                                                                </p>
                                                            ) : (
                                                                <p className="loading-end">
                                                                    <b>Yay! You have seen it all</b>
                                                                </p>
                                                            )
                                                        }
                                                    >
                                                        {this.state.skills &&
                                                            this.state.skills.map((item, index) => (
                                                                
                                                                    <DraftItem
                                                                        index={index}
                                                                        //   openConfigure={this.openConfigure}
                                                                        key={item.id}
                                                                        skill={item}
                                                                    />
                                                                
                                                            ))}
                                                    </InfiniteScroll>
                                                </>
                                            )}


                                            


                                        </>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => ({
    skills: state.skillReducer,
    userReducer: state.userReducer,
    searchTerm: state.searchTerm
});

export default compose(
    withRouter,
    connect(mapStateToProps, {
        searchDraft,
        notify,

    })
)(SearchResults);
