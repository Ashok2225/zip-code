/*global chrome*/
import React, { Component } from "react";
import poygonplay from "../../../../../images/Polygon 1@2x.png";
import info from "../../../../../images/info.png";
import installed from "../../../../../images/notif-tones/MicrosoftTeams-image (3).png";
import getColors from "../../../../../components/colors";
import deleteIcon from "../../../../../images/training/delete-red.png";
import rtbmenu from "../../../../../images/training/rtb-menu.png";
import {
  viewHelperSkill,
  executeFlow,
  changeSkillAreaView,
} from "../../../../../redux/actions/skill";


import { notify } from "../../../../../redux/actions/snack";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";

const TEMPLATE_WITH_LOOP_RESTRICTION = [
  "User Documentation",
  "Web Automation",
  "In-App Walkthrough",
  "User Onboarding",
];


class MyDocumentFlow extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    window.$('[data-toggle="popover"]').popover({
      container: "body",
    });
  }

  deleteItem = (viewItem) => {
    this.props.viewHelperSkill(viewItem);
  };

  play = async (item) => {
    var data = {
      deviceId: this.props.skillReducer.draftSession,
      skillId: item.id,
      bulk: !TEMPLATE_WITH_LOOP_RESTRICTION.includes(
        item?.TEMPLATE
      ),
    };

    if (data.deviceId === undefined) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
    } else {
      const playSkill = await this.props.executeFlow(data);
      if (playSkill.data.status == false) {
        chrome.runtime.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          { type: "openLogin" },
          (response) => {
            if (response) {
              // console.log("Extension Response", response);
            }
          }
        );
      }
    }
  };

  render() {
    var item = this.props.skill;
    return (
      <div className="col-md-4 ss-block pdl-0">
        <div className="ss-box">
          {/* <div
            onClick={() => this.deleteItem(item)}
            className="deleteIcon"
            data-toggle="modal"
            data-target="#myDeleteModal"
          >
            <img src={deleteIcon} alt="" />
          </div> */}
          <div className="rtb-menu draft-menu">
            <div class="dropdown">
              <a
                class="rtb-menu-btn"
                type="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                <img src={rtbmenu} />
              </a>
              <ul class="dropdown-menu dropdown-menu-left pull-right">
                <li
                  onClick={() => this.deleteItem(item)}
                  data-toggle="modal"
                  data-target="#myDeleteModal"
                >
                  <button>
                    <span>
                      <img src={deleteIcon} />
                    </span>{" "}
                    Delete
                  </button>
                </li>
              </ul>
            </div>
          </div>
          <div
            className="ss-title-cont"
            onClick={() =>
              this.props.history.push(`/dashboard/skills/viewSkill/${item.id}`)
            }
          >
            <div
              className="ss-ico ss-text"
              style={{ backgroundColor: this.props.color }}
            >
              <p>{item.SKILL_NAME && item.SKILL_NAME.substring(0, 2)}</p>
            </div>
            <div className="hp-content">
              <h5 title={item.SKILL_NAME}>
                {item.SKILL_NAME && item.SKILL_NAME}
                {/* {item.SKILL_NAME && item.SKILL_NAME.length > 35 ? (
                  <span>
                    <strong>...</strong>
                  </span>
                ) : null} */}
              </h5>
              <div className="overflow-text">
                <p>{item.SKILL_DESCRIPTION}</p>
                {item.SKILL_DESCRIPTION &&
                item.SKILL_DESCRIPTION.length > 100 ? (
                  <>
                    <a
                      class="tlt-icon tl-tooltip"
                      href="javascript:void(0)"
                      data-toggle="popover"
                      data-html="true"
                      data-trigger="hover"
                      // data-placement={
                      //   (this.props.index + 1) % 3 === 0 ? "left" : "right"
                      // }
                      data-placement="auto right"
                      data-content={item.SKILL_DESCRIPTION}
                      title="Description"
                    >
                      <img src={info} alt="" />
                    </a>
                  </>
                ) : null}
              </div>
            </div>
          </div>
          <div className="ss-footer">
            {item.TEMPLATE === "In-App Walkthrough" ? (
              <div className="use-now">
                <button
                  className="btn btn-default use-button"
                  onClick={() => this.play(item)}
                >
                  Use Now
                </button>
                {/* <div className="use-ico">
                  <img src={poygonplay} alt="" />
                </div> */}
                {/* <p>Use Now</p> */}
              </div>
            ) : (
              <div className="use-now disabled">
                {/* <div className="use-ico">
                  <img src={poygonplay} alt="" aria-disabled="true" />
                </div> */}
                {/* <p>Use Now</p> */}
              </div>
            )}

            <div className="brand-list">
              {item.TEMPLATE === "In-App Walkthrough"
                ? "In-App Walkthrough"
                : item.TEMPLATE === "UserDocumentation"
                ? "User Documentation"
                : item.TEMPLATE === "Import Data from Spreadsheet to Web App"
                ? "Import Data from Spreadsheet.."
                : item.TEMPLATE === "WebAutomation"
                ? "Web Automation"
                : item.TEMPLATE === "UserOnboarding"
                ? "User Onboarding"
                : ""}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  snackReducer: state.snackReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    notify,
    changeSkillAreaView,
    viewHelperSkill,
  })
)(MyDocumentFlow);
