/*global chrome*/
import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getSkillsFromStore,
  addSkillToUser,
  filterSearchItem,
  getUserSkills,
  deleteMySkill,
  changeSkillAreaView,
  getDraftSkills,
  getUserHelperSkills,
  getMetaDataSkills,
  clearDraft,
} from "../../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import MySkillItem from "../MySkillItem";
import EmptyLoader from "../../../../../components/emptyLoader";
import Loader from "../../../../../components/loader";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../../redux/actions/snack";
import getColors from "../../../../../components/colors";
import { ReactNotifications, Store } from "react-notifications-component";
import MyDocumentFlow from "../MyDocumentFlow";
import MyHelperItem from "../MyHelperItem";

class MyPublishedSkills extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skills: [],
      isLoading: true,
      regularSkill: [],
      helperPublished: [],
      userSkillData: [],
      metaSkillData: [],
      isLoadingRegular: true,
      isLoadingHelper: true,
      allPublishedSkill: [],
      searchItem: "",
      publishedPageInfo: [],
      publishPage: 1,
      hasMore: true,
    };
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.publishPage !== this.state.publishPage) {
      this.getPublishedSkill();
    }
  }
  componentDidMount() {
    this.getPublishedSkill();
  }

  getPublishedSkill = async () => {
    let data0 = { page: this.state.publishPage };
    let applyFilter = "published";
    const metaDataSkill = await this.props.getMetaDataSkills(data0);
    metaDataSkill.data.data.results.map((item, i) => {
      item["kind"] = "onBoardedWalkThrough";
    });

    const userOnboardedSkill = await this.props.getUserSkills(data0);

    userOnboardedSkill.data.data.map((item, i) => {
      item["kind"] = "onboarded";
    });

    this.setState({
      userSkillData: userOnboardedSkill.data.data,
      metaSkillData: metaDataSkill.data.data.results,
    });

    if (
      userOnboardedSkill.data.data.length ||
      metaDataSkill.data.data.results.length
    ) {
      let allSkills = this.state.skills.concat(
        this.state.userSkillData,
        this.state.metaSkillData
      );
      allSkills.sort((a, b) => {
        return new Date(b.LAST_UPDATED_AT) - new Date(a.LAST_UPDATED_AT);
      });
      this.setState({
        isLoading: false,
        skills: allSkills,

        isScrolling: false,
        publishedPageInfo: [
          userOnboardedSkill.data.data,
          metaDataSkill.data.data.results,
        ],
      });
    } else {
      this.setState({
        isLoading: false,
        hasMore: false,
        isScrolling: false,
      });
    }
  };

  fetchData() {
    this.setState({ isScrolling: true });
    let totalItems =
      this.state.publishedPageInfo[0].length +
      this.state.publishedPageInfo[1].length;
    try {
      if (totalItems < 10) {
        this.setState({
          hasMore: false,
          isLoading: false,
        });
      } else {
        this.setState({
          publishPage: this.state.publishPage + 1,
          isLoading: false,
        });
      }
    } catch (err) {
      this.setState({
        hasMore: false,
        isLoading: false,
      });
      this.props.notify("error", "Failed to refresh");
    }
  }

  deleteMySkill = (e, id) => {
    let skillId = parseInt(
      this.props.skills.skillArea ? this.props.skills.skillArea.SKILL_ID : null
    );
    if (skillId !== null) {
      const deleteSkill = this.props.deleteMySkill(skillId);
      if (deleteSkill) {
        this.props.history.push(window.location.pathname);
      }
    }
  };

  deleteMyOnboardedSkill = async (e, id) => {
    let skillId = parseInt(this.props?.skills?.helper?.SKILL_ID);

    if (skillId !== "") {
      const deleteDraft = await this.props.deleteMySkill(skillId);
      if (deleteDraft) {
        this.props.history.push(window.location.pathname);
        this.props.clearDraft();
      }
    }
  };

  chatSkill = (skill) => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (response) {
            this.props.chatSkill(skill);
          } else {
            this.notificationPopUp();
          }
        }
      );
    } catch (error) {
      this.notificationPopUp();
      console.log("error ", error);
    }
  };

  notificationPopUp() {
    Store.addNotification({
      title: "Note: ",
      message:
        "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before creating/using skills.",
      type: "warning",
      insert: "top",
      container: "top-right",
      dismiss: {
        duration: 5000,
        onScreen: true,
      },
    });
    window.setTimeout(function () {
      window.open(
        `https://chrome.google.com/webstore/detail/techforce-ide-extension/${process.env.REACT_APP_CHROME_TAB_ID}`,
        "_blank"
      );
    }, 5000);
  }

  searchSkillStore = (e) => {
    this.setState({
      searchItem: e.target.value,
    });
  };

  onKeyPress = (e) => {
    if (e.key === "Enter") {
      this.setState({
        isSearching: true,
      });
      this.props.history.push({});
    }
  };

  render() {
    return (
      <React.Fragment>
        {/* Published Skill */}
        <div className="task-col-search">
          <div className="row mx-0 setting-search bg-white py-3 border-left">
            <div className="col-md-8">
              <div className="position-relative search">
                <input
                  id="searchField"
                  type="search"
                  placeholder="Search"
                  className="form-control border-0"
                  value={this.state.searchItem ? this.state.searchItem : ""}
                  onChange={(e) =>
                    this.setState({ searchItem: e.target.value })
                  }
                  // onKeyDown={(e) => this.onKeyPress(e)}
                />
                {/* <img src={SearchIcon} alt="Search" /> */}
              </div>
            </div>
          </div>

          <div className="task-col">
            <div className="title-btn">
              {/* <h1 className="title">Published Skills</h1> */}
              <h1 className="title">Added From Skill Hub</h1>
            </div>
            <div id="scrollableDiv" className="scrollable tl-scroll">
              {this.state.isLoading ? (
                <div class="empty-view">
                  <Loader
                    styles={{ width: "80px", margin: "auto" }}
                    root={{ display: "flex" }}
                  />
                </div>
              ) : (
                <div>
                  {this.state.isLoading === false &&
                  !this.state.publishedPageInfo.length ? (
                    <div>
                      <EmptyLoader
                        style={{ width: "30%" }}
                        message="No Skills found"
                      />
                    </div>
                  ) : (
                    <div>
                      <InfiniteScroll
                        dataLength={this.state.skills.length}
                        next={this.fetchData.bind(this)}
                        hasMore={this.state.hasMore}
                        loader={
                          this.state.isScrolling ? (
                            <Loader
                              styles={{ width: "80px", margin: "auto" }}
                              root={{ display: "flex" }}
                            />
                          ) : (
                            ""
                          )
                        }
                        scrollableTarget="scrollableDiv"
                        endMessage={
                          this.state.publishedPageInfo.length === 0 ? (
                            <p
                              className="loading-end"
                              style={{ textAlign: "center" }}
                            >
                              <b>No Published Skill Found</b>
                            </p>
                          ) : (
                            <p className="loading-end">
                              <b>Yay! You have seen it all</b>
                            </p>
                          )
                        }
                      >
                        {this.state.isLoading ? (
                          <Loader
                            styles={{ width: "50px", margin: "auto" }}
                            root={{ display: "flex" }}
                          />
                        ) : this.state.publishedPageInfo.length +
                            this.state.publishedPageInfo.length ===
                          0 ? (
                          <EmptyLoader message="No Skills found" />
                        ) : (
                          this.state.skills
                            .filter((item, i) => {
                              if (this.state.searchItem === "") {
                                return item;
                              } else if (
                                item.SKILL_NAME !== null &&
                                item.SKILL_NAME.toLowerCase().includes(
                                  this.state.searchItem.toLocaleLowerCase()
                                )
                              ) {
                                return item;
                              }
                            })
                            .map((item, index) => {
                              switch (item.kind) {
                                case "onboarded":
                                  return (
                                    <MySkillItem
                                      {...this.props}
                                      deleteMySkill={this.deleteMySkill}
                                      chatSkill={this.chatSkill}
                                      updateSkill={this.updateSkill}
                                      color={getColors(item.SKILL_NAME)}
                                      skills={item}
                                      index={index}
                                      key={index}
                                      item={item}
                                      {...this.props}
                                    />
                                  );
                                case "onBoardedWalkThrough":
                                  return (
                                    <MyHelperItem
                                      color={getColors(item.SKILL_NAME)}
                                      key={index}
                                      skill={item}
                                      {...this.props}
                                    />
                                  );
                                // case "helper":
                                //   if (item.status === "approved") {
                                //     return (
                                //       <MyHelperItem
                                //         color={getColors(item.SKILL_NAME)}
                                //         key={index}
                                //         skill={item}
                                //         {...this.props}
                                //         deleteDraftSkill={this.deleteDraftSkill}
                                //       />
                                //     );
                                //   }
                                //   break;

                                // case "regular":
                                //   return (
                                //     <MyDocumentFlow
                                //       color={getColors(item.SKILL_NAME)}
                                //       key={index}
                                //       skill={item}
                                //       {...this.props}
                                //       deleteDraftSkill={this.deleteDraftSkill}
                                //     />
                                //   );
                                default:
                                  return null;
                              }
                            })
                        )}
                      </InfiniteScroll>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* My Published Skill Delete Modal */}
        <div
          className="modal fade qa-modal1"
          id="mySkillDeleteModal"
          role="dialog"
        >
          <div className="modal-dialog modal-sm">
            <div className="modal-content share-modal">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <h3 className="qa-modal-title">Delete</h3>
                <div>
                  <h5>Please confirm delete action</h5>
                </div>

                <div className="frm-btns fb-right">
                  <button className="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      this.deleteMySkill();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Delete modal */}
        <div className="modal fade qa-modal1" id="myDeleteModal" role="dialog">
          <div className="modal-dialog modal-sm">
            <div className="modal-content share-modal">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className="modal-body">
                <h3 className="qa-modal-title">Delete</h3>
                <div>
                  <h5>Please confirm delete action.</h5>
                </div>

                <div className="frm-btns fb-right">
                  <button className="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    className="primary-btn"
                    data-dismiss="modal"
                    onClick={() => {
                      this.deleteMyOnboardedSkill();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    addSkillToUser,
    filterSearchItem,
    notify,
    getUserSkills,
    deleteMySkill,
    changeSkillAreaView,
    getUserHelperSkills,
    getDraftSkills,
    getMetaDataSkills,
    clearDraft,
  })
)(MyPublishedSkills);
