import React, { Component } from "react";
import poygonplay from "../../../../../images/Polygon 1@2x.png";
import info from "../../../../../images/info.png";
import getColors from "../../../../../components/colors";
import deleteIcon from "../../../../../images/training/delete-red.png";
import rtbmenu from "../../../../../images/training/rtb-menu.png";

class MySKillItem extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    window.$('[data-toggle="popover"]').popover({
      container: "body",
    });
  }

  render() {
        const userRole =
          this.props?.organizationReducer?.currentOrgUser?.role_id;

    var item = this.props.item;

    return (
      <div className="col-md-4 ss-block pdl-0">
        <div className="ss-box">
          <div className="rtb-menu draft-menu">
            {userRole==="2"?  <div class="dropdown">
              <a
                class="rtb-menu-btn"
                type="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                <img src={rtbmenu} />
              </a>
              <ul class="dropdown-menu dropdown-menu-left pull-right">
                <li
                  onClick={(e) => this.props.changeSkillAreaView(item)}
                  data-toggle="modal"
                  data-target="#mySkillDeleteModal"
                >
                  <button>
                    <span>
                      <img src={deleteIcon} />
                    </span>{" "}
                    Delete
                  </button>
                </li>
              </ul>
            </div>:null}
          

            {/* <span className="hlp-email">{item.USER_EMAIL}</span> */}
            {item.USER_EMAIL?<span className="hlp-email">{item.USER_EMAIL}</span>
            :null}
          </div>

          <div
            className="ss-title-cont"
            onClick={() => this.props.chatSkill(item)}
          >
            <div
              className="ss-ico ss-text"
              style={{
                backgroundColor: getColors(item.SKILL_NAME),
              }}
            >
              <p>{item.SKILL_NAME && item.SKILL_NAME.substring(0, 2)}</p>
            </div>
            <div className="hp-content">
              <h5 title={item.SKILL_NAME}>
                {item.SKILL_NAME && item.SKILL_NAME}
                {/* {item.SKILL_NAME && item.SKILL_NAME.length > 35 ? (
                  <span>
                    <strong>...</strong>
                  </span>
                ) : null} */}
              </h5>

              <div className="overflow-text">
                <p>{item.description}</p>
                {item.description && item.description.length > 100 ? (
                  <>
                    <a
                      class="tlt-icon tl-tooltip"
                      href="javascript:void(0)"
                      data-toggle="popover"
                      data-html="true"
                      data-trigger="hover"
                      // data-placement={
                      //   (this.props.index + 1) % 3 === 0 ? "left" : "right"
                      // }
                      data-placement="auto right"
                      data-content={item.description}
                      title="Description"
                    >
                      <img src={info} alt="" />
                    </a>
                  </>
                ) : null}
              </div>
              {/* <p>
                {item.description && item.description.substring(0, 90)}
                {item.description && item.description.length > 90 ? (
                  <>
                    <span>
                      <strong>...</strong>
                    </span>
                    <a
                      class="tlt-icon tl-tooltip"
                      href="javascript:void(0)"
                      data-toggle="popover"
                      data-html="true"
                      data-trigger="hover"
                      data-placement={
                        (this.props.index + 1) % 3 === 0 ? "left" : "right"
                      }
                      data-content={item.description}
                      title="Description"
                    >
                      <img src={info} alt="" />
                    </a>
                  </>
                ) : null}
              </p> */}
            </div>
          </div>
          <div className="ss-footer">
            <div className="use-now">
              <button
                className="btn btn-default use-button"
                onClick={() => this.props.chatSkill(item)}
              >
                Use Now
              </button>
              {/* <div className="use-ico">
                <img src={poygonplay} alt="" />
              </div> */}
              {/* <p>Use Now</p> */}
            </div>

            <div className="brand-list">Automation Skill</div>
            {/* <div className="instance-count">
              <p>Logs</p>
              <span className="badge">20</span>
            </div> */}
          </div>
        </div>
      </div>
    );
  }
}

export default MySKillItem;
