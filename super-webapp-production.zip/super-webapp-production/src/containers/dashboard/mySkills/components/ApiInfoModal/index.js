import React from "react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import CodeEditor from "@uiw/react-textarea-code-editor";
import userReducer from "../../../../../redux/reducers/userReducer";
import { getAllApiTokens } from "../../../../../redux/actions/auth";

const ApiInfoModal = () => {
  const userDeviceId = useSelector((state) => state.skillReducer.draftSession);
  const _skillInfo = useSelector((state) => state.skillReducer.helper);
  const userId = useSelector((state) => state.userReducer?.user?.sub);
  const [code, setCode] = useState();

  useEffect(() => {
    let _cmd = `curl -L -X POST "${process.env.REACT_APP_BOT_SERVICE_URL}/draftSkills/extension/execute" -H "X-API-TOKEN:YOUR API TOKEN" -H "X-API-ORG: ${_skillInfo?.organizationId}" -H "Content-Type: application/json" --data-raw "{\"deviceId\": ${userDeviceId},\"skillId\": ${_skillInfo?.id},\"orgId\":  ${_skillInfo?.organizationId},\"bulk\": true,\"isAPI\":false,\"userId\":\"${userId}\",\"additionalParams\":{Your input payload goes here}`;
    setCode(_cmd);
    return () => {
      setCode("");
    };
  }, [_skillInfo]);

  return (
    <div
      id="apiModal"
      className="modal fade crt-skill"
      role="dialog"
      data-backdrop="static"
      data-keyboard="false"
    >
      <div className="modal-dialog">
        <div className="modal-content crt-content">
          <div className="modal-header">
            <button type="button" className="close" data-dismiss="modal">
              &times;
            </button>
            <h4 className="modal-title">API Info</h4>
          </div>
          <div className="modal-body">
            <div className="form-contain">
              <div className="steps-block">
                {/* <ol>
                  <li>
                    <span>
                      Select post request, paste the URL{" "}
                      <a
                        href="https://teams.microsoft.com/_?culture=en-us&c"
                        target="_blank"
                      >
                        https://teams.microsoft.com/_?culture=en-us&c
                      </a>
                    </span>
                  </li>
                  <li>
                    <span>Select post request, paste the URL</span>
                  </li>
                </ol> */}
              </div>
              <div className="code-block">
                <pre className="scrollable">
                  <CodeEditor
                    readOnly={true}
                    value={code}
                    language="js"
                    padding={15}
                    style={{
                      fontSize: 12,
                      backgroundColor: "#f5f5f5",
                      fontFamily:
                        "ui-monospace,SFMono-Regular,SF Mono,Consolas,Liberation Mono,Menlo,monospace",
                    }}
                  />
                  <br />
                </pre>
              </div>
              <div className="frm-btns">
                <button className="btn-outline" data-dismiss="modal">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiInfoModal;
