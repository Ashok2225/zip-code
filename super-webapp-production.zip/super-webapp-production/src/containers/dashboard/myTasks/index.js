import React, { Component } from "react";
import { connect } from "react-redux";
import SideBar from "./components/SideBar/index";
import MyTasksDashboard from "./components/MyTasks";
import ApproveHelper from "./components/ApproveHelper";
import { Switch, Route, withRouter } from "react-router-dom";

import "../../../css/app.css";
import HelperEdit from "../skillStore/components/HelperEdit";

class MyTasks extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    return (
      <div className="align-row">
        {/* <SideBar />
        <HelperEdit /> */}

        <Switch>
          <Route
            path="/dashboard/tasks/approveWalkThrough"
            render={() => <ApproveHelper />}
          />
          {/* <Route path="/dashboard/tasks" render={() => <MyTasksDashboard />} /> */}
        </Switch>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(MyTasks);
