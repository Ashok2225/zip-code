import React, { Component } from "react";
import { connect } from "react-redux";

import newImage from "../../../../../images/new.png";
import thumb from "../../../../../images/thumb.png";
import {
  getSharedKnowledge,
  approveSharedKnowledge,
  rejectSharedKnowledge,
} from "../../../../../redux/actions/knowledge";

const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
const orgId = getOrgDetails ? getOrgDetails.id : null;

class MyTasksDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isLoadingApprove: false,
      isLoadingReject: false,
      alter_questions: [],
      checked_knowledges: [],
    };
  }

  async componentWillMount() {
    await this.props.getSharedKnowledge();
  }

  handleCheck = (e, knowledge) => {
    console.log("event: ", e.target.checked);
    if (e.target.checked) {
      let checked = [...this.state.checked_knowledges, knowledge];
      this.setState({ checked_knowledges: checked });
    } else {
      this.state.checked_knowledges.map((item, index) => {
        if (knowledge.id === item.id) {
          let checked = this.state.checked_knowledges;
          checked.splice(index, 1);
          this.setState({ checked_knowledges: checked });
        }
      });
    }
  };

  approveKnowledge = async () => {
    this.setState({ isLoadingApprove: true });

    try {
      await this.props.approveSharedKnowledge(this.state.checked_knowledges);
      this.props.getSharedKnowledge();
      this.setState({ checked_knowledges: [], isLoadingApprove: false });
    } catch (err) {
      console.log("approve error");
    }
  };

  rejectKnowledge = async () => {
    this.setState({ isLoadingReject: true });

    try {
      await this.props.rejectSharedKnowledge(this.state.checked_knowledges);
      this.props.getSharedKnowledge();
      this.setState({ checked_knowledges: [], isLoadingReject: false });
    } catch (err) {
      console.log("reject error");
    }
  };

  modalPopUp = (data) => {
    this.setState({ popUpQuestion: data });
  };

  render() {
    let { isLoadingApprove, isLoadingReject } = this.state;
    let { sharedKnowledge } = this.props.knowledge;
    return (
      <div className="fw-screen">
        <div
          className={
            this.props.minMode ? "right-content rm-margin" : "right-content"
          }
        >
          <div className="task-col">
            <div className="title-btn">
              <h1 className="title">My Tasks</h1>
              <div className="btn-flex-ra">
                <button
                  disabled={
                    this.state.checked_knowledges.length > 0 ? false : true
                  }
                  className="btn btn-danger"
                  onClick={this.rejectKnowledge}
                >
                  {isLoadingReject ? (
                    <div class="sp sp-circle"></div>
                  ) : (
                    "Reject"
                  )}
                </button>
                <button
                  disabled={
                    this.state.checked_knowledges.length > 0 ? false : true
                  }
                  className="btn btn-approve"
                  onClick={this.approveKnowledge}
                >
                  {isLoadingApprove ? (
                    <div class="sp sp-circle"></div>
                  ) : (
                    "Approve"
                  )}
                </button>
              </div>
            </div>
            <ul className="nav nav-pills task-pills">
              <li className="active">
                <a data-toggle="pill" href="#waiting">
                  <div className="tlc-title">
                    <span className="tlc-icon">
                      <img
                        src={newImage}
                        alt=""
                        style={{ marginLeft: "10px", width: "28px" }}
                      />
                    </span>
                    <p>Shared Notes</p>
                  </div>
                </a>
              </li>

              <li>
                <a data-toggle="pill" href="#completed">
                  <div className="tlc-title">
                    <span className="tlc-icon">
                      <img src={thumb} alt="" />
                    </span>
                    <p>Approved Notes</p>
                  </div>
                </a>
              </li>
            </ul>
            <div className="scrollable tl-scroll task-tb-scroll">
              <div className="tab-content task-tabs">
                {!sharedKnowledge.length ? (
                  <div align="center" style={{ margin: "auto" }}>
                    <p style={{ color: "grey", fontSize: "12px" }}>
                      Nothing Found
                    </p>
                  </div>
                ) : (
                  <div id="waiting" className="tab-pane fade in active">
                    <div className="table-responsive tt-block">
                      <table className="table table-striped table-task">
                        <thead>
                          <tr>
                            <th></th>
                            <th>Title / Question</th>
                            {/* <th>Priority</th> */}
                            <th>Created by</th>
                            <th>Created Date</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          {sharedKnowledge.map((knowledge) =>
                            knowledge.hasOwnProperty("shared_status") &&
                            knowledge.shared_status == "pending" ? (
                              <tr>
                                <td>
                                  <input
                                    name={knowledge.id}
                                    onClick={(e) =>
                                      this.handleCheck(e, knowledge)
                                    }
                                    type="checkbox"
                                  />
                                </td>
                                <td>{knowledge.question}</td>
                                {/* <td><span className="label label-warning">Medium</span></td> */}
                                <td>
                                  <div className="email-user">
                                    <div className="em-icon">
                                      <span>
                                        {knowledge.created_user.slice(0, 2)}
                                      </span>
                                    </div>
                                    <p>{knowledge.created_user}</p>
                                  </div>
                                </td>
                                <td>{knowledge.created_at.slice(0, 10)}</td>
                                <td>
                                  <button
                                    className="btn btn-info btn-sm"
                                    data-toggle="modal"
                                    data-target="#mytaskModal1"
                                    onClick={(e) => this.modalPopUp(knowledge)}
                                  >
                                    View
                                  </button>
                                </td>
                              </tr>
                            ) : null
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                <div id="completed" className="tab-pane fade">
                  <div className="table-responsive tt-block">
                    <table className="table table-striped table-task">
                      {sharedKnowledge.length > 0 ? (
                        <thead>
                          <tr>
                            <th>Title / Question</th>
                            {/* <th>Priority</th> */}
                            <th>Created by</th>
                            <th>Created Date</th>
                            <th></th>
                          </tr>
                        </thead>
                      ) : null}
                      <tbody>
                        {sharedKnowledge.map((knowledge) =>
                          knowledge.hasOwnProperty("shared_status") &&
                          knowledge.shared_status == "approved" ? (
                            <tr>
                              {/* <td><input name={knowledge.id} onClick={(e) => this.handleCheck(e, knowledge)} type="checkbox"/></td> */}
                              <td>{knowledge.question}</td>
                              {/* <td><span className="label label-warning">Medium</span></td> */}
                              <td>
                                <div className="email-user">
                                  <div className="em-icon">
                                    <span>
                                      {knowledge.created_user.slice(0, 2)}
                                    </span>
                                  </div>
                                  <p>{knowledge.created_user}</p>
                                </div>
                              </td>
                              <td>{knowledge.created_at.slice(0, 10)}</td>
                              <td>
                                <button
                                  className="btn btn-info btn-sm"
                                  data-toggle="modal"
                                  data-target="#mytaskModal1"
                                  onClick={(e) => this.modalPopUp(knowledge)}
                                >
                                  View
                                </button>
                              </td>
                            </tr>
                          ) : null
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="modal fade qa-modal" id="mytaskModal1" role="dialog">
            <div className="modal-dialog">
              <div className="modal-content">
                <button type="button" className="close" data-dismiss="modal">
                  &times;
                </button>
                <div className="modal-body md-edit">
                  <h4>Title / Question:</h4>
                  <p>
                    {this.state.popUpQuestion
                      ? this.state.popUpQuestion.question
                      : null}
                  </p>
                  <hr />
                  <h4>Alternate Questions:</h4>
                  {this.state.popUpQuestion &&
                  this.state.popUpQuestion.alter_questions.length ? (
                    <div>
                      {this.state.popUpQuestion.alter_questions.map((ques) => {
                        return <p>{ques.data}</p>;
                      })}
                    </div>
                  ) : null}
                </div>
                <div class="frm-btns fb-right">
                  <button class="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  knowledge: state.knowledgeReducer,
  user: state.userReducer,
  skill: state.skillReducer,
});

export default connect(mapStateToProps, {
  getSharedKnowledge,
  approveSharedKnowledge,
  rejectSharedKnowledge,
})(MyTasksDashboard);
