import React, { Component } from "react";
import $ from "jquery";
import searchicon from "../../../../../images/serach-black.png";
import closeicon from "../../../../../images/close.png";
import menu_toggle from "../../../../../images/menu-side.png";
import { connect } from "react-redux";
import { compose } from "redux";
import { withRouter } from "react-router";
import getColors from "../../../../../components/colors";
class SideBar extends Component {
  state = {
    minMode: false,
    activeMenu: "All Tasks",
  };
  shrinkSidebar = () => {
    this.setState({
      minMode: !this.state.minMode,
    });
  };

  componentDidMount() {
    var path = window.location.href;

    if (path.match("/dashboard/tasks")) {
      this.setState({
        activeMenu: "All Tasks",
      });
    }
    if (path.match("/dashboard/tasks/approveHelper")) {
      this.setState({
        activeMenu: "Helper Skills",
      });
    }
  }

  render() {
    const user =
      this.props.user && this.props.user.user !== null
        ? this.props.user.user.email
        : "";
    return (
      <div className={this.state.minMode ? "task-list minibar" : "task-list"}>
        <div className="flex-title">
          <h3 className="title">My Tasks</h3>
          {/* <div className="ls-sidebar">
            <input type="text" placeholder="search" />
            <div className="ls-icons">
              <button className="ls-search">
                <img src={searchicon} alt="" />
              </button>
              <button
                className="ls-close"
                onClick={() => $(".ls-sidebar").removeClass("active")}
              >
                <img src={closeicon} alt="" />
              </button>
            </div>
          </div> */}
          <div className="icon-list">
            {/* <div
              className="src-icon"
              // style={{ display: this.props.minMode ? "none" : "flex" }}
              onClick={() => $(".ls-sidebar").addClass("active")}
            >
              <img src={searchicon} alt="" />
            </div> */}
            <div
              className="collapse-menu"
              onClick={() => {
                this.shrinkSidebar();
              }}
            >
              <img src={menu_toggle} alt="" />
            </div>
          </div>
        </div>
        <div className="task-block">
          {/* <p className="small-title">Frequently Used</p> */}
          <div className="tl-list">
            <div
              className="all-task"
              onClick={() => {
                this.props.history.push({
                  pathname: "/dashboard/tasks",
                });
              }}
            >
              {/* <div
                className={`tl-block ${
                  this.state.activeMenu === "All Tasks" ? "active" : ""
                }`}
              >
                <div className="tl-icon">
                  <div
                    className="tl-text"
                    style={{ background: getColors("Notes") }}
                  >
                    N
                  </div>
                </div>
                <div className="tl-cont">
                  <p>Notes</p>
                  <span>23 skills</span>
                </div>
              </div> */}
            </div>
            {/* Helper tab */}

            {(user && user === process.env.REACT_APP_ADMIN1) ||
            user === process.env.REACT_APP_ADMIN2 ||
            user === process.env.REACT_APP_ADMIN3 ||
            user === process.env.REACT_APP_ADMIN4 ? (
              <React.Fragment>
                <div
                  className="all-task"
                  onClick={() => {
                    this.props.history.push({
                      pathname: "/dashboard/tasks/approveHelper",
                    });
                  }}
                >
                  <div
                    className={`tl-block ${
                      this.state.activeMenu === "Helper Skills" ? "active" : ""
                    }`}
                  >
                    <div className="tl-icon">
                      <div
                        className="tl-text "
                        style={{ background: getColors("Pending Helper") }}
                      >
                        HE
                        {/* {this.props.skill && this.props.skill.helperTask
                          ? this.props.skill.helperTask.results.length
                          : ""}{" "} */}
                      </div>
                    </div>
                    <div className="tl-cont">
                      <p>Helper Skills</p>
                      <span>
                        {/* {this.props.skill && this.props.skill.helperTask
                          ? this.props.skill.helperTask.results.length
                          : ""}{" "}
                        skills */}
                      </span>
                    </div>
                  </div>
                </div>
              </React.Fragment>
            ) : (
              <React.Fragment></React.Fragment>
            )}
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  user: state.userReducer,
  skill: state.skillReducer,
  knowledge: state.knowledgeReducer,
});
export default compose(withRouter, connect(mapStateToProps, {}))(SideBar);
