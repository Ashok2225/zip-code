/*global chrome*/
import React, { Component } from "react";
import { connect } from "react-redux";

import newImage from "../../../../../images/new.png";
import thumb from "../../../../../images/thumb.png";
import {
  getHelperTask,
  approveDraftSkill,
  getSession,
  executeFlow,
  updateDraftSkill,
  getDraftSkillsById,
} from "../../../../../redux/actions/skill";
import Loader from "../../../../../components/loader";
import EmptyLoader from "../../../../../components/emptyLoader";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../../redux/actions/snack";
import { withRouter } from "react-router";
import { compose } from "redux";
const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
const orgId = getOrgDetails ? getOrgDetails.id : null;

const TEMPLATE_WITH_LOOP_RESTRICTION = [
  "User Documentation",
  "Web Automation",
  "In-App Walkthrough",
  "User Onboarding",
];
class ApproveHelper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isLoadingApprove: false,
      isLoadingReject: false,
      helperTask: [],
      page: 1,
      pageInfo: [],
      hasMore: true,
      isScrolling: false,
      checked_task: [],
      category: "",
    };
  }

  componentWillMount() {
    this.props.getSession();
    this.getTask();
  }
  componentDidUpdate(prevProps, prevState) {
    if (prevState.page !== this.state.page) {
      this.getTask();
    }
  }
  getTask = async () => {
    const taskList = await this.props.getHelperTask(this.state.page);

    if (taskList && taskList.results) {
      this.setState({
        helperTask: this.state.helperTask.concat(taskList.results),
        pageInfo: taskList.results,
        isLoading: false,
        isScrolling: false,
      });
    } else {
      this.setState({
        isLoading: false,
        isScrolling: false,
        hasMore: false,
      });
    }
  };
  fetchData() {
    this.setState({ isScrolling: true });
    try {
      if (this.state.pageInfo.length < 14) {
        this.setState({
          hasMore: false,
        });
      } else {
        this.setState({
          page: this.state.page + 1,
        });
      }
    } catch (err) {
      this.setState({
        hasMore: false,
      });
      this.props.notify("error", "Failed to refresh");
    }
  }

  handleCheck = (e, task) => {
    // console.log("event: ", e.target.checked);
    if (e.target.checked) {
      let checked = [...this.state.checked_task, task.id];
      this.setState({ checked_task: checked });
    }
  };

  approveHelperTask = async () => {
    this.setState({ isLoadingApprove: true });

    try {
      const response = await this.props.approveDraftSkill(
        this.state.checked_task,
        "approved"
      );
      if (response) {
        this.props.notify(
          "success",
          `${
            this.state.checked_task.length +
            "" +
            "Helper Skill Approved Successfully !"
          }`
        );

        this.setState({ checked_task: [], isLoadingApprove: false });
        this.props.history.push(window.location.pathname);
      }
    } catch (err) {
      console.log("approve error");
    }
  };

  rejectHelperTask = async () => {
    this.setState({ isLoadingReject: true });
    try {
      const response = await this.props.approveDraftSkill(
        this.state.checked_task,
        "declined"
      );
      if (response) {
        this.setState({ checked_task: [], isLoadingReject: false });
        this.props.notify("success", "Helper Rejected");
        this.props.history.push(window.location.pathname);
      }
    } catch (err) {
      console.log("reject error");
    }
  };

  modalPopUp = (data) => {
    this.setState({ popUpQuestion: data });
  };

  playSkill = async (item) => {
    var data = {
      deviceId: this.props.skill.draftSession,
      skillId: item.id,
      bulk: !TEMPLATE_WITH_LOOP_RESTRICTION.includes(
        item?.TEMPLATE
      ),
    };
    if (data.deviceId === undefined) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
    } else {
      const playSkill = await this.props.executeFlow(data);
      if (playSkill.data.status == false) {
        chrome.runtime.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          { type: "openLogin" },
          (response) => {
            if (response) {
              console.log("Extension Response", response);
            }
          }
        );
      }
    }
  };

  handleInputChange = (e, i) => {
    let helper_task = [...this.state.helperTask];

    helper_task[i].CATEGORY = e.target.value;
    this.setState({ helper_task });
  };

  updateCategory = async (task) => {
    const skillDetails = await this.props.getDraftSkillsById(task.id);
    let skillData = skillDetails?.data?.data;
    const updateHelper = await this.props.updateDraftSkill(task.id, {
      ...skillData,
      CATEGORY: task.CATEGORY,
    });
    if (updateHelper) {
      this.props.notify("success", "Updated SuccessFully !");
    }
  };
  render() {
    let { isLoadingApprove, isLoadingReject, helperTask } = this.state;

    return (
      <div className="fw-screen">
        <div
          className={
            this.props.minMode ? "right-content rm-margin" : "right-content"
          }
        >
          <div className="task-col">
            <div className="title-btn">
              <h1 className="title">My Tasks</h1>
              <div className="btn-flex-ra">
                <button
                  disabled={this.state.checked_task.length > 0 ? false : true}
                  className="btn btn-danger"
                  onClick={this.rejectHelperTask}
                >
                  {isLoadingReject ? (
                    <div class="sp sp-circle"></div>
                  ) : (
                    "Reject"
                  )}
                </button>
                <button
                  disabled={this.state.checked_task.length > 0 ? false : true}
                  className="btn btn-approve"
                  onClick={this.approveHelperTask}
                >
                  {isLoadingApprove ? (
                    <div class="sp sp-circle"></div>
                  ) : (
                    "Approve"
                  )}
                </button>
              </div>
            </div>
            <ul className="nav nav-pills task-pills">
              <li className="active">
                <a data-toggle="pill" href="#waiting">
                  <div className="tlc-title">
                    <span className="tlc-icon">
                      <img
                        src={newImage}
                        alt=""
                        style={{ marginLeft: "10px", width: "28px" }}
                      />
                    </span>
                    <p>In-App Walkthroughs</p>
                  </div>
                </a>
              </li>
            </ul>
            <div
              id="scrollableDiv"
              className="scrollable tl-scroll task-tb-scroll mytask-scroll"
            >
              <InfiniteScroll
                dataLength={this.state.helperTask.length}
                next={this.fetchData.bind(this)}
                hasMore={this.state.hasMore}
                loader={
                  this.state.isScrolling ? (
                    <Loader
                      styles={{
                        width: "80px",
                        margin: "auto",
                      }}
                      root={{ display: "flex" }}
                    />
                  ) : (
                    ""
                  )
                }
                scrollableTarget="scrollableDiv"
                endMessage={
                  this.state.helperTask.length === 0 ? (
                    <p className="loading-end" style={{ textAlign: "center" }}>
                      <b>No Data Found</b>
                    </p>
                  ) : (
                    <p className="loading-end">
                      <b>Yay! You have seen it all</b>
                    </p>
                  )
                }
              >
                {this.state.isLoading ? (
                  <Loader
                    styles={{ width: "50px", margin: "auto" }}
                    root={{ display: "flex" }}
                  />
                ) : this.state.pageInfo.length + this.state.pageInfo.length ===
                  0 ? (
                  <EmptyLoader message="No Data found" />
                ) : (
                  <div className="tab-content task-tabs ">
                    <div id="waiting" className="tab-pane fade in active">
                      <div className="table-responsive tt-block">
                        <table className="table table-task">
                          <thead>
                            <tr>
                              <th style={{ width: "5%" }}></th>
                              <th style={{ width: "20%" }}>Skill Name</th>
                              <th style={{ width: "8%" }}>Status</th>
                              <th style={{ width: "25%" }}>Created by</th>
                              <th style={{ width: "10%" }}>Last Update</th>
                              <th style={{ width: "25%" }}>Category</th>
                              <th></th>
                            </tr>
                          </thead>

                          <tbody>
                            {helperTask.map((task, i) =>
                              task.status == "pending" ? (
                                <tr key={i}>
                                  <td className="mt-checkbox">
                                    <input
                                      name={task.id}
                                      onClick={(e) => this.handleCheck(e, task)}
                                      type="checkbox"
                                    />
                                  </td>
                                  <td>{task.SKILL_NAME}</td>
                                  <td>
                                    <span className="label label-warning label-pending">
                                      {task.status}
                                    </span>
                                  </td>
                                  <td>
                                    <div className="email-user">
                                      {/* <div className="em-icon">
                                        <span>
                                          {task.USER_EMAIL &&
                                            task.USER_EMAIL.slice(0, 2)}
                                        </span>
                                      </div> */}
                                      <p title={task.USER_EMAIL}>{task.USER_EMAIL}</p>
                                    </div>
                                  </td>
                                  <td>{task.updated_at.slice(0, 10)}</td>
                                  <td>
                                    <div className="catg-box">
                                    <input
                                      id={task.id}
                                      type="text"
                                      placeholder="Enter Category"
                                      defaultValue={task.CATEGORY}
                                      onChange={(e) =>
                                        this.handleInputChange(e, i)
                                      }
                                    />
                                    <button
                                      className="btn btn-default btn-outline-primary btn-sm"
                                      onClick={() => this.updateCategory(task)}
                                    >
                                      Save
                                    </button>
                                    </div>
                                  </td>
                                  <td>
                                    <button
                                      className="btn btn-primary btn-sm"
                                      onClick={() => this.playSkill(task)}
                                    >
                                      Play
                                    </button>
                                  </td>
                                </tr>
                              ) : null
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    {/* )} */}
                  </div>
                )}
              </InfiniteScroll>
            </div>
          </div>
          <div className="modal fade qa-modal" id="mytaskModal1" role="dialog">
            <div className="modal-dialog">
              <div className="modal-content">
                <button type="button" className="close" data-dismiss="modal">
                  &times;
                </button>
                <div className="modal-body md-edit">
                  <h4>Title / Question:</h4>
                  <p>
                    {this.state.popUpQuestion
                      ? this.state.popUpQuestion.question
                      : null}
                  </p>
                  <hr />
                  <h4>Alternate Questions:</h4>
                  {this.state.popUpQuestion &&
                  this.state.popUpQuestion.alter_questions.length ? (
                    <div>
                      {this.state.popUpQuestion.alter_questions.map((ques) => {
                        return <p>{ques.data}</p>;
                      })}
                    </div>
                  ) : null}
                </div>
                <div class="frm-btns fb-right">
                  <button class="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  knowledge: state.knowledgeReducer,
  user: state.userReducer,
  skill: state.skillReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    notify,
    getHelperTask,
    approveDraftSkill,
    getSession,
    executeFlow,
    updateDraftSkill,
    getDraftSkillsById,
  })
)(ApproveHelper);
