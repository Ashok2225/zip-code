import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Table } from "reactstrap";
import EllipsisWithTooltip from "react-ellipsis-with-tooltip";
import { getSchedules, deleteSchedule } from "../../../redux/actions/schedules";
import { getWorkers } from "../../../redux/actions/workers";
import { getProcesses } from "../../../redux/actions/processes";
import EmptyScreen from "./images/Empty-Screen.png";
import CustomModal from "../../../UtilityComponents/customModal";
import CreateSchedule from "./create";
import DeleteSchedule from "./delete";
import { addNotification } from "../../../Utilities/notifications";
import stringToDate from "../../../Utilities/stringToDate";
import loader from "./images/loaderTransaparent.gif";
import ScheduleSuccess from "./success";
import { notify } from "../../../redux/actions/snack";
import "./index.css";

function Schedules(props) {
  let { user } = props;
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [workers, setWorkers] = useState(false);
  const [bots, setBots] = useState(false);
  const [schedules, setSchedules] = useState([]);
  const [modal, setModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [schedule, setSchedule] = useState({});
  const [search_data, setsearch_data] = useState();
  const [schedule_Success, setScheduleSuccess] = useState(false);

  useEffect(() => {
    // document.title = "Schedules | SuperApp | Techforce.ai";
    const fetchData = async () => {
      setLoading(true);
      let data = await getSchedules();
      setLoading(false);
      if (data && data.length > 0) {
        setSchedules(data);
      }
    };
    fetchData();
  }, []);

  const scheduleSuccess = () => {
    toggle();
    scheduleSuccessPage();
  };

  const scheduleSuccessPage = () => {
    setScheduleSuccess(!schedule_Success);
  };

  const reload = async () => {
    scheduleSuccessPage();
    let data = await getSchedules();
    if (data.length > 0) {
      setSchedules(data);
    }
  };

  const handleChange = (e) => {
    setsearch_data(e.target.value);
    if (e.target.value.length === 0) {
      setsearch_data(null);
      fetchData();
    }
  };

  const fetchData = async () => {
    setLoading(true);
    let data = await getSchedules();
    setLoading(false);
    if (data.length > 0) {
      setSchedules(data);
    }
  };

  const handleSearch = async () => {
    if (search_data) {
      let org = schedules.find((obj) => obj.name.toString() === search_data);
      if (org) {
        setSchedules([org]);
      } else {
        setSchedules([]);
      }
    } else {
      let data = await getSchedules();
      if (data.length > 0) {
        setSchedules(data);
      }
    }
  };

  const handleCreate = async () => {
    setProcessing(true);

    let workersData = await props.getWorkers();
    console.log("===>>>>>>>", workersData);
    if (workersData.length > 0) {
      setWorkers(workersData);
      let botsData = await props.getProcesses();
      console.log(botsData, "bot=>>>>>>>>>>>>>>>>>>>>>>>");
      if (botsData.rows.length > 0) {
        setBots(botsData.rows);
        setModal(true);
      } else {
        props.notify(
          "error",
          "Seems like you haven't published any action flows, Please create a action flow and try to schedule"
        );
        // addNotification({
        //   title: "Techforce.ai",
        //   message:
        //     "Seems like you haven't created any action flows, Please create a action flow and try to schedule",
        //   type: "info",
        //   container: "top-center",
        // });
        // setTimeout(() => {
        //   props.history.push("/processes");
        // }, 2000);
      }

      setProcessing(false);
    } else {
      setProcessing(false);
      props.notify(
        "error",
        "Seems like you haven't created any worker, Please create a worker and try to schedule"
      );
      // addNotification({
      //   title: "Techforce.ai",
      //   message:
      //     "Seems like you haven't created any worker, Please create a worker and try to schedule",
      //   type: "info",
      //   container: "top-center",
      // });
    }
  };

  const toggle = () => setModal(!modal);

  const deleteModalToggle = (obj) => {
    if (obj) {
      setSchedule(obj);
    }
    setDeleteModal(!deleteModal);
  };
  const handleDelete = async () => {
    deleteModalToggle();
    let cron_tasks = schedules.map((obj) => {
      if (obj.id === schedule.id) {
        return { ...obj, deleting: true };
      } else {
        return { ...obj };
      }
    });
    setSchedules(cron_tasks);

    try {
      await deleteSchedule(schedule.key);
      props.notify("success", "schedule deleted succesfully");
    } catch (err) {
      props.notify("error", "failed to delete schedule");
    }

    // setDelete(false);
    setLoading(true);

    let data = await getSchedules();

    setLoading(false);
    setSchedules(data);
  };

  const keyPress = async (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  if (loading) {
    return (
      <div className="task-col-search">
        <div className="row mx-0 setting-search bg-white py-3 border-left">
          <div className="col-md-8">
            <div className="position-relative search">
              <input
                id="searchField"
                type="search"
                placeholder="Search"
                className="form-control border-0"
                // value={this.state.searchItem ? this.state.searchItem : ""}
                // onChange={(e) => this.searchSkillStore(e)}
                // onKeyDown={(e) => this.onKeyPress(e)}
              />
              {/* <img src={SearchIcon} alt="Search" /> */}
            </div>
          </div>
        </div>

        <div className="task-col">
          <div className="title-btn">
            <h1 className="title">Schedules</h1>
            {/* <i className="fa fa-search" onClick={handleSearch} style={{height:"22px",color:"#938989",position:"absolute",right:"240px",padding:"7px",marginTop:"7px"}}></i>
          <input type="text"  name="search_data"onKeyPress={keyPress} onChange={handleChange}placeholder="Search" style={{height:"39px",backgroundColor:"#f7f7f7",position:"absolute",right:"95px"}}/> */}
            <button className="btn btn-primary" onClick={handleCreate}>
              {processing ? (
                <div className="sp sp-circle text-white"></div>
              ) : (
                "+ Create"
              )}
            </button>
          </div>
          <div id="scrollableDiv" className="scrollable tl-scroll">
            <div style={{ textAlign: "center", marginTop: "15%" }}>
              <img src={loader} width="120" alt="loading"></img>
            </div>
          </div>
        </div>
      </div>
    );
  } else {
    return (
      <div className="task-col-search">
        <div className="row mx-0 setting-search bg-white py-3 border-left">
          <div className="col-md-8">
            <div className="position-relative search">
              <input
                id="searchField"
                type="search"
                placeholder="Search"
                className="form-control border-0"
                // value={this.state.searchItem ? this.state.searchItem : ""}
                // onChange={(e) => this.searchSkillStore(e)}
                // onKeyDown={(e) => this.onKeyPress(e)}
              />
              {/* <img src={SearchIcon} alt="Search" /> */}
            </div>
          </div>
        </div>
        <div className="task-col">
          <div className="title-btn">
            <h1 className="title">Schedules</h1>
            {/* <i className="fa fa-search" onClick={handleSearch} style={{height:"22px",color:"#938989",position:"absolute",right:"240px",padding:"7px",marginTop:"7px"}}></i>
          <input type="text"  name="search_data"onKeyPress={keyPress} onChange={handleChange}placeholder="Search" style={{height:"39px",backgroundColor:"#f7f7f7",position:"absolute",right:"95px"}}/> */}
            <button className="btn btn-primary" onClick={handleCreate}>
              {processing ? (
                <div className="sp sp-circle text-white"></div>
              ) : (
                "+ Create"
              )}
            </button>
          </div>
          <div id="scrollableDiv" className="scrollable tl-scroll">
            {schedules.length > 0 ? (
              <div className="table-default">
                <Table className="table-main">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Bot Id</th>
                      {/* <th>EXCECUTION TYPE</th> */}
                      <th style={{ whiteSpace: "nowrap" }}>Worker Name</th>
                      {/* <th>WORKER TYPE</th> */}
                      <th>Timezone</th>
                      <th>Status</th>
                      <th style={{ whiteSpace: "nowrap" }}>Published By</th>
                      <th>Created At</th>
                      <th>Stop Time</th>
                      {/* <th>Next Tick</th> */}
                      <th></th>
                    </tr>
                  </thead>
                  <tbody className="table-body">
                    {schedules.map((obj, ind) => {
                      return (
                        <tr key={ind}>
                          <td className="scheduleName">
                            {obj.name.length > 8 ? (
                              <EllipsisWithTooltip>
                                {obj.name}
                              </EllipsisWithTooltip>
                            ) : (
                              <div className="scheduleName">{obj.name}</div>
                            )}
                          </td>
                          <td>
                            {obj.bot_id.length > 12 ? (
                              <EllipsisWithTooltip>
                                {obj.name}
                              </EllipsisWithTooltip>
                            ) : (
                              <div>{obj.bot_id}</div>
                            )}
                          </td>
                          {/* <td>
                        {obj.execution_type !== "0" ? (
                          <div>{obj.execution_type}</div>
                        ) : (
                          "-"
                        )}
                      </td> */}
                          <td>
                            {obj["worker_name"] != null ? (
                              obj["worker_name"].length > 10 ? (
                                <EllipsisWithTooltip>
                                  {obj["worker_name"]}
                                </EllipsisWithTooltip>
                              ) : (
                                <div>{obj["worker_name"]}</div>
                              )
                            ) : (
                              "-"
                            )}
                          </td>
                          {/* <td>
                        {obj["TF_WORKER.worker_type"] != null ? (
                          obj["TF_WORKER.worker_type"].length > 10 ? (
                            <EllipsisWithTooltip>
                              {obj["TF_WORKER.worker_type"]}
                            </EllipsisWithTooltip>
                          ) : (
                            <div>{obj["TF_WORKER.worker_type"]}</div>
                          )
                        ) : (
                          "-"
                        )}
                      </td> */}
                          <td>
                            {obj.timezone.length > 10 ? (
                              <EllipsisWithTooltip>
                                {obj.timezone}
                              </EllipsisWithTooltip>
                            ) : (
                              <div>{obj.timezone}</div>
                            )}
                          </td>
                          <td>{obj.status}</td>
                          <td
                            className="email"
                            style={{ marginLeft: "3px !important" }}
                          >
                            {obj.email.length > 12 ? (
                              <EllipsisWithTooltip>
                                {obj.email}
                              </EllipsisWithTooltip>
                            ) : (
                              <div className="email">{obj.email}</div>
                            )}
                          </td>
                          <td>
                            <EllipsisWithTooltip>
                              {stringToDate(obj.created_at)}
                            </EllipsisWithTooltip>
                          </td>
                          <td>
                            {obj.stop_time.length === 16 ? (
                              <EllipsisWithTooltip>
                                {stringToDate(obj.stop_time)}
                              </EllipsisWithTooltip>
                            ) : (
                              "-"
                            )}
                          </td>
                          {/* <td>
                            <EllipsisWithTooltip>
                              {stringToDate(obj.next_interval)}
                            </EllipsisWithTooltip>
                          </td> */}
                          <td className="text-center">
                            {obj.deleting ? (
                              <i
                                style={{ color: "#02ce9d" }}
                                className="fas fa-circle-notch fa-spin"
                              ></i>
                            ) : (
                              <i
                                style={{ color: "red", fontSize: "1.1em" }}
                                className="fa fa-trash"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete"
                                onClick={() => deleteModalToggle(obj)}
                              ></i>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </Table>
              </div>
            ) : schedules.length === 0 && search_data != null ? (
              <div className="content">
                <Table hover responsive className="responsive-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Bot Name</th>
                      {/* <th>EXCECUTION TYPE</th> */}
                      <th style={{ whiteSpace: "nowrap" }}>Worker Name</th>
                      {/* <th>WORKER TYPE</th> */}
                      <th>Timezone</th>
                      <th>Status</th>
                      <th style={{ whiteSpace: "nowrap" }}>Published By</th>
                      <th>Created At</th>
                      <th>Stop Time</th>
                      <th>Next Tick</th>
                    </tr>
                  </thead>
                </Table>
              </div>
            ) : (
              <div className="empty-skill text-center">
                <img src={EmptyScreen} alt="empty Screen"></img>
                <p>Seems like you don't have any schedules yet.</p>
                <button className="btn btn-primary">+ Please create</button>
              </div>
            )}

            {modal ? (
              <CustomModal
                comp={
                  <CreateSchedule
                    toggle={() => toggle()}
                    scheduleSuccess={() => scheduleSuccess()}
                    workers={workers}
                    bots={bots}
                    modal={modal}
                  />
                }
                name="New Schedule"
                toggle={() => toggle()}
                modal={modal}
              />
            ) : null}
            {deleteModal ? (
              <CustomModal
                comp={
                  <DeleteSchedule
                    handleDelete={() => handleDelete()}
                    toggle={() => deleteModalToggle()}
                    name={schedule.name}
                  />
                }
                name={`Are you sure you want to delete`}
                toggle={() => deleteModalToggle()}
                modal={deleteModal}
              />
            ) : null}
            {schedule_Success ? (
              <CustomModal
                comp={<ScheduleSuccess reload={() => reload()} />}
                name="Schedule Created"
                toggle={() => reload()}
                modal={schedule_Success}
              />
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  user: state.user,
});

export default connect(mapStateToProps, { getWorkers, getProcesses, notify })(
  Schedules
);
