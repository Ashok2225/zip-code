export const createCronExpression = (schedule) => {
    let cron_expression = ''
    let { name,  bot_id, worker, triggerType, hours, timeZone, minutes, advanced_expression, weekDays, months } = schedule;
    if(name && bot_id !== "0" && worker !== "0" && timeZone !== "0"){
        switch(triggerType){
            case "minutes":
            cron_expression = `*/${minutes} * * * *`;
            break;
            
            case "hourly":
            cron_expression = `*/${minutes} */${hours} * * *`;
            break;
            
            case "daily":
            cron_expression = `${minutes} ${hours} * * *`;
            break;
            
            case "weekly":
            let days = ''
            weekDays.forEach(day => {
                if(day.active){
                days += (day.id) + ',';
                }
            });
            cron_expression = `${minutes} ${hours} * * ${days.slice(0,-1)}`;
            break;
            
            case "monthly":
            let selectedMonths = '';
            let selectedDays = '';
            weekDays.forEach(day => {
                if(day.active){
                    selectedDays += (day.id)+ ','
                }
            });
            months.forEach(month => {
                if(month.active){
                selectedMonths += (month.id-1) + ','
                }
            });

            cron_expression = `${minutes} ${hours} * ${selectedMonths.slice(0,-1)} ${selectedDays.slice(0,-1)}`;
            break;
            
            case "advanced":
            cron_expression = advanced_expression;
            break;

            default:
            cron_expression = '';
            break;
        };
    return cron_expression;
    }
    else{
        return false;
    }
}