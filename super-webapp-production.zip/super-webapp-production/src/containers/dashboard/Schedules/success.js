import React  from "react";
import successimg from './images/success.png'

function success(props) {     
    return (
        <div className="text-center">
            <div className="success-page">
                    <img src={successimg} alt="Success!" height="20%" className="success-page-img"  />
                    <div className="success-page-main-msg"> Schedule has been Successfully created</div>
                    <div className="success-page-sub-msg"> Please go back to schedule page</div>
            </div>
            <div className="text">
                <button className="btn btn-primary back_btn" onClick={() => props.reload()}>
                   Back to Schedule page
               </button>
            </div>
        </div>
    )
}
export default success;