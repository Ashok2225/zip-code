import React, { useState } from "react";
import timezones from "../../../Utilities/timezones";
import datesCompare from "../../../Utilities/datesCompare.js";
import { createSchedule } from "../../../redux/actions/schedules";
import { createCronExpression } from "./createCronExpression";
import { addNotification } from "../../../Utilities/notifications";
import { notify } from "../../../redux/actions/snack";
import { connect } from "react-redux";
import "./index.css";


function CreateSchedule(props) {

  let state = {
    name: "",
    workerType: "standard",
    worker: "0",
    bot_id: "0",
    timeZone: "0",
    excecutionType: "0",
    triggerType: "minutes",
    hours: "",
    minutes: "",
    advanced_expression: "",
    stop_time: "",
    stop_date: "",
    stop: false,
    stop_type: "stop",
    params: false,
    parameters: "",
    paramsType: "String"
  }

  let { bots } = props;

  const [workers, setWorkers] = useState(props.workers ? props.workers.filter(obj => obj.worker_type === "standard") : []);
  let [err, setErr] = useState(false)
  let [minErr, setMinErr] = useState(false)
  let [validate, setValidate] = useState(false)
  let [validateSchedule, setValidateSchedule] = useState(false)
  let [obj, setObj] = useState(state);
  const [enableSubmit, setEnableSubmit] = useState(true);
  const [loading, setLoading] = useState(false);
  const [jsonErrMsg, setJsonErrMsg] = useState(false)
  const [months, setMonths] = useState([{ id: "1", value: "Jan", active: false },
  { id: "2", value: "Feb", active: false },
  { id: "3", value: "Mar", active: false },
  { id: "4", value: "Apr", active: false },
  { id: "5", value: "May", active: false },
  { id: "6", value: "Jun", active: false },
  { id: "7", value: "Jul", active: false },
  { id: "8", value: "Aug", active: false },
  { id: "9", value: "Sep", active: false },
  { id: "10", value: "Oct", active: false },
  { id: "11", value: "Nov", active: false },
  { id: "12", value: "Dec", active: false }]);

  const [weekDays, setWeekDays] = useState([
    { id: "1", value: "Mon", name: "days", active: false },
    { id: "2", value: "Tue", name: "days", active: false },
    { id: "3", name: "days", value: "Wed", active: false },
    { id: "4", name: "days", value: "Thu", active: false },
    { id: "5", value: "Fri", name: "days", active: false },
    { id: "6", value: "Sat", name: "days", active: false },
    { id: "0", value: "Sun", name: "days", active: false }]);

  const handleParamsChange = (e, index) => {
    if (e.target.type === 'radio') {
      obj = { ...obj, "paramsType": e.target.name }
      setObj(obj);
    }
  }

  const handleChange = (e) => {
    setErr(false)
    if (e.target.name === "months") {
      let updatedMonths = months.map(mon => {
        if (mon.id === e.target.value) {
          mon.active = !mon.active;
        }
        return mon;
      });
      setMonths(updatedMonths)
    }
    else if (e.target.name === "weeks") {
      let updatedWeeks = weekDays.map(obj => {
        if (obj.id === e.target.value) {
          obj.active = !obj.active
        }
        return obj
      })
      setWeekDays(updatedWeeks);
    }
    else if (e.target.type === "radio") {
      if (e.target.name === "dynamic") {
        let _workers = props.workers ? props.workers.filter(obj => obj.worker_type === "dynamic") : [];
        if (_workers.length > 0)
          setWorkers([_workers[0]]);
        else
          setWorkers([]);
      }
      else {
        let _workers = props.workers ? props.workers.filter(obj => obj.worker_type === "standard") : [];
        if (_workers.length > 0)
          setWorkers(_workers);
        else
          setWorkers([]);
      }
      obj = { ...obj, "workerType": e.target.name }
      console.log(obj);
      setObj(obj);
    }
    else {
      if (e.target.name == "name") {
        setValidateSchedule(false);
      }
      obj = { ...obj, [e.target.name]: e.target.value }
      setObj(obj);
    }
    if (e.target.name === "hours") {
      validate = e.target.value > 24 ? "Please select upto 24 hours & not should be 0" : false
      setValidate(validate)
      setObj({ ...obj });
    }
    else if (e.target.name === "minutes") {
      minErr = e.target.value > 60 ? "Please select valid minutes" : false
      setMinErr(minErr)
    }
    else if (e.target.name === "parameters") {
      obj = { ...obj, [e.target.name]: e.target.value }
      setObj(obj);
      setJsonErrMsg(false)
    }
    setEnableSubmit(false);
  }

  const toggleHandleChange = e => {
    if (e.target.name === "stop") {
      obj = { ...obj, "stop": !obj.stop }
      setObj(obj)
    }
    if (e.target.name === "params") {
      obj = { ...obj, "params": !obj.params }
      setObj(obj)
    }
  }

  const isValidJson = (json) => {
    try {
      JSON.parse(json);
      return true;
    } catch (e) {
      return false;
    }
  }

  const focusOut = async (e) => {
    if (e.target.name === "name") {
      let status = await createSchedule(obj);
      if (status === 202) {
        setValidateSchedule(true)
      }
    }
    else if (e.target.name === "parameters") {
      let check = isValidJson(e.target.value)
      if (check) {
        setJsonErrMsg(false)
      }
      else {
        setJsonErrMsg(true)
      }
    }
  };

  const handleSubmit = async (e) => {
    setLoading(true);
    e.preventDefault();
    let cron_expression = createCronExpression({ ...obj, weekDays, months });
    let { name, bot_id, worker, stop, stop_type, stop_time, stop_date, excecutionType, timeZone, parameters } = obj;
    let stop_timeValid;
    if (stop_time.length > 0) {
      stop_timeValid = datesCompare(stop_date, stop_time)
      stop_time = stop_date + 'T' + stop_time
    }
    let condition = cron_expression && validate === false
    var device_name = "";
    workers.map(work => {

      if (parseInt(worker) === parseInt(work.worker_id)) {
        console.log("worker: " + work.worker_name)
        device_name = work.worker_name
      }


      // console.log("worker: "+_worker.worker_name)
    })

    if ((condition && obj.stop === false) || (condition && obj.stop && stop_time.length > 0 && stop_timeValid === true)) {
      let status = await createSchedule({
        name, bot_id,
        cron_expression,
        timezone: timeZone,
        execution_type: excecutionType,
        worker_id: worker,
        params: encodeURIComponent(parameters),
        stop,
        stop_type,
        stop_time,
        worker_name: device_name
      });

      if (status === 201) {
        setLoading(false);
        props.scheduleSuccess();
      }
      else {

        props.notify("error", "Schedule has been Failed ")
        // addNotification({
        //   title: "Techforce.ai",
        //   message: "Schedule has been Failed ",
        //   type: "danger"
        // });
        setLoading(false)
      }
    }
    else {
      setErr(true)
      setLoading(false);
    }
  }

  const renderParamsFields = () => {
    if (obj.paramsType === 'String') {
      return (
        <div className="rf-input-block">
          <input type="text"
            name="parameters"
            value={obj.parameters}
            onChange={handleChange} />
        </div>
      )
    } else {
      return (
        <div>
          <textarea className="form-control" name="parameters" value={obj.parameters} style={{ width: "100%" }} onBlur={focusOut} onChange={handleChange}></textarea>
          {jsonErrMsg &&
            <span className='error'>Please enter valid json object</span>}
        </div>
      )
    }

  }
  const renderTrigger = () => {
    return (
      <div className="row">
        {obj.triggerType === 'monthly' ?
          <div className="col-md-12">
            <div className="row">
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">AT (HRS)</span>
                  <input type="number"
                    name="hours"
                    value={obj.hours}
                    onChange={handleChange}
                    min="1" max="24"
                    placeholder="Enter" required>
                  </input>
                </div>
                {validate !== false &&
                  <span className='error'>{validate}</span>}
              </div>
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">Every(Min)</span>
                  <input type="number"
                    // className="form-control-1"
                    name="minutes"
                    value={obj.minutes}
                    onChange={handleChange}
                    min="1" max="60"
                    placeholder="Enter" required></input>
                </div>
                {minErr !== false &&
                  <span className='error'>{minErr}</span>}
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
                <h5 className="sch-title">Every(Months)</h5>
                <div className="month-day-btns">
                  {months.map((month, index) => <button
                    key={index}
                    name="months"
                    value={month.id}
                    onClick={handleChange}
                    className={month.active ? "active" : ""}>
                    {month.value}
                  </button>)
                  }
                </div>
              </div>
              <div className="col-md-12">
                <h5 className="sch-title">Every(Days)</h5>
                <div className="month-day-btns">
                  {weekDays.map((day, index) => <button key={index}
                    name="weeks"
                    value={day.id}
                    onClick={handleChange}
                    className={(day.active ? "active" : "")}>
                    {day.value}
                  </button>)}
                </div>
              </div>
            </div>

          </div> : null}
        {obj.triggerType === 'weekly' ?
          <div className="col-md-12">
            <div className="row">
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="exampleInputName">AT (HRS)</span>
                  <input type="number"
                    // className="form-control-1"
                    name="hours"
                    value={obj.hours}
                    onChange={handleChange}
                    min="1" max="24"
                    placeholder="Enter" required>
                  </input>
                </div>
                {validate !== false &&
                  <span className='error'>{validate}</span>}
              </div>
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="exampleInputName">EVERY (MIN)</span>
                  <input type="number"
                    // className="form-control-1"
                    name="minutes"
                    value={obj.minutes}
                    onChange={handleChange}
                    min="1" max="60"
                    placeholder="Enter" required></input>
                </div>
                {minErr !== false &&
                  <span className='error'>{minErr}</span>}
              </div>
              <div className="col-md-12">
                <h5 htmlFor="exampleInputName">EVERY (DAYS)</h5>
                <div className="month-day-btns">
                  {weekDays.map((day, index) => <button key={index}
                    name="weeks"
                    value={day.id}
                    onClick={handleChange}
                    className={(day.active ? "active" : "")}>
                    {day.value}
                  </button>)}
                </div>
              </div>
            </div>
          </div>
          : null}

        {obj.triggerType === "daily" ?
          <div className="col-md-12">
            <div className="row">
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">EVERY DAY AT (HRS)</span>
                  <input type="number"
                    name="hours"
                    value={obj.hours}
                    onChange={handleChange}
                    min="1" max="24"
                    placeholder="Enter" required>
                  </input>
                </div>
                {validate !== false &&
                  <span className='error'>{validate}</span>}
              </div>
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">EVERY (MIN)</span>
                  <input type="number"
                    name="minutes"
                    value={obj.minutes}
                    onChange={handleChange}
                    min="1" max="60"
                    placeholder="Enter" required></input>
                </div>
                {minErr !== false &&
                  <span className='error'>{minErr}</span>}
              </div>
            </div>
          </div> : null}

        {obj.triggerType === "hourly" ?
          <div className="col-md-12">
            <div className="row">
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">EVERY (HRS)</span>
                  <input type="number"
                    // className="form-control-1"
                    name="hours"
                    value={obj.hours}
                    onChange={handleChange}
                    min="1" max="24"
                    placeholder="Enter" required>
                  </input>
                </div>
                {validate !== false &&
                  <span className='error'>{validate}</span>}
              </div>
              <div className="col-md-6">
                <div className="ip-tl-label">
                  <span className="tl-label" htmlFor="inputEmail4">AT (MIN)</span>
                  <input type="number"
                    name="minutes"
                    value={obj.minutes}
                    onChange={handleChange}
                    min="1" max="60"
                    placeholder="Enter" required></input>
                </div>
                {minErr !== false &&
                  <span className='error'>{minErr}</span>}
              </div>
            </div>
          </div> : null}

        {obj.triggerType === 'minutes' ?
          <div className="col-md-12">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="exampleInputName">EVERY (MIN)</span>
              <input type="number"
                name="minutes"
                value={obj.minutes}
                onChange={handleChange}
                min="1" max="60"
                placeholder="Enter" required></input>
            </div>
            {minErr !== false &&
              <span className='error'>{minErr}</span>}
          </div> : null}

        {obj.triggerType === 'advanced' ?
          <div className="col-md-12">
            <div className="ip-tl-label">
              <label htmlFor="exampleInputName">CRON EXPRESSION</label>
              <input
                type="name"
                className="form-control-1"
                name="advanced_expression"
                onChange={handleChange}
                value={obj.advanced_expression}
                placeholder=" * * * * * *"
                required
              ></input>
            </div>
          </div> : null}
      </div>
    );
  }



  const renderParameters = () => {
    return (
      <div className="radio-flex">
        <div className="rf-item">
          <input className="form-check-input"
            type="radio" id="inlineCheckbox1"
            name="String"
            onChange={handleParamsChange}
            checked={obj.paramsType === 'String' ? true : false} />
          <label className="form-check-label" htmlFor="inlineCheckbox1">String</label>
        </div>
        <div className="rf-item">
          <input className="form-check-input"
            type="radio" id="inlineCheckbox2"
            name="JSON"
            onChange={handleParamsChange}
            checked={obj.paramsType === 'JSON' ? true : false} />
          <label className="form-check-label" htmlFor="inlineCheckbox2">JSON</label>
        </div>
        {renderParamsFields()}
      </div>
    )
  }


  return (
    <form className="form-contain">
      {
        err ? <div className="alert alert-danger" role="alert">
          Please Fillout All The Fields With Valid Data
        </div> : ""
      }
      {
        validateSchedule ? <div className="alert alert-danger" role="alert">
          Schedule has been Already Exist</div> : ""
      }
      <div className="frm-block">
        <div className="row">
          <div className="col-md-6">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="inputEmail4">Schedule Name</span>
              <input
                type="name"
                name="name"
                onChange={handleChange}
                onBlur={focusOut}
                value={obj.name}
                id="inputEmail4"
                placeholder="Enter"
                required
              ></input>
            </div>
          </div>
          <div className="col-md-6">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="inputEmail4">Skill</span>
              <select
                id="bots"
                name="bot_id"
                value={obj.bot_id}
                onChange={handleChange}
                required
              >
                <option value="0">Select</option>
                {bots.map((obj, index) => (
                  <option key={index} value={obj.id}>
                    {obj.SKILL_NAME}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
      {/* <div className="frm-block-el">
        <div className="row">
          <div className="col-md-12">
            <div className="rf-title">
                <h5 htmlFor="inputEmail4">Worker Type</h5>                  
            </div>
            <div className="radio-flex">
                <div className="rf-item">
              <input
                    className="form-check-input"
                    type="radio"
                    id="inlineCheckbox1"
                    name="standard"
                    onChange={handleChange}
                    checked={obj.workerType === "standard" ? true : false}
                  />
              <label htmlFor="inlineCheckbox1">Reserved worker</label>              
            </div>
            <div className="rf-item">
              <input
                className="form-check-input"
                type="radio"
                id="inlineCheckbox2"
                name="dynamic"
                onChange={handleChange}
                checked={obj.workerType === "dynamic" ? true : false}
              />
              <label htmlFor="inlineCheckbox2">Dynamic worker</label>
            </div>
            </div>            
        </div>
        </div>        
      </div> */}
      <div className="frm-block">
        <div className="row">
          <div className="col-md-6">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="inputEmail4">E-Worker</span>
              <select
                id="worker"
                name="worker"
                value={obj.worker}
                onChange={handleChange}
                required
              >
                <option value="0">Select</option>
                {workers.map((obj, index) => (
                  <option key={index} value={obj.worker_id}>
                    {obj.worker_name}
                  </option>
                ))}
              </select></div>
          </div>
          <div className="col-md-6">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="inputEmail4">Browser Option</span>
              <select
                name="excecutionType"
                value={obj.excecutionType}
                onChange={handleChange}
                id="excecution_type"
                required
              >
                <option value="" >Select</option>
                <option value="chrome">Chrome</option>
                <option value="mozilla firefox">Mozilla Firefox</option>
                <option value="microsoft edge">Microsoft Edge</option>
                <option value="headless">Headless</option>
              </select></div>
          </div>
          <div className="col-md-6">
            <div className="ip-tl-label">
              <span className="tl-label" htmlFor="inputEmail4">Timezone</span>
              <select
                name="timeZone"
                id="exampleFormControlSelect1"
                value={obj.timeZone}
                onChange={handleChange}
                required
              >
                <option value="0">Select</option>
                {timezones.map((zone, index) => <option key={index} value={zone}>{zone}</option>)}
              </select></div>
          </div>
        </div>

      </div>
      <div className="frm-block d-flex title-switch">
        <h5 className="mt-2">Parameters</h5>
        <label className="switch">
          <input type="checkbox" name="params" onChange={toggleHandleChange} checked={obj.params} />
          <span className="slider round" >
          </span>
        </label>
        {obj.params ? renderParameters() : null}
      </div>


      <div className="frm-block-el">
        <h5>Trigger</h5>
        <div className="trigger-buttons">
          <button
            name="triggerType"
            value="minutes"
            className={obj.triggerType === 'minutes' ? "active" : ""}
            onClick={handleChange}
          >
            Minutes
          </button>
          <button
            name="triggerType"
            value="hourly"
            className={obj.triggerType === 'hourly' ? "active" : ""}
            onClick={handleChange}
          >
            Hourly
          </button>
          <button
            name="triggerType"
            value="daily"
            className={obj.triggerType === 'daily' ? "active" : ""}
            onClick={handleChange}
          >
            Daily
          </button>
          <button
            name="triggerType"
            value="weekly"
            className={obj.triggerType === 'weekly' ? "active" : ""}
            onClick={handleChange}
          >
            Weekly
          </button>
          <button
            name="triggerType"
            value="monthly"
            className={obj.triggerType === 'monthly' ? "active" : ""}
            onClick={handleChange}
          >
            Monthly
          </button>
          <button
            name="triggerType"
            value="advanced"
            className={obj.triggerType === 'advanced' ? "active" : ""}
            onClick={handleChange}
          >
            Advanced
          </button>
        </div>
      </div>
      <div className="frm-block">
        {renderTrigger()}
      </div>

      <div className="frm-block d-flex title-switch">
        <h5 className="mt-2">Stop Schedule at</h5>
        <label className="switch">
          <input type="checkbox" name="stop" onChange={toggleHandleChange} checked={obj.stop} />
          <span className="slider round" >
          </span>
        </label>
      </div>

      {obj.stop ?
        <div className="frm-block-el">
          <div className="row">
            <div className="col-md-6">
              <div className="ip-tl-label">
                <span className="tl-label" htmlFor="inputEmail4">Date</span>
                <input
                  type="date"
                  name="stop_date"
                  onChange={handleChange}
                  value={obj.stop_date}
                  required
                ></input>
              </div>
            </div>
            <div className="col-md-6">
              <div className="ip-tl-label">
                <span className="tl-label" htmlFor="inputEmail4">Time</span>
                <input type="time"
                  name="stop_time"
                  onChange={handleChange}
                  value={obj.stop_time}
                  required />
              </div>
            </div>
          </div>
        </div> : null}
      <div className="frm-btns">
        <button className="btn-outline" onClick={() => props.toggle()}>Cancel</button>
        <button className="primary-btn text-center" onClick={handleSubmit} disabled={enableSubmit || validate !== false && obj.triggerType !== "minutes" || minErr !== false && obj.triggerType !== "advanced"}>
          {loading ? <i style={{ color: "#ffffff" }}
            className="fas fa-circle-notch fa-spin"
          ></i> : "Add"}
        </button>
      </div>
    </form>
  );
}

const mapStateToProps = (state) => ({
  user: state.user,
});

export default connect(mapStateToProps, { notify })(CreateSchedule);
