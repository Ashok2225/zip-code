import React  from "react";
import EllipsisWithTooltip from "react-ellipsis-with-tooltip";

function DeleteSchedule(props) {    
    return (
        <div className="form-contain">
            <div className="delete-text">
                <h4>{props.name.length > 40 ? <EllipsisWithTooltip placement="bottom">
                    {props.name} ?</EllipsisWithTooltip>:<div style={{textAlign:"center"}}>{props.name} ?</div>}
                </h4>
            </div>            
            <div className="frm-btns">
                <button className="btn btn-outline" onClick={() => props.toggle()}>
                    No
               </button>
                <button className="primary-btn text-center" onClick={() => props.handleDelete()}>
                    Yes
                </button>
            </div>
        </div>
    )
}
export default DeleteSchedule;