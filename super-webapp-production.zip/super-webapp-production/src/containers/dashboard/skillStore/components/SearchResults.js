import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getSkillsFromStore,
  addSkillToUser,
  filterSearchItem,
  automationSearch,
  helperSearch,
  getDraftSkills
} from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import SkillItem from "../components/SkillItem";
import EmptyLoader from "../../../../components/emptyLoader";
import Loader from "../../../../components/loader";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../redux/actions/snack";
import backArrow from "../../../../images/back-arrow.png";
import HelperItem from "./HelperItem";
import OwlCarousel from 'react-owl-carousel';
class SearchResults extends Component {
  constructor() {
    super();
    this.state = {
      skills: [],

      isLoading: true,

    };
  }


  componentDidMount() {
    this.getSearchResults();
  }

  getSearchResults = async () => {
    var query = this.props.match.params.id.split("=")[1];
    var skillType = this.props.match.params.id.split("?")[0];
    try {
      if (skillType === "all") {
        let skillFromeStore = await this.props.getSkillsFromStore();
        let category = "all";
        let page = -1;
        let type = "helper";
        let data = { type, page, category };
        let inApp = await this.props.getDraftSkills(data);


        let allSkills = [...skillFromeStore.results, ...inApp.results]

        let filtered = allSkills.filter((item) => (item.skill_name ? item.skill_name.toLowerCase() : item.SKILL_NAME.toLowerCase()) .includes (query.toLowerCase()))



        this.setState({
          skills: filtered,

          isLoading: false
        });

      } else {
        this.props.notify("error", "Something went wrong");
        this.setState({
          isLoading: false
        });
      }
    } catch (err) {
      this.props.notify("error", "Something went wrong");
      this.setState({
        isLoading: false
      });
    }
  };


  backtoggle() {
    this.props.history.goBack();
  }

  render() {
    return (
      <React.Fragment>
        <div>
          {
            this.state.isLoading ? (
              <div class="empty-view">
                <Loader
                  styles={{ width: "80px", margin: "auto" }}
                  root={{ display: "flex" }}
                />
              </div>
            ) :

              this.state.skills.length

                ?

                (
                  <div className="sk-slide-section">
                    <h4 className="tp-title">Search Results</h4>
                    <OwlCarousel className='owl-theme sk-boxes' id="sk-boxes1" items={4} margin={30} nav dots={false}>

                      {this.state.skills.map((skill, index) =>


                      (<SkillItem
                        item={skill}
                        key={index}
                      />)

                      )
                      }



                    </OwlCarousel>
                  </div>
                )
                :
                <EmptyLoader message="No results found" />


          }
        </div>

      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    addSkillToUser,
    filterSearchItem,
    notify,
    automationSearch,
    helperSearch,
    getDraftSkills
  })
)(SearchResults);
