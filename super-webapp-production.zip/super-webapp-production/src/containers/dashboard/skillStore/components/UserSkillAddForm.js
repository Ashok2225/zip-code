import React, { Component } from "react";
import { connect } from "react-redux";
import {
  disableUserPopup,
  getSkillsFromStore,
  getPrebuildSkills,
} from "../../../../redux/actions/skill";
import { notify } from "../../../../redux/actions/snack";
import axios from "axios";
import $, { type } from "jquery";
import { getKeycloackToken } from "../../../../redux/actions/auth";
import { isValidHttpUrl } from "../../../../utility";

export class UserSkillAddForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      status: "",
      metadata: {},
      isLoading: false,
    };
  }

  handleChange = (e) => {
    const metaData = this.props.skills?.current_skill?.metadata || {};
    this.setState({
      metadata: {
        ...metaData,
        ...this.state.metadata,
        [e.target.name]: e.target.value,
      },
    });
  };
  handleSubmit = async (e) => {
    this.setState({ isLoading: true });
    e.preventDefault();
    let can_forward = true;
    const { skill_fields } = this.props.skills;
    const { metadata } = this.state;
    for (let field = 0; field < skill_fields.length; field++) {
      const obj = skill_fields[field];
      const value = metadata[obj.field_name];
      if (obj?.validation === "weburl") {
        if (!isValidHttpUrl(value)) {
          this.props.notify("error", "Please enter valid url");
          this.setState({ isLoading: false });
          return false;
        }
      }
    }

    for (const [key, value] of Object.entries(this.state.metadata)) {
      if (value == "") {
        can_forward = false;
      } else {
        can_forward = true;
      }
    }
    if (
      this.props.skills.skill_fields.length !=
        Object.keys(this.state.metadata).length &&
      this.props.skills.current_skill.TYPE != "SkillHub"
    ) {
      can_forward = false;
    }
    if (can_forward) {
      try {
        const getOrgDetails = JSON.parse(
          window.localStorage.getItem("orgDetails")
        );
        const orgId = getOrgDetails ? parseInt(getOrgDetails.id) : null;
        let token = await getKeycloackToken();
        var config = {
          method: "post",
          url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/user/uploadSkill`,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          data: {
            skill_meta: this.state.metadata,
            skill_name:
              this.props.skills.current_skill.skill_name ||
              this.props.skills.current_skill.SKILL_NAME,
            skill_id: this.props.skills.current_skill.id,
            organization_id: orgId,
          },
        };
        const response = await axios(config);
        this.setState({
          status:
            "Skill uploaded successfully, please visit My Assistant SKills section",
          metadata: {},
        });
        this.props.getPrebuildSkills();
        this.props.getSkillsFromStore();
        if (this.props.skills.current_skill.updateSkills) {
          const { updateSkills, id, TYPE } = this.props.skills.current_skill;
          updateSkills(id, TYPE);
        }
        setTimeout(() => {
          this.setState({ status: "" });
          $(".close").click();
          $("input").val("");
          this.props.notify(
            "success",
            "Skill Added successfully, Please visit MySkills section"
          );
          this.setState({ isLoading: false });
        }, 2000);
      } catch (err) {
        console.log(err,"err")
        setTimeout(() => {
          $(".close").click();
          $("input").val("");
          this.props.notify("error", "Skill already added ");
        }, 2000);
        this.setState({ isLoading: false });
      }
    } else {
      this.props.notify("error", "Please fill all the mandatory fields");
      this.setState({ isLoading: false });
    }
  };
  render() {
    const itemUrl = this.props?.skills?.trainDraft?.RAW_DATA?.actions[0]?.value;
    const skillType = this.props?.skills?.current_skill?.TYPE;
    return (
      <div class="modal crt-skill fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-md">
          <div class="modal-content crt-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">
                &times;
              </button>
              <h4 class="modal-title"> Add a new skill</h4>
            </div>

            <div class="modal-body">
              <form action="#" class="form-contain">
                {this.props &&
                  this.props.skills.skill_fields.map((item) => (
                    <div class="frm-block">
                      <div className="ip-tl-label">
                        <span className="tl-label">
                          {itemUrl && skillType !== "automation" ? (
                            "Enter your application URL to add this skill to 'MySkills'"
                          ) : (
                            <>
                              {item.field_name.replace("_", " ").toUpperCase()}{" "}
                            </>
                          )}
                          <b style={{ color: "red" }}>*</b>
                        </span>
                        <input
                          type={item.field_type}
                          name={item.field_name}
                          onChange={(e) => this.handleChange(e)}
                          placeholder="Enter"
                        />
                      </div>

                      {itemUrl && skillType !== "automation" ? (
                        <h5 style={{ wordBreak: "break-all" }}>
                          For Example: {itemUrl}
                        </h5>
                      ) : null}
                    </div>
                  ))}
                <div class="frm-btns">
                  <button class="btn-outline" data-dismiss="modal">
                    Cancel
                  </button>
                  <button
                    class="primary-btn"
                    onClick={(e) => this.handleSubmit(e)}
                  >
                    {" "}
                    {this.state.isLoading
                      ? "Adding.. Please wait"
                      : "Add Skill"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  item: state.userReducers,
});

export default connect(mapStateToProps, {
  disableUserPopup,
  getPrebuildSkills,
  notify,
  getSkillsFromStore,
})(UserSkillAddForm);
