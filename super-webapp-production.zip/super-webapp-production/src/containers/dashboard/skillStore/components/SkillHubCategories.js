import React, { Component } from "react";
import OwlCarousel from "react-owl-carousel";
import { withRouter } from "react-router";
import { compose } from "redux";
import Loader from "../../../../components/loader";
import {
  getSkillsFromStore,
  getDraftSkills,
  getDraftSkillCount,
} from "../../../../redux/actions/skill";
import EmptyLoader from "../../../../components/emptyLoader";
import SkillItem from "./SkillItem";
import { connect } from "react-redux";
export class SkillHubCategories extends Component {
  constructor() {
    super();
    this.state = {
      skills: [],
      isLoading: true,
      currentCategory: "",
      allSkills: [],
      options: {
        // loop: true,
        margin: 30,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 3,
            },
            1000: {
                items: 4,
            },
        },
    },
    };
  }

  componentDidMount() {
    this.getCategorySkills();
  }

  getFullCategory = (id) => {
    switch (id) {
      case "fu":
        return "For You";
      case "finance":
        return "Finance";
      case "sales":
        return "Sales";
      case "marketing":
        return "Marketing";
      case "cs":
        return "Customer Service";
      case "it":
        return "IT";
      case "hr":
        return "HR";
      case "procurement":
        return "Procurement";
      case "sc":
        return "Supply Chain";
      case "all":
        return "all";
    }
  };

  getCategorySkills = async () => {
    let category = "all";
    let page = -1;
    let type = "SkillHub";
    let data = { type, page, category };
    let dfSkills = await this.props.getDraftSkills(data);
    let id = this.props.match.params.id;
    // let categoryFull = this.getFullCategory(id);
    if (id == "all") {
      let allCats = [];
      const cats = await this.props.getDraftSkillCount();
      cats.map((cat, i) => {
        if (cat.CATEGORY == "" || cat.CATEGORY == null) {
        } else {
          let individualCat = {};
          individualCat["category"] = cat.CATEGORY;
          individualCat["skills"] = dfSkills.results.filter((item) =>
            item.CATEGORY ? item.CATEGORY.includes(cat.CATEGORY) : false
          );
          allCats.push(individualCat);
        }
      });
      //   let financeSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Finance"
      //   );
      //   let salesSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Automation"
      //   );
      //   let marketingSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Technology"
      //   );
      //   let csSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Customer Service"
      //   );
      //   let itSkills = dfSkills.results.filter((item) => item.CATEGORY === "IT");
      //   let hrSkills = dfSkills.results.filter((item) => item.CATEGORY === "HR");
      //   let procurementSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Procurement"
      //   );
      //   let scSkills = dfSkills.results.filter(
      //     (item) => item.CATEGORY === "Supply Chain"
      //   );

      this.setState({
        isLoading: false,
        skills: [],
        currentCategory: "all",
        allSkills: allCats,
      });
    } else {
      let skills = dfSkills.results.filter((item) => item.CATEGORY === id);
      this.setState({
        isLoading: false,
        skills: skills,
      });
    }
  };
  render() {
    return (
      <div>
        {this.state.isLoading ? (
          <div class="empty-view">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : this.state.currentCategory === "all" ? (
          <React.Fragment>
            {this.state.allSkills.map((cat, i) => (
              <div key={i} className="sk-slide-section">
                <h4 className="tp-title">{cat.category}</h4>
                {cat.skills.length ? (
                  <OwlCarousel
                    className="owl-theme sk-boxes"
                    id="sk-boxes1"
                    {...this.state.options}
                  >
                    {cat.skills.map((skill, index) => (
                      <SkillItem item={skill} key={index} />
                    ))}
                  </OwlCarousel>
                ) : (
                  <EmptyLoader message="No results found" />
                )}
              </div>
            ))}
          </React.Fragment>
        ) : this.state.skills.length ? (
          <div className="sk-slide-section">
            <h4 className="tp-title">{this.props.match.params.id} Skills</h4>
            <OwlCarousel
              className="owl-theme sk-boxes"
              id="sk-boxes1"
              {...this.state.options}
            >
              {this.state.skills.map((skill, index) => (
                <SkillItem item={skill} key={index} />
              ))}
            </OwlCarousel>
          </div>
        ) : (
          <EmptyLoader message="No results found" />
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkills,
    getDraftSkillCount,
  })
)(SkillHubCategories);
