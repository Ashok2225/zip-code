import React, { Component } from "react";
import {
  getPrebuildSkills,
  filterSearchItem,
  getSkillsFromStore,
  getDraftSkillCount,
  changeActiveCategory,
} from "../../../../redux/actions/skill";
import { connect } from "react-redux";

import menu_toggle from "../../../../images/menu-side.png";
import helperIcon from "../../../../images/helper-Icon.png";
import AutomationIcon from "../../../../images/automationIcon.png";
import tlDropIcon from "../../../../images/drop-arrow.png";

import { compose } from "redux";
import { withRouter } from "react-router";
import getColors from "../../../../components/colors";
import ReactTooltip from "react-tooltip";

class SideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchItem: null,
      minMode: false,
      activeMenu: "",
      helperProperty: null,
    };
  }

  shrinkSidebar = () => {
    this.setState({
      minMode: !this.state.minMode,
    });
  };

  async componentDidMount() {
    const res = await this.props.getDraftSkillCount();
    if (res) {
      this.setState({
        helperProperty: res,
      });
    }
    var path = window.location.href;

    if (path.match("/dashboard/skill-store/helper-skills")) {
      this.setState({
        activeMenu: "Helper Skills",
      });
    }
    if (path.match("/dashboard/skill-store/automation-skills")) {
      this.setState({
        activeMenu: "Automation Skills",
      });
    }
  }

  render() {
    const currentActiveGroup = this.props.location.pathname.split("/")[4];
    const item = this.props.skills;
    let allHelperSkill = 0;
    this.state.helperProperty &&
      this.state.helperProperty.map((count) => {
        allHelperSkill = allHelperSkill + parseInt(count.count);
      });
    const email =
      this.props && this.props.userReducer.user !== null
        ? this.props.userReducer.user.email
        : "";

    return (
      <div className={this.state.minMode ? "task-list minibar" : "task-list"}>
        <div className="flex-title">
          <h3 className="title">Super Store</h3>

          <div className="icon-list">
            <div className="collapse-menu" onClick={() => this.shrinkSidebar()}>
              <img src={menu_toggle} alt="" />
            </div>
          </div>
        </div>
        <div className="task-block">
          <div className="tl-list">
            {/* <p className="small-title">Grouped by process</p> */}
            <div className="scrollable skill-list-scroll">
              {/* Accordion */}
              <div className="panel-group" id="accordion">
                <div className="panel panel-default">
                  <div className="panel-heading">
                    <h4 className="panel-title">
                      <a
                        data-toggle="collapse"
                        data-parent="#accordion"
                        href="#collapse1"
                      >
                        <div
                          className={`tl-block ${
                            this.state.activeMenu === "Automation Skills"
                              ? "active"
                              : ""
                          }`}
                          onClick={() =>
                            this.props.history.push({
                              pathname:
                                "/dashboard/skill-store/automation-skills",
                            })
                          }
                        >
                          <div className="tl-icon">
                            <div
                              className="tl-text"
                              style={{ backgroundColor: "#ff7007" }}
                            >
                              <img src={AutomationIcon} />
                            </div>
                          </div>
                          <div className="tl-cont">
                            <p>Automation Skills</p>
                            <span>{item.pageInfoSkill.total} skills</span>
                          </div>
                          <div className="tl-drop">
                            <img src={tlDropIcon} />
                          </div>
                        </div>
                      </a>
                    </h4>
                  </div>
                </div>
                <div className="panel panel-default">
                  <div className="panel-heading">
                    <h4 className="panel-title">
                      <a
                        data-toggle="collapse"
                        data-parent="#accordion"
                        href="#collapse2"
                      >
                        <div
                          className={`tl-block ${
                            this.state.activeMenu === "Helper Skills"
                              ? "active"
                              : ""
                          }`}
                          onClick={() =>
                            this.props.history.push({
                              pathname:
                                "/dashboard/skill-store/helper-skills/all",
                            })
                          }
                        >
                          <div className="tl-icon">
                            <div
                              className="tl-text"
                              style={{ backgroundColor: "#078dff" }}
                            >
                              <img src={helperIcon} />
                            </div>
                          </div>
                          <div className="tl-cont">
                            <p>Helper Skills</p>
                            <span>{allHelperSkill} skills</span>
                          </div>
                          <div className="tl-drop">
                            <img src={tlDropIcon} />
                          </div>
                        </div>
                      </a>
                    </h4>
                  </div>

                  <div
                    id="collapse2"
                    className={`panel-collapse collapse ${
                      this.state.activeMenu === "Helper Skills" ? "in" : ""
                    }`}
                  >
                    {this.state.helperProperty !== null &&
                      this.state.helperProperty.map((category, i) => {
                        if (
                          category.CATEGORY !== null &&
                          category.CATEGORY !== ""
                        ) {
                          return (
                            <div
                              key={i}
                              className={`tl-block ${
                                currentActiveGroup === category.CATEGORY
                                  ? "active"
                                  : ""
                              }`}
                              onClick={() =>
                                this.props.history.push({
                                  pathname: `/dashboard/skill-store/helper-skills/${category.CATEGORY}`,
                                })
                              }
                            >
                              <div className="tl-icon">
                                <div
                                  className="cts-avatar"
                                  style={{
                                    backgroundColor: getColors(
                                      `${category.CATEGORY}`
                                    ),
                                  }}
                                >
                                  <span>
                                    {category.CATEGORY === null &&
                                    category.CATEGORY === ""
                                      ? "U"
                                      : category.CATEGORY.charAt(0)}
                                  </span>
                                </div>
                              </div>
                              <div
                                className="tl-cont"
                                data-tip
                                data-for={category.CATEGORY}
                              >
                                <p>
                                  {category.CATEGORY.length > 20 ? (
                                    <React.Fragment>
                                      {category.CATEGORY.substring(0, 19)}...
                                      <ReactTooltip
                                        id={category.CATEGORY}
                                        type="error"
                                        backgroundColor="white"
                                      >
                                        <span>{category.CATEGORY}</span>
                                      </ReactTooltip>
                                    </React.Fragment>
                                  ) : (
                                    <React.Fragment>
                                      {category.CATEGORY}
                                    </React.Fragment>
                                  )}
                                </p>
                              </div>
                            </div>
                          );
                        }
                      })}
                  </div>
                </div>
              </div>

              {/* end of accordion */}

              <div className="all-task"></div>
            </div>

            {(email && email === process.env.REACT_APP_ADMIN1) ||
            email === process.env.REACT_APP_ADMIN2 ||
            email === process.env.REACT_APP_ADMIN3 ? (
              <button
                className={
                  this.state.minMode
                    ? "outline-new filled-btn btn-addSkill"
                    : "outline-new filled-btn "
                }
                data-toggle="modal"
                data-target="#myModalnew"
              >
                {this.state.minMode ? "+" : "+ Upload Skill"}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  prebuild: state.prebuildSkillsReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    getPrebuildSkills,
    filterSearchItem,
    getDraftSkillCount,
    changeActiveCategory,
  })
)(SideBar);
