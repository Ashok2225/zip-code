import React, { Component } from "react";

import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import { withRouter } from "react-router";

import SkillsHubSearch from "./SkillsHubSearch";
import { Route, Switch } from "react-router";
import SkillsHubHome from "./SkillsHubHome";
import { connect } from "react-redux";
import { compose } from "redux";
import SkillHubCategories from "./SkillHubCategories";
import SearchResults from "./SearchResults";


class SkillsHub extends Component {
  render() {
    return (
      <div className="skill-home scrollable">
        <SkillsHubSearch />
        <Switch>

          <Route path="/dashboard/skill-store/home" render={() => <SkillsHubHome />} />
          <Route path="/dashboard/skill-store/category/:id" render={() => <SkillHubCategories />} />
          <Route path="/dashboard/skill-store/search/:id" render={() => <SearchResults />} />


        </Switch >


      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  // skills: state.skillReducer,
  // userReducer: state.userReducer,
  // searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {

  })
)(SkillsHub)
