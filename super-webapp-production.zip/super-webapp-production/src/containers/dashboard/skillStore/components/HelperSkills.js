import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getDraftSkills,
  addSkillToUser,
  filterSearchItem,
  executeFlow,
  getSession,
} from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import EmptyLoader from "../../../../components/emptyLoader";
import Loader from "../../../../components/loader";
import HelperItem from "./HelperItem";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../redux/actions/snack";
import HelperEdit from "./HelperEdit";
class HelperSkills extends Component {
  constructor() {
    super();
    this.state = {
      helper_skills: [],
      page: 1,
      helperPageInfo: [],
      pageSize: 10,
      hasMore: true,
      searchItem: null,
      isLoading: true,
      isScrolling: false,
      category: "all",
    };
  }

  componentDidMount() {
    this.getHelperSkill();
    this.props.getSession();
  }
  componentDidUpdate(nextProps, prevState) {
    if (prevState.page !== this.state.page) {
      this.getHelperSkill();
    }
  }

  getHelperSkill = async () => {
    let category = this.props.match.params.id;
    let page = this.state.page;
    let type = "helper";
    let data = { type, page, category };
    let skillFromeStore = await this.props.getDraftSkills(data);
    if (skillFromeStore) {
      if (skillFromeStore.results && skillFromeStore.results.length) {
        this.setState({
          helper_skills: this.state.helper_skills.concat(
            skillFromeStore.results
          ),
          // helperPageInfo: skillFromeStore.pagination,
          helperPageInfo: skillFromeStore,

          isLoading: false,
        });
      } else {
        this.setState({
          isLoading: false,
          hasMore: false,
        });
      }
    } else {
      this.setState({
        isLoading: false,
        hasMore: false,
      });
    }
  };

  fetchData() {
    this.setState({ isScrolling: true });
    try {
      if (this.state.helperPageInfo.results.length < 10) {
        this.setState({
          hasMore: false,
        });
      } else {
        this.setState({
          page: this.state.page + 1,
        });
      }
    } catch (err) {
      this.setState({
        hasMore: false,
      });
      this.props.notify("error", "Failed to refresh");
    }
  }

  searchSkillStore = (e) => {
    this.setState({
      searchItem: e.target.value,
    });
  };
  onKeyPress = (e) => {
    if (e.key === "Enter") {
      this.setState({
        isSearching: true,
      });
      this.props.history.push({
        pathname: `/dashboard/skill-store/search/helper-skill?query=${this.state.searchItem}`,
      });
    }
  };

  render() {
    return (
      <React.Fragment>
        <div className="task-col-search">
          <div className="row mx-0 setting-search bg-white py-3 border-left">
            <div className="col-md-8">
              <div className="position-relative search">
                <input
                  id="searchField"
                  type="search"
                  placeholder="Search"
                  className="form-control border-0"
                  value={this.state.searchItem ? this.state.searchItem : ""}
                  onChange={(e) => this.searchSkillStore(e)}
                  onKeyDown={(e) => this.onKeyPress(e)}
                />
                {/* <img src={SearchIcon} alt="Search" /> */}
              </div>
            </div>
          </div>

          <div className="task-col">
            <div className="title-btn">
              <h1 className="title">In-App Walkthroughs</h1>
            </div>

            <div id="scrollableDiv" className="scrollable tl-scroll">
              {this.state.isLoading ? (
                <div class="empty-view">
                  <Loader
                    styles={{ width: "80px", margin: "auto" }}
                    root={{ display: "flex" }}
                  />
                </div>
              ) : (
                <div>
                  {this.state.isLoading === false &&
                  !this.state.helper_skills.length ? (
                    <div>
                      <EmptyLoader
                        style={{ width: "30%" }}
                        message="No Skills found"
                      />
                    </div>
                  ) : (
                    <div>
                      <InfiniteScroll
                        dataLength={this.state.helper_skills.length}
                        next={this.fetchData.bind(this)}
                        hasMore={this.state.hasMore}
                        loader={
                          this.state.isScrolling ? (
                            <Loader
                              styles={{ width: "80px", margin: "auto" }}
                              root={{ display: "flex" }}
                            />
                          ) : (
                            ""
                          )
                        }
                        scrollableTarget="scrollableDiv"
                        endMessage={
                          this.state.helper_skills.length == 0 ? (
                            <p
                              className="loading-end"
                              style={{ textAlign: "center" }}
                            >
                              <b>No In-App Walkthrough Skills Found</b>
                            </p>
                          ) : (
                            <p className="loading-end">
                              <b>Yay! You have seen it all</b>
                            </p>
                          )
                        }
                      >
                        {this.state.helper_skills.map((item, index) => (
                          <HelperItem index={index} key={item.id} item={item} />
                        ))}
                      </InfiniteScroll>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkills,
    addSkillToUser,
    filterSearchItem,
    notify,
    getSession,
    executeFlow,
  })
)(HelperSkills);
