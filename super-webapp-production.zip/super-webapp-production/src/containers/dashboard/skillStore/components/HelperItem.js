/*global chrome*/
import React, { Component } from "react";
import Helper from "../../../../images/Helper.png";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import poygonplay from "../../../../images/Polygon 1@2x.png";
import info from "../../../../images/info.png";

import {
  viewHelperSkill,
  updateDraftSkill,
  executeFlow,
  getDraftSkillsById,
} from "../../../../redux/actions/skill";
import HelperEdit from "./HelperEdit";
import helperIcon from "../../../../images/helper-Icon.png";
import getColors from "../../../../components/colors";

const TEMPLATE_WITH_LOOP_RESTRICTION = [
  "User Documentation",
  "Web Automation",
  "In-App Walkthrough",
  "User Onboarding",
];
class HelperItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOnboarded: false,
      colors: [
        "#0250ce",
        "#f54747",
        "#33d0b7",
        "#ffa933",
        "#21b8dd",
        "#8a5fff",
      ],
      isViewing: false,
      currentViewItem: "",
      canEdit: false,
      canDelete: false,
      answers: "",
      isLoading: true,
      question: "",
      showModal: false,
    };
  }
  componentDidMount() {}
  viewItem = (viewItem) => {
    this.props.viewHelperSkill(viewItem);
    this.props.history.push(`/dashboard/skill-store/view/${viewItem.id}`);
  };

  play = async (data) => {
    if (data.deviceId === undefined || !data.skillId) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
      return;
    } else {
      const playSkill = await this.props.executeFlow(data);
      if (playSkill.data.status === false) {
        chrome.runtime.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          { type: "openLogin" },
          (response) => {
            if (response) {
              // console.log("Extension Response", response);
            }
          }
        );
      }
    }
  };

  componentDidMount() {
    window.$('[data-toggle="popover"]').popover({
      container: "body",
    });
  }

  render() {
    var item = this.props.item;
    var data = {
      deviceId: this.props.skills.draftSession,
      skillId: item.id,
      bulk: !TEMPLATE_WITH_LOOP_RESTRICTION.includes(
        item?.TEMPLATE
      ),
    };
    return (
      <React.Fragment>
        {/* <HelperEdit  /> */}

        <div className="col-md-4 ss-block pdl-0 hlp-box">
          <div className="ss-box">
            <div onClick={() => this.viewItem(item)} className="ss-title-cont">
              <span className="hlp-email">
                {item.updated_at.substring(0, 10)}
              </span>
              <div
                className="ss-ico ssh-ico ss-text"
                style={{
                  backgroundColor:
                    // this.state.colors[parseInt(Math.random() * 6)],
                    getColors(item.SKILL_NAME),
                }}
              >
                {/* <img src={helperIcon} alt="" /> */}
                <p>{item.SKILL_NAME.substring(0, 2)}</p>
              </div>

              <div className="hp-content">
                <h5>{item.SKILL_NAME}</h5>

                <div className="overflow-text">
                  <p>{item.SKILL_DESCRIPTION}</p>
                  {item.SKILL_DESCRIPTION &&
                  item.SKILL_DESCRIPTION.length > 100 ? (
                    <>
                      <a
                        class="tlt-icon tl-tooltip"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        // data-placement={
                        //   (this.props.index + 1) % 3 === 0 ? "left" : "right"
                        // }
                        data-placement="auto right"
                        data-content={item.SKILL_DESCRIPTION}
                        title="Description"
                      >
                        <img src={info} alt="" />
                      </a>
                    </>
                  ) : null}
                </div>

                {/* <p>
                  {item.SKILL_DESCRIPTION &&
                    item.SKILL_DESCRIPTION.substring(0, 90)}
                  {item.SKILL_DESCRIPTION &&
                  item.SKILL_DESCRIPTION.length > 90 ? (
                    <>
                      <span>
                        <strong>...</strong>
                      </span>
                      <a
                        class="tlt-icon tl-tooltip"
                        href="javascript:void(0)"
                        data-toggle="popover"
                        data-html="true"
                        data-trigger="hover"
                        data-placement={
                          (this.props.index + 1) % 3 === 0 ? "left" : "right"
                        }
                        data-content={item.SKILL_DESCRIPTION}
                        title="Description"
                      >
                        <img src={info} alt="" />
                      </a>
                    </>
                  ) : null}
                </p> */}
              </div>
            </div>
            <div className="ss-footer">
              <div
                className="use-now"
                onClick={() => {
                  this.play(data);
                }}
              >
                <div className="use-ico">
                  <img src={poygonplay} alt="" />
                </div>

                {/* <p>Use now</p> */}
              </div>

              <div className="brand-list">
                <span> {item.USER_EMAIL}</span>
                <br />
                {/* <button onClick={() => this.increaseVote(item)}>
                    Upvote
                  </button> */}

                {/* {item.UP_VOTES && item.UP_VOTES.length} */}
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    viewHelperSkill,
    updateDraftSkill,
    executeFlow,
    getDraftSkillsById,
  })
)(HelperItem);
