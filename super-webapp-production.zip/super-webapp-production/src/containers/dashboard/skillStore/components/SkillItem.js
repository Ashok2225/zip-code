import React, { Component } from "react";
import poygonplay from "../../../../images/Polygon 1@2x.png";
import info from "../../../../images/info.png";
import installed from "../../../../images/notif-tones/MicrosoftTeams-image (3).png";
import getColors from "../../../../components/colors";
import dataLoadingIcon from "../../../../images/template-img/data-loading.png";
import walkthroughIcon from "../../../../images/template-img/walkthrough-icon.png";
import img1 from "../../../../images/skill-store/templates/1.png";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import { notify } from "../../../../redux/actions/snack";
import {
  getSkillsFromStore,
  addSkillToUser,
  filterSearchItem,
  viewHelperSkill,
  executeFlow,
  getSession,
  getPrebuildSkills,
  changeSkillAreaView,
  getDraftSkillsById,
  addSkillFromStore,
} from "../../../../redux/actions/skill";
import automation1 from "../../../../images/skill-store/templates/automation1.png";
import automation2 from "../../../../images/skill-store/templates/automation2.png";
import automation3 from "../../../../images/skill-store/templates/automation3.png";
import automation4 from "../../../../images/skill-store/templates/automation4.png";
import helper1 from "../../../../images/skill-store/templates/helper1.png";
import helper2 from "../../../../images/skill-store/templates/helper2.png";
import helper3 from "../../../../images/skill-store/templates/helper3.png";
import helper4 from "../../../../images/skill-store/templates/helper4.png";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import $ from "jquery";
import axios from "axios";
import { getKeycloackToken } from "../../../../redux/actions/auth";
const imageAutomation = [automation1, automation2, automation3, automation4];

const imageHelper = [helper1, helper2, helper3, helper4];
class SkillItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOnboarded: false,
      colors: [
        "#ff6060",
        "#8a5fff",
        "#47a5f5",
        "#02ce9d",
        "#f547f5",
        "#f58f2a",
      ],
      modalOpen: false,
      isLoading: false,
      metadata: {
        Type: "draft_skill",
      },
      item: this.props.item,
      isAdding: false,
    };
  }

  componentDidMount() {
    window.$('[data-toggle="popover"]').popover({
      container: "body",
    });
  }

  updateItemStatus = (id, type) => {
    const { item } = this.state;
    if (type === "automation") {
      item.isAvailable = true;
    } else {
      item.isavailable = 1;
    }
    this.setState({ item });
  };

  play = async (data) => {
    this.setState({
      isPlaying: true,
    });
    if (
      data.deviceId === undefined ||
      !data.skillId ||
      data.deviceId === null
    ) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
      this.setState({
        isPlaying: false,
      });
      return;
    } else {
      const playSkill = await this.props.executeFlow(data);
      this.setState({
        isPlaying: false,
      });
      if (playSkill.data.status === false) {
      }
    }
  };

  useNow = async (skill) => {
    if (skill.TYPE === "automation") {
      skill.updateSkills = this.updateItemStatus;
      this.props.addSkillToUser(skill);
      $("#flag").click();
    } else if (skill.TYPE === "SkillHub") {
      let skillDetail = await this.props.getDraftSkillsById(skill.id);
      if (skillDetail?.data?.data?.onboarding_url == false) {
        this.setState({ isAdding: true });
        let url;
        skillDetail?.data?.data?.RAW_DATA?.actions.map((item) => {
          if (item?.actionType?.toLowerCase() === "open") {
            url = item.value;
          }
        });
        let onboardSkillInfo = {
          skillId: skill.id,
          skillMeta: {
            Type: "draft_skill",
            Template: skillDetail?.data?.data?.TEMPLATE,
            URL: url,
          },
          skillName: skillDetail?.data?.data?.SKILL_NAME,
        };
        await this.props.addSkillFromStore(onboardSkillInfo);
        let data = { skillId: skill.id, type: "SkillHub" };
        this.updateItemStatus(data);
        this.props.notify(
          "success",
          "Skill Added successfully, Please visit MySkills section"
        );
        this.setState({ isAdding: false });
      } else {
        const skillTemp = { ...skill };
        skillTemp.metadata = {
          Type: "draft_skill",
          Template: skill["TEMPLATE"],
        };
        skillTemp.updateSkills = this.updateItemStatus;
        skillTemp.tags = [
          {
            skill_fields: [
              {
                field_name: "URL",
                field_type: "text",
                validation: "weburl",
              },
            ],
          },
        ];
        this.props.addSkillToUser(skillTemp);
        $("#flag").click();
      }
    }
  };

  viewItem = async (viewItem) => {
    if (!(viewItem.TYPE === "automation")) {
    } else {
      if (!viewItem.isAvailable) {
        this.props.addSkillToUser(viewItem);
        $("#flag").click();
      }
    }
  };

  render() {
    var item = this.state.item;
    var opt = this.props?.opt;
    return (
      <>
        <div class="item" onClick={() => this.viewItem(item)}>
          <div className="tpb-outer">
            <div className="tlp-icon" style={{ padding: "0px" }}>
              <img
                src={
                  item.TYPE === "automation"
                    ? imageAutomation[
                        parseInt(Math.random() * imageAutomation.length)
                      ]
                    : imageHelper[parseInt(Math.random() * imageHelper.length)]
                }
                alt=""
              />
            </div>
            <div className="tp-content">
              <p className="tlp-text">
                {item.skill_name ? item.skill_name : item.SKILL_NAME}
              </p>

              {item.isAvailable || parseInt(item.isavailable) ? (
                <div className="use-now">
                  <div className="install-ico">
                    <img style={{ width: "20px" }} src={installed} alt="" />
                  </div>
                  <p style={{ fontStyle: "italic" }}> Added To MySkills</p>
                </div>
              ) : (
                <>
                  {this.state.isPlaying ? (
                    <button className="btn btn-default">
                      <div class="sp sp-circle text-light"></div>
                    </button>
                  ) : opt && item.TYPE === "SkillHub" ? (
                    <div className="use-now">
                      <button
                        className="btn btn-default use-button"
                        onClick={(e) => {
                          console.log("first", item);
                          e.stopPropagation();
                          this.useNow(item);
                        }}
                      >
                        {this.state.isAdding ? (
                          <div class="sp sp-circle text-light"></div>
                        ) : (
                          "Add To MySkills"
                        )}
                      </button>
                    </div>
                  ) : (
                    <div className="use-now">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          this.useNow(item);
                        }}
                        className="btn btn-default use-button"
                      >
                        Add To MySkills
                      </button>
                    </div>
                  )}
                </>
              )}

              <button
                id="flag"
                data-toggle="modal"
                data-target="#myModal"
                style={{ display: "none" }}
              ></button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    addSkillToUser,
    viewHelperSkill,
    executeFlow,
    notify,
    getSession,
    getSkillsFromStore,
    getPrebuildSkills,
    changeSkillAreaView,
    getDraftSkillsById,
    addSkillFromStore,
  })
)(SkillItem);
