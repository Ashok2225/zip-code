/*global chrome*/
import React, { Component } from "react";
import TextareaAutosize from "react-textarea-autosize";
import { connect } from "react-redux";
import {
  deleteDraftSkill,
  updateDraftSkill,
  getDraftSkills,
  publishHelperSkill,
  viewHelperSkill,
  updateFormatedData,
  executeFlow,
  getSession,
  getDraftSkillsById,
  getUserHelperSkills,
} from "../../../../redux/actions/skill";
import { notify } from "../../../../redux/actions/snack";
import { compose } from "redux";
import { withRouter } from "react-router";
import Loader from "../../../../components/loader";
import poygonplay from "../../../../images/Polygon 1@2x.png";

import refresh from "../../../../images/training/refresh.png";
import sendwhite from "../../../../images/training/send-white.png";
import play from "../../../../images/training/play.png";
import runningIcon from "../../../../images/brands/Progress.gif";
import deleteRed from "../../../../images/training/delete-red.png";
import { getFileUrl } from "../../../../redux/actions/fileUpload";

import {
  Document,
  Page,
  Text,
  StyleSheet,
  PDFDownloadLink,
  Image,
  View,
} from "@react-pdf/renderer";
// Create styles

class HelperEdit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isViewing: false,
      currentViewItem: "",
      canEdit: false,
      canDelete: false,
      answers: [],
      isLoading: true,
      question: "",
      itemData: [],
      editedAnswers: [],
      page: 1,
      showOption: false,
      itemId: null,
      isLoadingAnswers: true,
    };
  }

  componentDidMount = () => {
    if (this.props.location.pathname === "/dashboard/skills") {
      this.setState({
        showOption: true,
      });
    }

    this.props.getSession();
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.skills && nextProps.skills.helper) {
      this.setState({
        itemId: nextProps.skills.helper.id,
        itemData: nextProps.skills.helper,
        question: nextProps.skills.helper.SKILL_NAME,
      });
    }
  }

  async componentDidUpdate(nextProps, nextState) {
    if (nextState.itemId !== this.state.itemId) {
      this.setState({
        isLoadingAnswers: true,
      });
      const getHelperData = await this.props.getDraftSkillsById(
        this.state.itemId
      );
      if (getHelperData) {
        let helperData = Object.keys(getHelperData.data);
        if (helperData.length > 0) {
          this.setState({
            answers: getHelperData.data.data.RAW_DATA,
            isLoadingAnswers: false,
            itemData: getHelperData.data.data,
          });
        }
      }
    }
  }

  handleChangeAns = (e, index) => {
    let editedAnswers = [...this.state.answers.actions];
    editedAnswers[index].description = e.target.value;
    this.setState((prevState) => ({
      editedAnswers,
    }));
  };

  uploadFile = async (i, file) => {
    let url = await this.props.getFileUrl(file);
    if (url) {
      let editedAnswers = [...this.state.answers.actions];
      editedAnswers[i].pageScreenshot = url;
      this.setState((prevState) => ({
        editedAnswers,
      }));
    }
  };

  handleChangeQue = (e) => {
    this.setState({
      question: e.target.value,
    });
  };

  deleteDraft = async (data) => {
    var datain = await this.props.deleteDraftSkill(data);
    if (datain) {
      this.props.notify("success", "Deleted Successfully");
      this.props.getUserHelperSkills();

      // let page = this.state.page;
      // let type = "helper";
      // let data = { page, type };
      // this.props.getDraftSkills(data);
      // this.props.history.push(window.location.pathname);
    }
  };
  publishSkill = async (data) => {
    if (data.status == "self") {
      let payloadData = {
        status: "pending",
      };
      const publishHelper = await this.props.publishHelperSkill(
        this.state.itemId,
        { payload: payloadData }
      );
      this.props.viewHelperSkill(publishHelper.data.data);

      this.props.notify("success", "Success!");
      // this.props.history.push(window.location.pathname);
      this.props.getUserHelperSkills();
    } else {
      this.props.notify("error", "Already Published!");
    }
  };

  updateStatus = async (data) => {
    var rawData;
    if (this.state.question.trim().length === 0) {
      this.props.notify("error", "Please enter skill name");
      return;
    }
    if (this.state.editedAnswers.length > 0) {
      rawData = {
        actions: this.state.editedAnswers,
        type: "record",
        description: this.state.question,
        label: this.state.question,
      };
    } else {
      rawData = {
        actions: this.state.answers.actions,
        type: "record",
        description: this.state.question,
        label: this.state.question,
      };
    }

    let skillName = this.state.question;
    let status =
      this.state.itemData.status === "approved" ||
      this.state.itemData.status === "declined"
        ? "pending"
        : this.state.itemData.status;
    let itemId = this.state.itemId;
    let updatedData = { status, rawData, skillName, itemId };
    const updateHelper = await this.props.updateFormatedData(updatedData);

    if (updateHelper) {
      this.props.viewHelperSkill(updateHelper.data);
      this.props.history.push(window.location.pathname);

      this.props.notify("success", "Updated Successfully!");
    } else {
      this.props.notify("error", " Something went wrong.Failed to update!");
    }
  };

  play = async () => {
    var data = {
      deviceId: this.props.skills.draftSession,
      skillId: this.state.itemId,
      
    };
    if (data.deviceId === undefined) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
    } else {
      const playSkill = await this.props.executeFlow(data);
      if (playSkill.data.status == false) {
        chrome.runtime.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          { type: "openLogin" },
          (response) => {
            if (response) {
              // console.log("Extension Response", response);
            }
          }
        );
      }
    }
  };

  render() {
    return (
      <React.Fragment>
        <div
          key={this.state.itemId}
          className="modal fade qa-modal"
          id="myModalHelperEdit"
          role="dialog"
        >
          <div className="modal-dialog modal-lg">
            <div className="modal-content" id={this.state.itemId}>
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>

              <div className="modal-body md-edit">
                <div className="">
                  <div>
                    <div className="title-btn right-flex">
                      <div class="rt-btns">
                        {this.state.showOption ? (
                          <button class="sm-btn" onClick={(e) => this.play()}>
                            <img src={play} alt="" />
                            <span>Play</span>
                          </button>
                        ) : (
                          ""
                        )}
                        {this.state.showOption ? (
                          <React.Fragment>
                            {/* {this.props.userReducer.user !== null &&
                            this.props.userReducer.user.email ===
                              this.state.itemData.USER_EMAIL ? (
                              <>
                                <button
                                  class="sm-btn"
                                  data-dismiss="modal"
                                  onClick={() => {
                                    this.deleteDraft(this.state.itemId);
                                  }}
                                >
                                  <img src={deleteRed} alt="" />

                                  <span>Delete</span>
                                </button>
                              </>
                            ) : (
                              <> </>
                            )} */}

                            {this.props.userReducer.user !== null &&
                            this.props.userReducer.user.email ===
                              this.state.itemData.USER_EMAIL ? (
                              <button
                                class="sm-btn"
                                data-dismiss="modal"
                                onClick={() => {
                                  this.updateStatus(this.state.itemData);
                                }}
                              >
                                <img src={refresh} alt="" />

                                <span>Update</span>
                              </button>
                            ) : (
                              ""
                            )}
                          </React.Fragment>
                        ) : (
                          <React.Fragment></React.Fragment>
                        )}
                        <PDFDownloadLink
                          document={
                            <MyDocument
                              key={this.state.itemId}
                              props={this.state.itemData}
                            />
                          }
                          fileName={this.state.itemData.SKILL_NAME}
                        >
                          {({ blob, url, loading, error }) =>
                            error ? (
                              <button class="sm-btn" disabled>
                                <img src={refresh} alt="" />

                                <span>Export To Pdf</span>
                              </button>
                            ) : (
                              <button class="sm-btn">
                                <img src={refresh} alt="" />

                                <span>Export To Pdf</span>
                              </button>
                            )
                          }
                        </PDFDownloadLink>{" "}
                        {this.props.userReducer.user !== null &&
                        this.props.userReducer.user.email ===
                          this.state.itemData.USER_EMAIL ? (
                          this.state.itemData.status === "self" ? (
                            <React.Fragment>
                              <button
                                className="btn btn-approve"
                                onClick={() => {
                                  this.publishSkill(this.state.itemData);
                                }}
                              >
                                {" "}
                                <span>Publish</span>
                              </button>
                            </React.Fragment>
                          ) : (
                            <React.Fragment>
                              {this.state.itemData.status === "pending" ? (
                                <React.Fragment>
                                  <button className="btn btn-approve" disabled>
                                    <span>Waiting for approval</span>
                                  </button>
                                </React.Fragment>
                              ) : (
                                <React.Fragment>
                                  {this.state.itemData.status === "declined" ? (
                                    <React.Fragment>
                                      <button
                                        className="btn btn-danger"
                                        disabled
                                      >
                                        <span>Declined</span>
                                      </button>
                                    </React.Fragment>
                                  ) : (
                                    <React.Fragment>
                                      <button
                                        className="btn btn-approve"
                                        disabled
                                      >
                                        <span>Published</span>
                                      </button>
                                    </React.Fragment>
                                  )}
                                </React.Fragment>
                              )}
                            </React.Fragment>
                          )
                        ) : (
                          ""
                        )}
                      </div>
                    </div>

                    {/* <h3 className="qa-modal-title">View</h3> */}
                  </div>

                  <div className="title-card md-flex">
                    <div className="modal-title">
                      {this.props.userReducer.user !== null &&
                      this.props.userReducer.user.email ===
                        this.state.itemData.USER_EMAIL ? (
                        <React.Fragment>
                          <h4>Title</h4>
                          {this.state.showOption ? (
                            <React.Fragment>
                              <TextareaAutosize
                                minRows={1}
                                maxRows={10}
                                placeholder="Type Something..."
                                defaultValue={this.state.question}
                                onChange={(e) => this.handleChangeQue(e)}
                                name="question"
                              />
                            </React.Fragment>
                          ) : (
                            <React.Fragment>
                              {this.state.question}
                            </React.Fragment>
                          )}
                        </React.Fragment>
                      ) : (
                        <React.Fragment>
                          <h4>Title</h4>
                          {this.state.question}
                        </React.Fragment>
                      )}
                    </div>
                  </div>

                  {this.state.isLoadingAnswers ? (
                    <React.Fragment>
                      <Loader
                        styles={{ width: "80px", margin: "auto" }}
                        root={{ display: "flex" }}
                      />
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {this.state.answers &&
                        this.state.answers.actions &&
                        this.state.answers.actions.map((subData, index) => (
                          <div key={subData.id}>
                            <div className="ans-img">
                              <div className="ans-data">
                                <div className="data-extract1">
                                  <div className="in-data">
                                    {subData.type === "record" && (
                                      <>
                                        <div className="box-curve">
                                          <span>{index + 1}</span>
                                        </div>
                                        {this.props.userReducer.user !== null &&
                                        this.props.userReducer.user.email ===
                                          this.state.itemData.USER_EMAIL ? (
                                          <>
                                            <div className="qst-input">
                                              {this.state.showOption ? (
                                                <React.Fragment>
                                                  <TextareaAutosize
                                                    minRows={1}
                                                    maxRows={10}
                                                    placeholder="Type Something..."
                                                    defaultValue={
                                                      subData.description
                                                    }
                                                    onChange={(e) =>
                                                      this.handleChangeAns(
                                                        e,
                                                        index
                                                      )
                                                    }
                                                  />
                                                  <img
                                                    src={subData.pageScreenshot}
                                                    alt=""
                                                  />
                                                  {/* <input
                                                    type="file"
                                                    accept="image/*"
                                                    onChange={(e) =>
                                                      this.uploadFile(
                                                        index,
                                                        e.target.files[0]
                                                      )
                                                    }
                                                  ></input> */}
                                                </React.Fragment>
                                              ) : (
                                                <React.Fragment>
                                                  <p>{subData.description}</p>
                                                  <img
                                                    src={subData.pageScreenshot}
                                                    alt=""
                                                  />
                                                </React.Fragment>
                                              )}
                                            </div>
                                          </>
                                        ) : (
                                          <>
                                            <div className="qst-input">
                                              <p>{subData.description}</p>
                                              <img
                                                src={subData.pageScreenshot}
                                                alt=""
                                              />
                                            </div>
                                          </>
                                        )}
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                    </React.Fragment>
                  )}

                  <div className="frm-btns fb-right">
                    <button className="btn-outline bg-red" data-dismiss="modal">
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const styles = StyleSheet.create({
  page: {
    padding: 30,
  },
  header: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "left",
    color: "#000",
    fontWeight: "900",
    borderBottom: "1px solid #cdcdcd",
    paddingBottom: 10,
    textTransform: "capitalize",
  },
  steps: {
    marginBottom: "15px",
  },
  text: {
    marginbottom: "15px",
    fontSize: 12,
    color: "#1d262e",
  },
  image: {
    marginTop: "15px",
  },
  pageNumber: {
    position: "absolute",
    fontSize: 12,
    bottom: 10,
    left: 30,
    right: 30,
    textAlign: "center",
    color: "grey",
    borderTop: "1px solid #cdcdcd",
    paddingTop: 10,
  },
  points: {
    fontWeight: "bold",
    fontSize: "12px",
  },
});

const MyDocument = (data) => {
  return (
    <Document key={data && data.props.id}>
      <Page size="A4" style={styles.page}>
        <View style={styles.header} fixed>
          <Text>{data.props.SKILL_NAME}</Text>
        </View>
        {data.props &&
          data.props.RAW_DATA &&
          data.props.RAW_DATA.actions.map((steps, i) => (
            <View style={styles.steps}>
              <Text style={styles.text}>
                <View style={styles.points}>{i + 1}. </View>
                {steps.description}
              </Text>
              {steps.pageScreenshot && (
                <Image style={styles.image} src={steps.pageScreenshot}></Image>
              )}
            </View>
          ))}
        <Text
          style={styles.pageNumber}
          render={({ pageNumber, totalPages }) =>
            `${pageNumber} / ${totalPages}`
          }
          fixed
        />
      </Page>
    </Document>
  );
};

const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkills,
    deleteDraftSkill,
    updateDraftSkill,
    publishHelperSkill,
    viewHelperSkill,
    updateFormatedData,
    executeFlow,
    getSession,
    getDraftSkillsById,
    notify,
    getUserHelperSkills,
    getFileUrl,
  })
)(HelperEdit);
