import React, { Component } from "react";

import automation from "../../../../images/template-img/automation-icon.png";
import skillHero from "../../../../images/skill-store/bg-skill.png";
import womenImg from "../../../../images/skill-store/women.png";
import search from "../../../../images/serach-black.png";
import forYou from "../../../../images/skill-store/for-u.png";
import finance from "../../../../images/skill-store/finance.png";
import automationIco from "../../../../images/skill-store/automation.png";
import sales from "../../../../images/skill-store/sales.png";
import marketing from "../../../../images/skill-store/marketing.png";
import customer from "../../../../images/skill-store/customer.png";
import hrIcon from "../../../../images/skill-store/hr.png";
import procurement from "../../../../images/skill-store/procurement.png";
import supplyChain from "../../../../images/skill-store/supply-chain.png";
import category from "../../../../images/skill-store/category.png";
import { getDraftSkillCount } from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import { connect } from "react-redux";

export class SkillsHubSearch extends Component {
  constructor() {
    super();
    this.state = {
      searchItem: "",
      categroies: [],
    };
  }

  changeCategory = (cat) => {
    this.props.history.push({
      pathname: `/dashboard/skill-store/category/${cat}`,
    });
  };

  componentDidMount() {
    // this.getSearchResults();
    this.getCategories();
  }

  getCategories = async () => {
    const cats = await this.props.getDraftSkillCount();
    const filtered = cats.filter((skill) => {
      if (skill.CATEGORY == "" || skill.CATEGORY == null) {
        return false;
      } else {
        return true;
      }
    });
    this.setState({ categroies: filtered });
  };
  onChange = (e) => {
    this.setState({
      searchItem: e.target.value,
    });
  };

  onKeyPress = (e) => {
    if (e.key === "Enter") {
      this.props.history.push({
        pathname: `/dashboard/skill-store/search/all?query=${this.state.searchItem}`,
      });
    }
  };

  render() {
    return (
      <div>
        <div
          className="sk-hero"
          style={{ backgroundImage: `url(${skillHero})` }}
        >
          <div className="wm-text">
            <p>
              Now I’m able to produce 2x faster work after accessing Super app
            </p>
          </div>
          <div className="women">
            <img src={womenImg} />
          </div>
          <div className="sk-center text-center">
            <h2>Make Work Awesome</h2>
            <div class="search-g-input">
              <div class="input-search">
                <span class="search-icon">
                  <img src={search} alt="" />
                </span>
              </div>
              <div class="input-gs">
                <input
                  className="super-search"
                  value={this.state.searchItem}
                  onKeyDown={(e) => this.onKeyPress(e)}
                  onChange={(e) => this.onChange(e)}
                  type="text"
                  placeholder="Search"
                />
              </div>
            </div>
            <div className="sk-links hidden-xs hidden-sm">
              <ul>
                {/* <li className="skl-item"
                                onClick={()=>{this.changeCategory("fu")}}
                                >
                                    <div className="skl-ico">
                                        <img src={forYou} />
                                    </div>
                                    <span>For You</span>
                                </li> */}

                <li
                  className="skl-item"
                  onClick={() => {
                    this.changeCategory("all");
                  }}
                >
                  <div className="skl-ico">
                    <img src={finance} />
                  </div>
                  <span>ALL</span>
                </li>

                {this.state.categroies.map((cat, i) => (
                  <li
                    className="skl-item"
                    key={i}
                    onClick={() => {
                      this.changeCategory(cat.CATEGORY.split(",")[0]);
                    }}
                  >
                    <div className="skl-ico">
                      <img src={finance} />
                    </div>
                    <span>{cat.CATEGORY.split(",")[0]}</span>
                  </li>
                ))}
              </ul>
            </div>
            {/* Mobile Version Select */}
            <div className="sk-links-mob hidden-md hidden-lg">
              <select>
                <option onClick={(e) => {
                    this.changeCategory("all");
                  }}>All</option>

                  {this.state.categroies.map((cat, i) => (
                  <option
                    className="skl-item"
                    key={i}
                    onClick={(e) => {
                      this.changeCategory(cat.CATEGORY.split(",")[0]);
                    }}
                  >{cat.CATEGORY.split(",")[0]}
                  </option>
                ))}

              </select>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkillCount,
  })
)(SkillsHubSearch);
