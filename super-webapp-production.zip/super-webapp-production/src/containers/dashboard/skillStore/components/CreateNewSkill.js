import axios from 'axios';
import React, { Component } from 'react'
import { notify } from "../../../../components/Snack"
import $ from "jquery"
import { v4 as uuid } from "uuid"
import { connect } from "react-redux";
import { getSkillsFromStore, addSkillToUser } from "../../../../redux/actions/skill"
import deleteimg from "../../../../images/training/delete-red.png"
import upload_icon from "../../../../images/up-icon.png"
import doc_img from "../../../../images/doc-input.png"
import pic_dark from "../../../../images/pic-dark.png"
import { getKeycloackToken } from "../../../../redux/actions/auth"

var temp = 0
export class CreateNewSkill extends Component {

    constructor(props) {
        super(props)
        this.state = {
            skill_file: [],
            partner_files: [],
            bpmn_file: [],
            isFieldsDisabled: false,
            input_fields: [],
            fields_data: {},
            skill_name: "",
            skill_description: "",
            isLoading: false,


        }
    }

    onAdd = (e) => {
        e.preventDefault()
        let input = `input-${temp}`
        temp++
        this.setState({
            input_fields: [...this.state.input_fields, input],
            fields_data: {
                ...this.state.fields_data, [input]: { field_name: "", field_type: "" }
            }
        })
    }

    onImageDelete = (e, type, file) => {
        e.stopPropagation()
        var current_files = this.state[type]
        let filtered_files = current_files.filter(item => { return file.name !== item.name })

        this.setState({ [type]: filtered_files })
    }

    onFieldChange = (e, item) => {
        // console.log(e)
        this.setState({
            fields_data: {
                ...this.state.fields_data, [item]: { ...this.state.fields_data[item], [e.target.name]: e.target.value }
            }
        })
    }
    onInputChange = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }
    handleFileChange = (e) => {

        if (e.target.name == "skill_file") {
            this.setState({ skill_file: [...e.target.files] })
        } else if (e.target.name == "bpmn_file") {
            this.setState({ bpmn_file: [...e.target.files] })
        } else {
            this.setState({ partner_files: [...this.state.partner_files, ...e.target.files] })
        }

    }

    onFieldDelete = (e, field) => {
        e.preventDefault()
        let fields_data = this.state.fields_data
        let fields = this.state.input_fields.filter(item => field != item)
        delete fields_data[field]
        this.setState({
            input_fields: fields,
            fields_data: fields_data
        })

    }

    handleSubmit = async (e) => {
        this.setState({ isLoading: true })
        var canForward = true
        e.preventDefault()

        let skill_fields = []
        for (const [key, value] of Object.entries(this.state.fields_data)) {
            skill_fields.push(value)
        }
        //console.log(skill_fields)
        if (this.state.skill_name == "" || this.state.skill_description == "" || this.state.skill_file[0] == undefined || this.state.bpmn_file[0] == undefined || this.state.partner_files[0] == undefined) {

            canForward = false
        }

        for (const [key, value] of Object.entries(this.state.fields_data)) {
            if (value.field_name == "" || value.field_type == "") {
                canForward = false
            }
        }

        if (canForward) {
            this.setState({ isFieldsDisabled: true })
            try {
                var data = new FormData();
                data.append('skill_logo', this.state.skill_file[0]);
                this.state.partner_files.map(item => {
                    data.append('partner_logos', item);
                })
                data.append("bpmn_file", this.state.bpmn_file[0])
                data.append("skill_name", this.state.skill_name)
                data.append("skill_description", this.state.skill_description)
                data.append("skill_fields", JSON.stringify(skill_fields))
                let token = await getKeycloackToken()
                var config = {
                    method: 'post',
                    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/skills/uploadSkills`,
                    headers: {
                        "Content-Type": "multipart/form-data",
                        'Authorization': `Bearer ${token}`
                    },
                    data: data
                };

                const result = await axios(config)
                $('.close').click()
                $('input').val('')
                this.props.notify("success", "Skill uploaded successfully")
                this.props.getSkillsFromStore()

                this.setState({
                    skill_file: [],
                    partner_files: [],
                    bpmn_file: [],
                    isFieldsDisabled: false,
                    input_fields: [],
                    fields_data: {},
                    skill_name: "",
                    skill_description: "",
                    isLoading: false,
                    alerStatus: true,
                    alerMessage: "Successfully Uploaded skill ..!"
                })
            } catch (err) {
                this.setState({ isFieldsDisabled: false, isLoading: false })
                this.props.notify("error", "Skill Uploaded Failed " + err.toString())
            }

        } else {
            this.setState({ isLoading: false })
            this.props.notify("error", "Please fill all the Details")

        }


    }
    render() {
        // console.log("ner =>>>>>>", this.state)
        return (
            <div class="modal crt-skill fade" id="myModalnew" role="dialog">
                <div class="modal-dialog modal-md">
                    <div class="modal-content crt-content">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="modal-body scrollable" id="skill-dialog">
                            <div class="form-contain">
                                <h1>Upload a new skill</h1>
                                <form action="#">
                                    <div class="frm-block">
                                        <label>Skill Name</label>
                                        <input name="skill_name" value={this.state.skill_name} onChange={(e) => this.onInputChange(e)} type="text" placeholder="Enter" disabled={this.state.isFieldsDisabled ? "disable" : ""} />
                                    </div>
                                    <div class="frm-block">
                                        <label>Descriptions</label>
                                        <textarea name="skill_description" value={this.state.skill_description} onChange={(e) => this.onInputChange(e)} placeholder="Enter" disabled={this.state.isFieldsDisabled ? "disable" : ""}></textarea>
                                    </div>
                                    <div class="frm-block">
                                        <label>Skill Logo</label>
                                        <div class="form-group cst-fl-input">
                                            <div class="input-group input-file" style={{ cursor: "pointer" }} name="Fichier1" onClick={() => $('#skill_logo').click()}>
                                                {this.state.skill_file.length == 0 ?
                                                    <div class="ipt-placeholder">
                                                        <div class="ipt-ico-text">
                                                            <img src={pic_dark} alt="" />
                                                            <p>Browse</p>
                                                        </div>
                                                    </div>
                                                    :

                                                    <div class="ipt-filled">
                                                        <div class="ipt-flex-ico">
                                                            {this.state.skill_file.map((file, index) => (
                                                                <div key={index} class="ipt-fl-icon ">
                                                                    <span onClick={(e) => this.onImageDelete(e, "skill_file", file)} class="ipt-delete">
                                                                        <img src={deleteimg} alt="" />
                                                                    </span>
                                                                    <img src={URL.createObjectURL(file)} alt="" />
                                                                </div>
                                                            ))}


                                                        </div>
                                                    </div>
                                                }


                                                <span class="input-group-btn">
                                                    <button class="btn btn-default btn-choose" onClick={(e) => { e.stopPropagation(); $('#skill_logo').click() }} type="button"><img src={upload_icon} alt="" /></button>
                                                    <input class="btn btn-default btn-choose" accept="image/*" id="skill_logo" style={{ display: "none" }} name="skill_file" onChange={(e) => this.handleFileChange(e)} type="file" disabled={this.state.isFieldsDisabled ? "disable" : ""} />
                                                </span>
                                            </div>
                                        </div>
                                        <span>Logo colour should be in white!</span>
                                    </div>
                                    <div class="frm-block">
                                        <label>Partner Images</label>
                                        <div class="form-group cst-fl-input">
                                            <div class="input-group input-file" style={{ cursor: "pointer" }} name="Fichier1" onClick={() => $('#partner_files').click()}>

                                                {this.state.partner_files.length == 0 ?
                                                    <div class="ipt-placeholder">
                                                        <div class="ipt-ico-text">
                                                            <img src={pic_dark} alt="" />
                                                            <p>Browse</p>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div class="ipt-filled">
                                                        <div class="ipt-flex-ico">
                                                            {this.state.partner_files.map((file, index) => (
                                                                <div key={index} class="ipt-fl-icon">
                                                                    <span onClick={(e) => this.onImageDelete(e, "partner_files", file)} class="ipt-delete">
                                                                        <img src={deleteimg} alt="" />
                                                                    </span>
                                                                    <img src={URL.createObjectURL(file)} alt="" />
                                                                </div>
                                                            ))}

                                                        </div>
                                                    </div>
                                                }

                                                <span class="input-group-btn">
                                                    <button class="btn btn-default btn-choose" onClick={(e) => { e.stopPropagation(); $('#partner_files').click() }} type="button"><img src={upload_icon} alt="" /></button>
                                                    <input class="btn btn-default btn-choose" accept="image/*" style={{ display: "none" }} id="partner_files" name="partner_files" onChange={(e) => this.handleFileChange(e)} type="file" disabled={this.state.isFieldsDisabled ? "disable" : ""} multiple />
                                                </span>
                                            </div>
                                        </div>
                                        <span>Partner images should be transparent!</span>
                                    </div>
                                    <div class="frm-block">
                                        <label>Skill BPMN File</label>
                                        <div class="form-group cst-fl-input">
                                            <div class="input-group input-file" style={{ cursor: "pointer" }} name="Fichier1" onClick={() => $('#bpmn_file').click()}>

                                                {this.state.bpmn_file.length == 0 ?
                                                    <div class="ipt-placeholder">
                                                        <div class="ipt-ico-text">
                                                            <img src={doc_img} alt="" />
                                                            <p>Browse</p>
                                                        </div>
                                                    </div>
                                                    :
                                                    <div class="ipt-filled">
                                                        <div class="ipt-flex-ico">
                                                            {this.state.bpmn_file.map((file, index) => (
                                                                <React.Fragment>
                                                                    <div key={index} class="ipt-fl-icon">
                                                                        <span onClick={(e) => this.onImageDelete(e, "bpmn_file", file)} class="ipt-delete">
                                                                            <img src={deleteimg} alt="" />
                                                                        </span>
                                                                        <img src={doc_img} alt="" />

                                                                    </div>
                                                                    <span>{file.name}</span>
                                                                </React.Fragment>
                                                            ))}

                                                        </div>
                                                    </div>
                                                }

                                                <span class="input-group-btn">
                                                    <button class="btn btn-default btn-choose" onClick={(e) => { e.stopPropagation(); $('#bpmn_file').click() }} type="button"><img src={upload_icon} alt="" /></button>
                                                    <input class="btn btn-default btn-choose" accept=".bpmn" style={{ display: "none" }} id="bpmn_file" name="bpmn_file" onChange={(e) => this.handleFileChange(e)} type="file" disabled={this.state.isFieldsDisabled ? "disable" : ""} />
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="cst-para">
                                        <div class="ctm-title">
                                            <h3>Custom Parameters</h3>
                                            <button onClick={(e) => this.onAdd(e)} class="primary-btn" disabled={this.state.isFieldsDisabled ? "disable" : ""}>+</button>
                                        </div>
                                        {this.state.input_fields.map((item, index) => (
                                            <div key={index} class="ctm-flex" >
                                                <div class="frm-block">
                                                    <label>Parameter Name</label>
                                                    <input type="text" value={this.state.fields_data[item].field_name} name="field_name" onChange={(e) => this.onFieldChange(e, item)} placeholder="Enter" disabled={this.state.isFieldsDisabled ? "disable" : ""} />
                                                </div>
                                                <div class="frm-block">
                                                    <label>Parameter Type</label>
                                                    <select name="field_type" value={this.state.fields_data[item].field_type} class="dropdown" onChange={(e) => this.onFieldChange(e, item)} disabled={this.state.isFieldsDisabled ? "disable" : ""}>
                                                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Text
                                                            <span class="caret"></span></button>
                                                        <option value="">Select</option>
                                                        <option value="text">Text</option>
                                                        <option value="password">Password</option>


                                                    </select>
                                                </div>
                                                <div onClick={(e) => this.onFieldDelete(e, item)} class="delete-param">
                                                    <img src={deleteimg} alt="" />
                                                </div>
                                            </div>
                                        ))}



                                    </div>
                                    <div class="frm-btns">
                                        <button class="btn-outline" data-dismiss="modal" disabled={this.state.isFieldsDisabled ? "disable" : ""}>Cancel</button>
                                        <button class="primary-btn" onClick={(e) => this.handleSubmit(e)} disabled={this.state.isFieldsDisabled ? "disable" : ""}> {this.state.isLoading ? "Uploading.." : "Upload Skill"}</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => ({
    item: state.item,
    skills: state.skills
});

export default connect(mapStateToProps, {

    getSkillsFromStore,
    addSkillToUser,
    notify

})(CreateNewSkill)
