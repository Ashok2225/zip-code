import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getSkillsFromStore,
  addSkillToUser,
  filterSearchItem,
} from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import SkillItem from "../components/SkillItem";
import EmptyLoader from "../../../../components/emptyLoader";
import Loader from "../../../../components/loader";
import InfiniteScroll from "react-infinite-scroll-component";
import { notify } from "../../../../redux/actions/snack";

class AutomationSkills extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skills: [],
      page: 1,
      skillPageInfo: null,
      pageSize: 10,
      hasMore: true,
      searchItem: null,
      isSearching: false,
      isLoading: true,
      isScrolling: false,
    };
  }

  openConfigure = (item) => {
    this.props.addSkillToUser(item);
  };

  componentDidMount() {
    this.getAutomationSkill();
  }

  getAutomationSkill = async () => {
    let skillFromeStore = await this.props.getSkillsFromStore(this.state.page);
    if (skillFromeStore) {
      if (skillFromeStore.results.length) {
        this.setState({
          skills: this.state.skills.concat(skillFromeStore.results),
          skillPageInfo: skillFromeStore.pageInfo,
          isLoading: false,
          isScrolling: false,
        });
      } else {
        this.setState({
          isLoading: false,
          hasMore: false,
          isScrolling: false,
        });
      }
    } else {
      this.setState({
        isLoading: false,
        hasMore: false,
        isScrolling: false,
      });
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevState.page !== this.state.page) {
      this.getAutomationSkill();
    }
  }

  componentWillUnmount() {
    this.setState({ page: 1 });
  }

  fetchData() {
    this.setState({ isScrolling: true });

    try {
      if (this.state.page === this.state.skillPageInfo.pageCount) {
        this.setState({
          hasMore: false,
        });
      } else {
        this.setState({
          page: this.state.page + 1,
        });
      }
    } catch (err) {
      this.setState({
        hasMore: false,
      });
      this.props.notify("error", "Failed to refresh");
    }
  }

  searchSkillStore = (e) => {
    this.setState({
      searchItem: e.target.value,
    });
  };

  onKeyPress = (e) => {
    if (e.key === "Enter") {
      this.setState({
        isSearching: true,
      });
      this.props.history.push({
        pathname: `/dashboard/skill-store/search/automation-skill?query=${this.state.searchItem}`,
      });
    }
  };

  render() {
    const email =
      this.props && this.props.userReducer.user !== null
        ? this.props.userReducer.user.email
        : "";
    return (
      <React.Fragment>
        {/* Automation Skill */}
        <div className="task-col-search">
          <div className="row mx-0 setting-search bg-white py-3 border-left">
            <div className="col-md-8">
              <div className="position-relative search">
                <input
                  id="searchField"
                  type="search"
                  placeholder="Search"
                  className="form-control border-0"
                  value={this.state.searchItem ? this.state.searchItem : ""}
                  onChange={(e) => this.searchSkillStore(e)}
                  onKeyDown={(e) => this.onKeyPress(e)}
                />
                {/* <img src={SearchIcon} alt="Search" /> */}
              </div>
            </div>
          </div>

          <div className="task-col">
            <div className="title-btn">
              <h1 className="title">Automation Skills</h1>
              <div>
                {(email && email === process.env.REACT_APP_ADMIN1) ||
                email === process.env.REACT_APP_ADMIN2 ||
                email === process.env.REACT_APP_ADMIN3 ||
                email === process.env.REACT_APP_ADMIN4 ? (
                  <button
                    className="btn btn-primary btn-at-up"
                    data-toggle="modal"
                    data-target="#myModalnew"
                  >
                    {"+ Upload Skill"}
                  </button>
                ) : null}
              </div>
            </div>          
            <div id="scrollableDiv" className="scrollable tl-scroll">
              {this.state.isLoading ? (
                <div class="empty-view">
                  <Loader
                    styles={{ width: "80px", margin: "auto" }}
                    root={{ display: "flex" }}
                  />
                </div>
              ) : (
                <div>
                  {this.state.isLoading === false &&
                  !this.state.skills.length ? (
                    <div>
                      <EmptyLoader
                        style={{ width: "30%" }}
                        message="No Skills found"
                      />
                    </div>
                  ) : (
                    <div>
                      <InfiniteScroll
                        dataLength={this.state.skills.length}
                        next={this.fetchData.bind(this)}
                        hasMore={this.state.hasMore}
                        loader={
                          this.state.isScrolling ? (
                            <Loader
                              styles={{ width: "80px", margin: "auto" }}
                              root={{ display: "flex" }}
                            />
                          ) : (
                            ""
                          )
                        }
                        scrollableTarget="scrollableDiv"
                        endMessage={
                          this.state.skills.length == 0 ? (
                            <p
                              className="loading-end"
                              style={{ textAlign: "center" }}
                            >
                              <b>No Automation Skill Found</b>
                            </p>
                          ) : (
                            <p className="loading-end">
                              <b>Yay! You have seen it all</b>
                            </p>
                          )
                        }
                      >
                        {this.state.skills.map((item, index) => (
                          <SkillItem
                            index={index}
                            openConfigure={this.openConfigure}
                            key={item.id}
                            item={item}
                          />
                        ))}
                      </InfiniteScroll>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  skills: state.skillReducer,
  userReducer: state.userReducer,
  searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    addSkillToUser,
    filterSearchItem,
    notify,
  })
)(AutomationSkills);
