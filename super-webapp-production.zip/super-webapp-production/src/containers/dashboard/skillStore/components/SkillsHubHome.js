import React, { Component } from "react";

import OwlCarousel from "react-owl-carousel";
import SkillItem from "./SkillItem";
import {
  getSkillsFromStore,
  getDraftSkills,
} from "../../../../redux/actions/skill";
import { withRouter } from "react-router";
import { compose } from "redux";
import { connect } from "react-redux";
import Loader from "../../../../components/loader";

export class SkillsHubHome extends Component {
  constructor() {
    super();
    this.state = {
      mostPopular: [],
      trending: [],
      allSkills: [],
      searchedSkills: [],
      isLoading: true,
      options: {
        // loop: true,
        margin: 30,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 3,
            },
            1000: {
                items: 4,
            },
        },
    },
    };
  }

  componentDidMount() {
    this.getAllSkill();
  }

  // manipulate = async (nextProps) => {
  //   let { allSkills } = this.state;
  //   let { searchSkill } = nextProps.skills;
  //   let searchSkills = [];
  //   if (searchSkill.length > 0 && allSkills.length > 0) {
  //     this.setState({
  //       mostPopular: [],
  //       trending: [],
  //       isLoading: true,
  //     });
  //     // searchSkills = allSkills.map()
  //     for (let i = 0; i < allSkills.length; ++i) {
  //       let searchItem = allSkills[i].skill_name || allSkills[i].SKILL_NAME;
  //       if (searchItem.includes(searchSkill)) {
  //         searchSkills.push(allSkills[i]);
  //       }
  //     }
  //     this.setState({
  //       searchedSkills: searchSkills,
  //       mostPopular: [],
  //       trending: [],
  //       allSkills: allSkills,
  //       isLoading: false,
  //     });
  //   } else {
  //     this.setState({
  //       mostPopular: allSkills.slice(0, 10),
  //       trending: allSkills.slice(10, allSkills.length),
  //       allSkills: allSkills,
  //       searchedSkills: [],
  //       isLoading: false,
  //     });
  //   }
  // };

  getAllSkill = async () => {
    let skillFromeStore = await this.props.getSkillsFromStore();
    let category = "all";
    let page = -1;
    let type = "SkillHub";
    let data = { type, page, category };
    let inApp = await this.props.getDraftSkills(data);
    skillFromeStore.results.map((skill) => {
      skill["TYPE"] = "automation";
    });

    if (skillFromeStore || inApp) {
      if (skillFromeStore.results.length || inApp.results.length) {
        let allSkills = [...skillFromeStore.results, ...inApp.results];
        allSkills = allSkills.sort(function (x, y) {
          return (
            new Date(
              y.LAST_UPDATED_AT ? y.LAST_UPDATED_AT : y.updated_at
            ).getTime() -
            new Date(
              x.LAST_UPDATED_AT ? x.LAST_UPDATED_AT : x.updated_at
            ).getTime()
          );
        });
        this.setState({
          mostPopular: allSkills.slice(0, 10),
          trending: allSkills.slice(10, allSkills.length),
          allSkills: allSkills,
          isLoading: false,
        });
      } else {
        this.setState({
          isLoading: false,
        });
      }
    } else {
      this.setState({
        isLoading: false,
      });
    }
  };

  renderItems = () => {
    let items = [];

    items = [<h1>hi</h1>];

    return items;
  };

  render() {
    let { mostPopular, trending, isLoading } = this.state;
    return (
      <div>
        {isLoading ? (
          <div class="empty-view">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : (
          <div>
            {mostPopular.length ? (
              <div className="sk-slide-section">
                <h4 className="tp-title">Most Popular</h4>
                <OwlCarousel
                  className="owl-theme sk-boxes"
                  id="sk-boxes1"
                  {...this.state.options}
                >
                  {mostPopular.map((skill, index) => (
                    <SkillItem item={skill} key={skill.id} opt={false} />
                  ))}
                </OwlCarousel>
              </div>
            ) : null}

            {trending.length ? (
              <div className="sk-slide-section">
                <h4 className="tp-title">Automation Trending Skills</h4>
                <OwlCarousel
                  className="owl-theme sk-boxes"
                  id="sk-boxes1"
                  {...this.state.options}
                >
                  {trending.map((skill, index) => (
                    <SkillItem item={skill} key={skill.id} opt={true} />
                  ))}
                </OwlCarousel>
              </div>
            ) : null}
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  // skills: state.skillReducer,
  // userReducer: state.userReducer,
  // searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    getDraftSkills,
  })
)(SkillsHubHome);
