/*global chrome*/
import React, { Component } from "react";
import arrowDown from "../../../../images/training/arrow-down.png";
import pausewhite from "../../../../images/pause-white.png";
import sendwhite from "../../../../images/training/send-white.png";
import play from "../../../../images/training/play.png";
import dottedBg from "../../../../images/dotted.png";
import playWhite from "../../../../images/play-white.png";
import arrowEmpty from "../../../../images/training/arrow-empty.png";

import {
  getDraftSkillsById,
  executeFlow,
  getSession,
  changeActiveTab,
} from "../../../../redux/actions/skill";
import { compose } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { notify } from "../../../../redux/actions/snack";
import Draggable from "react-draggable"; // The default
import NotFound from "../../../../components/notFound";
import Loader from "../../../../components/loader";
import Zoom from "react-medium-image-zoom";
import "react-medium-image-zoom/dist/styles.css";
import { PDFDownloadLink } from "@react-pdf/renderer";
import MyDocument from "../../../../components/document";
class WalkthroughFlowChart extends Component {
  state = {
    currentSkillArea: [],
    isLoading: true,
    notFound: false,
    markerIndex: 0,
  };

  componentDidMount = () => {
    this.props.changeActiveTab("Super Skills");
    this.trainYourSkill();
  };

  play = async (data) => {
    if (data.deviceId === undefined || !data.skillId) {
      this.props.notify(
        "error",
        "Your local machine is not connected to Super Assistant. Please install Super Assistant app on your local machine to connect it with Super Assistant"
      );
      return;
    } else {
      const playSkill = await this.props.executeFlow(data);
      if (playSkill.data.status === false) {
        chrome.runtime.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          { type: "openLogin" },
          (response) => {
            if (response) {
              // console.log("Extension Response", response);
            }
          }
        );
      }
    }
  };

  trainYourSkill = async () => {
    var businessViewActions = [];
    var _actionPayload;
    var businessViewData;
    const trainSkillId = this.props.match.params.id;
    const trainSkill = await this.props.getDraftSkillsById(trainSkillId);
    if (trainSkill === undefined) {
      this.setState({
        notFound: true,
        isLoading: false,
      });
    } else {
      if (
        trainSkill &&
        trainSkill.data.data &&
        trainSkill.data.data.FORMATED_DATA !== null &&
        trainSkill.data.data.RAW_DATA !== null
      ) {
        trainSkill.data.data.RAW_DATA.actions.map((a, i) => {
          var defaultDescription = a.actionType;
          if (a.text) {
            defaultDescription = a.actionType.concat(" ", a.text);
          }
          if (i === 0) {
            _actionPayload = {
              text: a.text,
              type: a.type,
              value: a.value,
              timeStamp: a.timeStamp,
              actionType: a.actionType,
              description: a.description ? a.description : defaultDescription,
              pageScreenshot: a.pageScreenshot,
              isManualStep: a.isManualStep ? a.isManualStep : false,
            };
            businessViewActions.push(_actionPayload);
          } else {
            _actionPayload = {
              value: a.value,
              tabTitle: a.tabTitle,
              text: a.text,
              frame: a.frame,
              actionType: a.actionType,
              pageScreenshot: a.pageScreenshot,
              timeStamp: a.timeStamp,
              title: a.title,
              tabUrl: a.tabUrl,
              type: a.type,
              id: a.id,
              xPath: a.xPath,
              description: a.description ? a.description : defaultDescription,
              isManualStep: a.isManualStep ? a.isManualStep : false,
            };
            businessViewActions.push(_actionPayload);
          }
        });
        businessViewData = {
          id: trainSkill.data.data.id,
          type: trainSkill.data.data.RAW_DATA.type,
          actions: businessViewActions,
        };

        this.setState({
          currentSkillArea: trainSkill.data.data,
          isLoading: false,
          // currentSkillActions: trainSkill.data.data.RAW_DATA,
          currentSkillActions: businessViewData,
        });
      } else {
        if (
          Object.keys(trainSkill.data) &&
          Object.keys(trainSkill.data).length === 0
        ) {
          this.setState({
            notFound: true,
            isLoading: false,
          });
        }
      }
    }
  };

  render() {
    var data = {
      deviceId: this.props.skillReducer.draftSession,
      skillId: this.state.currentSkillArea.id,
    };
    return (
      <React.Fragment>
        {this.state.notFound === true ? (
          <React.Fragment>
            <NotFound />
          </React.Fragment>
        ) : (
          <React.Fragment>
            {this.state.isLoading ? (
              <React.Fragment>
                <Loader
                  styles={{ width: "80px", margin: "auto" }}
                  root={{ display: "flex" }}
                />
              </React.Fragment>
            ) : (
              <React.Fragment>
                <div
                  className="fw-screen"
                  style={{
                    backgroundImage: `url(${dottedBg})`,
                    backgroundSize: "cover",
                  }}
                >
                  <div className="chat-col-skill">
                    <div className="flex-title rt-flex-title">
                      <div className="cts-title">
                        <div className="cts-ico">
                          <span>
                            {this.state.currentSkillArea.SKILL_NAME
                              ? this.state.currentSkillArea.SKILL_NAME.toUpperCase().charAt(
                                  0
                                )
                              : ""}
                          </span>
                        </div>
                        <p>{this.state.currentSkillArea.SKILL_NAME}</p>
                      </div>
                      <div className="rt-btns">
                        <React.Fragment>
                          <button
                            className="sm-btn"
                            onClick={() => {
                              this.play(data);
                            }}
                          >
                            <img src={play} alt="" />
                            <span>Play</span>
                          </button>

                          <PDFDownloadLink
                            document={
                              this.state.currentSkillArea ? (
                                <MyDocument
                                  key={this.state.currentSkillArea.id}
                                  props={this.state.currentSkillArea}
                                />
                              ) : null
                            }
                            fileName={this.state.currentSkillArea.SKILL_NAME}
                          >
                            {({ blob, url, loading, error }) =>
                              error ? (
                                <button className="lg-btn" disabled>
                                  <img src={sendwhite} alt="" />
                                  <span>Export To Pdf</span>
                                </button>
                              ) : (
                                <button className="lg-btn">
                                  <img src={sendwhite} alt="" />
                                  <span>Export To Pdf</span>
                                </button>
                              )
                            }
                          </PDFDownloadLink>
                        </React.Fragment>
                      </div>
                    </div>
                    <div className="outer-drag scrollable">
                      {/* <Draggable> */}
                      <div className="rt-train-block" id="draggable">
                        <div className="rt-block-flex">
                          <div className="rt-block rt-start">
                            <div
                              className="rtb-ico"
                              style={{ backgroundColor: "#02ce9d" }}
                            >
                              <img src={playWhite} alt="" />
                            </div>
                            <div className="rtb-text">
                              <p>Training Start</p>
                            </div>
                            <div className="arrow-divider arrow-start">
                              <img src={arrowEmpty} alt="" />
                            </div>
                          </div>
                          <React.Fragment>
                            {this.state.currentSkillActions &&
                              this.state.currentSkillActions.actions &&
                              this.state.currentSkillActions.actions.map(
                                (record, index) => (
                                  <React.Fragment>
                                    <div
                                      key={record.id}
                                      id={record.id}
                                      className="rt-block-full"
                                    >
                                      <span className="rt-item-number">
                                        0{index}
                                      </span>
                                      <div className="rtb-menu">
                                        {/* <img src={rtbmenu} alt="" /> */}
                                      </div>

                                      <div className="rt-block-header">
                                        <div className="rth-title">
                                          <React.Fragment>
                                            <div className="tl-cont">
                                              <div className="rth-tl-tp">
                                                {/* {record.tabTitle && (
                                                  <p>
                                                    Title :{" "}
                                                    <span
                                                      title={record.tabTitle}
                                                    >
                                                      {record.tabTitle}
                                                    </span>
                                                  </p>
                                                )} */}
                                                {index === 0 && (
                                                  <React.Fragment>
                                                    <p>
                                                      Go to{" "}
                                                      <span
                                                        className="nav-url"
                                                        title={record.value}
                                                      >
                                                        <a
                                                          href={record.value}
                                                          target="_blank"
                                                          rel="noreferrer"
                                                        >
                                                          {record.value}
                                                        </a>
                                                      </span>
                                                    </p>
                                                  </React.Fragment>
                                                )}
                                                <div className="rth-tooltip">
                                                  <p>ToolTip: </p>
                                                  <span>
                                                    {record.description}
                                                  </span>
                                                </div>
                                              </div>
                                            </div>
                                          </React.Fragment>
                                        </div>
                                      </div>

                                      <Zoom>
                                        <div className="rtb-screenshot">
                                          {record.pageScreenshot ? (
                                            <img
                                              src={record.pageScreenshot}
                                              alt="pageScreenshot"
                                            />
                                          ) : (
                                            ""
                                          )}
                                        </div>
                                      </Zoom>
                                      {record.isManualStep ? (
                                        <div className="step-position">
                                          <div className="manual-step">
                                            <div class="ch-switch">
                                              <input
                                                class="tgl tgl-light"
                                                name={index}
                                                id={index}
                                                type="checkbox"
                                                disabled="true"
                                                defaultChecked={
                                                  record.isManualStep
                                                    ? true
                                                    : false
                                                }
                                              />
                                              <label
                                                class="tgl-btn"
                                                for={index}
                                              ></label>
                                            </div>
                                            <span>Manual Step</span>
                                          </div>

                                          <div class="dropdown">
                                            <button
                                              class="btn btn-default dropdown-toggle"
                                              type="button"
                                              data-toggle="dropdown"
                                            >
                                              {record.position
                                                ? record.position
                                                : "auto"}
                                              <span class="caret"></span>
                                            </button>
                                          </div>
                                        </div>
                                      ) : (
                                        ""
                                      )}
                                    </div>
                                    <div className="arrow-divider arrow-start">
                                      <img src={arrowEmpty} alt="" />
                                    </div>
                                  </React.Fragment>
                                )
                              )}
                          </React.Fragment>

                          <div className="rt-block rt-end">
                            <div
                              className="rtb-ico"
                              style={{ backgroundColor: "#ff3333" }}
                            >
                              <span className="circle"></span>
                            </div>
                            <div className="rtb-text">
                              <p>Training End</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* </Draggable> */}
                    </div>

                    <div
                      style={{
                        width: "300px",
                        position: "fixed",
                        bottom: -25,
                        marginLeft: "20px",
                      }}
                    ></div>
                  </div>
                </div>
              </React.Fragment>
            )}
          </React.Fragment>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  userReducer: state.userReducer,
  snackReducer: state.snackReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkillsById,
    notify,
    executeFlow,
    getSession,
    changeActiveTab,
  })
)(WalkthroughFlowChart);
