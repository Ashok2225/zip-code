import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getSkillsFromStore,
  addSkillToUser,
  filterSearchItem,
  getDraftSkills,
} from "../../../redux/actions/skill";
import { withRouter } from "react-router";

import SkillItem from "../skillStore/components/SkillItem";
import EmptyLoader from "../../../components/emptyLoader";
import Loader from "../../../components/loader";
import SideBar from "./components/sideBar";
import UserSkillAddForm from "./components/UserSkillAddForm";
import CreateNewSkill from "./components/CreateNewSkill";
import HelperItem from "./components/HelperItem";
import HelperEdit from "./components/HelperEdit";
import AutomationSkills from "./components/AutomationSkills";
import HelperSkills from "./components/HelperSkills";
import { Switch, Route } from "react-router";
import SearchResults from "./components/SearchResults";
import { compose } from "redux";
import WalkthroughFlowChart from "./components/WalkthroughFlowChart";
import SkillsHub from "./components/SkillsHub";
class SkillStore extends Component {
  constructor() {
    super();
    this.state = {
      skills: [],
      filter: "All Skills",
      draft_skills: [],
      page: 1,
      draftPageInfo: [],
      skillPageInfo: [],
      pageSize: 10,
      hasMore: true,
      draftPage: 1,
      searchItem: null,
    };
  }

  openConfigure = (item) => {
    this.props.addSkillToUser(item);
  };

  async componentDidMount() {
    const currentFilter =
      this.props && this.props.location.pathname === "/dashboard/skill-store"
        ? "All Skills"
        : "";

    this.setState({
      filter: currentFilter,
    });

    let page = this.state.draftPage;
    let type = "helper";
    let data = { page, type };
    // this.props.getDraftSkills(data);
    this.props.getSkillsFromStore(this.state.page);
  }

  render() {
    return (
      <React.Fragment>
        <div className="align-row">
          {/* <SideBar {...this.props} /> */}
          <UserSkillAddForm />
          <CreateNewSkill />

          <Switch>
            <Route
              path="/dashboard/skill-store/automation-skills"
              render={() => <AutomationSkills />}
            />

            <Route
              path="/dashboard/skill-store/helper-skills/:id"
              render={() => <HelperSkills />}
            />

            <Route
              path="/dashboard/skill-store/view/:id"
              render={() => <WalkthroughFlowChart />}
            />
            <Route
              path="/dashboard/skill-store"
              render={() => <SkillsHub />}
            />
          </Switch>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  // skills: state.skillReducer,
  // userReducer: state.userReducer,
  // searchTerm: state.searchTerm,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getSkillsFromStore,
    addSkillToUser,
    filterSearchItem,
    getDraftSkills,
  })
)(SkillStore);
