export const SHOW_LOGS = 'SHOW_LOGS'
export const CLEAR_LOGS = 'CLEAR_LOGS'