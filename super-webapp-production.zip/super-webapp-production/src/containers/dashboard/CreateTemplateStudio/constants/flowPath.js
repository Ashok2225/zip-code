export const SAVE_PATH = 'SAVE_PATH'
export const CLEAR_PATH = 'CLEAR_PATH'
