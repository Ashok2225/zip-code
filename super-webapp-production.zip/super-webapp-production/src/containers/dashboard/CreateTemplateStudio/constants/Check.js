export const CHECK = 'CHECK'
