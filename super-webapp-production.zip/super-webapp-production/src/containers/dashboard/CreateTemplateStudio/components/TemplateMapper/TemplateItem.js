import React, { Component } from 'react'
import outlookIcon from "../../../../../images/training/outlook-icon.png";
import outlookImage from "../../../../../images/training/outlook-image.png";
import desktopIcon from "../../../../../images/training/configure-icon.png"
import desktopImage from "../../../../../images/training/configure-image.png"
import webImg from "../../../../../images/template-img/web.PNG"
import excelImg from "../../../../../images/template-img/data-loading.png"
import loop from "../../../../../images/template-img/loop.png"
import jump from "../../../../../images/template-img/jump.png"
import tryImg from "../../../../../images/template-img/try.png"
import condition from "../../../../../images/template-img/condition.png"
import spreadsheet from "../../../../../images/template-img/spreadsheet.png"
import connection from "../../../../../images/template-img/connection.png"
import query from "../../../../../images/template-img/query.png"

export class TemplateItem extends Component {


    renderImage = (type, imgType = null) => {




        switch (type) {


            case "desktop":
                return (imgType == "icon" ? <img style={{ width: '30px' }} src={desktopIcon} /> : <img src={desktopImage} />)
            case "webautomation":
                return (imgType == "icon" ? <img style={{ width: '30px' }} src={webImg} /> : <img src={webImg} />)

            case "excel":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={excelImg} /> : <img src={excelImg} />)
            case "spreadsheet":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={spreadsheet} /> : <img src={spreadsheet} />)

            // case "getsheetnames":

            //     return (imgType == "icon" ? <img style={{ width: '30px' }} src={excelImg} /> : <img src={excelImg} />)

            // case "getMail":

            //     return (imgType == "icon" ? <img style={{ width: '30px' }} src={outlookIcon} /> : <img src={outlookImage} />)

            case "outlook":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={outlookIcon} /> : <img src={outlookImage} />)
            // case "filtercolumn":

            //     return (imgType == "icon" ? <img style={{ width: '30px' }} src={outlookIcon} /> : <img src={outlookImage} />)

            case "if":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={condition} /> : <img src={condition} />)

            case "ifelse":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={condition} /> : <img src={condition} />)

            case "elseif":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={condition}/> : <img ssrc={condition} />)
            case "trycatch":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={tryImg} /> : <img src={tryImg} />)
            case "for":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={loop} /> : <img src={loop} />)

            case "statements":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={jump} /> : <img src={jump} />)

            case "connection":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={connection} /> : <img src={connection} />)
            case "executequery":

                return (imgType == "icon" ? <img style={{ width: '30px' }} src={query} /> : <img src={query} />)
        }
    }
    render() {

        const { action } = this.props
        return (
            <div className="rt-block-full" style={{ cursor: "pointer" }}>
                <div className="rt-block-header">
                    <div className="rth-title">
                        <div className="tl-cont flex-irt">
                            <div className="tl-cont-ico">
                                {this.renderImage(action.key, "icon")}
                            </div>
                            <div className="rth-tl-tp">
                                <p>{action.label}</p>

                            </div>
                        </div>
                    </div>
                </div>
                <div className="rtb-screenshot filled-bg">
                    {this.renderImage(action.key, "image")}
                </div>
            </div>
        )
    }
}

export default TemplateItem