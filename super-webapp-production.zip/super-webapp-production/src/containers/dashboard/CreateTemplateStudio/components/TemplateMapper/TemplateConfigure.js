import React, { Component } from 'react'
import $ from "jquery"
import close from "../../../../../images/close.png";
import { editTemplateAction } from "../../../../../redux/actions/template"
import { connect } from "react-redux";
import { bindActionCreators } from 'redux'
export class TemplateConfigure extends Component {


    state = {

    }

    closePanel = () => {




        $(".property-panel").removeClass("open-prt");
    }

    handleCheck = (e) => {

       
       
        this.props.editTemplateAction(this.props.template.currentAction)

    }


    componentDidUpdate(prevProps) {
        if (prevProps.open != this.props.open) {
            if (this.props.open) {
                // this.props.triggerPannel(record);


                setTimeout(() => {
                    $(".property-panel").addClass("open-prt");

                }, 0);
            } else {
                $(".property-panel").removeClass("open-prt");
            }
        }
    }

    render() {
        return (
            <div className="property-panel" style={{ zIndex: "10000000" }}>
                <div className="prt-inner">
                    <div className="prt-title">
                        <div className="prt-title-text">
                            <h3>Property Panel</h3>
                            <p>Identified Steps</p>
                        </div>

                        <div
                            className="prt-close"
                            onClick={this.closePanel}
                        >
                            <img src={close} alt="" />
                        </div>
                    </div>

                    <div
                        className="prt-list scrollable"
                        style={{
                            height: "70vh",
                            marginTop: "5px",
                            paddingRight: "15px",
                        }}
                    >

                        <div class="ch-switch"


                        >
                            <span style={{marginRight:"10px"}}>Is Show</span>
                            <input
                                // class="tgl tgl-light"

                                checked={this.props.template.currentAction.isShow}
                                onChange={this.handleCheck}
                                type="checkbox"


                            />
                            <label class="tgl-btn" ></label>
                        </div>

                    </div>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => ({

    template: state.templateReducer
});

const mapDispatchToProps = (dispatch) => ({
    editTemplateAction: bindActionCreators(editTemplateAction, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(TemplateConfigure)




