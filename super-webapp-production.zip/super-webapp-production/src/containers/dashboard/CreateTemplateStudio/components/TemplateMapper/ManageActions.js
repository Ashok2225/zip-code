export const action = (node, actions, parentId=null)=>{
    let temp
    switch (node.key) {
        case "if":
            actions.addIf(parentId)
            break;

        case "ifelse":
            actions.addIfElse(parentId)
            break;

        case "elseif":
            actions.addElseIf(parentId)
            break;

        case "excel":
            actions.addExcelScope()
            break;

        case "getcell":
            actions.addGetCell(parentId)
            break;

        case "getcolumn":
            actions.addGetColumn()
            break;

        case "hidecolumn":
            actions.addHideColumn(parentId)
            break;

        case "getrow":
            actions.addGetRow(parentId)
            break;

        case "getsheetnames":
            actions.addGetSheetNames()
            break;

        case "deletecolumn":
            actions.addDeleteColumn(parentId)
            break;

        case "deleterow":
            actions.addDeleteRow(parentId)
            break;

        case "getrange":
            actions.addGetRange(parentId)
            break;

        case "writerange":
            actions.addWriteRange(parentId)
            break;

        case "deleterange":
            actions.addDeleteRange(parentId)
            break;

        case "appendrange":
            actions.addAppendRange(parentId)
            break;

        case "writecell":
            actions.addWriteCell(parentId)
            break;

        case "getcellcolor":
            actions.addGetCellColor(parentId)
            break;

        case "setrangecolor":
            actions.addSetRangeColor(parentId)
            break;

        case "getcellformula":
            actions.addGetCellFormula(parentId)
            break;
        case "clearcache":
            actions.addClearCache(parentId)
            break;

        case "click":
            actions.addMouse(node,parentId)
            break;

        case "rclick":
            actions.addMouse(node,parentId)
            break;

        case "dclick":
            actions.addMouse(node,parentId)
            break;

        case "hover":
            actions.addMouse(node,parentId)
            break;

        case "techforce":
            actions.addOcr(node, parentId)
            break;

        case "for":
            actions.addFor(parentId)
            break;

        case "trycatch":
            actions.addTryCatch(parentId)
            break;

        case "connect":
            actions.addFtp(parentId)
            break;

        case "getfile":
            actions.GetFtp(parentId)
            break;

        case "putfile":
            actions.PutFtp(parentId)
            break;

        case "getfiles":
            actions.MgetFtp(parentId)
            break;

        case "putfiles":
            actions.MputFtp(parentId)
            break;

        case "delete":
            actions.deleteFtp(parentId)
            break;

        case "Mdelete":
            actions.MdeleteFtp(parentId)
            break;
        
        case "ftpcreatefolder":
            actions.CreateFolderFtp(parentId)
            break;

        case "ftpdeletefolder":
            actions.DeleteFolderFtp(parentId)
            break; 

        case "csvheader":
            actions.addCsvHeader(parentId)
            break;

        case "csvrow":
            actions.addCsvRow(parentId)
            break;

        case "createfilefolder":
            actions.addCreateFilesFolders(parentId)
            break;

        case "writetofile":
            actions.addWriteFile(parentId)
            break;

        case "copyfilefolder":
            actions.addCopyFilesFolders(parentId)
            break;

        case "getfoldercontents":
            actions.addGetFolderContents(parentId)
            break;

        case "deletefilefolder":
            actions.addDeleteFilesFolders(parentId)
            break;

        case "readfile":
            actions.addReadFile(parentId)
            break;

        case "unzipfiles":
            actions.addUnzipFiles(parentId)
            break;
            
        case "exporttopdf":
            actions.addExportToPDF(parentId)
            break;

        case "echo":
            actions.addEcho(parentId)
            break;

        case "clipboard":
            actions.addClipboard(parentId)
            break;

        case "GetSecret":
            actions.AddGetSecret(parentId)
            break;

        case "GetCredentials":
            actions.AddGetAsset(parentId)
            break;
        
        case "GetParameters":
            actions.AddGetParameters(parentId)
            break;

        case "wait":
            actions.addWait(parentId)
            break;

        case "readmailoutlook":
            actions.readMail(parentId)
            break;

        case "sendmail" :
             actions.sendMail(parentId)
             break;

        case "outlookConfig":
             actions.outlookConfig(parentId)
             break;

        case "readmailimap":
             actions.readImapMail(node,parentId)
             break;

        case "saveattachment":
             actions.saveAttachment(parentId)
             break;

        case "webautomation":
             actions.addWebAutomation()
             break;

        case "webscrapper":
             actions.addWebScrapper(parentId)
             break;

        case "apiconfiguration":
            actions.addAPIConfiguration(parentId)
            break;
            
        case "getspreadsheetdata":
            actions.addGetSpreadsheetData(parentId)   
            break;

        case "writespreadsheetdata":
            actions.addWriteSpreadsheetData(parentId)
            break;
            
        case "spreadsheet":
            actions.addCreateSpreadsheet(parentId)
            break;
            
        case "deletespreadsheetdata":
            actions.addDeleteSpreadsheetData(parentId)
            break;
        
        case "createevent":
            actions.addCreateEvent(parentId)
            break;

        case "modifyevent":
            actions.addModifyEvent(parentId)
            break;
                
        case "deleteevent":
            actions.addDeleteEvent(parentId)
            break;

        case "sendmessagetochatbot":
            actions.addSendMessageToChatBot(parentId)
            break;
            
        case "enterkeystrokes":
             actions.addKeyboardText(parentId)
             break;

        case "keyboardshortcuts":
             actions.addDeskKeyboard(parentId)
             break;

        case "desktop":
             actions.addDesktopAction()
             break

        case "show":
             actions.addShow(parentId)
             break;

        case "snap":
             actions.addSnap(parentId)
             break;

        case 'dom':
            actions.addDom(parentId)
            break;
        case 'readmailpop3':
            actions.readPop3Mail(node,parentId)
            break;

        case "imageclassification" :
            actions.addImageClassification(parentId)
            break;

        case "facesimilarity" :
             actions.addFaceSimilarity(parentId)
             break;

        case "superresolution" :
             actions.addSuperResolution(parentId)
             break;

        case "assign" :
             actions.addAssign(parentId)
             break;

        case "read" :
             actions.readValue(parentId)
             break;

        case 'httpapi':
            actions.httpAPI(parentId)
            break;

        case 'statements':
            actions.addStatement(parentId)
            break;

        case "openapp" :
             actions.addOpenApp(parentId)
            break;

        case "closeapp" :
             actions.addCloseApp(parentId)
             break;

              actions.addDom(parentId)
              break;

        case 'javascript':
              actions.addTechnology(node, parentId)
              break;

        case 'python':
              actions.addTechnology(node, parentId)
              break;

        case 'vision':
            actions.addTechnology(node, parentId)
            break;

        case 'r':
              actions.addTechnology(node, parentId)
              break;

        case "switchapp" :
             actions.addSwitchApp(parentId)
             break;

        case "addexternalflow":
              actions.addExternalFlow(parentId)
              break;

        case "createpivottable":
            actions.addPivotTable(parentId)
            break;

        case "convertxlsx":
            actions.addConvertXlsx(parentId)
            break;

        case "select":
             actions.addSelect(parentId)
             break

        case "outlook":
             actions.getMail(node,parentId)
             break;

        case "sendOutlookMail":
            actions.sendOutlookMail(node,parentId)
            break;

        case "msgbox":
            actions.addMsgbox(parentId)
            break;

        case "ask":
            actions.askAction(parentId)
            break

        case "sequence":
            actions.addSequence()
            break

        case "popup":
            actions.addPopup(parentId)
            break

        case "scroll":
            actions.addScroll(parentId)
            break;

        case "popup":
            actions.addPopup(parentId)
            break;

        case "back":
            actions.addBack(parentId)
            break;

        case "readtable":
            actions.addReadTable(parentId)
            break;

        case "sendSmtpMail":
            actions.sendSmtpMail(node,parentId)
            break;

        case "filtercolumn":
            actions.addFilterColumn(parentId)
            break;

        case "stringformat":
            actions.addString(parentId)
            break;

        case "dateformat":
            actions.addDateFormat(parentId)
            break;

        case "frame":
            actions.addFrame(parentId)
            break

        case "moveremotefile":
            actions.addFtpRMFile(parentId)
            break

        case "moveremotefiles":
            actions.addFtpRMFiles(parentId)
            break
            
        case "screenshot":
            actions.addScreenshot(parentId)
            break

        case "insertcolumn":
            actions.addInsertColumn(parentId)
            break
            
        case "connection":
            actions.addConnection(parentId)
            break;
            
        case "executequery":
            actions.addExecuteQuery(parentId)
            break;
        case "close":
            actions.addClose(parentId)
            break;    
        case "saplogon":
            actions.saplogon(parentId)
            break;    
        case "winactive":
            actions.addWinactive(parentId)
            break;
        
        case "stop":
            actions.addStop(parentId)
            break;
        case "createExcel":
            actions.addCreateExcel(parentId)
            break;
        case "pivotTable":
            actions.addPivotTable(parentId)    
            break;
        case "refreshExcel":
            actions.addRefreshExcel(parentId)
            break;
        case "dataScrape":
            actions.addDataScrape(parentId)    
        default:
            break;
    }
}
