import React, { Component } from 'react'
import { connect } from "react-redux";
import * as actions from "../../actions"
import { bindActionCreators } from 'redux'
import Draggable from "react-draggable"; // The default
import { action } from "./ManageActions"
import { setCurrentAction } from "../../../../../redux/actions/template"
import $ from "jquery";

import arrowLine from "../../../../../images/training/arrow-empty.png";

import excelIcon from "../../../../../images/training/excel-icon.png";

import mapperIcon from "../../../../../images/training/mapper-icon.png";

import TemplateItem from './TemplateItem';
import TemplateConfigure from './TemplateConfigure';



export class TemplateMapper extends Component {

    state = {
        count: 1,
        isConfigure: false,
        currentAction: {},
        templateName:""
    }

    handleZoomIn = () => {
        this.setState({ count: this.state.count + 0.1 });
        $(".rt-train-block").css("zoom", this.state.count + 0.1);
    };

    handleZoomOut = () => {
        this.setState({ count: this.state.count - 0.1 });
        $(".rt-train-block").css("zoom", this.state.count - 0.1);
    };


    handleDrop = (e) => {
        e.preventDefault()
        e.stopPropagation()

        const node = JSON.parse(e.dataTransfer.getData('Action'))
        // console.log("Action: ",node)
        this.addAction(node)

    }

    addAction = (node) => {
        action(node, this.props.actions)
    }

    handleDragOver(e) {
        e.preventDefault()
    }

    toggleTemplateConfigure = () => {

        this.setState({ isConfigure: !this.state.isConfigure })
    }

    onActionSelected = (action) => {

        this.props.setCurrentAction(action)

        this.toggleTemplateConfigure()

    }

    downloadObjectAsJson = () => {
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.props.flow.template));
        var downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", this.state.templateName  + ".json");
        document.body.appendChild(downloadAnchorNode); // required for firefox
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    }

    handleChange=(e)=>{

        this.setState({templateName:e.target.value})
    }


    render() {

        const { template } = this.props.flow
        return (
            // <div draggable className="right-content"
            // onDragOver={(e) => this.handleDragOver(e)}
            // onDrop={(e)=>{

            //    this.handleDrop(e)
            // }}>
            //     <div>FlowMapper</div>
            // </div>
            <React.Fragment>
                <TemplateConfigure open={this.state.isConfigure} />
                <div className='right-content'>
                    <div className="tp-title flex-title" style={{ marginTop: "15px", marginRight: "15px" }}>
                        <form class="form-contain" action="javascript:void(0)"  style={{marginLeft:"15px"}}>
                            <div class="frm-block">
                                <div className="ip-tl-label">
                                    <span style={{marginLeft:"15px"}} className="tl-label">Enter Template Name</span>
                                    <input
                                        type="text"
                                        name="text"
                                        placeholder="Enter"
                                        style={{width:"250px",height:"40px",marginLeft:"15px",padding:"10px"}}
                                        onChange={(e) => this.handleChange(e)}
                                        value={this.state.templateName}
                                    />
                                </div>
                            </div>
                            
                            
                        </form>

                        <button
                            onClick={this.downloadObjectAsJson}
                            className="btn btn-primary btn-outline"

                        >
                            Export to file
                        </button>
                    </div>

                    <div className='outer-drag flow-outer-drag scrollable'>
                        <Draggable>
                            <div className='rt-train-block'>
                                <div className='rt-block-flex'>

                                    {template.map((action, index) => (
                                        <div onClick={() => this.onActionSelected(action)}>
                                            <TemplateItem key={index} action={action} />
                                            <div className="arrow-divider arrow-start">
                                                <img src={arrowLine} />
                                            </div>
                                        </div>

                                    ))}






                                    <div className='rt-block-full'
                                        onDragOver={(e) => this.handleDragOver(e)}
                                        onDrop={(e) => {

                                            this.handleDrop(e)
                                        }}>

                                        <div className='rt-drag-block'>
                                            <h4>Drag & Drop Here</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Draggable>
                        {/* Zoom btns */}
                        <div className="zoom-btns">
                            <button
                                className="btn zoom"
                                onClick={() => this.handleZoomIn()}
                            >
                                +
                            </button>
                            <button
                                className="btn zoom-out"
                                onClick={() => this.handleZoomOut()}
                            >
                                -
                            </button>
                        </div>
                    </div>
                </div>

            </React.Fragment>


        )
    }
}
const mapStateToProps = (state) => ({

    flow: state.templateReducer
});

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(actions, dispatch),
    setCurrentAction: bindActionCreators(setCurrentAction, dispatch)

})

export default connect(mapStateToProps, mapDispatchToProps)(TemplateMapper);