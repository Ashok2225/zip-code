import React from 'react'
import ActionComponent from './ActionComponent'
import libraryList from './libraryList'
import './index.css'

const filterData = (data, search) => {
  let results = []
  for (let o of data) {
    let itr = { ...o }
    if (itr.nodes) {
      let childNodes = []
      for (let iterator of itr.nodes) {
        let itr1 = { ...iterator }
        if (itr1.nodes && itr1.nodes.length > 0) {
          itr1["nodes"] = itr1.nodes.filter(function (ob) {
            return (ob.label.toUpperCase().includes(search.toUpperCase()))
          })
        }
        if (itr1.nodes) {
          if (itr1.nodes.length > 0) {
            childNodes.push(itr1)
          } else if (itr1.nodes.length === 0 && (itr1.label.toUpperCase().includes(search.toUpperCase()))) {
            childNodes.push(iterator)
          }
        }
        else{
          if (itr1.label.toUpperCase().includes(search.toUpperCase())){
            childNodes.push(iterator)
          }
        }
      }
      itr["nodes"] = childNodes
    }
    if (itr.nodes.length > 0) {
      results.push(itr)
    }
    else if (itr.nodes.length === 0 && (itr.label.toUpperCase().includes(search.toUpperCase()))) {
      results.push(o)
    }
  }
  return results
}

class ActionLibrary extends React.Component {
  constructor(props) {
    super(props)
    this.state={
      search:"",
      actions : []
    }
  }

  componentWillMount(){
    this.setState({
      actions:[...libraryList]
    })
  }

  handleChange(e){
    let search = e.target.value
    let l = libraryList
    let newList = []
    if(search != ''){
      newList = filterData(l,search)
    }else{
      newList = libraryList
    }
    this.setState({
      search : e.target.value,
      actions : newList
    })
  }

  render() {
    return (
      <div className = "action-library task-list">
        <div className='al-header'>
          <h4 className="al-title">Actions Library</h4>
          <div className='al-search'>
            <input placeholder="search your action items" type="text" name="search" value={this.state.search} onChange={(e) => this.handleChange(e)}/>
          </div>
        </div>        
        <div className="action-library-items scrollable">
          {this.state.actions.map((item, index) => <ActionComponent key={index + 'action-component'} {...item} />)}
        </div>
      </div>
    )
  }
}

export default ActionLibrary
