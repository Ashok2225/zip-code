import React from 'react'
import stage1 from '../Images/stage1.png'
import stagelabel1 from '../Images/stagelabel1.png'
import desktop_automation1 from '../Images/desktop_automation1.png'
import keyboard_shortcuts from '../Images/keyboard_shortcuts.png'
import drag_and_drop from '../Images/drag_and_drop.png'
import open_app from '../Images/open_app.png'
import close_app from '../Images/close_app.png'
import switch_app from '../Images/switch_app.png'
import web_automation from '../Images/web_automation.png'
import open_web_page from '../Images/open_web_page.png'
import read_table from '../Images/read_table.png'
import popup from '../Images/popup.png'
import show from '../Images/show.png'
import snap from '../Images/snap.png'
import dom from '../Images/dom.png'
import scroll from '../Images/scroll.png'
import back from '../Images/back.png'
import general from '../Images/general.png'
import enter_key_strokes from '../Images/enter_key_strokes.png'
import echo from '../Images/echo.png'
import message_box from '../Images/message_box.png'
import clipboard from '../Images/clipboard.png'
import get_secret from '../Images/get_secret.png'
import get_credentials from '../Images/get_credentials.png'
import get_parameters from '../Images/get_credentials.png'
import read from '../Images/read.png'
import wait from '../Images/wait.png'
import http_api from '../Images/http_api.png'
import assign from '../Images/assign.png'
import ask from '../Images/ask.png'
import module1 from '../Images/module1.png'
import mouse from '../Images/mouse.png'
import conditions from '../Images/conditions.png'
import exception_handling from '../Images/exception_handling.png'
import excel from '../Images/excel.png'
import loops from '../Images/loops.png'
import jump_statement from '../Images/jump_statement.png'
import ocr from '../Images/ocr.png'
import files_folders from '../Images/files_folders.png'
import secure_ftp from '../Images/secure_ftp.png'
import csv from '../Images/csv.png'
import programming from '../Images/programming.png'
import string from '../Images/string.png'
import technology from '../Images/technology.png'
import mail_integration from '../Images/mail_integration.png'
import outlook from '../Images/outlook.png'
import imap from '../Images/imap.png'
import pop3 from '../Images/pop3.png'
import outlook2016 from '../Images/outlook2016.png'
import save_attachment from '../Images/save_attachment.png'
import cognitive from '../Images/cognitive.png'
import super_resolution from '../Images/super_resolution.png'
import image_classification from '../Images/image_classification.png'
import face_similarity from '../Images/face_similarity.png'
import calendar from '../Images/calendar.png'
import googleapi from '../Images/google.png'
import database from '../Images/cognitive.png'
import connection from '../Images/pop3.png'
import execute_query from '../Images/imap.png'


import './librarylist.css'


/**
 * This is the sample object structure for Action Library
   [
     {
     label : "",
     key : "" ,
     nodes : [
       {
         label : "",
         nodes : [
             {
               label:"",
               key : "",
               nodes : []
             },
             {
               ...
             }
         ],
         key : ''
       },
       {
         label : "",
         nodes : [],
         key : ""
       }
     ]
   },
   {
     ....
   }
 ]
*/


export default [
  // {
  //   label:"Stage",
  //   key: "stage",
  //   icon: <img className="icon-size" src={stage1}/>,
  //   nodes: [
  //     {
  //       label: "Stage",
  //       key: "sequence",
  //       icon: <img className="icon1-size" src={stagelabel1} />,
  //       tooltip: "Groups a set of related child actions."

  //     }
  //   ]
  // },
  {
    label: "Desktop Automation",
    key: "desktopautomation",
    icon:<img className="icon-size" src={desktop_automation1}/>,
    nodes: [
     
      {
        label: "Desktop Automation",
        key: "desktop",
        icon:  <img className="icon1-size" src={drag_and_drop}/>,
        tooltip: "Used to automate Desktop actions"
      },
     
      
    ]
  },
  {
    label: "Web Automation",
    key: "webautomation",
    icon: <img className="icon-size" src={web_automation}/>,
    nodes: [{
      label: "Web Automation",
      key: "webautomation",
      icon:<img className="icon1-size" src={open_web_page}/> ,
      tooltip: "Used to automate Web actions"
    }
  ]
  },
  {
    label: "General",
    icon: <img className="icon-size" src={general}/>,
    key: "general",
    nodes: [
      // {
      //   label: "Enter Keystrokes",
      //   key: "enterkeystrokes",
      //   icon: <img className="icon1-size" src={enter_key_strokes}/>,
      //   tooltip: "Sends keystrokes to a specified UI Element or selected image."
      // },
      // {
      //   label: "Stop",
      //   key: "stop",
      //   icon: <img className="icon1-size" src={pop3} />,
      //   tooltip: "Stops the execution of Action Flow."
      // },
      // {
      //   label: "Echo",
      //   key: "echo",
      //   icon: <img className="icon1-size" src={echo}/>,
      //   tooltip: "Prints a string or the value of a string variable to the Logs Panel."
      // },
      // {
      //   label:"Message Box",
      //   key: "msgbox",
      //   icon: <img className="icon1-size" src={message_box}/>,
      //   tooltip: "Displays a given text message as a pop-up. Optionally, set a time duration for the text message in seconds."
      // },
      // {
      //   label: "Clipboard",
      //   key: "clipboard",
      //   icon: <img className="icon1-size" src={clipboard}/>,
      //   tooltip: "Copies clipboard data to the given variable"
      // },
      // {
      //   label: "Get Secret",
      //   key: "GetSecret",
      //   icon: <img className="icon1-size" src={get_secret}/>,
      //   tooltip: "Gets secret text value from a specified asset by connecting to eManager console and copies to a defined variable."
      // },
      // {
      //   label: "Get Credentials",
      //   key: "GetCredentials",
      //   icon:<img className="icon1-size" src={get_credentials}/>,
      //   tooltip: "Gets credentials from a specified asset by connecting to eManager console and copy to defined variable(s)."
      // },
      // {
      //   label: "Get Parameters",
      //   key: "GetParameters",
      //   icon:<img className="icon1-size" src={get_parameters}/>,
      //   tooltip: "Gets parameters from an encoded string and stores it in a defined variable(s)."
      // },
      // {
      //   label: "Read",
      //   key: "read",
      //   icon: <img className="icon1-size" src={read}/>,
      //   tooltip: "Reads data from a specified web UI element and stores it in a defined variable."
      // },
      // {
      //   label: "Wait",
      //   key: "wait",
      //   icon: <img className="icon1-size" src={wait}/>,
      //   tooltip: "Pauses the execution of Action Flow for a specified amount of time (in seconds)."
      // },

      // {
      //   label: "HTTP API",
      //   key: "httpapi",
      //   icon: <img className="icon1-size" src={http_api}/>,
      //   tooltip: "Performs HTTP operations on the specified REST API."
      // },

      // {
      //   label: "Assign",
      //   key: "assign",
      //   icon: <img className="icon1-size" src={assign}/>,
      //   tooltip: "Allocates values to Action Flow variables."
      // },
      // {
      //   label: "Ask",
      //   key: "ask",
      //   icon:<img className="icon1-size" src={ask}/>,
      //   tooltip: "Pauses the execution of Action Flow for human input or verification."
      // },
      // {
      //   label: "Active Window",
      //   key:"winactive",
      //   icon:<img className="icon1-size" src={dom}/>,
      //   tooltip:"Activates the indicated window."
      // },
      // // {
      // //   label:"SAP Logon",
      // //   icon:<img className="icon1-size" src={secure_ftp}/>,
      // //   key: "saplogon",
      // //   description:"logon to the sap"

      // // },
      // {
      //   label: "Module",
      //   key: "module",
      //   icon: <img className="icon1-size" src={module1}/>,
      //   nodes: [{
      //     label: "Add External Flow", key: "addexternalflow",
      //     tooltip: "Invokes sub Action Flows from main Action Flow."
      //   }]
      // },
      // {
      //   label: "Mouse",
      //   icon:  <img className="icon1-size" src={mouse}/>,
      //   key: "mouse",
      //   nodes: [{
      //     label: "Click", key: "click", tooltip: `Clicks on the specified UI element or the image.
      //      `},
      //   { label: "Right Click", key: "rclick", tooltip: "Right clicks on the specified UI element or the image." },
      //   { label: "Double Click", key: "dclick", tooltip: "Double clicks on the specified UI element or the image." },
      //   { label: "Hover", key: "hover", tooltip: "Hovers on the specified UI element or the image." },
      //   {
      //     label: "Select", key: "select", tooltip: `Selects an item from a combo box or list box.
      //              `}
      //   ]
      // },
      {
        label: "Conditions",
        icon:  <img className="icon1-size" src={conditions}/>,
        key: "conditions",
        nodes: [
          { label: "If", key: "if", tooltip: "Models an If condition." },
          { label: "If/Else", key: "ifelse", tooltip: "Models an If-Else condition." },
          { label: "ElseIf", key: "elseif", tooltip: "Models an If-ElseIf-Else condition." },
        ]
      },
      {
        label: "Exception Handling",
        icon:  <img className="icon1-size" src={exception_handling}/>,
        key: "exceptionhandling",
        nodes: [{ label: "Try Catch", key: "trycatch", tooltip: "Encapsulates group of actions to be executed in exception handling block." }]
      },
      {
        label: "Excel",
        icon: <img className="icon1-size" src={excel}/>,
        key: "excel",
        nodes: [
          { label: "Excel Action", key: "excel", tooltip: "Opens an Excel workbook in background mode and provides a scope for Excel Activities. When the execution of this activity ends, the specified workbook and the Excel application will be closed." },
          

        ]
      },
      {
        label:  "Loops",
        icon: <img className="icon1-size" src={loops}/>,
        key: "loops",
        nodes: [{ label: "For", key: "for", tooltip: "Executes an action or series of actions for a specified number of iterations or until the target result is achieved." }]
      },
      {
        label: "Jump Statements",
        icon:  <img className="icon1-size" src={jump_statement}/>,
        key: "jumpstatements",
        nodes: [{ label: "Statements", key: "statements", tooltip: "Breaks or continues the loop." }]
      },
      // {
      //   label:  "OCR",
      //   icon:  <img className="icon1-size" src={ocr}/>,
      //   key: "ocr",
      //   nodes: [{ label: "Techforce.ai OCR", key: "techforce", tooltip: "Extracts text from the uploaded PDF or Word document files." }]
      // },
      // {
      //   label: "Files and Folders",
      //   icon: <img className="icon1-size" src={files_folders}/>,
      //   key: "filesandfolders",
      //   nodes: [{ label: "Create File/Folder", key: "createfilefolder", tooltip: "Creates a file/folder in the specified location." },
      //   { label: "Write to File", key: "writetofile", tooltip: "Appends or Overwrites the specified string or the value of a variable to the target file." },
      //   { label: "Copy File/Folder", key: "copyfilefolder", tooltip: "Copies or Moves a file from one location to another location." },
      //   { label: "Get Folder Contents", key: "getfoldercontents", tooltip: "Lists the contents of a folder based on the filter criteria." },
      //   { label: "Delete File/Folder", key: "deletefilefolder", tooltip: "Deletes the specified file or folder." },
      //   { label: "Read File", key: "readfile", tooltip: "Reads the content from a specified file and stores it into a variable." },
      //   { label: "Unzip Files", key: "unzipfiles", tooltip: "Extracts the contents of a zipped file."},
      //   { label: "Export To PDF", key: "exporttopdf", tooltip: "Converts .docx, .doc, .dotx, .odt, .xlsx, .xls file formats to PDF format."}]
      // },
      // {
      //   label: "Secure FTP",
      //   icon: <img className="icon1-size" src={secure_ftp}/>,
      //   key: "secureftp",
      //   nodes: [{ label: "Connect", key: "connect", tooltip: "Connects to a secure FTP server." },
      //   { label: "Get File", key: "getfile", tooltip: "Gets a single file from the specified remote path to local path." },
      //   { label: "Put File", key: "putfile", tooltip: "Puts a single file from the specified local path to remote path." },
      //   { label: "Get Files", key: "getfiles", tooltip: "Gets multiple files from the specified remote path to local path." },
      //   { label: "Put Files", key: "putfiles", tooltip: "Puts multiple files from the specified local path to remote path." },
      //   { label: "Delete", key: "delete", tooltip: "Deletes file from the specified path." },
      //   { label:"Delete Files",key:"Mdelete",tooltip:"Deletes multiple files from the specified path."},
      //   { label:"Move Remote File",key:"moveremotefile",tooltip:"Moves a remote file from one location to another location."},
      //   { label:"Move Remote Files",key:"moveremotefiles",tooltip:"Moves remote files from one location to another location."},
      //   { label: "Create New Folder",key:"ftpcreatefolder", tooltip:"Creates remote directory specified by path." },
      //   { label: "Delete Folder",key:"ftpdeletefolder", tooltip:"Deletes remote directory specified by path." }
      //   ]
      // },
      // {
      //   label: "CSV",
      //   icon:<img className="icon1-size" src={csv}/>,
      //   key: "csv",
      //   nodes: [{ label: "CSV Header", key: "csvheader", tooltip: "Creates a header row in the specified CSV file." },
      //   { label: "CSV Row", key: "csvrow", tooltip: "Creates a data row in the specified CSV file." }]
      // }
      ]
  },
  {
    label:"Google APIs",
    icon:<img className="icon-size" src={googleapi}/>,
    key:"googleapis",
    nodes: [
      // {label: "API Configuration", key: "apiconfiguration", tooltip: "Configures the API to use the service."},
    {
      label: "Spreadsheet API",
      icon: <img className="icon1-size" src={excel}/>,
      key: "googlecalendar",
      nodes: [
        { label: "Spreadsheet", key: "spreadsheet", tooltip: "Creates a spreadsheet."},
       
       ]
    },
    // {
    //   label: "Calendar API",
    //   icon: <img className="icon1-size" src={calendar}/>,
    //   key: "googlecalendar",
    //   nodes: [
    //   { label: "Create Event", key: "createevent", tooltip: "Creates a new event." },
    //   { label: "Modify Event", key: "modifyevent", tooltip: "Modifies the details of an event. Fields with the specified values will be updated." },
    //   { label: "Delete Event", key: "deleteevent", tooltip: "Deletes the specified event." }]
    // },
    // { label: "Send Message to Google Chatbot", key: "sendmessagetochatbot", tooltip: "Send a message to Google ChatBot."}
  ]
  },
//   {
//     label: "Programming",
//     icon: <img className="icon-size" src={programming}/>,
//     key: "programming",
//     nodes: [
//       {
//         label:  "Variables",
//         icon: <img className="icon1-size" src={string}/>,
//         key: "variables",
//         nodes: [{ label: "String Format", key: "stringformat", tooltip: "Modifies a string using string operations." },
//                 { label: "Date Format", key: "dateformat", tooltip: "Formats a date using date functions." }]
//       },
//       {
//         label: "Technologies",
//         icon: <img className="icon1-size" src={technology}/>,
//         key: "technologies",
//         nodes: [{ label: "JavaScript", key: "javascript", code: `
// const os = require('os')

// function printHostname() {
//     console.log(os.hostname())
// }

// printHostname()          
//         `, tooltip: "Encapsulates custom javascript code blocks." },
//         { label: "Python", key: "python", code: `
// import socket

// def print_hostname():
//     print(socket.gethostname())
    
// print_hostname()
// `, tooltip: "Encapsulates custom python code blocks." },
//         // { label: "R", key: "r", tooltip: "Encapsulates custom R code blocks." },
//         { label: "AutoHotkey", key: "vision", code: `
// MsgBox, %A_ComputerName%        
//         `,tooltip: "Encapsulates custom AutoHotKey code blocks." }]
//       }]
//   },
  {
    label: "Mail Integration",
    icon: <img className="icon-size" src={mail_integration}/>,
    key: "mailintegration",
    nodes: [
      // {
      //   label:  "Outlook",
      //   icon:  <img className="icon1-size" src={outlook}/>,
      //   key: "outlook",
      //   nodes: [{ label: "Config", key: "outlookConfig", tooltip: "User can configure OUTLOOK Server using this action item" },
      //   { label: "Read Mail", key: "readmailoutlook", tooltip: "User can READ mails from a specific email ID or all mails in INBOX" },
      //   { label: "Send Mail", key: "sendmail", tooltip: "User can SEND mails from a specific email ID" }]
      // },
      {
        label: "Outlook",
        icon: <img className="icon1-size" src={outlook2016}/>,
        key: "outlook2016",
        nodes: [{ label: "Outlook Mail", key: "outlook", tooltip: "Reads email from an Outlook mail box based on the given filter criteria." },
       ]
      },
     
    ]
  },
  {
    label: "Database",
    key: "database",
    icon: <img className="icon1-size" src={database} />,
    nodes: [
      {
        label: "Connection",
        key: "connection",
        icon:<img className="icon1-size" src={connection} />, 
        tooltip: "Connects to MySQL or PostgresQL database."
      },
      {
        label: "Execute Query",
        key: "executequery",
        icon: <img className="icon1-size" src={execute_query} />,
        tooltip: "Executes SQL query on the connected database."
      }
    ]
  }
  // ,
  // {
  //   label: "Cognitive",
  //   key: "cognitive",
  //   icon: <img className="icon-size" src={cognitive}/>,
  //   nodes: [
  //     {
  //       label:"Super Resolution",
  //       key: "superresolution",
  //       icon:<img className="icon1-size" src={super_resolution}/>,
  //       tooltip: "This action item enhances USER uploaded pic into high resolution"
  //     },
  //     {
  //       label: "Image Classification",
  //       key: "imageclassification",
  //       icon: <img className="icon1-size" src={image_classification}/>,
  //       tooltip: "This action item classifies different objects in a pic uploaded by USER"
  //     },
  //     {
  //       label: "Face Similarity",
  //       key: "facesimilarity",
  //       icon: <img className="icon1-size" src={face_similarity}/>,
  //       tooltip: "This action item recognises similarity between two images"
  //     }
  //   ]
  // }
]
