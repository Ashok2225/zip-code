import React from 'react'
import TreeView from 'react-treeview'
import './react-treeview.css'

/**
 * This compomnet display the tree view
 */

class ActionComponent extends React.Component {
    constructor (props) {
        super (props)
        this.handleClick = this.handleClick.bind(this)
    }

    state = {
        isHover: false,
        toolTipName: "",
        toolTipText: "",
        toolTipPos: {
            x: 0,
            y: 0,
        }
    };

    onHoverHandler = (e, name, text) => {
        let newToolTipPos = {
            x: e.clientX,
            y: e.clientY
        };
        this.setState({isHover: true, toolTipPos: newToolTipPos, toolTipName: name, toolTipText: text});
        console.log(e.clientX, e.clientY);
    }

    offHoverHandler = () => {
        let newToolTipPos = {
            x: 0,
            y: 0
        };
        this.setState({isHover: false, toolTipPos: newToolTipPos, toolTipName: "", toolTipText: ""});
    }

    handleDragStart(e, entry) {
       
      e.dataTransfer.setData('Action', JSON.stringify(entry))
      //my change
      let newToolTipPos = {
        x: 0,
        y: 0
        };
        this.setState({isHover: false, toolTipPos: newToolTipPos, toolTipName: ""});
    }

    /**
     * This method exicute collapsed folder
     * @param {i} //this is index
     */
    handleClick(i){
        console.log("")
    }
    /**
    * This React component is to iterate over the library list and implemented draggable for each nested list item.
    */

    render() {
        //to render tooltip
        let tooltip = null;

        if (this.state.isHover) {
            //when tooltip renders near end of window
            //then pushes tooltip box upwards slightly
            let heightFix = -20;
            // if (this.state.toolTipPos.y+150>screen.height) {
            //     heightFix = -55;
            // }

            tooltip = (
                <div>
                <div className="arrow-left" style={{left: `${this.state.toolTipPos.x+45.5}px`,top: `${this.state.toolTipPos.y}px`}}></div>
                <div className="arrow-left-inner" style={{left: `${this.state.toolTipPos.x+46}px`,top: `${this.state.toolTipPos.y}px`}}></div>
                <div className="toolTipStyle" style={{left: `${this.state.toolTipPos.x+50}px`,top: `${this.state.toolTipPos.y+heightFix}px`}}>
                    <h3 className="tool-tip-text-title">{this.state.toolTipName}</h3>
                    <p className="tool-tip-text">{this.state.toolTipText}</p>
                </div>
                </div>
            );
        }
        else if (!this.state.isHover) {
            tooltip = null;
        }




    return(
        <div>
            <TreeView key={"main"} nodeLabel={
                <span className="node" style={{ paddingTop: "3px", marginLeft: "3px", fontWeight: 1000, color: "#666666", display: "flex" }}>
                    {this.props.icon}<label style={{ paddingTop: "1.5%", paddingLeft: "7px" }}>{this.props.label}</label>
                </span>}
                defaultCollapsed={false}>
                {
                    this.props.nodes ?
                        this.props.nodes.map((entry1, index) => {
                            return <div key={index}>
                                {
                                    entry1.nodes ?
                                        <TreeView nodeLabel={<span className="node" style={{ marginTop: "3px", marginLeft: "3px", color: "#666666", display: "flex" }}>
                                            {entry1.icon}<label style={{ marginTop: "3px", marginLeft: "3px" }}>{entry1.label}</label>
                                        </span>}
                                            defaultCollapsed={false}
                                        >
                                            {entry1.nodes.map((entry2, index1) =>
                                                <div draggable className="tree-node-css" style={{ paddingLeft: "10px" }} key={entry2.key} onDragStart={(e) => this.handleDragStart(e, entry2)}
                                                    key={index + index1} onMouseOver={(e) => this.onHoverHandler(e, entry2.label, entry2.tooltip)}
                                                    onMouseOut={this.offHoverHandler}>{entry2.label}
                                                </div>)
                                            }
                                        </TreeView> :
                                        <div draggable className="tree-node-css" key={entry1.key} onDragStart={(e) => this.handleDragStart(e, entry1)} >
                                            <div className="node-icon-lable-jc"> <span style={{ marginBottom: "2px", marginLeft: "15px" }}>{entry1.icon}</span> <span onMouseOver={(e) => this.onHoverHandler(e, entry1.label, entry1.tooltip)}
                                                onMouseOut={this.offHoverHandler} style={{ marginLeft: "10px", marginTop: "3px" }}>{entry1.label}</span> </div>
                                        </div>
                                }
                            </div>
                        }) : null
                }
            </TreeView>
            {/* tooltip has visibility only if this.state.onHover is true */}
                {tooltip}
        </div>)
    }
}

export default ActionComponent
