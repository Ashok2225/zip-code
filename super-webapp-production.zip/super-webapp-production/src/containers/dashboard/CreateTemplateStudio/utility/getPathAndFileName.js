import os from 'os'
import upath from 'upath'

let getPathAndFileName = (filePath)=> {
    let fileName
    if(os.platform() == "win32" ){
       fileName= filePath.split('\\').pop()
    }
    else{
        fileName = filePath.split('/').pop()
    }
    return{
        filePath: upath.join(filePath, fileName ? fileName:"flow"),
        fileName: fileName
    }
}

export default getPathAndFileName