export var conditions = [
    {
        id:"contain",
        label:"contain"
    },
    {
        id:"not contain" ,
        label:"not contain",
    },
    {
        id:"equal to",
        label:"equal to (==)"
    },
    {
        id:"not equal to",
        label:"not equal to (!=)"
    },
    {
        id:"more than",
        label:"more than / greater than (>)",
    },
    {
        id: "more than or equal to",
        label:"more than or equal to (>=)"
    },
    {   
        id:"less than",
        label:"less than / lesser than (<)",
    },
    {
        id:"less than or equal to",
        label: "less than or equal to ( <= )",
    },
    {
        id:"custom condition",
        label:"Custom Condition"
    }
   
]