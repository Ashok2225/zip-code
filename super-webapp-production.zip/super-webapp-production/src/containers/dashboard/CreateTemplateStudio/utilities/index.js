import os from 'os'
import path from 'path'
import fs from 'fs'
import upath from 'upath'
import hash from 'object-hash'
import { keywords } from "../utility/keywords"

export const objToArr = (obj, seq = null) => {
    let order = seq ? seq : Object.keys(obj)
    return order.map(key => obj[key])
}

export const validateTab =(tab)=>{
    let tabKeys = ["actions", "currentAction", "dirPath", "flowPath", "id", "logs", "sequence", "variables"]
    let isValid = true
    for (const iterator of tabKeys) {
        isValid = tab.hasOwnProperty(iterator)
        if(!isValid) break;
    }
    return isValid
}

export const convertPath = (_path)=>{
    // if(os.platform() === "win32"){
    //     if(path.sep === '\\'){
    //         let temp = _path.replace(/\\/g,'\\\\' )
    //         return temp
    //     }else{
    //         return _path
    //     }
    // }
    return upath.normalize(_path)
}

export const isSave = (actualTab) =>{
    try {
        let read = fs.readFileSync(actualTab.flowPath + '.json', 'utf8')
        let savedTab = JSON.parse(read)
        let saveTabData = {
            ...savedTab.actions, ...savedTab.variables
        }
        let actualTabData = {
            ...actualTab.actions, ...actualTab.variables
        }
        let savedHashcode = hash(saveTabData)
        let newHashcode = hash(actualTabData)
        if( savedHashcode !== newHashcode ){
            return true
        }
        else{
            return false
        }
    } catch (error) {
        console.log("error while checking for saving",error);
        return false
    }
}

// function getKeywords(){
//     let read = fs.readFileSync(`${__static}/keywords.json`, 'utf8');
//     return JSON.parse(read).keywords;
// }

function hasDuplicates(array){
    return (new Set(array)).size !== array.length;
}
function getDuplicates(array){
    let duplicate_variables =[]
    for(let i=0;i<array.length;i++){
        for(let j=i+1;j<array.length;j++){
                  if(array[i]==array[j]){                  
                           if(!duplicate_variables.includes(array[i])){
                                duplicate_variables.push(array[i])
                           }
                  }
        }
}return duplicate_variables
}
export const variableCheck = (varName, variables) => {
    
    if (varName.length === 0){
        return { valid : false, msg : "Variable name cannot be empty" }
    }
    if(varName.length > 0 && varName.trim().includes(" ")){
        return { valid : false, msg: "Variable name should not have spaces" }
    }
    if (keywords.indexOf(varName.toLowerCase()) !== -1) {
        return { valid: false, msg: `"${varName}" is keyword cannot be a variable` }
    }
    let keys = Object.keys(variables)
    let created_variables = keys.map(var_id => variables[var_id].name)
    if (hasDuplicates(created_variables)) {
        let vars = getDuplicates(created_variables)        
        return { valid : false, msg: `Variable name of ${vars[0]} is already taken` }
    }
    return {valid : true}
}
export const parameterCheck = (paramName, parameters) => {
    if(!parameters){
        return { valid: true };
    }
    if (paramName.length === 0){
        return { valid : false, msg : "Parameter name cannot be empty" }
    }
    if(paramName.length > 0 && paramName.trim().includes(" ")){
        return { valid : false, msg: "Parameter name should not have spaces" }
    }
    if (keywords.indexOf(paramName.toLowerCase()) !== -1) {
        return { valid: false, msg: `"${paramName}" is keyword cannot be a Parameter` }
    }
    let keys = Object.keys(parameters)
    let created_parameters = keys.map(param_id => parameters[param_id].name)
    if (hasDuplicates(created_parameters)) {
        let params = getDuplicates(created_parameters)        
        return { valid : false, msg: `Parameter name of ${params[0]} is already taken` }
    }
    return {valid : true}
}