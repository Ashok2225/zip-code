// const {ipcRenderer} = require('electron')
import { openDialog } from './openDialog';

export const openRecorder = (type) => {
  return (dispatch,getState) => {
    // let { tabs , currentTab } = getState()
    // let tab = tabs[currentTab]
    // if(type === 'web')
    //   if(tab)
    //     ipcRenderer.send('open-recorder', 'web')
    //   else
    //     dispatch(openDialog("actions"))
    // else if(type === 'desktop'){
    //   ipcRenderer.send('open-recorder', 'desktop')
    // }
  }
}
