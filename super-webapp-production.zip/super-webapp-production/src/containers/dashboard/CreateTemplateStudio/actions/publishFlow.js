const { makeZip } = require('./makeZip');
const fs = require('fs');
const axios = require('axios');
const path = require('path');

export const publishFlow = (access_token) => {
    return async (dispatch, getState) => {
        let {tabs, currentTab} = getState()
        let tab = tabs[currentTab];
        if(tab.dirPath && tab.flowPath){
          try{
            makeZip(tab.dirPath);
          }catch(e){
            console.log(e)
          }
        }
      }
}