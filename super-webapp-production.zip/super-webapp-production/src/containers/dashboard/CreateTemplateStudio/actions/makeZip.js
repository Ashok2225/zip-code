// const fs = require('fs');
// const path = require("path");
// const archiver = require('archiver');

// export const makeZip = (folderPath) => {
    
//     let filename = path.basename(folderPath);
//     let output = fs.createWriteStream(folderPath + `/${filename}.zip`);
//     let archive = archiver('zip', {
//     zlib: { level: 9 } // Sets the compression level.
//     });

//     fs.readdirSync(folderPath).forEach(file => {
//         if(file.endsWith("png")){
//             // let file_stream = fs.createReadStream(`${folderPath}/${file}`);
//             archive.append(fs.createReadStream(`${folderPath}/${file}`), { name: `${filename}/${file}` });
//         }
//         if(file.endsWith("json")){
//             let file_stream = fs.createReadStream(`${folderPath}/${file}`);
//             archive.append(file_stream, { name: `${filename}/${file}` });
//             let jsonData = JSON.parse(fs.readFileSync(`${folderPath}/${file}`, 'utf-8'))
//             jsonData.sequence.forEach(action => {
//                 let subActions = jsonData.actions[action].subActions;
//                 subActions.forEach(act => {
//                     if(jsonData.actions[act].key === "addexternalflow"){
//                         recursiveZipCreation(jsonData.actions[act].path.dirPath, archive, folderPath)
//                         // fs.readdirSync(jsonData.actions[action].path).forEach(f)
//                     }
//                 }) 
//             })
//         }
//       })

//     archive.finalize();

//     archive.pipe(output);

//     output.on('close', function() {
//         console.log(archive.pointer() + ' total bytes');
//         console.log('archiver has been finalized and the output file descriptor has closed.');
//         return true
//       });
       
//       // This event is fired when the data source is drained no matter what was the data source.
//       // It is not part of this library but rather from the NodeJS Stream API.
//       // @see: https://nodejs.org/api/stream.html#stream_event_end
//       output.on('end', function() {
//         console.log('Data has been drained');
//       });
       
//       // good practice to catch warnings (ie stat failures and other non-blocking errors)
//       archive.on('warning', function(err) {
//         if (err.code === 'ENOENT') {
//           // log warning
//         } else {
//           // throw error
//           throw err;
//         }
//       });
       
//       // good practice to catch this error explicitly
//       archive.on('error', function(err) {
//         throw err;
//       });
//       // pipe archive data to the file
// }

// const recursiveZipCreation = (folderPath, archive, mainFolder) => {
//     let mainFolderName = path.basename(mainFolder);
//     let filename = path.basename(folderPath);
//     fs.readdirSync(folderPath).forEach(file => {
//         // let op = `${mainFolder}/${mainFolderName}/${filename}/${file}`;
//         // console.log(op);
//         if(file.endsWith("png")){
//             archive.append(fs.createReadStream(`${folderPath}/${file}`), { name: `${mainFolderName}/${filename}/${file}`});
//         }
//         if(file.endsWith("json")){
//             let file_stream = fs.createReadStream(`${folderPath}/${file}`);
//             archive.append(file_stream, { name: `${mainFolderName}/${filename}/${file}` });
//             let jsonData = JSON.parse(fs.readFileSync(`${folderPath}/${file}`, 'utf-8'));

//             jsonData.sequence.forEach(action => {
//                 let subActions = jsonData.actions[action].subActions;
//                 subActions.forEach(act => {
//                     if(jsonData.actions[act].key === "addexternalflow"){
//                         recursiveZipCreation(jsonData.actions[act].path.dirPath, archive, mainFolder)
//                         // fs.readdirSync(jsonData.actions[action].path).forEach(f)
//                     }
//                 }) 
//             })
//         }
//     })
// }
