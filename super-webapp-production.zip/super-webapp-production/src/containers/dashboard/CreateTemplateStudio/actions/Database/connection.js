import uuid from 'uuid/v1'
import * as databseConstants from '../../constants/Database'
import { updateTab , addActionInTab} from "../Tabs"
import crypto from 'crypto'
import { updateTemplateAcions} from "../../../../../redux/actions/template"
export function encrypt3DES(data, key){
  const md5Key = crypto.createHash("md5").update(key).digest('hex').substr(0, 24);
  const cipher = crypto.createCipheriv("des-ede3", md5Key, "");
 
  let encrypted = cipher.update(data, "utf8", "base64");
  encrypted += cipher.final("base64");
  return encrypted;
}

export const addConnection = (parentId = null) => {
  return (dispatch, getState) => {
   
    let action = {
      id : uuid(),
      type : databseConstants.DB_CONNECTION,
      parentId : parentId,
      label : "DB Connection",
      key : "connection",
     isSHow:false
    }
  
    dispatch(updateTemplateAcions(action))
  }
}

export const editConnection= (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let dbAction = tab["actions"][tab.currentAction]
    let temp = {
      ...dbAction,
      ...payload
    }
    let obj = {
            "host": temp.host,
            "username": temp.username,
            "password": temp.password,
            "port":temp.port,
            "database": temp.databasename,
            "type": temp.db_type,
            "sid":temp.sid,
            "servicename":temp.servicename,
            "selectorType":temp.selectorType,
            "isFIPS":temp.isFIPS
    }
    if(temp.db_type!="mssql"){
      temp.status = temp.host!="" && temp.username!="" && temp.password!="" && temp.port !="" && (temp.databasename != "" || temp.servicename!="" || temp.sid!="") && temp.db_type !="" 
    }
    else{
      temp.status = temp.selectorType!="" && temp.host!="" && temp.databasename != "" && (temp.selectorType == "winSelector" || (temp.username!="" && temp.password!= "")) && temp.db_type !=""
    }
 
    let buff = JSON.stringify(obj);
    let db_token = encrypt3DES(buff, process.env.USERNAME); 
    
    tab["actions"][tab.currentAction] = {
      ...temp,
      db_token:db_token,
      instruction : `db_token ="${db_token}"`,
      description : ``
    }    
    dispatch(updateTab(tab))
  }
}
