import uuid from 'uuid/v1'
// import { remote } from 'electron'
import * as databseConstants from '../../constants/Database'
import { updateTab, addActionInTab } from "../Tabs"
import { warningMsg } from '../openDialog'
import { updateTemplateAcions} from "../../../../../redux/actions/template"


export const addExecuteQuery = (parentId = null) => {
  return (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: databseConstants.DB_EXECUTE_QUERY,
      parentId: parentId,
      label: "DB Execute Query",
      key: "executequery",
      isShow: false
    }
   
    dispatch(updateTemplateAcions(action))

  }
}

export const editExecuteQuery = (payload) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // let dbAction = tab["actions"][tab.currentAction]
    // let temp = {
    //   ...dbAction,
    //   ...payload
    // }
    // if(temp.query !=""&&temp.variable!=""){
    //     temp.status=true
    // }
    // else{
    //     temp.status=false
    // }
    // let instruction = `api_config = {method:'POST', header:['Content-Type:application/json'], body:{'db_token':'\`db_token\`', 'query':'${temp.query}', 'with_column_names':${temp.withColumns}}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/new_query
    //                    ${temp.variable} = api_json.data`

    // tab["actions"][tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `${temp.query}`
    // }
    // dispatch(updateTab(tab))
  }
}
