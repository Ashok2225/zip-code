// import * as CheckConstants from '../constants/Check'
// import { updateTab, addTab } from "./Tabs/tabs"

// export const addCheck = (id, payload = {}) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let { currentFlow } = currentTab
//     let index = tabs.findIndex(obj => (obj.id === currentTab.id))
//     switch (currentFlow.type){
//       case "IFELSE":
//         addInnerConditionFind(tabs[index].flow, currentFlow.id,{id:id,...payload})
//         break;
//       case "LOOPS":
//         addInnerLoop(tabs[index].flow, currentFlow.id,{id:id, type:CheckConstants.CHECK, ...payload})
//         break;
//       default :
//         if(currentTab.id && tabs.length > 0){
//           tabs[index].flow = [
//             ...tabs[index].flow,
//             {
//               ...payload,
//               type: CheckConstants.CHECK,
//               id: id,
//               Check:payload.Check,
//               instruction: `Check ${payload.variable} ${payload.condition} ${payload.value} | ${payload.ifTrue} |${payload.ifFalse}`
//             }
//           ]
//         }else{
//           dispatch(addTab())
//         }
//     }
//     dispatch(updateTab(tabs))
//   }
// }

// export const editCheck = (id, payload = {}) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let index = tabs.findIndex(obj=>(obj.id===currentTab.id))
//     innerConditionFind(tabs[index], tabs[index].flow, id, payload)
//     dispatch(updateTab(tabs))
//   }
// }

// function addInnerConditionFind(instruction, id, payload) {

//   for (let obj of instruction) {
//     if (obj.id === id) {
//       if(obj.isThen){
//         obj.then = [...obj.then, {
//           type: CheckConstants.CHECK,
//           ...payload
//         }]
//       }
//       else if(obj.isElse){
//         obj.else = [...obj.else, {
//           type: CheckConstants.CHECK,
//           ...payload
//         }]
//       }
//       else{
//         obj.then = [...obj.then, {
//           type: CheckConstants.CHECK,
//           ...payload
//         }]
//       }

//       break;
//     }
//     if (obj.type === "IFELSE") {
//       addInnerConditionFind(obj.then, id, payload)
//       addInnerConditionFind(obj.else, id, payload)
//     }
//     if (obj.type === "LOOPS") {
//        addInnerConditionFind(obj.loopBody, id, payload)
//     }
//   }
// }

// function innerConditionFind(instruction,flow ,id, payload){
//   for(let obj of flow ){
//     if(obj.id === id){
//       obj.value = payload.value
//       obj.variable = payload.variable
//       obj.condition = payload.condition
//       obj.ifelse = payload.ifelse
//       obj.xpath = payload.xpath
//       obj.ifTrue = payload.ifTrue,
//       obj.ifFalse = payload.ifFalse
//       if (obj.ifelse === "custom")
//         obj.instruction = `Check ${payload.variable} ${payload.condition} ${payload.value}| ${payload.ifTrue} |${payload.ifFalse}`
//       else if (obj.ifelse === "present") {
//           obj.instruction = `Check present('${payload.xpath}') | ${payload.ifTrue} |${payload.ifFalse}`
//       }
//       else if (obj.ifelse === "visible"){
//           obj.instruction = `Check visible('${payload.xpath}') | ${payload.ifTrue} |${payload.ifFalse}`
//       }
//       else if (obj.ifelse === "count"){
//           obj.instruction = `Check count('${payload.xpath}') ${payload.condition} ${payload.value} | ${payload.ifTrue} |${payload.ifFalse}`
//       }
//       instruction.currentFlow = {
//         ...instruction.currentFlow,
//         ...obj
//       }
//       break;
//     }
//     if(obj.type === "IFELSE"){
//       innerConditionFind(instruction, obj.then, id, payload)
//       innerConditionFind(instruction, obj.else, id, payload)
//     }
//     if (obj.type === "LOOPS") {
//       innerConditionFind(instruction, obj.loopBody, id, payload)
//     }
//   }
// }
