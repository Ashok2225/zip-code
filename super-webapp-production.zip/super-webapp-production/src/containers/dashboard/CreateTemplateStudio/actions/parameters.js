import { updateTab, addTab, updateTabs } from "./Tabs"
import { warningMsg } from "./openDialog"

export const updateParameter = (payload,id) => {
  return (dispatch, getState) => {
    let { currentTab , tabs } = getState()
    if (currentTab && tabs ) {
        let tab =  tabs[currentTab]
        tab.parameters[id] = {
          ...tab.parameters[id],
          ...payload
      }
      dispatch(updateTab(tab))
    } 
  }
}
export const addParameter = (payload) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    if (currentTab && tabs.sequence.length > 0) {
      tab.parameters[payload.id] = payload
    } else {
      dispatch(addTab())
    }
    dispatch(updateTab(tab))
  }
}

export const removeParameters = (parameters) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    for (const iterator of parameters) {
      delete tab.parameters[iterator.id]
    }
    dispatch(updateTab(tab))
  }
}

export const selectAllParameters = (flag) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    let keys = Object.keys(tab.parameters)
    for (const iterator of keys) {
      tab.parameters[iterator]["checked"] = flag
    }
    dispatch(updateTab(tab))
  }
}

