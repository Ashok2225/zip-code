// var fs = require('fs');
// var archiver = require('archiver');
// const path = require('path')
// const fse = require('fs-extra')
// const  spawn  =  require('child_process').exec

// export const akeZip = (mypath,dispatch) => {
//   //segregating folder path
//   // let mypath = process.argv[2]
//   var res = mypath.split("/");
//   let file = res.pop()
//   let actucalFileName = file + '.zip'
//   let str = res.toString()
//   let replaced = str.replace(/,/g,'\\')
//   let newpath  = mypath + '.zip'
//   let destinationfile = path.join(mypath,actucalFileName)


//   // create a file to stream archive data to.

//   if (!fs.existsSync(destinationfile)) {  // checking for the zip file and deleting it before zipping

//   }else {

//     fs.unlink(destinationfile,function(err,data) {
//       if (!err) {

//       }
//     })

//   }

//   let myvar = path.join(__static,'Techforce', 'src','unx','zip.exe')

//   const zipped = spawn(`cd ${path.join(mypath,'..')} && ${myvar} -r ${actucalFileName} ${file}`)
//   zipped.stdout.on('data', (data) => console.log(data))
//   zipped.stderr.on('data', (data) => console.log(data))
//   zipped.on('close', (code) =>{
//      DeleteFile(destinationfile,replaced,actucalFileName)  //moving zip file inside the dir zipped
//   })

// }

// export const DeleteFile = (destinationfile,replaced,actucalFileName) =>{
//   if (!fs.existsSync(destinationfile)) {
//     fse.move(path.join(replaced,actucalFileName), destinationfile , 'utf8', function (err, data) {
//       if (err) {
//         console.log('err',err);
//       }
//     })
//   }else {
//     fs.unlink(destinationfile,function(err,data) {
//       if (!err) {
//         fse.move(path.join(replaced,actucalFileName), destinationfile , 'utf8', function (err, data) {
//           if (err) {
//             console.log(err);
//           }
//         })
//       }
//     })
//   }
// }
