// import * as logsConstants from '../constants/logs'
// import { updateTab } from "./Tabs"

// export const showLogs = (logs) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     if(running_flow_id){
//       let tab  = tabs[running_flow_id]
//       if(logs.includes("SyntaxError: Unexpected token '='") || logs.includes("SyntaxError: Invalid character:")){
//         tab.logs = tab.logs + "Variable declared in the flow is empty/reserved word. Please verify all the variables.... ";
//       }
//       else{
//         tab.logs = tab.logs + logs;
//       }
//       dispatch(updateTab(tab))
//     }
//   }
// }

// export const clearLogs = () => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let tab  = tabs[currentTab]
//     tab.logs = ""
//     dispatch(updateTab(tab))
//   }
// }