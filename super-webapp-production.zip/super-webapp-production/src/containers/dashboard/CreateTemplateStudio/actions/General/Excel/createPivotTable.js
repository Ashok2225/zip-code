import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addPivotTable = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''

    /**
    * If there is a parent Id then if that is open spread sheet, path of the
    * open spread sheet need to be added to this child action.
    */
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }

    let action = {
      id : uuid(),
      type : excelConstants.CREATE_PIVOT_TABLE,
      parentId : parentId,
      label : "Create Pivot Table",
      key : "createpivottable",
      allowNesting : false,
      path : path,
      sheetName : "",
      range : "",
      dataTable : '', 
      name:"",
      pivotTable:[],
      instruction : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editPivotTable = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // /**
    //   if the path of the parent spread sheet is updated then if this Append range
    //   is child under Open spread sheet so this actionId is passed else currentAction Id
    //   is updated.
    // */

    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // if((temp.path!=""&&temp.path!=".")&&temp.sheetName!=""){
    //   temp.status=true
    // }else{
    //   temp.status=false
    // }   
    // //  let reqBody =JSON.stringify({
    // //       filePath: temp.path,
    // //       sheetName: temp.sheetName,
    // //       range: temp.range,
    // //       dataTable: temp.dataTable,
    // //       pivotTable: temp.pivotTable,
    // //       title: temp.title,
    // //       name: temp.name
    // //   })
    //   let rows = ""
    //   let columns = ""
    //   let values = ""  
    //   let task = ""    
    //   temp.pivotTable.forEach((obj)=>{
    //     if(obj.type == 'ROW'){
    //        rows =rows+obj.name+","
    //     }else if(obj.type == 'COLUMN'){
    //        columns = columns+obj.name+","
    //     }else if(obj.type == "VALUES"){
    //        values = values+obj.name+","
    //        task = obj.function +","
    //     }
    //   })
    //   let reqBody = JSON.stringify({
    //     dir_path : temp.path,
    //     column:columns.slice(0,-1),
    //     row:rows.slice(0,-1),
    //     value:values.slice(0,-1),
    //     sheetName:temp.sheetName,
    //     range:temp.range,
    //     task:task.slice(0,-1),
    //     PivotSheetName:temp.title
    //   })      

    // let instruction = `api_config = {method:"POST", header:["Content-Type:application/json"], body:${reqBody}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/pivotTable
    //                    echo api_result`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description  : "creates pivot table"
    // }
    // dispatch(updateTab(tab))
  }
}
