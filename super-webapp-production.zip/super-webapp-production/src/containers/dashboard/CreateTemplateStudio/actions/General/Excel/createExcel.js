import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"
import { convertPath } from "../../../utilities"

export const addCreateExcel = (parentId = null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let path = ''
            // please refer to the appendRange.js
            if(parentId){
              let parentAction =  tab["actions"][parentId]
              if(parentAction.type==='OPEN_SPREADSHEET'){
                path = parentAction.path
              }
            }
            let action = {
              id : uuid(),
              type : excelConstants.CREATE_EXCEL,
              parentId : parentId,
              label : "Create Excel",
              key : "createExcel",
              allowNesting : false,
              path : path,
              sourcePath:"",
              fileName:"",
              variableName : '',
              instruction : "",
              description : "",
              status:false,
              breakpoint:false
            }
            tab = addActionInTab(tab, action, parentId)
            dispatch(updateTab(tab))
          }
}
export const editCreateExcel= (payload, actionId=null) => {
          return (dispatch, getState) => {
            // let { tabs, currentTab } = getState()
            // let tab = tabs[currentTab]
            // // please refer to the appendRange.js
            // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
            // let temp = {
            //   ...excelAction,
            //   ...payload
            // }
            // temp.sourcePath!="" && temp.fileName!=""?temp.status=true:temp.status=false
            
            // let sourcePath = convertPath(temp.sourcePath)
        
            // let instruction =  `api_config = {method:'GET', header:[], body:{}}
            //                     api ${remote.process.env.RPA_PYTHON_API}/api/v1/createExcel/?dir_path=${sourcePath}&name=${temp.fileName}
            //                     echo api_result`
            // tab["actions"][actionId ? actionId : tab.currentAction] = {
            //   ...temp,
            //   instruction : instruction,
            //   description : `create ${temp.fileName} in ${ temp.sourcePath }`
            // }
            // dispatch(updateTab(tab))
          }
        }
        