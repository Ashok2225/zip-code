import * as GetParamConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'
// this function is to add ftp Get container

export const AddGetParameters = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : GetParamConstants.GET_PARAMETERS,
      label : "Get Parameters",
      key : "GetParameters",
      allowNesting : false,
      variable : '',
      variableName : '',
      instruction : "",
      parentId:parentId,
      description:"",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
// this function is to edit ftp Get container
export const editGetParameters = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let getParamsAction = tab["actions"][currentAction]
        let temp = {
          ...getParamsAction,
          ...payload
        }
        temp.variable !== "" ? temp.status = true : temp.status = false
        
        tab.actions[currentAction] = {
          ...temp,
          instruction : `get params into ${temp.variable}`,
          description : `get params into ${temp.variable}`
        }
        dispatch(updateTab(tab))
      }
}
