import uuid from 'uuid/v1'

import * as configureConst from '../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../Tabs"

export const addAPIConfiguration = (parentId = null) => {
    return (dispatch, getState) => {
      let { tabs, currentTab } = getState()
      let tab = tabs[currentTab]
      let action = {
        id : uuid(),
        type : configureConst.API_CONFIGURATION,
        parentId : parentId,
        label : 'API Configuration',
        key : "apiconfiguration",
        allowNesting : true,
        subActions:[],
        description :  "",
        ApiKey: "",
        oAuthPath: "",
        saFilePath: "",
        selectorType:'apikey',
        status:false,
        breakpoint:false
      }
      tab = addActionInTab(tab, action, parentId)
      dispatch(updateTab(tab))
    }
  }

export const editAPIConfiguration= (payload, actionId=null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let configureAction = tab["actions"][actionId ? actionId : tab.currentAction]
            let temp = {
              ...configureAction,
              ...payload
            }

            if(temp.selectorType == "apikey"){
                temp.status = temp.ApiKey != ""
            }
            else if (temp.selectorType == "oauth"){
                temp.status = temp.oAuthPath != ""
            }
            else{
                temp.status = temp.saFilePath != ""
            }

            tab["actions"][actionId ? actionId : tab.currentAction] = {
              ...temp,
              instruction : `configure api using ${temp.selectorType}`,
              description : `configure api using ${temp.selectorType}`
            }
            dispatch(updateTab(tab))
          }
        }
        