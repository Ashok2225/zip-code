import { EditFtpDelete } from "./FtpDelete"
import { FtpEditGet } from "./FtpGet"
import { EditFtpMget } from "./FtpMget"
import { EditFtpMput } from "./FtpMput"
import { FtpEditPut } from "./FtpPut"
import { EditFtpMDelete } from "./FtpMdelete"
import {editFtpRMFile} from "./FtpRMFile"
import {editFtpRMFiles} from "./FtpRMFiles"
import {EditFtpCreateFolder} from "./FtpCreateFolder"
import {EditFtpDeleteFolder} from "./FtpDeleteFolder"


export const editScopeValues = (action,payload) => {
  console.log("action",action);
  return (dispatch,getState)=>{
    switch (action.type) {

      case 'FTP_DELETE':
        dispatch(EditFtpDelete(payload,action.id))
        break;

      case 'FTP_GET':
        dispatch(FtpEditGet(payload,action.id))
        break;

      case 'FTP_MGET':
        dispatch(EditFtpMget(payload,action.id))
        break;

      case 'FTP_MPUT':
        dispatch(EditFtpMput(payload,action.id))
        break;

      case 'FTP_PUT':
        dispatch(FtpEditPut(payload,action.id))
        break;

      case 'FTP_M_DELETE':
        dispatch(EditFtpMDelete(payload,action.id))
        break;

      case 'FTP_R_MOVE_FILES':
        dispatch(editFtpRMFiles(payload,action.id))
        break;

      case 'FTP_R_MOVE_FILE':
        dispatch(editFtpRMFile(payload,action.id))
        break;

      case 'FTP_CREATE_FOLDER':
        dispatch(EditFtpCreateFolder(payload,action.id))
        break;
      
      case 'FTP_DELETE_FOLDER':
        dispatch(EditFtpDeleteFolder(payload,action.id))
        break;
        
      default:
        break;
    }
  }
}
