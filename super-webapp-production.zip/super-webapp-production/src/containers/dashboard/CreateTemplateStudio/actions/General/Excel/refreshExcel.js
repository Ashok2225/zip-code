import uuid from 'uuid/v1'
import * as excelConstants from '../../../constants/General/Excel'
import {addActionInTab, updateTab} from '../../Tabs'

export const addRefreshExcel = (parentId= null)=>{
          return (dispatch,getState) =>{
                    let {tabs,currentTab}=getState()
                    let tab = tabs[currentTab]
                    let action = {
                              id : uuid(),
                              type : excelConstants.REFRESH_EXCEL,
                              parentId : parentId,
                              label : "Refresh Excel File",
                              key : "refreshExcel",
                              allowNesting: false,
                              path : "",
                              instruction : "",
                              description : "",
                              status:false,
                              breakpoint:false
                            }
                    tab= addActionInTab(tab, action, parentId)
                    dispatch(updateTab(tab))
          }
}
export const editRefreshExcel = (payload= {})=>{
          return (dispatch,getState) =>{

                  //   let {tabs,currentTab} = getState()
                  //   let tab = tabs[currentTab]
                  //   let {currentAction} = tab
                  //   let action = tabs[currentTab].actions[currentAction] 

                  //   let temp={
                  //             ...action,
                  //             ...payload
                  //   }
                  //  temp.filePath!=""?temp.status=true:temp.status=false
                  //   let instruction = `api_config = {method:'GET', header:[], body:{}}
                  //   api ${remote.process.env.RPA_PYTHON_API}/api/v1/refreshExcel?FilePath=${temp.path}`
                  //   tab.actions[currentAction] = {
                  //             ...temp,
                  //             instruction: instruction
                  //   }
                  //   dispatch(updateTab(tab))
          }

}