import * as CsvConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'


// this function is to add csv header container


export const addCsvHeader = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : CsvConstants.CSV_HEADER,
      label : "CSV Header",
      key : "csvheader",
      CsvFileName: "",
      value: [],
      variableName : '',
      instruction : "",
      parentId:parentId,
      description:"",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
// this function is to edit csv header container

export const editCsvHeader = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let CsvAction = tab["actions"][currentAction]
    let temp = {
      ...CsvAction,
      ...payload
    }
    temp.CsvFileName&&temp.value.length>0?temp.status=true:temp.status=false
    let CsvString = `csv_header = '`
    if (temp.value != undefined) {
      let v = temp.value.map((a,i)=>{
        console.log("a.value",a.value);
        CsvString = `${CsvString}"${a.value}"`
        if (i!=temp.value.length-1) {
          CsvString = CsvString + ','
        }

      })
      console.log("CsvString",CsvString);
    }
    let instruction = `${CsvString} \\r \\n' \ndump csv_header to ${temp.CsvFileName}`
    tab["actions"][actionId ? actionId : currentAction] = {
      ...temp,
      instruction : instruction,
      description : `${CsvString.split(" = ")[1]} in ${temp.CsvFileName}`
    }
    dispatch(updateTab(tab))
  }
}
