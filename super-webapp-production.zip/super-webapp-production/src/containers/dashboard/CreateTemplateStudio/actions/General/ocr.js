import uuid from 'uuid/v1'
import path from 'path'
import * as ocrConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"

export const addOcr = (node, parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : ocrConstants.OCR,
      parentId : parentId,
      label : node.label,
      key : node.key,
      allowNesting : false,
      selectorType : "locationSelector",
      imageCropSelector : '',
      single :"1",
      multiple : "",
      targetImageSelector : "",
      range : "all",
      pdffile : "",
      negate: false,
      variableName : 0,
      next_coordinate : {
        distance1 : -1,
        distance2 : -1,
        angle1 : -1,
        angle2 : -1,
      },
      source : {
        selectorType : "imgSelector",
        imgSelector : "",
        x1 : "",
        y1 : "",
        x2 : "",
        y2 : "",
           },
       target:{
         selectorType : "imgSelector",
         imgSelector : "",
         x1 : "",
         y1 : "",
         x2 : "",
         y2 : "",
       },
       formula:"",
       status:false,
       breakpint:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

/**
 * called from src\renderer\store\index.js when case "UPDATE_IMG_SELECTION"
 * @param  {[type]} payload This stores all the screenshot related information w.r.t "UPDATE_IMG_SELECTION".
 *                            Might contain other atributes that are exported from other functions as well.
 */
export const editOcr = (payload) => {
  return (dispatch, getState) => {    
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction, dirPath } = tab
    let ocrAction = tab["actions"][currentAction]
    let temp_img_data = {}
    if (payload.childType){
      temp_img_data = {
        [payload.childType]: {
          imgSelector: payload.imgSelector,
          x1: Math.round(payload.x),
          y1: Math.round(payload.y),
          x2: Math.round(payload.w),
          y2: Math.round(payload.h),
        }
      }
    }
    let temp = {
      ...ocrAction,
      ...payload,
      ...temp_img_data
    }
    temp.status = false
    if(temp.selectorType == "locationSelector"){
    //temp.x && temp.y && temp.w && temp.h!="" && temp.variableName !== 0 ? temp.status=true : temp.status=false
    temp.imgSelector!=null&& temp.variableName !== 0 ? temp.status=true : temp.status=false
    }
    else if(temp.selectorType=="screenSelector"){
      temp.source.imgSelector && temp.target.imgSelector !== "" && temp.variableName !== 0? temp.status=true : temp.status=false
    }
    else if(temp.selectorType=="imgSelector"){
      temp.file && temp.variableName !== 0? temp.status=true : temp.status=false
    }
    else if (temp.selectorType ==="pdfSelector"){
      if (temp.range === "single" ){
        temp.status = temp.single && temp.variableName!== 0 && temp.pdffile !== ""
      }
      else if (temp.range === "multiple"){
        temp.status = temp.multiple && temp.variableName!== 0 && temp.pdffile !== ""
      }
      else{
        temp.status = temp.variableName!== 0 && temp.pdffile !== ""
      }
    }
    if(temp.selectorType == "screenSelector") temp.imgSelector = ""
    if(payload.childType == 'target') {
      //Code that gets the mid point and calculates
      let source_mid_points = {x:0,y:0}
      let right_angle_coordinate_top = {x:0,y:0}
      let right_angle_coordinate_bottom = {x:0,y:0}
      let theta1 = 0
      let theta2 = 0
      let top_multiplier = 1
      let bottom_multiplier = 1

      source_mid_points['x'] = Math.round((temp.source.x2 + temp.source.x1)/2)
      source_mid_points['y'] = Math.round((temp.source.y2 + temp.source.y1)/2)

      top_multiplier = source_mid_points['y'] > temp.target.y1 ? -1 : 1
      bottom_multiplier = source_mid_points['y'] > temp.target.y2 ? -1 : 1

      right_angle_coordinate_top['x'] = temp.target.x1
      right_angle_coordinate_top['y'] = source_mid_points['y']
      right_angle_coordinate_bottom['x'] = temp.target.x2
      right_angle_coordinate_bottom['y'] = source_mid_points['y']

      let temp_delta_x = (temp.target.x1 - source_mid_points.x)
      let temp_delta_y = (temp.target.y1 - source_mid_points.y)

      let hypotenuse1 = Math.sqrt(Math.pow(temp_delta_x,2) + Math.pow(temp_delta_y,2))

      temp_delta_x = (right_angle_coordinate_top.x - temp.target.x1)
      temp_delta_y = (right_angle_coordinate_top.y - temp.target.y1)

      let opp_side1 = Math.sqrt(Math.pow(temp_delta_x,2) + Math.pow(temp_delta_y,2))

      temp_delta_x = (temp.target.x2 - right_angle_coordinate_bottom.x)
      temp_delta_y = (temp.target.y2 - right_angle_coordinate_bottom.y)

      let opp_side2 = Math.sqrt(Math.pow(temp_delta_x,2) + Math.pow(temp_delta_y,2))

      temp_delta_x = (source_mid_points.x - temp.target.x2)
      temp_delta_y = (source_mid_points.y - temp.target.y2)

      let hypotenuse2 = Math.sqrt(Math.pow(temp_delta_x,2) + Math.pow(temp_delta_y,2))

      theta1 = Math.asin(opp_side1/hypotenuse1)

      theta2 = Math.asin(opp_side2/hypotenuse2)

      console.log("source_mid_points",source_mid_points);
      console.log("right_angle_coordinate_top",right_angle_coordinate_top);
      console.log("right_angle_coordinate_bottom",right_angle_coordinate_bottom);
      console.log("opp_side1",opp_side1);
      console.log("opp_side2",opp_side2);
      console.log("hypotenuse1",hypotenuse1);
      console.log("hypotenuse2",hypotenuse2);

      temp = {...temp,
        next_coordinate : {
          distance1 : hypotenuse1,
          distance2 : hypotenuse2,
          angle1 : theta1,
          angle2 : theta2,
          top_multiplier : top_multiplier,
          bottom_multiplier : bottom_multiplier
        }
      }
      //checking code.
      let next_coordinate_function = (dis,theta,x,y) => {
        var result = {};

        result.x = Math.round(Math.cos(theta) * dis + x);
        result.y = Math.round(Math.sin(theta) * dis + y);

        return result;
      }


      let result_coordates = next_coordinate_function(hypotenuse1,theta1,source_mid_points.x,source_mid_points.y)
      let result_coordates2 = next_coordinate_function(hypotenuse2,theta2,source_mid_points.x,source_mid_points.y)

      console.log("---");
      console.log("result:");
      console.log(result_coordates.x,result_coordates.y);
      console.log("expected:");
      console.log(temp.target.x1,temp.target.y1);
      console.log("---");
      console.log("result:");
      console.log(result_coordates2.x,result_coordates2.y);
      console.log("expected:");
      console.log(temp.target.x2,temp.target.y2);
      console.log("---");
    }
    let instn = ""
    // categorizing the image type and storing the values in the respective keys.

    if (temp.selectorType === 'pdfSelector'){      
      if (temp.range === "all") {
        temp.rangeVal = "'ALL'"
      } else if (temp.range === "single") {
        temp.rangeVal = temp.single
      } else {
        temp.rangeVal = temp.multiple
      }
      instn = `"body":{"type":"pdf", "path": '${temp.pdffile}',"rangeVal":${temp.rangeVal}}`
    }
    else if(temp.selectorType === 'imgSelector'){
      instn = `"body":{"type":"img","path":'\`dirPath\`${temp.imageCropSelector}',"negate":${temp.negate}}`
    }
    else if(temp.selectorType === 'locationSelector'){
      instn = `"body":{"type":"img","selectorType":'location',"x":${temp.x},"y":${temp.y},"w":${temp.w},"h":${temp.h}}`
    }
    else if(temp.selectorType === 'screenSelector') {
      instn = `"body":{"type":"img","mode":"dynamic","path":'\`dirPath\`${temp.source.imgSelector}',"distance1":${temp.next_coordinate.distance1},"top_multiplier":${temp.next_coordinate.top_multiplier},"bottom_multiplier":${temp.next_coordinate.bottom_multiplier},"distance2":${temp.next_coordinate.distance2},"angle1":${temp.next_coordinate.angle1},"angle2":${temp.next_coordinate.angle2}}`
    }
    else{
      instn = `"body":{"type":"img","path":'\`dirPath\`${temp.imgSelector}',"negate":${temp.negate}}`
    }
    let instruction = `api_config = {method:'POST', header:['Content-Type:application/json'],${instn}}\napi ${process.env.RPA_PYTHON_API}/api/v1/ocr/\n${temp.variableName}=api_json.value`
    let description = `${temp.selectorType}`    
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : description
    }
    dispatch(updateTab(tab))
  }
}
