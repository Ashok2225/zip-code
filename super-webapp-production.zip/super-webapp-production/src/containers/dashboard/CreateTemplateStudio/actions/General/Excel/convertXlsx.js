import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"
import { convertPath } from "../../../utilities"

export const addConvertXlsx = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.CONVERT_XLSX,
      parentId : parentId,
      label : "Convert to XLSX",
      key : "convertxlsx",
      allowNesting : false,
      path : path,
      sourcePath:"",
      sheetName:"",
      fileName:"",
      variableName : '',
      instruction : "",
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editConvertXlsx = (payload, actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // temp.sourcePath!=""?temp.status=true:temp.status=false
    
    // let sourcePath = convertPath(temp.sourcePath)

    // let instruction =  `api_config = {method:'GET', header:[], body:{}}
    //                     api ${remote.process.env.RPA_PYTHON_API}/api/v1/convertXlsx?filePath=${temp.path}&source=${sourcePath}&fileName=${temp.fileName}
    //                     echo api_result`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `${temp.sourcePath}`+( temp.fileName ? ` to ${temp.fileName}`:``)
    // }
    // dispatch(updateTab(tab))
  }
}
