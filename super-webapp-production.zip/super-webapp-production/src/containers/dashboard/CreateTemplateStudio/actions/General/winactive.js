import uuid from 'uuid/v1'
import * as activeWindowConstants from '../../constants/'
import {addActionInTab,updateTab} from '../Tabs'

export const addWinactive = (parentId)=>{
          return(dispatch,getState)=>{
                    
                    let {tabs, currentTab} = getState()
                    let tab =tabs[currentTab]
                    let action = {
                              id : uuid(),
                              type : activeWindowConstants.ACTIVE_WINDOW,
                              label : 'Active Window',
                              key : "winActive",
                              allowNesting : false,
                              wait: "",
                              title:"",
                              parentId:parentId,
                              description:"waits until the required window actives",
                              status:false,
                              breakpoint:false
                            }
                   
                    tab =  addActionInTab(tab,action,parentId)         
                    dispatch(updateTab(tab))
          }
}
export const editWinActive = (payload={}) =>{
                    return(dispatch, getState)=>{
                              let {tabs, currentTab} = getState()
                              let tab = tabs[currentTab]
                              let {currentAction} = tab
                              let  winAction = tab.actions[currentAction]
                              let temp={
                                        ...winAction,
                                        ...payload
                              }
                              temp.wait!=""&&temp.title!=""?temp.status=true:temp.status=false
                              let instruction = `vision begin\nWinWait, ${temp.title}, ,${temp.wait}\nif ErrorLevel\n{\nMsgBox, WinWait timed out.\nreturn\n}\nelse\nWinMaximize \nvision finish;`
                              temp.instruction=instruction
                              tab.actions[currentAction]={
                                        ...temp
                              }
                              dispatch(updateTab(tab))
                    }
          }