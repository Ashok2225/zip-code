import uuid from 'uuid/v1'
import * as AssignConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"

 /* adding Assign action to currentTab*/
export const addAssign = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : AssignConstants.ASSIGN,
      label : 'Assign',
      key : "assign",
      variable1:"",
      variable2:"",
      allowNesting : false,
      parentId:parentId,
      description : "",
      status:false,
      breakpint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

/**
 * There three types of modes in assign.
 *    1. none   : This is a blind assign.
 *    2. string : This includes a string operation (For trim, left trim and right trim we don't have stringOperation variable).
 *    3. date   : THis icludes assigng a date to varaible in selected format.
 */

/* updating the Assign action to the currentTab and asigning one variable into another variable*/


export const editAssign = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let variables = tabs[currentTab].variables
    let assignAction = tab["actions"][currentAction]
    let temp = {
      ...assignAction,
      ...payload
    }
    let instruction = ''
    let description = ''
    temp.variable1 !== "" && temp.variable2 !== "" ? temp.status = true : temp.status = false
    if (temp.variable1 !== "" && temp.variable2 !== ""){
      let exp = temp.variable2.replace(/`/g, "")
      instruction = `${temp.variable1} = ${exp}`
      description = `${temp.variable1} = ${temp.variable2}`
    }
   
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : description
    }
    dispatch(updateTab(tab))
  }
}
