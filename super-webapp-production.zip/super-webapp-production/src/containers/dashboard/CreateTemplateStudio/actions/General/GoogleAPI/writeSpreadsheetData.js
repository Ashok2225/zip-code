import uuid from 'uuid/v1'

import * as GoogleAPIConstants from '../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../Tabs"
import {objToArr} from '../../../utilities'
import {openDialog} from '../../openDialog'

export const addWriteSpreadsheetData = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js    
    let action = {
      id : uuid(),
      type : GoogleAPIConstants.WRITE_SPREADSHEET_DATA,
      parentId : parentId,
      label : "Write SpreadSheet Data",
      key : "writespreadsheetdata",
      allowNesting : false,
      path : path,
      sheetName:"",
      range:"",
      selector:"Append",
      typeOff : "write",
      variableName : '',
      instruction : "",
      description : "",
      status:false,
      breakpoint:false
    }
    let apiConfig =  objToArr(tab.actions).find((action)=>{
      return tab.actions[action.id].type == 'API_CONFIGURATION'
      })          
      if(apiConfig){
        tab =  addActionInTab(tab,action,parentId)
        dispatch(updateTab(tab))
      }else{
        dispatch(openDialog("api",action))
      }
  }
}

export const editWriteSpreadsheetData = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    // please refer to the appendRange.js
    let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    let temp = {
      ...excelAction,
      ...payload
    }
    if((temp.path!=""&&temp.path!=".")&&temp.sheetName&&temp.range!=""&&temp.variableName!=""){
      temp.status=true
    }else{
      temp.status=false
    }    
    tab["actions"][actionId ? actionId : tab.currentAction] = {
      ...temp,
      instruction : `write ${temp.variableName} to ${temp.range} of ${temp.sheetName} in ${temp.path}`,
      description : `write ${temp.variableName} to ${temp.range} of ${temp.sheetName} in ${temp.path}`
    }
    dispatch(updateTab(tab))
  }
}
