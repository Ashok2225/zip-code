import * as GetFolderContentsConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'





export const addGetFolderContents = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : GetFolderContentsConstants.GETFOLDERCONSTANTS,
      label : "Get Folder Contents",
      key : "getfoldercontents",
      variable: "",
      dates:"dynamic",
      ifDateModified: "",
      ifDate: "",
      path: "",
      fromDateVar:"",
      toDateVar:"",
      ifCondition:'files',
      variableName : '',
      instruction : "",
      filter:"",
      parentId:parentId,
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editGetFolderContents = (payload)=>{
  return (dispatch, getState) => {
  //   let { tabs, currentTab  } = getState()
  //   let tab = tabs[currentTab]
  //   let {currentAction} = tab
  //   let GetFolderAction = tab["actions"][currentAction]
  //   let temp = {
  //     ...GetFolderAction,
  //     ...payload
  //   }    
  //   temp.path&&temp.variable!=""?temp.status=true:temp.status=false
  //   let path = temp.path?temp.path: ""
  //   path = path.replace(/\\/g,'\\\\' )
  //   let ifDateModified = temp.ifDateModified
  //   let ifDate = ifDateModified===true ?"true":"false"
  //   let fromDate=""
  //   let toDate=""
  //   if(ifDateModified==true){
  //   if(temp.dates === "static"){
  //     fromDate=temp.fromDate?temp.fromDate:""
  //     fromDate.split("/").reverse().join("/");
  //     toDate=temp.toDate?temp.toDate:""
  //     toDate.split("/").reverse().join("/");
  //   }else{
  //     fromDate = temp.fromDateVar?temp.fromDateVar:""
  //     toDate=temp.toDateVar?temp.toDateVar:""
  //   }
  // }
  //   // let fromDate = temp.fromDate?temp.fromDate:""
  //   // fromDate.split("/").reverse().join("/");
  //   // let toDate = temp.toDate?temp.toDate:""
  //   // toDate.split("/").reverse().join("/");
  //   let config_url= `${remote.process.env.RPA_API}/folders/getFolderContents?folderPath=${path}&ifCondition=${temp.ifCondition}&ifDateModified=${ifDate}&fromDate=${fromDate}&toDate=${toDate}&filter=${temp.filter}`
  //   let apiString = `api_config = { method:'GET', header:['Content-Type: application/json','Accept: application/json']};\napi ${config_url}\n${temp.variable}=api_json.data`
  //   let instruction = apiString
  //   tab["actions"][currentAction] = {
  //     ...temp,
  //     instruction : instruction
  //   }
  //   dispatch(updateTab(tab))
  }
}
