import uuid from 'uuid/v1'
import * as askConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"
export const  askAction= (parentId=null) =>{
   return (dispatch,getState) => {
    let {tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let action = {
          id : uuid(),
          type : askConstants.ASK,
          parentId : parentId,
          label : 'Ask',
          key : "ask",
          captcha:"",
          xpath:"",
          allowNesting : false,
          description : "",
          status:false,     
           breakpint:false
  }
     tab =  addActionInTab(tab,action,parentId)
    dispatch(updateTab(tab))
  }
}
export const editAskAction=(payload) =>{
          return (dispatch,getState) =>{
         let {tabs,currentTab} = getState()
         let tab = tabs[currentTab]
         let { currentAction } = tab
         let  askAction= tabs[currentTab].actions[currentAction]
         let temp={
                   ...askAction,
                   ...payload
         }
         temp.captcha!=""&&temp.xpath!=""?temp.status=true:temp.status=false
         let instruction = `ask ${temp.captcha} \n enter ${temp.xpath} as \`ask_result\` `
         tab["actions"][currentAction] = {
                   ...temp,
                   instruction:instruction
         }
         dispatch(updateTab(tab))
}
}
