import uuid from 'uuid/v1'

import * as spreadsheetConst from '../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../Tabs"
import {objToArr} from '../../../utilities'
import {openDialog} from '../../openDialog'
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addCreateSpreadsheet = (parentId = null) => {
          return (dispatch, getState) => {
        
            let action = {
              id : uuid(),
              type : spreadsheetConst.CREATE_SPREADSHEET,
              
              label : "Create a Spreadsheet",
              key : "spreadsheet",
             isShow:false
            }
           
                dispatch(updateTemplateAcions(action))
              
          }
}
export const editCreateSpreadsheet= (payload, actionId=null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let spreadsheetAction = tab["actions"][actionId ? actionId : tab.currentAction]
            let temp = {
              ...spreadsheetAction,
              ...payload
            }
            temp.status = temp.title!=""
            
            tab["actions"][actionId ? actionId : tab.currentAction] = {
              ...temp,
              instruction : `create ${temp.title}`,
              description : `create ${temp.title}`
            }
            dispatch(updateTab(tab))
          }
        }
        