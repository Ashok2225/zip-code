import * as httpConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'


export const httpAPI = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : httpConstants.HTTP,
      label : "HTTP API",
      key : "httpapi",
      allowNesting : false,
      reqBody: "",
      method: "GET" ,
      body: false ,
      url: "",
      headers: "",
      apiHeaders: [{id: 1, headerKey: 'Content-Type', headerValue: 'application/json', keyId: 1.1}],
      variableName : '',
      instruction : "",
      parentId:parentId,
      description : "",
      apiFileAttachments:"",
      status:false,
      breakpint:false
  }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}



export const editHttpAPI = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let HTTPAction = tab["actions"][currentAction]
    let temp = {
      ...HTTPAction,
      ...payload
    }
    temp.method&&temp.url!=""?temp.status=true:temp.status=false
    let requestHeaders = []
    let requests = []
    let formedInstruction = ''
    let apiConfig = {method: temp.method}
    let req_payload= ""
    if(temp.reqBody){
      try {
        req_payload = JSON.parse(temp.reqBody)
           apiConfig['body'] = req_payload.replace(/\n/g,"").replace(/"/g,"'")
      } catch (e) {
        req_payload = temp.reqBody
        apiConfig['body'] = req_payload.replace(/\n/g,"").replace(/"/g,"'")//JSON.parse(temp.reqBody)
      }
    }
    if(temp.apiHeaders.length){
        requestHeaders = temp.apiHeaders.map(head => {
          return {
            [head.headerKey]:head.headerValue
          }
        })
    }
    requestHeaders.map(reqHeader => {
      let key = Object.keys(reqHeader)[0].trim()
      let value = Object.values(reqHeader)[0].trim()
      if(key.length && value.length){
        reqHeader = JSON.stringify(reqHeader).replace(/{|}/g,'')
        requests.push(reqHeader)
      }
    })
    requests = requests.map(reqHeader => {
      return reqHeader.replace(/""|"/g,'')
    })
    if(requests.length){
      apiConfig['header'] = requests
    }    
    // if(temp.method == 'POST'&&temp.attachments&&temp.apiFileAttachments!=""){
    //   let options = {
    //     params : {
    //       file : temp.apiFileAttachments,
    //       url: temp.url
    //     },
    //     headers: apiConfig['header'] 
    //   }
    //   formedInstruction =`api_config = { method:'POST', header:['Content-Type:application/json'],body:${JSON.stringify(options).replace(/\n/g,"").replace(/"/g,"'")}}\napi ${process.env.RPA_API}/http/upload \necho api_result\necho api_json`
    // }
    if(temp.method == 'POST'){
      formedInstruction=`api_config = { method:'POST', header:${JSON.stringify(apiConfig['header'])},body:${req_payload.replace(/\n/g,"").replace(/"/g,"'")}}\napi ${temp.url}\necho api_result\necho api_json`
    }else{
     formedInstruction = `api_config =${JSON.stringify(apiConfig)}\napi ${temp.url}\necho api_result\necho api_json`
     }
    tab["actions"][actionId ? actionId : currentAction] = {
      ...temp,
      instruction : formedInstruction,
      description : `API call to ${temp.url} with ${requests.toString()}`
    }
    dispatch(updateTab(tab))
  }
}
