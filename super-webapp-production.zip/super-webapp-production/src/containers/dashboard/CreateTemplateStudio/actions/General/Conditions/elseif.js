import uuid from 'uuid/v1'
import * as ifElseConstants from '../../../constants/General'
import { updateTab, addActionInTab } from "../../Tabs"
import { updateTemplateAcions } from "../../../../../../redux/actions/template"
export const addElseIf = (parentId = null) => {
  return (dispatch, getState) => {
   
    
      let action = {
        id: uuid(),
        type: ifElseConstants.ELSEIF,
        label: "Else If",
        key: "elseif",
       
        ifType: "custom",
       

      }
     
        
        dispatch(updateTemplateAcions(action))
      
    
  }
}

export const updateElseIf = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let ifAction = tab["actions"][currentAction]
    let temp = {
      ...ifAction,
      ...payload
    }
    if (temp.ifType === "custom") {
      if (temp.condition == "custom condition") {
        temp.value != "" ? temp.status = true : temp.status = false
      } else
        temp.variable != "" && temp.value && temp.condition != "" ? temp.status = true : temp.status = false
    } else if (temp.ifType == "present" || temp.ifType == "visible") {
      if (temp.selectorType === "elSelector") {
        temp.xpath != "" ? temp.status = true : temp.status = false
      } else {
        temp.imgSelector ? temp.status = true : temp.status = false
      }
    } else {
      temp.status = false
      temp.xpath && temp.condition && temp.value != "" ? temp.status = true : temp.status = false
    }
    let instruction = ""
    // temp.value&&temp.variable&&temp.condition!=""?temp.status=true:temp.status=false
    if (temp.ifType === "custom") {
      instruction = `else if ${temp.variable} ${temp.condition} ${temp.value} `
    }
    else if (temp.ifType === "present") {
      if (temp.selectorType === "elSelector")
        instruction = `else if present('${temp.xpath}')`
      else {
        instruction = `else if present('${temp.imgSelector}')`
      }
    } else if (temp.ifType === "visible") {
      if (temp.selectorType === "elSelector")
        instruction = `else if visible('${temp.xpath}')`
      else {
        instruction = `else if visible('${temp.imgSelector}')`
      }
    }
    else if (temp.ifType === "count") {
      instruction = `else if count('${temp.xpath}') ${temp.condition} ${temp.value}  `
    }
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction
    }
    dispatch(updateTab(tab))
  }
}
