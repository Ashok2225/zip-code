import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab, addActionInTab } from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addGetSheetNames = (parentId = null) => {
  return (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: "getsheetnames",

      label: "Get Sheet Names",
      key: "getsheetnames",
      isShow: true
    }
   
    dispatch(updateTemplateAcions(action))
  }
}

export const editGetSheetNames = (payload, actionId = null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // if (temp.path != "" && temp.path != "." && temp.variableName != "") {
    //   temp.status = true
    // } else { temp.status = false }
    // let instruction = `api_config = {method:'GET', header:[], body:{}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/sheet?filePath=${temp.path}
    //                    ${temp.variableName} = api_json.data`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction: instruction,
    //   description: `get sheet names in ${temp.path}`
    // }
    // dispatch(updateTab(tab))
  }
}
