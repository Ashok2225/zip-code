import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab, addActionInTab } from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"

export const addFilterColumn = (parentId = null) => {
  return (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: "filtercolumn",

      label: "Filter Columns",
      key: "filtercolumn",
      isShow: false
    }
   
    dispatch(updateTemplateAcions(action))
  }
}


export const editFilterColumn = (payload, actionId = null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // /**
    //   if the path of the parent spread sheet is updated then if this Append range
    //   is child under Open spread sheet so this actionId is passed else currentAction Id
    //   is updated.
    // */

    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // let parentAction = tab.actions[temp.parentId]
    // let path = temp.path
    // if(parentAction.type  === "OPEN_SPREADSHEET"){
    //   temp.sheetName!=""?temp.status=true:temp.status=false
    //   path = parentAction.path
    // }else{
    //   (temp.path!=""&&temp.path!=".")&&(temp.sheetName!="")&&(temp.variableName!="")?temp.status=true:temp.status=false}

    // let objs = ""
    // //constrating filter object to this format [ {"key" :"value"} ]
    // temp.filters.forEach( (obj, index)=> {
    //    if(index != 0){
    //     objs += `, { 'key':'${obj.key}' ,'value':'${obj.value}' }`
    //    }
    //    else{
    //     objs += `{ 'key':'${obj.key}' ,'value':'${obj.value}' }`
    //    }
    // })
    // let instruction = `api_config = {method:'POST', header:['Content-Type:application/json'], body:{'filePath':'${path}','sheetName':'${temp.sheetName}',"includeHeaders":'${temp.includeHeaders}' ,'filters':[${objs}]}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/column
    //                    ${temp.variableName} = api_json.data
    //                    `

    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `${temp.sheetName} of ${temp.path}. variable name : ${temp.variableName}`
    // }
    // dispatch(updateTab(tab))
  }
}
