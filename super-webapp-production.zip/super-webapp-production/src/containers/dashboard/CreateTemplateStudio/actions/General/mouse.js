import uuid from 'uuid/v1'
import * as mouseConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"

export const addMouse = (node, parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : mouseConstants.CLICK_EL,
      parentId : parentId,
      label : node.label,
      key : node.key,
      allowNesting : false,
      selector : "",
      selectorType : 'elSelector',
      elSelector : '',
      imgSelector : null,
      instruction : ``,
      description : "",
      status:false,
      breakpint:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editMouse = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let mouseAction = tab["actions"][currentAction]
    let temp = {
      ...mouseAction,
      ...payload
    }
    temp.selectorType=="elSelector"?temp.status=true:temp.status=false
    if(temp.selectorType=="elSelector"){
      temp.selector!=""?temp.status=true:temp.status=false
    }else if(temp.selectorType == "imgSelector"){
      temp.imgSelector!=null?temp.status=true:temp.status=false
    }else if(temp.selectorType == "location"){
      temp.imgSelector&&temp.x&&temp.y!=""?temp.status=true:temp.status=false
    }
    else{
      temp.x&&temp.y!=""?temp.status=true:temp.status=false
    }
    let instruction =``
    let description = ``
    if(temp.selectorType === "imgSelector") {
      instruction = `${temp.key} \`dirPath\`${temp.imgSelector}`
      description = "click on img"
    }
    if(temp.selectorType === "elSelector") {
      instruction = `${temp.key} ${temp.selector}`
      description = temp.imgSelector && temp.imgSelector.length && temp.imgSelector.startsWith('data:image/png') ? temp.imgSelector : `${temp.key} ${temp.selector}`
    }
    if(temp.selectorType === "location"){
      if(temp.key==='dclick'){
          instruction = `vision MouseClick, left, ${Math.round(temp.x)}, ${Math.round(temp.y)}, 2`
          description = `Click left, ${Math.round(temp.x)}, ${Math.round(temp.y)}, 2`
      }
      else if (temp.key === 'rclick') {
          instruction = `vision MouseClick, right, ${Math.round(temp.x)}, ${Math.round(temp.y)}`
          description = `Click right, ${Math.round(temp.x)}, ${Math.round(temp.y)}`
      }
      else if(temp.key === 'hover'){
        instruction = `vision MouseMove, ${Math.round(temp.x)}, ${Math.round(temp.y)}`
        description = `Hover, ${Math.round(temp.x)}, ${Math.round(temp.y)}`        
      }
      else{
          instruction = `vision MouseClick, left, ${Math.round(temp.x)}, ${Math.round(temp.y)}`
          description = `Click left, ${Math.round(temp.x)}, ${Math.round(temp.y)}`
      }
    }
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description : description
    }
    dispatch(updateTab(tab))
  }
}
