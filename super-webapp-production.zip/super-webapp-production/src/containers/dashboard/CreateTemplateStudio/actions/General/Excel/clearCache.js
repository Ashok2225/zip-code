import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addClearCache = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''

    /**
       If there is a parent Id then if that is open spread sheet, path of the
       open spread sheet need to be added to this child action.
    */

    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.CLEAR_CACHE,
      parentId : parentId,
      label : "Clear Cache",
      key : "clearcache",
      typeOff : "append",
      allowNesting : false,
      path : path,
      sheetName : "",
      range : "",
      variableName : '',
      instruction : "",
      description: "",
      status:false,
      clearAllCache: false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editClearCache = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // /**
    //   if the path of the parent spread sheet is updated then if this Append range
    //   is child under Open spread sheet so this actionId is passed else currentAction Id
    //   is updated.
    // */

    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    
    // if((temp.path!=""&&temp.path!=".")){
    //     temp.status=true
    // }
    // else{temp.status=false}

    // let instruction = `api_config = {method:'GET', header:[], body:{}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/ClearMemory?FilePath=${temp.path}&clearCache=true&clearAllCache=${temp.clearAllCache}`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `${temp.path}`
    // }
    // dispatch(updateTab(tab))
  }
}
