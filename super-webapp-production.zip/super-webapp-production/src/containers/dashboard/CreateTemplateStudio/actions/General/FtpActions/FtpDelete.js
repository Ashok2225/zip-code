import * as ftpConstants from '../../../constants/General/SecureFtp'
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'

import {openDialog} from '../../openDialog'

// this function is to add ftp delete container

export const deleteFtp = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : ftpConstants.FTP_DELETE,
      label : "Delete",
      key : "delete",
      allowNesting : false,
      RemotePath: "",
      variableName : '',
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpint:false

    }
    let temp_id = parentId
    let sequence_id = tab.sequence[0]
    while(!tab.sequence.includes(temp_id)){
      if(tab.actions[temp_id].key == 'connect' || tab.actions[temp_id].parentId == temp_id) break
      temp_id = tab.actions[temp_id].parentId
      console.log("in loop");
    }
    if(tab.actions[temp_id].key != 'connect'){
      dispatch(openDialog("ftp",action))
    }else{
      tab.connect_tree[temp_id].push(action.id)
      tab = addActionInTab(tab, action, parentId)
      dispatch(updateTab(tab))
    }
 
  }
}
// this function is to edit ftp delete container
export const EditFtpDelete = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab  } = getState()
    // let tab = tabs[currentTab]
    // let {currentAction} = tab
    // let FtpAction = tab["actions"][actionId ? actionId : currentAction]
    // let temp = {
    //   ...FtpAction,
    //   ...payload
    // }
    // let temp_id = temp.parentId
    // while(true){
    //   if(tab.actions[temp_id].key == 'connect' || tab.actions[temp_id].parentId == temp_id) break
    //   temp_id = tab.actions[temp_id].parentId
    //   console.log("in loop");
    // }
    // temp.user = tab['actions'][temp_id]['user']
    // temp.host = tab['actions'][temp_id]['host']
    // temp.password = tab['actions'][temp_id]['password']
    // temp.port = tab['actions'][temp_id]['port']
    // temp.RemotePath!=""?temp.status=true:temp.status=false
    // let Remotepath = temp.RemotePath?temp.RemotePath:null
    // let api= `${remote.process.env.RPA_API}/FtpActions/SFtpDelete`
    // let data = {
    //   method: 'POST',
    //   header: ['Content-Type: application/json','Accept: application/json'],
    //   body: {
    //     "host": temp.host,
    //     "user": temp.user,
    //     "password": temp.password,
    //     "port": temp.port,
    //     "remotePath": Remotepath

    //   }
    // }
    // let instruction = `api_config = {method:'POST', header:['Content-Type:application/json','Accept: application/json'], body:{'host':'${data.body.host}','user':'${data.body.user}','password':'${data.body.password}','port':'${data.body.port}','remotePath':'${Remotepath}'}};
    //                    \napi ${api}\necho api_result`
    // tab["actions"][actionId ? actionId : currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `Delete ${temp.RemotePath}`
    // }
    // dispatch(updateTab(tab))
  }
}
