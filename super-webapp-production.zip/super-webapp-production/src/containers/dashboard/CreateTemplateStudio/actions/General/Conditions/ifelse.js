import uuid from 'uuid/v1'
import * as ifElseConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addIfElse = (parentId = null) => {
  return (dispatch, getState) => {
   
    let action = {
      id: uuid(),
      type: ifElseConstants.IFELSE,
      label:"If/Else",
      key:"ifelse",
     
      ifType:"custom",
     
  }
    
    dispatch(updateTemplateAcions(action))
  }
}
