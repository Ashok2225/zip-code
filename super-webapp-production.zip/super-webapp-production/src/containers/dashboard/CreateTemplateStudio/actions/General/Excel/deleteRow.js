import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addDeleteRow = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.DELETE_ROW,
      parentId : parentId,
      label : "Delete Row",
      key : "deleterow",
      allowNesting: false,
      path : path,
      sheetName : "",
      rowNumber : '',
      instruction : "",
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editDeleteRow = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // if((temp.path!=""&&temp.path!=".")&&temp.sheetName&&temp.rowNumber!=""){
    //   temp.status=true
    // }else{
    //   temp.status=false
    // }
    // let instruction = `api_config = {method:'DELETE', header:[], body:{}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/row?filePath=${temp.path}&sheetName=${temp.sheetName}&rowNumber=${temp.rowNumber}`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `delete ${temp.rowNumber} of ${temp.sheetName} in ${temp.path}`
    // }
    // dispatch(updateTab(tab))
  }
}
