import * as unzipFiles from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'


export const addUnzipFiles = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : unzipFiles.UNZIPFILES,
      label : "Unzip Files",
      key : "unzipfiles",
      variableName : '',
      sourcePath: "",
      destinationPath: "",
      extractToSameLocation: false,
      skip: 'overwrite',
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editUnzipFiles = (payload,actionId=null)=>{
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let FileAction = tab["actions"][currentAction]
        let temp = {
          ...FileAction,
          ...payload
        }
        temp.status = temp.sourcePath!="" && (temp.extractToSameLocation || temp.destinationPath!="")
        let sourcePath = temp.sourcePath
        let destinationPath = temp.destinationPath
        let val = temp.extractToSameLocation ? 'same as source directory' : destinationPath
        let instruction = `extract from ${sourcePath} to ${val}`
        let description = `extract from ${sourcePath} to ${val}`
        tab.actions[currentAction] = {
          ...temp,
          instruction : instruction,
          description : description
        }
        dispatch(updateTab(tab))
      }}