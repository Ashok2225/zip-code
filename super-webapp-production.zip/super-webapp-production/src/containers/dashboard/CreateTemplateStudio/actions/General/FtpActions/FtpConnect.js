import uuid from 'uuid/v1'

import * as ftpConstants from '../../../constants/General/SecureFtp'
import { updateTab , addActionInTab} from "../../Tabs"
import { editScopeValues } from "./editFtpScope"

// this function is to add ftp container
export const addFtp = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : ftpConstants.FTP_CONNECT,
      label : "Connect",
      key : "connect",
      allowNesting : true,
      subActions : [],
      host : "",
      user:"",
      port: "",
      password : '',
      variableName : '',
      instruction : "",
      parentId:parentId,
      description: "random",
      status:false,
      breakpint:false

    }
    tab.connect_tree = tab.connect_tree ? tab.connect_tree : {}
    tab.connect_tree[action.id] = []
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
// this function is to edit ftp container

export const FtpEditConnect = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let FtpAction = tab["actions"][currentAction]
    let subActions  = tab.connect_tree[currentAction]
    // if(subActions.length > 0){
    //   subActions.forEach(function(actionId){
    //     let action = tab["actions"][actionId]
    //     dispatch(editScopeValues(action,payload))
    //   })
    //   // editScopeValues is to pass ftp connect creds to all child components in that container
    // }
    let temp = {
      ...FtpAction,
      ...payload
    }
    if((temp.host!="")&&(temp.user!="")&&(temp.password!="")&&(temp.port!="")){
      temp.status=true
      tab.ftpConfig = tab.ftpConfig ? tab.ftpConfig : {}
      tab.ftpConfig['host'] = temp.host
      tab.ftpConfig['user'] = temp.user
      tab.ftpConfig['password'] = temp.password
      tab.ftpConfig['port'] = temp.port
    }
    else{
      temp.status=false
    }

//     console.log("temptemptemp",temp);
//     let api= `${remote.process.env.RPA_API}/v1/rpa/metadata/FtpActions/FtpConnect`
//     let data = {
//       method: 'POST',
//       header: ['Content-Type: application/json','Accept: application/json'],
//       body: {
// "host": temp.host,
// "user": temp.user,
// "password": temp.password
// }
//     }
//     let instruction = `api_config = ${JSON.stringify(data)};\napi ${api}\necho api_result`
    tab["actions"][currentAction] = {
      ...temp,
      description : `Connect ${temp.host} with ${temp.user}`
      // instruction : instruction
    }
    dispatch(updateTab(tab))
    if(subActions.length > 0){
      subActions.forEach(function(actionId){
        let action = tab["actions"][actionId]
        dispatch(editScopeValues(action,payload))
      })
      // editScopeValues is to pass ftp connect creds to all child components in that container
    }
  }
}
