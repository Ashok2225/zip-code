import uuid from 'uuid/v1'
import * as ifElseConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addIf = (parentId = null) => {
  return (dispatch, getState) => {
  
    let action = {
      id: uuid(),
      type: ifElseConstants.IF,
      label:"If",
      key:"if",
     
      ifType:"custom",
     
      status:false,
      breakpoint:false

    }
   
    dispatch(updateTemplateAcions(action))
  }
}

export const updateIf = (payload) => {  
  return (dispatch, getState) => {
    let { tabs, currentTab  } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let ifAction = tab["actions"][currentAction]
    let temp = {
      ...ifAction,
      ...payload
    }
    let flag
    let variables = tabs[currentTab].variables
    if(temp.ifType === "custom"){
      if(temp.condition == "custom condition"){
        temp.value!=""?temp.status=true:temp.status=false
      }else
        temp.variable!=""&&temp.value&&temp.condition!=""?temp.status=true:temp.status=false
    }else if(temp.ifType == "present" || temp.ifType == "visible"){
        if(temp.selectorType === "elSelector"){
          temp.xpath!=""?temp.status=true:temp.status=false
        }else{
          temp.imgSelector?temp.status=true:temp.status=false
        }
    }else{
        temp.status=false
        temp.xpath&&temp.condition&&temp.value!=""?temp.status=true:temp.status=false
    }
    let instruction=""
    if(temp.ifType === "custom"){
      instruction =`if ${temp.variable} ${temp.condition} ${temp.value} `
      if(temp.condition == "custom condition"){
        instruction = ` if ${temp.value}`
      }
    }
    else if(temp.ifType === "present"){
      if(temp.selectorType === "elSelector")
        instruction = `if present('${temp.xpath}')`
      else{
        instruction = `if present('\`dirPath\`${temp.imgSelector}')`
      }
    }else if(temp.ifType === "visible"){
      if(temp.selectorType === "elSelector")
        instruction = `if visible('${temp.xpath}')`
      else{
        instruction = `if visible('\`dirPath\`${temp.imgSelector}')`
      }
    }
    else if (temp.ifType === "count"){
          instruction = `if count('${temp.xpath}') ${temp.condition} ${temp.value}  `
      }
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction
    }
    dispatch(updateTab(tab))
  }
}
