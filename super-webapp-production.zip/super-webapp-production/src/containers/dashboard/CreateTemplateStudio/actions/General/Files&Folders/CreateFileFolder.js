import * as createFilesFoldersConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'




export const addCreateFilesFolders = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : createFilesFoldersConstants.CREATEFILESFOLDERS_ACTION,
      label : "Create File/Folder",
      key : "createfilefolder",
      variableName : '',
      path: "",
      subType2:'file',
      skip:'overwrite',
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editCreateFilesFolders = (payload)=>{
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // let FtpAction = tab["actions"][tab.currentAction]    
    // let temp = {
    //   ...FtpAction,
    //   ...payload
    // }
    // temp.path!=""?temp.status=true: temp.status=false
    
    // let instruction
    // let description
    // let path = ''
    // if( temp.subType2 === "file") {
    //   path = temp.path?temp.path.replace(/\\/g,'\\\\' ):null
    //   let config_url= `${remote.process.env.RPA_API}/folders/createFile`
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{'filePath':'${path}'}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    //   description = `Create file`+(path==null ? '' : ` at ${path}`)
    // }else{
    //   path = temp.path?temp.path.replace(/\\/g,'\\\\' ):null
    //   let config_url= `${remote.process.env.RPA_API}/folders/createFolder`
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{'folderPath':'${path}', "ifExists":'${temp.skip}'}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    //   description = `Create folder `+(path==null?'':(temp.skip?`at ${path} and ${temp.skip} if exists` : `at ${path}`))
    // }
    // tab["actions"][tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : description
    // }
    // dispatch(updateTab(tab))
  }
}
