import * as WriteFileConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'




export const addWriteFile = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : WriteFileConstants.WRITEFILE,
      label : "Write to File",
      key : "writetofile",
      skip : 'overwrite',
      path:"",
      content : '',
      variableName : '',
      instruction : "",
      parentId:parentId,
      description : '',
      status:false,
      api: 'http://localhost:5555/v1/rpa/metadata/folders/writeFile',
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editWriteFile = (payload,actionId=null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab }= getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let FileAction = tab["actions"][currentAction]
    let temp = {
      ...FileAction,
      ...payload
    }
    if((temp.path!="")&&(temp.content)){
      temp.status=true
    }else{
      temp.status=false
    }
    let instruction
    let description = temp ? `Write '${temp.content}' ` : ''
    //if( temp.skip === "overwrite") {
      let content = temp.content.split("\n").join("\\n")
      let path = temp.path.replace(/\\/g,'\\\\' )
     // instruction = `dump  '${content}' to ${path}`
     instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{'path':'${path}','content':'${content}','mode':'${temp.skip}'}};
     \napi ${temp.api}`
      description += (temp.path ? `to ${path} ` : '') + 'and overwrite if exists'
    // }else{
    //   let path = temp.path.replace(/\\/g,'\\\\' )
    //   let content = temp.content.split("\n").join("\\n")
    //   instruction = `write '${content}' to ${path}`
    //   description += (temp.path ? `to ${path} ` : '') + 'and append if exists'
    // }
    tab["actions"][actionId ? actionId : currentAction] = {
      ...temp,
      instruction : instruction,
      description : description
    }
    dispatch(updateTab(tab))
  }
}
