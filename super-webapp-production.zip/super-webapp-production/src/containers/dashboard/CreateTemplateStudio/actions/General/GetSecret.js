import * as GetAssetConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'
import qs from 'qs'
const fs = require('fs')
const path = require('path')
const os = require('os')

// this function is to add ftp Get container

export const AddGetSecret = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : GetAssetConstants.GET_ASSET,
      label : "Get Secret",
      key : "GetSecret",
      allowNesting : false,
      AssetName: "",
      variable: "",
      variableName : '',
      instruction : "",
      parentId:parentId,
      description:"",
      status:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
// this function is to edit ftp Get container
export const EditGetSecret = (payload,actionId=null) => {
  return (dispatch, getState) => {
  //   let { tabs, currentTab } = getState()
  //   let tab = tabs[currentTab]
  //   let {currentAction} = tab
  //   let AssetAction = tab["actions"][actionId ? actionId : currentAction]
  //   let temp = {
  //     ...AssetAction,
  //     ...payload
  //   }
  //   let config ={}
  //   let TokenData={}
  //   if(temp.AssetName!=""&&temp.variable!=""){
  //     temp.status =true
  //   }
  //   else{temp.status=false}
  //   if(fs.existsSync(path.join(os.tmpdir(),"TechforceAuthentication")))
  //   {
  //     config = JSON.parse(fs.readFileSync(path.join(os.tmpdir(),"TechforceAuthentication"),"utf8"))
  //   }
  //   else{
  //     console.log("file does not exit")
  //   }
  //   // let header = {
  //   //       headers: {
  //   //        'default-token': `${TokenData.defaultToken}`
  //   //        }
  //   //      }
  //   // let api= `http://${config.ip}:6565/v1/rpa/metadata/secretVault/getUniqueId?TF_SECRET_NAME=${temp.AssetName}&TF_ROLE=${config.role}&TF_CREATED_BY=${config.name}`
  //   // let data = {
  //   //   method: 'GET',
  //   //   header: header.headers
  //   // }
  //   // let data1 = {
  //   //   method: 'GET',
  //   //   header:  header.headers
  //   // }
  //   // data = `{ method:'GET', header:['default-token: ${TokenData.defaultToken}']}`
  //   // let instruction = "api_config =" + data + ";\n api " + api + "\n" + "tf_967479873123kjasdbasjdnkejfgfadrjueihwrk" + "= api_json.data.TF_UNIQUE_KEY\n" + "\n" + ";\n" + "api_config =" + data + ";\n api " + `http://${config.ip}:6565` + "/v1/rpa/metadata/secretVault/readSecret?secretID='+tf_967479873123kjasdbasjdnkejfgfadrjueihwrk+' \n" + "\n" + temp.variable + "= api_json.data.Secret_data[tf_967479873123kjasdbasjdnkejfgfadrjueihwrk].value"
  //   console.log("temptemptemp get",temp);console.log
  //   (config);
  //   let options = qs.stringify({
  //     username: config.name,
  //    password: config.password,
  //    grant_type:"password",
  //    client_id: "admin-cli"
  //  })
  //  let api = `${config.ip}/v1/csrftoken`
  //  let instruction = `api_config = {method:'POST' ,header:["Content-Type:application/x-www-form-urlencoded"],body:"username=${config.name}&password=${config.password}&grant_type=password&client_id=admin-cli"} \n api ${config.baseUrl}/protocol/openid-connect/token \n token_data = api_json.access_token \n api_config = {method:'GET',  header:[ ]} \n api ${api} \n csrf_token = api_json.csrfToken \n api_config = {method:'GET',  header:[ 'Authorization: Bearer \`token_data\`','X-Frame-Options:sameorigin','set_cookie:HttpOnly','strict-transport-security:max-age=31536000; includeSubDomains','Public-Key-Pins:pin-sha256="AbCdEf123="; pin-sha256="ZyXwVu456=";max-age=2592000; includeSubDomains','X-XSS-Protection:1; mode=block','x-content-type-options:nosniff','X-Download-Options:noopen','csrfToken:\`csrf_token\`']} \n api ${config.ip}/v1/vault/getUniqueId?secret_name=${temp.AssetName} \n ${temp.variable}=api_json.value `
   
  //  tab["actions"][actionId ? actionId : currentAction] = {
  //     ...temp,
  //     instruction : instruction,
  //     description:"Gets the text data from Secretvault "
  //   }
  //   dispatch(updateTab(tab))
  }
}
