import uuid from 'uuid/v1'
import * as tryCatchConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addTryCatch = (parentId = null) => {
  return (dispatch, getState) => {
   
    let tryAction = {
      id: uuid(),
      type: tryCatchConstants.TRY_CATCH,
      label: 'Try Catch',
      key: 'trycatch',
     
    }
   
    dispatch(updateTemplateAcions(tryAction))
  }
}
