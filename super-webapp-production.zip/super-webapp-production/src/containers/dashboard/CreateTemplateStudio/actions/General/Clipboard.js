import * as ClipboardConstants from "../../constants/General"
import { updateTab , addActionInTab} from "../Tabs"

import uuid from 'uuid/v1'

export const addClipboard = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : ClipboardConstants.GET_CLIPBOARD,
      label : "Clipboard",
      key : "clipboard",
      variable: "",
      instruction : "",
      parentId:parentId,
      description: '',
      status:false,
      breakpint:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}


export const editClipboard = (payload)=>{
  return (dispatch, getState) => {

    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let clipboardAction = tab["actions"][tab.currentAction]
    
    let temp = {
      ...clipboardAction,
      ...payload
    }
    let variables = tab.variables
    let flag=Object.keys(variables).map((varId)=>{
      return variables[varId]
    }).some((obj)=>{
      return obj.name ===  temp.variable
    }) 
    flag?temp.status=true:temp.status=false
    let instruction = `clipboard ${temp.variable}`
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction : instruction,
      description: temp.variable
    }
    dispatch(updateTab(tab))
  }
}
