import * as sequenceConstants from '../../constants'
import { updateTab, addActionInTab } from '../Tabs'
import uuid from 'uuid/v1'


export const addSequence = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let seq = tab.sequence[tab.sequence.length-1]
        let title =seq?tab.actions[seq].title:""
        let count = title?parseInt(title.split("-")[1])+1:1
        let action = {
            id: uuid(),
            type: sequenceConstants.ADD_SEQUENCE,
            label: "Sequence",
            key: "sequence",
            title : "Stage-"+count,
            allowNesting: true,
            expanded:true,
            subActions:[]
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}

export const updateSequence = (payload, id = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let { currentAction } = tab
        let sequenceAction
        if(id){
            sequenceAction = tab["actions"][id]
            let temp = {
                ...sequenceAction,
                ...payload
            }    
            let instruction = `// ${temp.title} starts here`
            tab["actions"][id] = {
                ...temp,
                instruction: instruction
            }
        }
        else{
            sequenceAction = tab["actions"][currentAction]
            let temp = {
                ...sequenceAction,
                ...payload
            }
            let instruction = `// ${temp.title} starts here`
            tab["actions"][currentAction] = {
                ...temp,
                instruction: instruction
            }
        }
        dispatch(updateTab(tab))
    }
}

