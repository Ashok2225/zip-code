import * as exportToPDF from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'


export const addExportToPDF = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : exportToPDF.EXPORTTOPDF,
      label : "Export To PDF",
      key : "exporttopdf",
      variableName : '',
      sourcePath: "",
      destinationPath: "",
      instruction : "",
      parentId:parentId,
      description : "",
      skip: 'overwrite',
      exportToPdf: 'word',
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editExportToPDF = (payload,actionId=null)=>{
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let FileAction = tab["actions"][currentAction]
        let temp = {
          ...FileAction,
          ...payload
        }
        temp.status = temp.sourcePath!="" &&  temp.destinationPath!=""
        let instruction = `export ${temp.sourcePath} to ${temp.destinationPath}`
        let description = `export ${temp.sourcePath} to ${temp.destinationPath}`
        tab.actions[currentAction] = {
          ...temp,
          instruction : instruction,
          description : description
        }
        dispatch(updateTab(tab))
      }}