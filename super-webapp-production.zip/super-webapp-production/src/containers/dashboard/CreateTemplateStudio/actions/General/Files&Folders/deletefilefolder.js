import * as deleteFilesFoldersConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'




export const addDeleteFilesFolders = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : deleteFilesFoldersConstants.DELETEFILESFOLDERS_ACTION,
      label : "Delete File/Folder",
      key : "deletefilefolder",
      variableName : '',
      subType2:'file',
      path: "",
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editDeleteFilesFolders = (payload,actionId=null)=>{
  return (dispatch, getState) => {
    // let { tabs, currentTab} = getState()
    // let tab = tabs[currentTab]
    // let {currentAction} = tab
    // let FtpAction = tab["actions"][actionId ? actionId : currentAction]
    // let temp = {
    //   ...FtpAction,
    //   ...payload
    // }
    // let pathInVar = false
    // temp.path!=""?temp.status=true: temp.status=false
    // let path = temp.path?temp.path.replace(/\\/g,'\\\\' ):null
    // let instruction
    // let description
    // if( temp.type1 === "file") {
    //   let config_url= `${remote.process.env.RPA_API}/folders/deleteFolder`
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{"folderPath":${path},"ifExists":"overwrite"}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    //   description = `Delete file ` + (path === null ? '':` at ${path}`)
    // }else{
    //   let config_url= `${remote.process.env.RPA_API}/folders/deleteFolder`
    //   let api_body ={
    //     "folderPath":path,
    //      "ifExists":"overwrite"
    //   }
    //   let api_body_string = JSON.stringify(api_body)
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{"folderPath":'${path}',"ifExists":"overwrite"}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    //   description = `Delete folder ` + (path === null ? '':` at ${path}`)

    // }
    // tab["actions"][actionId ? actionId : currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : description,
    // }
    // dispatch(updateTab(tab))
  }
}
