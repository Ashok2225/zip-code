import uuid from 'uuid/v1'
import * as waitConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"

export const addWait = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : waitConstants.WAIT_ACTION,
      parentId : parentId,
      label : "Wait",
      key : "wait",
      time : '',
      allowNesting : false,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editWait = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let waitAction = tab["actions"][currentAction]
    let temp = {
      ...waitAction,
      ...payload
    }
    temp.time!=''?temp.status=true:temp.status=false
    let instruction = `wait ${temp.time}`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description: instruction + " Sec",
    }
    dispatch(updateTab(tab))
  }
}
