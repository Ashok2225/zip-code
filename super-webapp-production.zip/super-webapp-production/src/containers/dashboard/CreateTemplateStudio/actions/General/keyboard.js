import * as keyboardConstants from '../../constants/General'
import {updateTab , addActionInTab } from '../Tabs'
import uuid from 'uuid/v1'

export const addKeyboardText = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : keyboardConstants.TYPE_TEXT_EL,
      parentId : parentId,
      label : "Enter Keystrokes",
      key : "keyboard",
      selectorType:"elSelector",
      resultType:"string",
      xpath:'',
      text:"" ,
      imgSelector:null,
      allowNesting : false,
      instruction: `type "" as ""`,
      description: '',
      status:false,
      breakpint:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
  }

export const updateKeyboardText = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab  = tabs[currentTab]
    let { currentAction }= tab
    let keyBoardAction = tab["actions"][currentAction]
    let temp = {
      ...keyBoardAction,
      ...payload
    }
  //   if((temp.text!="")&&( temp.xpath!="")){
  //     temp.status=true
  //  }else{
  //       temp.status=false}
    let instruction
    let description = ``
    if (temp.selectorType === "imgSelector") {
      instruction = `type \`dirPath\`${temp.imgSelector} as ${temp.text}`
      temp.text!=""&&temp.imgSelector!=null?temp.status=true:temp.status=false
      description = `${temp.text} in ${temp.imgSelector}`
    } else if (temp.imgSelector && temp.imgSelector.length && temp.imgSelector.startsWith('data:image/png')) {
      instruction = `type ${temp.xpath} as ${temp.text}`
      description = `${temp.text} in ${temp.imgSelector}`
    } else {
      instruction = `type ${temp.xpath} as ${temp.text}`
      temp.xpath&&temp.text!=""?temp.status=true:temp.status=false
      description = `${temp.text} in ${temp.xpath}`
    }

    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description: description
    }
    dispatch(updateTab(tab))
  }
}
