import {addActionInTab,updateTab} from '../Tabs';
import uuid from 'uuid/v1';
import * as SAP_CONSTNATS from '../../constants';
export const saplogon = (parentId=null)=>{
          return (dispatch,getState)=>{
                    let {tabs, currentTab} = getState()
                    let tab = tabs[currentTab]
                    let action = {
                           id:uuid(),
                           type:SAP_CONSTNATS.SAP_LOGON,
                           label: "saplogon",
                           key:"saplogon",
                           logon:"",
                           allowNesting:true,
                           description:"logon to the sap",
                           status:false,
                           parentId:parentId,
                           breakpint:false
                     }
                    tab = addActionInTab(tab,action,parentId)
                    dispatch(updateTab(tab))
          }
}
export const editSapLogon = (payload = {})=>{
          return(dispatch, getState)=>{
                    let {tabs,currentTab} = getState()
                    let tab = tabs[currentTab]
                    let {currentAction} =tab
                    let sapAction  = tabs[currentTab].actions[currentAction]
                    let temp = {
                              ...sapAction,
                              ...payload
                    }
                    temp.logon!=""?temp.status=true:temp.status=false
                    let instruction = `IfWinExist, SAP Logon 740\n{WinActivate, SAP Logon 740\nSleep, 4000\nSend, {Enter}\nSleep, 7000\n\}\nelse\n{\nMsgBox, SAP Logon 740 Screen is Loading failure.\n}`
                   tab.actions[currentAction] = {
                              ...temp,
                              instruction
                    }
                    dispatch(updateTab(tab))
          }
}