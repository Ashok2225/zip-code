import * as statements from '../../constants/General'
import { updateTab, addActionInTab } from "../Tabs"
import uuid from 'uuid/v1'
import { updateTemplateAcions} from "../../../../../redux/actions/template"

export const addStatement = (parentId = null) => {
  return (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: statements.STATEMENT,
      label: "Statements",
      key: "statements",
      isShow: false
    }
    
    dispatch(updateTemplateAcions(action))
  }
}



export const editStatement = (payload, actionId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let StatementsAction = tab["actions"][actionId ? actionId : currentAction]
    let temp = {
      ...StatementsAction,
      ...payload
    }
    let arr = ["break", "continue"]
    arr.includes(temp.statement) ? temp.status = true : temp.status = false
    let instruction = `${temp.statement}`
    tab["actions"][actionId ? actionId : currentAction] = {
      ...temp,
      instruction: instruction
    }
    dispatch(updateTab(tab))
  }
}
