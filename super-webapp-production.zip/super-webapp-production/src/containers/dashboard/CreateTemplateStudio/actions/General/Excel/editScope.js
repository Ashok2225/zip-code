import { editGetCell } from "./getCell"
import { editGetColumn } from "./getColumn"
import { editSetRangeColor } from "./setRangeColor"
import { editWriteRange } from "./writeRange"
import { editWriteCell } from "./writeCell"
import { editGetSheetNames } from "./getSheetNames"
import { editGetRow } from "./getRow"
import { editGetRange } from './getRange'
import { editGetCellFormula } from './getCellFormula'
import { editGetCellColor } from './getCellColor'
import { editDeleteRow } from './deleteRow'
import { editDeleteRange } from './deleteRange'
import { editDeleteColumn } from './deleteColumn'
import { editAppendRange } from './appendRange'

/**
   This function is called when path is changed in openspreadsheet action,
   so path of the Child actions need to be updated to maintain the scope
*/


export const editScopePath = (action,payload) => {
  return (dispatch,getState)=>{
    switch (action.type) {

      case 'GET_CELL':
        dispatch(editGetCell(payload,action.id))
        break;

      case 'GET_COLUMN':
        dispatch(editGetColumn(payload,action.id))
        break;

      case 'GET_SHEET_NAMES':
        dispatch(editGetSheetNames(payload,action.id))
        break;

      case 'GET_ROW':
        dispatch(editGetRow(payload,action.id))
        break;

      case 'WRITE_CELL':
        dispatch(editWriteCell(payload,action.id))
        break;

      case 'DELETE_ROW':
        dispatch(editDeleteRow(payload,action.id))
        break;

      case 'DELETE_COLUMN':
        dispatch(editDeleteColumn(payload,action.id))
        break;

      case 'GET_RANGE':
        dispatch(editGetRange(payload,action.id))
        break;

      case 'GET_CELL_COLOR':
        dispatch(editGetCellColor(payload,action.id))
        break;

      case 'SET_RANGE_COLOR':
        dispatch(editSetRangeColor(payload,action.id))
        break;

      case 'WRITE_RANGE':
        dispatch(editWriteRange(payload,action.id))
        break;

      case 'GET_CELL_FORMULA':
        dispatch(editGetCellFormula(payload,action.id))
        break;

      case 'DELETE_RANGE':
        dispatch(editDeleteRange(payload,action.id))
        break;

      case 'APPEND_RANGE':
        dispatch(editAppendRange(payload,action.id))
        break;

      default:
        break;
    }
  }
}
