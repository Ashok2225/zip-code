import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addGetCellFormula = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.GET_CELL_FORMULA,
      parentId : parentId,
      label : "Get Cell Formula",
      key : "getcellformula",
      allowNesting: false,
      path : path,
      sheetName:"",
      cellAddress : '',
      variableName : '',
      instruction : "",
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editGetCellFormula = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // if((temp.path!=""&&temp.path!=".")&&temp.sheetName&&temp.cellAddress!=""&&temp.variableName!=""){
    //   temp.status=true
    // }else{
    //   temp.status=false
    // }
    // let instruction = `api_config = {method:'GET', header:[], body:{}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/formula?filePath=${temp.path}&sheetName=${temp.sheetName}&cellAddress=${temp.cellAddress}
    //                    ${temp.variableName} = api_json.data`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `get ${temp.cellAddress} of ${temp.sheetName} in ${temp.path}`
    // }
    // dispatch(updateTab(tab))
  }
}
