import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addGetRow = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.GET_ROW,
      parentId : parentId,
      label : "Get Row",
      key : "getrow",
      allowNesting: false,
      path : path,
      sheetName:"",
      rowNumber : '',
      variableName : '',
      instruction : "",
      description : "",
      status:false,
      storeCache:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editGetRow = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    // if((temp.path!=""&&temp.path!=".")&&temp.sheetName&&temp.rowNumber!=""&&temp.variableName!=""){
    //   temp.status=true
    // }else{
    //   temp.status=false
    // }
    // let instruction = `api_config = {method:'GET', header:[], body:{}}
    //                    api ${remote.process.env.RPA_PYTHON_API}/api/v1/row?filePath=${temp.path}&sheetName=${temp.sheetName}&rowNumber=${temp.rowNumber}&storeCache=${temp.storeCache}
    //                    ${temp.variableName} = api_json.data`
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `get ${temp.rowNumber} of ${temp.sheetName} in ${temp.path}`

    // }
    // dispatch(updateTab(tab))
  }
}
