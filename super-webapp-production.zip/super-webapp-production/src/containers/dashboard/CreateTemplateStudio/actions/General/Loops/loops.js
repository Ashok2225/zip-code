import uuid from 'uuid/v1'
import * as loopConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addFor = (parentId = null) => {
  return (dispatch, getState) => {
   
    let action = {
      id: uuid(),
      type: loopConstants.LOOPS,
      label:"For",
      key:"for",
      isShow:false
    }
    
    dispatch(updateTemplateAcions(action))
  }
}

export const updateFor = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let loopAction = tab["actions"][currentAction]
    let temp = {
      ...loopAction,
      ...payload
    }
    temp.element&&temp.range&&/\S/.test(temp.initial)?temp.status=true:temp.status=false
    let instruction =`for ${temp.element} from ${temp.initial} to ${temp.range}`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction
    }
    dispatch(updateTab(tab))
  }
}
