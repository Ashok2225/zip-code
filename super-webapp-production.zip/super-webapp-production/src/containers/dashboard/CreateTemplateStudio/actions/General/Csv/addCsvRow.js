import * as CsvConstants from '../../../constants/General'
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'



// this function is to add csv row container


export const addCsvRow = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : CsvConstants.CSV_ROW,
      label : "CSV Row",
      key : "csvrow",
      CsvFileName : "",
      CsvArray:"",
      variableName : '',
      instruction : "",
      parentId:parentId,
      description: "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
// this function is to edit csv row container

export const editCsvRow = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let CsvAction = tab["actions"][currentAction]
    let temp = {
      ...CsvAction,
      ...payload
    }
    let flag
    let variables = tabs[currentTab].variables
    flag=Object.keys(variables).map((varId)=>{
          return variables[varId]
    }).some((obj)=>{
       return obj.name ===  temp.CsvArray
    }) 
    console.log("Flag========",flag);
    flag&&temp.CsvFileName!=""?temp.status=true:temp.status=false

    let instruction = `write csv_row(${temp.CsvArray}) to ${temp.CsvFileName}`
    tab["actions"][actionId ? actionId : currentAction] = {
      ...temp,
      instruction : instruction,
      description : `${temp.CsvArray} to ${temp.CsvFileName}`
    }
    dispatch(updateTab(tab))
  }
}
