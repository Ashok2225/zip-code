import uuid from 'uuid/v1'
import * as excelConstants from '../../../constants/General/Excel'
import { editScopePath } from "./editScope"
import { editGetCell } from "./getCell"
import { updateTab , addActionInTab} from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"
export const addExcelScope = (parentId = null) => {
  return (dispatch, getState) => {
    
    let action = {
      id: uuid(),
      type: "Excel",
      label:"Excel Action",
      key: "excel",
      isShow:true
     
    
    }
   
    dispatch(updateTemplateAcions(action))
  }
}

export const editExcelScope = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let excelAction = tab["actions"][tab.currentAction]
    let { subActions } = excelAction

    /**
    When we edit Excel scope, if this parent actions has subActions , then path
    of the subActions need to be updated.
    */
    if(subActions.length > 0){
      subActions.forEach(function(actionId){
        let action = tab["actions"][actionId]
        dispatch(editScopePath(action,payload))
      })
    }
    let temp = {
      ...excelAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
    tab["actions"][tab.currentAction] = {
      ...temp
    }
    dispatch(updateTab(tab))
  }
}
