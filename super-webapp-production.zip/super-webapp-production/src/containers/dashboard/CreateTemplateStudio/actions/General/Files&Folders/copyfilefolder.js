import * as copyFilesFoldersConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'


export const addCopyFilesFolders = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : copyFilesFoldersConstants.COPYFILESFOLDERS_ACTION,
      label : "Copy File/Folder",
      key : "copyfilefolder",
      path: "",
      sourcePath:"",
      destinationPath:"",
      variableName : '',
      subType2:'file',
      mode:'copy',
      skip:'overwrite',
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editCopyFilesFolders = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // let {currentAction} = tab
    // let FtpAction = tab["actions"][currentAction]
    // let temp = {
    //   ...FtpAction,
    //   ...payload
    // }
    // if((temp.sourcePath!="")&&(temp.destinationPath!="")){
    //   temp.status = true;
    // }else{
    //   temp.status=false}
    // let sourcePath='', destinationPath='', mode='';
    // mode = temp.mode === undefined ? "":temp.mode
    // let instruction
    // if( temp.mode === "copy") {
    //   sourcePath = temp.sourcePath?temp.sourcePath.replace(/\\/g,'\\\\' ):''
    //   destinationPath=temp.destinationPath?temp.destinationPath.replace(/\\/g,'\\\\' ):''
    //   let config_url= `${remote.process.env.RPA_API}/folders/copyFolder`
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{"sourcePath":'${sourcePath}', "destinationPath":'${destinationPath}',"ifExists":'${temp.skip}'}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    // }else{
    //   sourcePath = temp.sourcePath?temp.sourcePath.replace(/\\/g,'\\\\' ):''
    //   destinationPath=temp.destinationPath?temp.destinationPath.replace(/\\/g,'\\\\' ):''
    //   let config_url= `${remote.process.env.RPA_API}/folders/moveFolder`
    //   let apiString = `api_config = { method:'POST', header:['Content-Type: application/json','Accept: application/json'],  body:{"sourcePath":'${sourcePath}', "destinationPath":'${destinationPath}',"ifExists":'${temp.skip}'}};\napi ${config_url}\necho api_result`
    //   instruction = apiString
    // }
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description :  `${mode.charAt(0).toUpperCase() + mode.slice(1)} from ${sourcePath} to ${destinationPath}`
    // }
    // dispatch(updateTab(tab))
  }
}


// export const editCopyFilesFolders = (id, payload)=>{
//   console.log('payloaddddddddddd',id,payload);
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//       let index = tabs.findIndex(obj=>(obj.id===id))
//       console.log(tabs);
//       if(index == -1){
//         let lengthTabs = tabs.length - 1
//         innerConditionFind(tabs[lengthTabs],tabs[lengthTabs].flow, id, payload)
//
//       }else{
//         innerConditionFind(tabs[index],tabs[index].flow, id, payload)
//
//       }
//       dispatch(updateTab(tabs))
//   }
// }
