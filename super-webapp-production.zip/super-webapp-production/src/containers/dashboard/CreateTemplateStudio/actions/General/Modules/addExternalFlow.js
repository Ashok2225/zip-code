import uuid from 'uuid/v1'
import * as moduleConstants from '../../../constants/General'
import { updateTab, addActionInTab } from "../../Tabs"

export const addExternalFlow = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            id: uuid(),
            type: moduleConstants.ADD_EXTERNAL_FLOW,
            label: "Add External Flow",
            key: "addexternalflow",
            allowNesting: false,
            path:"",
            parentId: parentId,
            status:false,
            breakpoint:false
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}

export const editExternalFlow = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let { currentAction } = tab
        let moduleAction = tab["actions"][currentAction]
        let temp = {
            ...moduleAction,
            ...payload
        }
        temp.path!=""&&temp.path!="."?temp.status=true:temp.status=false
        let instruction = `dirPath = "${temp.path.dirPath}/"\ntechforce ${temp.path.filePath}\ndirPath = "${tab.dirPath}/"`
        tab["actions"][currentAction] = {
            ...temp,
            instruction : instruction,
            description : instruction
        }
        dispatch(updateTab(tab))
    }
}
