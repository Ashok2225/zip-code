import uuid from 'uuid/v1'

import * as excelConstants from '../../../constants/General/Excel'
import { updateTab , addActionInTab} from "../../Tabs"

export const addInsertColumn = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let path = ''
    // please refer to the appendRange.js
    if(parentId){
      let parentAction =  tab["actions"][parentId]
      if(parentAction.type==='OPEN_SPREADSHEET'){
        path = parentAction.path
      }
    }
    let action = {
      id : uuid(),
      type : excelConstants.INSERT_COLUMN,
      parentId : parentId,
      label : "Insert Column",
      key : "insertcolumn",
      allowNesting : false,
      path : path,
      sheetName:"",
      position : '',
      noColumns : 1,
      instruction : "",
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editInsertColumn = (payload,actionId=null) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // // please refer to the appendRange.js
    // let excelAction = tab["actions"][actionId ? actionId : tab.currentAction]
    // let temp = {
    //   ...excelAction,
    //   ...payload
    // }
    //   let parent_action  = tab.actions[excelAction.parentId]
    //   if(parent_action.type === "OPEN_SPREADSHEET"){
    //     temp.status = temp.sheetName!="" && temp.position!=""
    //   }
    //   else{
    //     temp.status = temp.path!="" && temp.path!="." && temp.sheetName!="" && temp.position!=""
    //   }

    // let instruction =  `api_config = {method:'PUT', header:['Content-Type:application/json'], body:{'filePath':'${temp.path}','sheetName':'${temp.sheetName}','position':${temp.position},'noColumns':${temp.noColumns}}}
    //                     api ${remote.process.env.RPA_PYTHON_API}/api/v1/column
    //                     `
    // tab["actions"][actionId ? actionId : tab.currentAction] = {
    //   ...temp,
    //   instruction : instruction,
    //   description : `position ${temp.position} columns ${temp.noColumns} of ${temp.sheetName} in ${temp.path}`

    // }
    // dispatch(updateTab(tab))
  }
}
