import uuid from 'uuid/v1'
import * as readConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"

export const readValue = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : readConstants.READ,
      label : 'Read',
      key : "read",
      allowNesting : false,
      subType: '',
      readFromElement: '',
      readToVariable: '',
      parentId:parentId,
      description:"",
      status:false,
      breakpint:false

    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editReadValue = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let readAction = tab["actions"][currentAction]
    let temp = {
      ...readAction,
      ...payload
    }
    temp.readFromElement!=""&&temp.readToVariable!=""?temp.status=true:temp.status=false
    let instruction = `read ${temp.readFromElement} to ${temp.readToVariable}`
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : instruction
    }
    dispatch(updateTab(tab))
  }
}
