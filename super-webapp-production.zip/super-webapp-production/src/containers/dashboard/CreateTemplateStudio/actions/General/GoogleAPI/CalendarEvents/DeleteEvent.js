import uuid from 'uuid/v1'

import * as deleteConst from '../../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../../Tabs"
import {objToArr} from '../../../../utilities'
import {openDialog} from '../../../openDialog'

export const addDeleteEvent = (parentId = null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let action = {
              id : uuid(),
              type : deleteConst.DELETE_EVENT,
              parentId : parentId,
              label : "Delete Event",
              key : "deleteevent",
              allowNesting : false,
              variableName : '',
              instruction : "",
              description : "",
              status:false,
              breakpoint:false
            }
            let apiConfig =  objToArr(tab.actions).find((action)=>{
              return tab.actions[action.id].type == 'API_CONFIGURATION'
              })          
              if(apiConfig){
                tab =  addActionInTab(tab,action,parentId)
                dispatch(updateTab(tab))
              }else{
                dispatch(openDialog("api",action))
              }
          }
}
export const editDeleteEvent= (payload, actionId=null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let deleteEventAction = tab["actions"][actionId ? actionId : tab.currentAction]
            let temp = {
              ...deleteEventAction,
              ...payload
            }
            temp.status = temp.eventid!=""
            
            tab["actions"][actionId ? actionId : tab.currentAction] = {
              ...temp,
              instruction : `delete event`,
              description : `delete event`
            }
            dispatch(updateTab(tab))
          }
        }
        