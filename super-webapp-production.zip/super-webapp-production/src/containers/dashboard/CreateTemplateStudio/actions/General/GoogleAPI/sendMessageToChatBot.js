import uuid from 'uuid/v1'
import * as GoogleAPIConstants from '../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../Tabs"
import {objToArr} from '../../../utilities'
import {openDialog} from '../../openDialog'

export const addSendMessageToChatBot = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : GoogleAPIConstants.SEND_MESSAGE_TO_GOOGLECHATBOT,
      parentId : parentId,
      label : 'Send Message To GoogleChatBot',
      key : "sendmessagetochatbot",
      allowNesting : false,
      description :  "",
      message: "",
      spacename: "",
      status:false,
      breakpoint:false
    }
    let apiConfig =  objToArr(tab.actions).find((action)=>{
      return tab.actions[action.id].type == 'API_CONFIGURATION'
      })          
      if(apiConfig){
        tab =  addActionInTab(tab,action,parentId)
        dispatch(updateTab(tab))
      }else{
        dispatch(openDialog("api",action))
      }
  }
}

export const editsendMessageToChatBot = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let sendMsgAction = tab["actions"][currentAction]
    let temp = {
      ...sendMsgAction,
      ...payload
    }
    temp.status = temp.message!="" &&  temp.spacename!=""
    let instruction = `send ${temp.message} to ${temp.spacename} `
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : temp.message
    }
    dispatch(updateTab(tab))
  }
}
