import uuid from 'uuid/v1'

import * as spreadsheetConst from '../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../Tabs"
import {objToArr} from '../../../utilities'
import {openDialog} from '../../openDialog'

export const addDeleteSpreadsheetData = (parentId = null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let path = ''
            let action = {
              id : uuid(),
              type : spreadsheetConst.DELETE_SPREADSHEET_DATA,
              parentId : parentId,
              label : "Delete Spreadsheet Data",
              key : "deletespreadsheetdata",
              allowNesting : false,
              deleteScope:'cell',
              variableName : '',
              instruction : "",
              description : "",
              status:false,
              breakpoint:false
            }
            let apiConfig =  objToArr(tab.actions).find((action)=>{
              return tab.actions[action.id].type == 'API_CONFIGURATION'
              })          
              if(apiConfig){
                tab =  addActionInTab(tab,action,parentId)
                dispatch(updateTab(tab))
              }else{
                dispatch(openDialog("api",action))
              }
          }
}
export const editDeleteSpreadsheetData= (payload, actionId=null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let spreadsheetAction = tab["actions"][actionId ? actionId : tab.currentAction]
            let temp = {
              ...spreadsheetAction,
              ...payload
            }
            temp.status = temp.path!="" && temp.sheetName!="" && temp.range!=""
            
            tab["actions"][actionId ? actionId : tab.currentAction] = {
              ...temp,
              instruction : `delete ${temp.deleteScope} ${temp.range} in ${temp.sheetName}`,
              description : `delete ${temp.deleteScope} ${temp.range} in ${temp.sheetName}`
            }
            dispatch(updateTab(tab))
          }
        }
        