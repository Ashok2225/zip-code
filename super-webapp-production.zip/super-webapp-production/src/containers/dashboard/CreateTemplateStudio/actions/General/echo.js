import uuid from 'uuid/v1'
import * as echoConstants from '../../constants/General'
import { updateTab , addActionInTab} from "../Tabs"
import { ELSEIF } from '../../constants';

export const addEcho = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : echoConstants.ECHO,
      parentId : parentId,
      label : 'Echo',
      key : "echo",
      selector : "custom",
      variable : '',
      string : '',
      custom : '',
      allowNesting : false,
      description : "",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editEcho = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let echoAction = tab["actions"][currentAction]
    let temp = {
      ...echoAction,
      ...payload
    }
    let instruction = ''
    if(temp.selector === "custom") {
      temp.custom!=""?temp.status=true:temp.status=false
      if (temp.custom !== ""){
        let exp = temp.custom.replace(/`/g, "")
        instruction = `${temp.key} ${exp}`
      }
    }
    else if(temp.selector === "string"){
      temp.string != "" ? temp.status = true : temp.status = false
      instruction = `${temp.key} "${temp.string}"`
    }
    else{
      temp.variable !== ""? temp.status = true : temp.status = false
      if (temp.variable !== 0){
        instruction = `${temp.key} ${temp.variable}`
      }
    }
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : instruction
    }
    dispatch(updateTab(tab))
  }
}
