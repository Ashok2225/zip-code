import * as ReadFileConstants from "../../../constants/General/FilesAndFolders"
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'



export const addReadFile = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : ReadFileConstants.READFILE,
      label : "Read File",
      key : "readfile",
      variable:"",
      path: "",
      variableName : '',
      instruction : "",
      parentId:parentId,
      description : "",
      status:false,
      breakpoint:false    
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editReadFile = (payload,actionId=null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let FileAction = tab["actions"][currentAction]
    let temp = {
      ...FileAction,
      ...payload
    }
    temp.path&&temp.variable!=""?temp.status=true: temp.status=false
    let path = temp.path.replace(/\\/g,'\\\\' )
    let instruction = `load ${path} to ${temp.variable}\necho ${temp.variable}`
    let description = (temp.variable ? `Read ${temp.variable}` : '')+(temp.path ? ` from ${path}`:'')
    tab.actions[currentAction] = {
      ...temp,
      instruction : instruction,
      description : description
    }
    dispatch(updateTab(tab))
  }
}
