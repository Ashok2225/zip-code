import uuid from 'uuid/v1'

import * as modifyConst from '../../../../constants/General/GoogleAPI'
import { updateTab , addActionInTab} from "../../../Tabs"
import {objToArr} from '../../../../utilities'
import {openDialog} from '../../../openDialog'

export const addModifyEvent = (parentId = null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let action = {
              id : uuid(),
              type : modifyConst.MODIFY_EVENT,
              parentId : parentId,
              label : "Modify Event",
              key : "modifyevent",
              allowNesting : false,
              variableName : '',
              instruction : "",
              description : "",
              status:false,
              breakpoint:false
            }
            let apiConfig =  objToArr(tab.actions).find((action)=>{
              return tab.actions[action.id].type == 'API_CONFIGURATION'
              })          
              if(apiConfig){
                tab =  addActionInTab(tab,action,parentId)
                dispatch(updateTab(tab))
              }else{
                dispatch(openDialog("api",action))
              }
          }
}
export const editModifyEvent= (payload, actionId=null) => {
          return (dispatch, getState) => {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let modifyEventAction = tab["actions"][actionId ? actionId : tab.currentAction]
            let temp = {
              ...modifyEventAction,
              ...payload
            }
            temp.status = (temp.eventid!=""&&temp.eventid!=undefined) && ((temp.title!=""&&temp.title!=undefined) || (temp.attendees!=""&&temp.attendees!=undefined) || (temp.starttime!=""&&temp.starttime!=undefined) 
              || (temp.endtime!=""&&temp.endtime!=undefined) || (temp.timezone!=""&&temp.timezone!=undefined) || (temp.location!=""&&temp.location!=undefined) || (temp.rrule!=""&&temp.rrule!=undefined) || (temp.eventdescription!=""&&temp.eventdescription!=undefined))
            
            tab["actions"][actionId ? actionId : tab.currentAction] = {
              ...temp,
              instruction : `modify event`,
              description : `modify event`
            }
            dispatch(updateTab(tab))
          }
        }
        