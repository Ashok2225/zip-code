import * as stopConstants from '../../constants/General'
import { updateTab, addActionInTab } from "../Tabs"
import uuid from 'uuid/v1'

export const addStop = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            id: uuid(),
            type: stopConstants.STOP,
            label: "Stop",
            key: "stop",
            allowNesting: false,
            instruction: "stop",
            parentId: parentId,
            breakpoint:false
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}
export const editStop= (payload)=>{
    return (dispatch,getState)=>{
      let {tabs,currentTab} = getState()
      let tab = tabs[currentTab]
      let {currentAction} = tab
      let stopAction = tab.actions[currentAction]
      let temp = {
        ...stopAction,
        ...payload
      }
      tab.actions[currentAction] ={...temp}
      dispatch(updateTab(tab))
    }
  }