import * as ftpConstants from '../../../constants/General/SecureFtp'
import { updateTab , addActionInTab} from "../../Tabs"
import uuid from 'uuid/v1'

import {openDialog} from '../../openDialog'

export const DeleteFolderFtp = (parentId = null) => {
    return (dispatch, getState) => {
      let { tabs, currentTab } = getState()
      let tab = tabs[currentTab]
      let action = {
        id : uuid(),
        type : ftpConstants.FTP_DELETE_FOLDER,
        label : "Delete Folder",
        key : "ftpdeletefolder",
        allowNesting : false,
        RemotePath: "",
        variableName : '',
        instruction : "",
        parentId:parentId,
        description : "",
        status:false,
        breakpint:false
  
      }
      let temp_id = parentId
      let sequence_id = tab.sequence[0]
      while(!tab.sequence.includes(temp_id)){
        if(tab.actions[temp_id].key == 'connect' || tab.actions[temp_id].parentId == temp_id) break
        temp_id = tab.actions[temp_id].parentId
      }
      if(tab.actions[temp_id].key != 'connect'){
        dispatch(openDialog("ftp",action))
      }
      else{
        tab.connect_tree[temp_id].push(action.id)
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
      }
    }
  }

  export const EditFtpDeleteFolder = (payload,actionId=null) => {
    return (dispatch, getState) => {
      let { tabs, currentTab } = getState()
      let tab = tabs[currentTab]
      let {currentAction} = tab
      let FtpAction = tab["actions"][actionId ? actionId : currentAction]
      let temp = {
        ...FtpAction,
        ...payload
      }
      let temp_id = temp.parentId
      while(true){
        if(tab.actions[temp_id].key == 'connect' || tab.actions[temp_id].parentId == temp_id) break
        temp_id = tab.actions[temp_id].parentId
      }
      temp.user = tab['actions'][temp_id]['user']
      temp.host = tab['actions'][temp_id]['host']
      temp.password = tab['actions'][temp_id]['password']
      temp.port = tab['actions'][temp_id]['port']
      temp.RemotePath!=""?temp.status=true:temp.status=false
      let Remotepath = temp.RemotePath?temp.RemotePath:null
      
      tab["actions"][actionId ? actionId : currentAction] = {
        ...temp,
        instruction : `Delete ${temp.RemotePath}`,
        description : `Delete ${temp.RemotePath}`
      }
      dispatch(updateTab(tab))
    }
  }