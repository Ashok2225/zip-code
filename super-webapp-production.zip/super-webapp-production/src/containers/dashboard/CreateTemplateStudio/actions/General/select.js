import * as selectConstants from '../../constants/select'
import {updateTab , addActionInTab } from '../Tabs'
import uuid from 'uuid/v1'

export const addSelect = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : selectConstants.ADD_SELECT,
      parentId : parentId,
      label : "Select",
      key : "select",
      selector:"", 
      value:"" , 
      allowNesting : false,
      status:false,
      breakpint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
  }

export const editSelect = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab  = tabs[currentTab]
    let { currentAction }= tab
    let selectAction = tab["actions"][currentAction]
    let temp = {
      ...selectAction,
      ...payload
    }
    temp.selector&&temp.value!=""?temp.status=true:temp.status=false
    let instruction = `select ${temp.selector} as ${temp.value}`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction
    }
    dispatch(updateTab(tab))
  }
}
