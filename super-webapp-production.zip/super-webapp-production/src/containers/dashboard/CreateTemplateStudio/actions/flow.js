// import fs, { read } from 'fs'
// import os from 'os'
// import { spawn } from 'child_process'
// import path from 'path'
// import * as flowConstants from '../constants/flow'
// import { clearLogs, showLogs } from './logs'
// import { clearPath } from "./flowPath"
// import { objToArr, variableCheck } from '../utilities'
// import  zipFolder  from 'zip-folder'
// import { updateTab, updateRunningProcess } from './Tabs';
// import axios from 'axios'

// import { warningMsg } from './openDialog'
// const dialog = remote.dialog
// const uuid = require('uuid/v1')
// const fse = require('fs-extra')
// // const nodepath = require('../../static/node-v10.14.1-win-x64')
// // const spawn = require('child_process').execSync
// const ZipaFolder = require('./zip.js')
// global.running_flow_id = false
// global.techforce_process = {
//   killed : true,
//   pid : 0
// }


// export const getBrowser = (actions)=>{
//   let browser = ""
//   for (let [key, flow] of Object.entries(actions))  {
//     if (flow.type === "OPEN_WEB_PAGE" || flow.type === "ADD_EXTERNAL_FLOW"){
//       browser = flow.browser
//       if(browser === "chrome") break;
//     }
//   }
//   return browser
// }

// export const stopFlow = () => {
//   return (dispatch, getState) => {
//     const files = ["techforce_chrome.in","techforce_chrome.out","techforce_chrome.log"]
//     const autohotkey_files = ["techforce_autohotkey.out", "techforce_windows.log", "techforce.ahk", "techforce.log"]
//     let mainWindow = remote.getCurrentWindow()
//     let techforcePath  = path.join(__static, "/Techforce/src")
//     let autohotkey_techforcePath  = path.join(__static, "/Techforce/src/techforce.autohotkey")
//     if(!techforce_process.killed){
//       let exepath = path.join(__static, '/Configs/processKill/Processkill.exe')
//       const stop = spawn(exepath,[techforce_process.pid])
//       stop.on('close', (code) => {
//         if(code===0){
//           files.forEach(function (filePath){
//             fs.access(techforcePath+"/"+filePath, error => {
//               if (!error) {
//                 fs.unlinkSync(techforcePath + "/" + filePath, function (error) {
//                   console.log(error);
//                 });
//               } else {
//                 console.log(error);
//               }
//             });
//           })
//           autohotkey_files.forEach(function (filePath){
//             fs.access(autohotkey_techforcePath+"/"+filePath, error => {
//               if (!error) {
//                 fs.unlinkSync(autohotkey_techforcePath + "/" + filePath, function (error) {
//                   console.log(error);
//                 });
//               } else {
//                 console.log(error);
//               }
//             });
//           })
//           techforce_process.killed = true
//           techforce_process.pid = 0
//           dialog.showMessageBox(mainWindow, { type: "info", title: "Botforce-IDE", message: "Bot stopped Successfully", buttons: ["ok"] })
//           fs.writeFileSync(path.join(os.tmpdir(),"TechforceProcessStatus"),
//                                                 JSON.stringify({
//                                                     ifFlowRunning: false,
//                                                     data : new Date()
//                                                 }),"utf8")
//         }
//       })
//     }else{
//       dialog.showMessageBox(mainWindow, { type: "info", title: "Botforce-IDE", message: "No bot is runnning", buttons: ["ok"] })
//     }
//   }
// }


// export const executeFlow = () => {
//   return (dispatch, getState) => {

//     let { currentTab, tabs } = getState()
//     //let flowCommands = createFlow(currentTab.contextualActions, currentTab.flow, currentTab)
//     let browser = ""
//     let json_data =  fs.readFileSync(`${tabs[currentTab].flowPath}.json`)
//     let actions = JSON.parse(json_data.toString('utf-8')).actions
//     if(Object.keys(actions).length!= Object.keys(tabs[currentTab].actions).length){
//       dispatch(warningMsg("Please save the flow"))
//       return " "
//     }
//       if(currentTab){
//       dispatch(clearLogs())
//       let tab  = tabs[currentTab]
//       // let flows = objToArr(tab.actions, tab.sequence)
//       let browser = getBrowser(tab.actions)
//       // browser = result?result:""
//       let rpaPath = 'tagui'
//       if (os.platform() === 'win32') {
//         rpaPath = path.join(__static, '/Techforce/src/techforcerpa.exe')
//       }
//       if(!fs.existsSync(path.join(os.tmpdir(),"TechforceProcessStatus"))){
//         fs.writeFileSync(path.join(os.tmpdir(),"TechforceProcessStatus"),
//                                               JSON.stringify({
//                                                   ifFlowRunning: false,
//                                                   data : new Date()
//                                               }),"utf8")
//       }
//       //path.join(os.tmpdir(),"TechforceProcessStatus")
//       let read1 = fs.readFileSync(path.join(os.tmpdir(),"TechforceProcessStatus"), 'utf8')
//       read1 = JSON.parse(read1)
//       if(read1.ifFlowRunning== true){
//         return false
//       }else{
//         running_flow_id = tab.id
//         fs.writeFileSync(path.join(os.tmpdir(),"TechforceProcessStatus"),
//                                               JSON.stringify({
//                                                   ifFlowRunning: true,
//                                                   data : new Date()
//                                               }),"utf8")
//                                               dispatch(updateRunningProcess(true))
//                                               const rpa = spawn(rpaPath, ['run', '-f', `${path.dirname(tab.flowPath)}`, '-b', browser,'--debug'])
//                                               window.rpa = rpa
//                                               techforce_process.killed = rpa.killed
//                                               techforce_process.pid = rpa.pid
//                                               console.log(rpa.pid)
//                                               fs.writeFileSync(path.join(os.tmpdir(),"TechforceProcessStatus"),
//                                                                                     JSON.stringify({
//                                                                                         ifFlowRunning: false,
//                                                                                         data : new Date()
//                                                                                     }),"utf8")
//                                               rpa.stdout.on('data', (data) => dispatch(showLogs(data)))
//                                               rpa.stderr.on('data', (data) => dispatch(showLogs(data)))
//                                               rpa.on('close', (code) => {
//                                                 console.log("@@@@@@@@@@@@@@@@@@@@",code)
//                                                 if(code === 1) spawn(path.join(__static, '/Techforce/src/kill_on_exception.exe'), [])
//                                                 techforce_process.killed = true
//                                                 techforce_process.pid = 0
//                                                 dispatch(updateRunningProcess(false))
//                                               })
//                                               rpa.on('exit', function (code, signal) {
//                                                 techforce_process.killed = true
//                                                 techforce_process.pid = 0
//                                                 dispatch(updateRunningProcess(false))
//                                                 });
//                                               return true
//       }
//     }
//   }
// }

// export const executeFlowQueue = () =>{
//   return (dispatch, getState) => {
//     let { currentTab, tabs } = getState()
//     let tab  = tabs[currentTab]
//     let payload = {
// 	     TF_FLOW_PATH: tab.flowPath,
// 	      execution_type:"chrome",
//         user_name:"ide",
//         role:"admin"
//     }
//     let data = axios.post(`http://localhost:5555/v1/rpa/metadata/rabbitMQ/producer`,payload).then(()=>{
//       return true
//     }).catch((e)=>{
//       console.log('e',e);
//       return false
//     })
//     return data
//   }
// }

// export const addSchedule =(schedule)=>{
//     return(dispatch, getState) => {
//        try {
//           let scheduletype=
//           Object.keys(schedule.minute).length!==0?{minute:schedule.minute}:Object.keys(schedule.hourly).length!==0?{hourly:schedule.hourly}:
//                     Object.keys(schedule.daily).length!==0 ? {daily:schedule.daily}:Object.keys(schedule.weekly).length!==0?{weekly:schedule.weekly}:
//                     Object.keys(schedule.monthly).length!==0?{monthly:schedule.monthly}:  Object.keys(schedule.advanced).length!==0?{advanced:schedule.advanced}:undefined
//           let scheduleKey = Object.keys(scheduletype)!==undefined?Object.keys(scheduletype):null
//           let scheduleValue = scheduletype[scheduleKey]
//           let { currentTab, tabs } = getState()
//           let tab
//           if(currentTab){
//             tab  = tabs[currentTab]
//           }
//           let payload ={
//             process_id:uuid(),
//             stopTime:schedule.stopJob===true?schedule.date:null,
//             timeZone:schedule.timezone,
//             schedule_name:schedule.name,
//             TF_FLOW_PATH:tab.flowPath,
//             routingKey:schedule.routingKey,
//             stop:schedule.stopJob===true?schedule.actions==="stop"?"true":"false":null,
//             filePath: "xyz",
//             execution_type:schedule.execution_type
//             }

//             payload[scheduleKey] = scheduleValue
//             console.log("payload",payload);
//             let data = axios.post(`http://localhost:5555/v1/rpa/metadata/scheduler/cronJob`,payload).then(()=>{
//               return true
//             }).catch((e)=>{
//               console.log('e',e);
//               return false
//             })
//             return data
//        } catch (error) {
//           console.log('e',error);
//           return false
//        }
//      }
//   }


// export const clearFlowRequest=()=>({
//    type: flowConstants.CLEAR_FLOW
// })


// export const clearFlow = () => {
//   return (dispatch)=>{
//     dispatch(clearLogs())
//     dispatch(clearFlowRequest())
//     dispatch(clearPath())
//   }
// }

// const createCommands = (flows, actions, variables) => {
//   let flowCommands = ""
//   for (const flow of flows) {

//     if(flow.instruction){
//       if (flow.variableName && flow.instruction.includes(flow.variableName) && variables.hasOwnProperty(flow.variableName)){
//         let str = flow.instruction.replace(flow.variableName, variables[flow.variableName].name)
//         flowCommands = flowCommands + str  + os.EOL ;
//       }else{
//         flowCommands = flowCommands + flow.instruction  + os.EOL ;
//        }
//     }
//     if(flow.type === "IF" || flow.type === "LOOPS" || flow.type === "IFELSECHILED" || flow.type === "ELSEIF" || flow.type === "TRY_CATCH" ||
//         flow.type === "POPUP" || flow.type === 'FRAME' ){
//       flowCommands += "{"+ os.EOL + createCommands(objToArr(actions, flow.subActions), actions, variables) +"}"+os.EOL;
//     }
//     else if(flow.subActions && flow.subActions.length ){
//       flowCommands +=  createCommands(objToArr(actions, flow.subActions), actions, variables);
//     }
//   }
//   return flowCommands
// }

// export const saveFlow = (tabId=null) => {
//   return async (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let tab = null
//     if(currentTab)tab = tabs[tabId?tabId:currentTab];

//     if(tab){
//       try {

//         let flow = objToArr(tab.actions, tab.sequence)
//         let actions = objToArr(tabs[currentTab].actions)
//         if(actions.some((action)=>{return action.status == false;})){
//           dispatch(warningMsg("flow has some validation errors, please resolve them first"))
//         }
//         else{
//         let variables = objToArr(tab.variables)
//         let flowCommands = ""
//         for (let variable of variables) {
//           let variablecheck = variableCheck(variable.name, tab.variables)
//           if (!variablecheck.valid) {
//             dispatch(warningMsg(variablecheck.msg))
//             return
//           }
//           else {
//             if (variable.type === "string") {
//               if (variable.defaultValue.includes('"')) {
//                 flowCommands = flowCommands + os.EOL + `${variable.name} = ${variable.defaultValue === "" ? '""' : `'${variable.defaultValue}'`}`
//               }
//               else {
//                 flowCommands = flowCommands + os.EOL + `${variable.name} = ${variable.defaultValue === "" ? '""' : `"${variable.defaultValue}"`}`
//               }

//             }
//             else if (variable.type === "secure") {
//               flowCommands = flowCommands + os.EOL + `${variable.name} = secureEntry("${variable.name}",${variable.defaultValue === "" ? null : `"${variable.defaultValue}"`})`
//             }
//             else {
//               flowCommands = flowCommands + os.EOL + `${variable.name} = ${variable.defaultValue === "" ? '[]' : variable.defaultValue}`
//             }
//           }
//         }

//         // for (let action of tab.actions){
//         //   for (let variable of variables){
//         //       if(action.instruction && action.instruction.includes(variable.id)){
//         //         action.str = action.instruction.replace(variable.id,variable.name)
//         //       }
//         //   }
//         //   console.log("action after setting", action)
//         // }


//         flowCommands += os.EOL + `js begin${os.EOL}var sys = require('system')${os.EOL}try{ console.log(dirPath) }catch(e) {sys.args.forEach(function (param, idx) {if (param == "--cli") {dirPath = sys.args[idx + 1].split('\\\\').slice(0,-1).join('/')+"/"}})}${os.EOL}js finish`
//         flowCommands += os.EOL + createCommands(flow, tab.actions, tab.variables)
//         fs.writeFileSync(tab.flowPath, flowCommands, {
//                 encoding: 'utf8'
//               })
//         let saved_data = JSON.parse(JSON.stringify(tab));
//         saved_data.logs = ""
//         await fs.writeFileSync(tab.flowPath + ".json", JSON.stringify(saved_data, 0, 2))
//         // let zipfolder = tab.dirPath
//         // let changepath = zipfolder.replace(/\//g,'\\')
//         // ZipaFolder.MakeZip(zipfolder,dispatch)
//         dispatch(updateTab(tab))
//             }
//       }catch (error) { console.log(error)}
//     }
//   }
// }
