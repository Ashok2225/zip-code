import * as domConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addDom = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            type: domConstants.DOM,
            id: uuid(),
            key:"dom",
            label:"DOM",
            Dom: "",
            domFunction: "history.back()",
            instruction: 'dom history.back()',
            parentId:parentId,
            status:false,
            breakpoint:false
        }
        let webpage =  objToArr(tab.actions).find((action)=>{
            return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
            })          
            if(webpage){
              tab =  addActionInTab(tab,action,parentId)
              dispatch(updateTab(tab))
            }else{
              dispatch(openDialog("web",action))
            }
      }
    }



export const updateDom = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let dom = tab["actions"][currentAction]
        let temp = {
            ...dom,
            ...payload
        }
        temp.Dom!=""?temp.status=true:temp.status=false
        let instruction= `dom return ${temp.Dom}`
        tab["actions"][currentAction] = {
        ...temp,
        instruction: instruction,
        description: temp.Dom
        }
        dispatch(updateTab(tab))
    }
    }
