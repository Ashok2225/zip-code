 import * as types  from '../../constants/WebAutomation'
 import {addActionInTab, updateTab} from '../Tabs'
 import uuid from 'uuid/v1'
 import {openDialog} from '../openDialog'
 import {objToArr} from '../../utilities'
export const addBack = (parentId=null)=>{
  return(dispatch,getState)=>{
         let {tabs,currentTab} = getState()
         let tab = tabs[currentTab]
         let action = {
              id:uuid(),
              type: types.BACK,
              key:"back",
              label:"Back",
              instruction: `dom history.back()`,
              parentId:parentId,
              description:"",
              breakpoint:false
          }
          let webpage =  objToArr(tab.actions).find((action)=>{
          return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
          })          
          if(webpage){
            tab =  addActionInTab(tab,action,parentId)
            dispatch(updateTab(tab))
          }else{
            dispatch(openDialog("web",action))
          }
        }
}

export const editBack= (payload)=>{
  return (dispatch,getState)=>{
    let {tabs,currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let backAction = tab.actions[currentAction]
    let temp = {
      ...backAction,
      ...payload
    }
    tab.actions[currentAction] ={...temp}
    dispatch(updateTab(tab))
  }
}
