import * as scrollConstants from   "../../constants/WebAutomation"
import {addActionInTab,updateTab} from "../Tabs"
import uuid from 'uuid/v1'
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addScroll = (parentId=null)=>{
return(dispatch,getState)=>{
let {tabs,currentTab} = getState()
let tab = tabs[currentTab]
let action = {
          type: scrollConstants.SCROLL,
          id: uuid(),
          key:"scroll",
          label:"scroll",
          page:"",
          label:"Scroll",
          scroll:"scrollIfneeded",
          instruction: `dom`,
          parentId:parentId,
          status:false,
          breakpoint:false
    }
    let webpage =  objToArr(tab.actions).find((action)=>{
      return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
      })          
      if(webpage){
        tab =  addActionInTab(tab,action,parentId)
        dispatch(updateTab(tab))
      }else{
        dispatch(openDialog("web",action))
      }
  }
}
export const updateScroll = (payload={})=>{
   return (dispatch,getState)=>{
          let { tabs, currentTab } = getState()
          let tab=tabs[currentTab]
          let {currentAction} = tab
          let scroll=tab["actions"][currentAction]
          let temp={
                     ...scroll,
                     ...payload
           }
           temp.page!=""?temp.status=true:temp.status=false
           let instruction
           if(temp.scroll == "always"){
            instruction =   `dom ${temp.page}.scrollIntoView()`
           }else{
           instruction =   `dom ${temp.page}.scrollIntoViewIfNeeded() `}
           tab["actions"][currentAction]={
             ...temp,
             instruction:instruction
           }
           dispatch(updateTab(tab))

   }
}
