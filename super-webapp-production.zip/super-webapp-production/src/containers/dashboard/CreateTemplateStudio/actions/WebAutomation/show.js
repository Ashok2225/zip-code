import * as showConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addShow = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            type: showConstants.SHOW,
            id: uuid(),
            key:"show",
            label:"Show",
            instruction: `show`,
            parentId:parentId,
            status:false,
            breakpoint:false
        }
        let webpage =  objToArr(tab.actions).find((action)=>{
            return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
            })          
            if(webpage){
              tab =  addActionInTab(tab,action,parentId)
              dispatch(updateTab(tab))
            }else{
              dispatch(openDialog("web",action))
            }
      }
    }



export const updateShow = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let show = tab["actions"][currentAction]
        let temp = {
        ...show,
        ...payload
        }
        temp.element!=""?temp.status=true:temp.status=false
        let instruction = `show ${temp.element}`
        tab["actions"][currentAction] = {
        ...temp,
        instruction: instruction,
        description: temp.element
        }
        dispatch(updateTab(tab))
    }
    }
