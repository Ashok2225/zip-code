import uuid from 'uuid/v1'
import * as webScrapperConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"

export const addWebScrapper = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id: uuid(),
      type: webScrapperConstants.WEB_SCRAPPER,
      label:"Web Scrapper",
      key:"webscrapper",
      allowNesting:false,
      subActions: [],
      url:"",
      path : "",
      URLList : "",
      ImageList : "",
      TextContent : "",
      browser:"headless",
      instruction:"",
      parentId:parentId,
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const updateWebScrapper = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab  } = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let webPage = tab["actions"][currentAction]
    let temp = {
      ...webPage,
      ...payload
    }

    temp.url != "" ? temp.status = true : temp.status = false
    let instruction = ""
    
    instruction = temp.url
    
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description: `Scrape page data - ${instruction}`
    }
    dispatch(updateTab(tab))
  }
}
