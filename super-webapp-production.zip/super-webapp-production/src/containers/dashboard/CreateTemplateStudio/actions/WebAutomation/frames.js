import uuid from 'uuid/v1'
import * as webPageConstants from '../../constants/WebAutomation'
import { updateTab, addActionInTab } from "../Tabs"
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addFrame = (parentId = null) => {
    return (dispatch, getState) => {
        if (parentId) {
            let { tabs, currentTab } = getState()
            let tab = tabs[currentTab]
            let action = {
                id: uuid(),
                type: webPageConstants.FRAME,
                label: "Frame",
                key: "frame",
                frameName : "",
                allowNesting: true,
                subActions: [],
                parentId: parentId,
                status: false,
                breakpoint:false
            }
            let webpage =  objToArr(tab.actions).find((action)=>{
                return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
                })          
                if(webpage){
                  tab =  addActionInTab(tab,action,parentId)
                  dispatch(updateTab(tab))
                }else{
                  dispatch(openDialog("web",action))
                }
        }
    }
}

export const editFrame = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let { currentAction } = tab
        let frame = tab["actions"][currentAction]
        let temp = {
            ...frame,
            ...payload
        }
        let instruction = ''
        temp.frameName !== "" ?  temp.status = true : temp.status = false
        instruction = `frame ${temp.frameName}`
        tab["actions"][currentAction] = {
            ...temp,
            instruction: instruction,
            description: instruction
        }
        dispatch(updateTab(tab))
    }
}
