import uuid from 'uuid/v1'
import * as webPageConstants from '../../constants/WebAutomation'
import { updateTab, addActionInTab } from "../Tabs"
import { updateTemplateAcions } from "../../../../../redux/actions/template"
export const addWebAutomation = (parentId = null) => {
  return (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: "webautomation",
      label: "Web Automation",
      key: "webautomation",


      isShow: true
    }
    dispatch(updateTemplateAcions(action))
  }
}

export const updateOpenWebpage = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let webPage = tab["actions"][currentAction]
    let temp = {
      ...webPage,
      ...payload
    }

    temp.url != "" ? temp.status = true : temp.status = false
    let instruction = ""
    if (temp.path != "" && temp.path != ".") {
      instruction = `${temp.url} | ${temp.path}`
    } else {
      instruction = temp.url
    }
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description: instruction
    }
    dispatch(updateTab(tab))
  }
}
