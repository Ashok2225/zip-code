import uuid from 'uuid/v1'
import * as webPageConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addReadTable = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id: uuid(),
      type: webPageConstants.READ_TABLE,
      label:"Read Table",
      key:"readtable",
      allowNesting:false,
      subActions: [],
      xpath: "",
      colName: "",
      variableName: "",
      instruction: "",
      parentId:parentId,
      status:false,
      description: "",
      iframe_name:"",
      breakpoint:false
    }
    let webpage =  objToArr(tab.actions).find((action)=>{
      return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
      })          
      if(webpage){
        tab =  addActionInTab(tab,action,parentId)
        dispatch(updateTab(tab))
      }else{
        dispatch(openDialog("web",action))
      }
  }
}

export const editReadTable = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab  } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let webPage = tab["actions"][currentAction]
    let temp = {
      ...webPage,
      ...payload
    }
    if (temp.xpath && temp.variableName) {
      temp.status = true
    } else {
      temp.status = false
    }
    let xpath  = temp.xpath ? temp.xpath.replace(/\"/g,'\\"') : null
    let instruction = `${temp.variableName} = readTable("${xpath}", "${temp.colName}","${temp.iframe_name}")`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description: `Read "${temp.colName}" column of "${temp.xpath}" table`
    }
    dispatch(updateTab(tab))
  }
}
