import * as snapConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addSnap = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            type: snapConstants.SNAP,
            id: uuid(),
            key:"snap",
            label:"Snap",
            variable: "page",
            snapValue:"",
            imageName: "",
            imgName:"",
            parentId:parentId,
            instruction : "snap page",
            description: "snap page",
            status:false,
            breakpoint:false
        }
        let webpage =  objToArr(tab.actions).find((action)=>{
            return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
            })          
            if(webpage){
              tab =  addActionInTab(tab,action,parentId)
              dispatch(updateTab(tab))
            }else{
              dispatch(openDialog("web",action))
            }
      }
    }



export const updateSnap = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab  } = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let snap = tab["actions"][currentAction]
        let temp = {
            ...snap,
            ...payload
        }
        let instruction = ''
        let description = ''
        if(temp.variable === "page"){            
            if(temp.imageName.trim()){
                instruction = `snap page to ${temp.imageName}`
                description = temp.imageName
            }else{
                instruction = 'snap page'
                description = 'page'
            }
            temp.imgName!=""?temp.status=true:temp.status=false
        }else{            
            if (temp.snapValue.trim() && temp.imageName.trim()) {
                instruction = `snap ${temp.snapValue} to ${temp.imageName}`
                description = `${temp.snapValue} to ${temp.imageName}`
            } else if(temp.snapValue.trim()){
                instruction = `snap ${temp.snapValue}`
                description = temp.snapValue
            }else{
                instruction =  `snap page`
                description = 'page'
            }
            temp.imageName&&temp.snapValue?temp.status=true:temp.status=false
        }
        tab["actions"][currentAction] = {
        ...temp,
        instruction: instruction,
        description: description
        }
        dispatch(updateTab(tab))
    }
    }
