import uuid from 'uuid/v1'
import * as webPageConstants from '../../constants/WebAutomation'
import { updateTab , addActionInTab} from "../Tabs"
import {openDialog} from '../openDialog'
import {objToArr} from '../../utilities'

export const addPopup = (parentId = null) => {
        return (dispatch, getState) => {
            if(parentId){
                let { tabs, currentTab } = getState()
                let tab = tabs[currentTab]
                let action = {
                    id: uuid(),
                    type: webPageConstants.POPUP,
                    label:"Popup",
                    key:"popup",
                    allowNesting:true,
                    subActions: [],
                    value:"",
                    instruction: "popup",
                    parentId:parentId,
                    status:false,
                    breakpoint:false
                }
                let webpage =  objToArr(tab.actions).find((action)=>{
                    return tab.actions[action.id].type == 'OPEN_WEB_PAGE'
                    })          
                if(webpage){
                      tab =  addActionInTab(tab,action,parentId)
                      dispatch(updateTab(tab))
                    }else{
                      dispatch(openDialog("web",action))
                    }
            }
        }
    }

export const updatePopup = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let { currentAction } = tab
    let popup = tab["actions"][currentAction]
        let temp = {
        ...popup,
        ...payload
        }
        temp.value !="" ?temp.status=true:temp.status=false
        let instruction = `popup ${temp.value}`
        tab["actions"][currentAction] = {
            ...temp,
            instruction: instruction,
            description: temp.value
        }
        dispatch(updateTab(tab))
  }
}
