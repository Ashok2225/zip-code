import fs from 'fs'
import path from 'path'
import uuid from 'uuid/v1'

export const addActionInTab = (tab, action, parentId = null) => {
  let parentAction = tab.actions[parentId];
  tab.actions[action.id] = action;
  if(action.key == "then" || action.key== "else") {
    tab.selectedActions = [action.parentId]
    tab.currentAction = action.parentId
  }else if(action.key == "catch"){
    tab.selectedActions = [action.dependentActions[0]]
    tab.currentAction = action.dependentActions[0]
  }else{
    tab.selectedActions = [action.id];
    tab.currentAction = action.id;
  }

  if (parentAction && parentAction.type === "IFELSE") {
    
      if (action.type === "IFELSECHILED") {
        tab.actions[action.id] = action
        tab.actions[parentId].subActions.push(action.id)
        return tab
      }
      else if (action.type === "ELSEIF") {
        tab.actions[action.id] = action
        tab.actions[parentId].subActions.splice(tab.actions[parentId].subActions.length - 1, 0, action.id)
        return tab
      }
      else{
        let thenActionId = parentAction.subActions[0]
        tab.actions[action.id].parentId = thenActionId
        tab.actions[thenActionId].subActions.push(action.id);
      }
  }
  
  else if (parentId && parentAction.allowNesting) {
    tab.actions[parentId].subActions.push(action.id)
  }
  else if (parentId) {
    let index
    if (!parentAction.allowNesting) {
      let actions = tab.actions[parentAction.parentId].subActions;
      index = actions.indexOf(parentId) + 1;
      if(action.key == "catch"){ index = actions.indexOf(parentId) + 2}
      tab.actions[action.id].parentId = parentAction.parentId
      parentId = parentAction.parentId;
    } else {
      index = parentAction.subActions.length;
    }
    tab.actions[parentId].subActions.splice(index, 0 , action.id);
  }
  else {
    tab.sequence.push(action.id)
  }
  return tab
}

/**
 * This method deletes the images in File system
 * @param {*} tab 
 * @param {*} actionId 
 */
const deleteFile = (tab, actionId) => {
//   let deletePath;
//   if (tab.actions[actionId]["key"] == "draganddrop") {
//     if (tab.actions[actionId]['from']["imgSelector"]) {
//       deletePath = path.join(tab.dirPath, tab.actions[actionId]['from']["imgSelector"])
//       if (fs.existsSync(deletePath)) {
//         fs.unlinkSync(deletePath)
//       }
//     }
//     if (tab.actions[actionId]['to']["imgSelector"]) {
//       deletePath = path.join(tab.dirPath, tab.actions[actionId]['to']["imgSelector"])
//       if (fs.existsSync(deletePath)) {
//         fs.unlinkSync(deletePath)
//       }
//     }
//   }
//   else {
//     if (tab.actions[actionId]["imgSelector"]) {
//       deletePath = path.join(tab.dirPath, tab.actions[actionId]['imgSelector'])
//       if (fs.existsSync(deletePath)) {
//         fs.unlinkSync(deletePath)
//       }
//     }
//   }
// }

// const getSequence = (tab, parentId) => {
//   let parentAction = tab.actions[parentId]
//   if (parentAction.parentId) {
//     if(tab.actions[parentAction.parentId].key==="try" ){
//       return tab.actions[parentAction.parentId]
//     }
//     return getSequence(tab, parentAction.parentId)
//   } else {
//     return parentAction
//   }
}

export const removeActionsFromTab = (tab, actionId) => {
  let { selectedActions } = tab
  if(selectedActions.length > 0 &&actionId?tab.actions[actionId].key!="sequence":true){
    for (let actionId of selectedActions) {
      let action = {...tab.actions[actionId]}
      if(tab.actions[actionId]){
        tab.actions[actionId].dependentActions = tab.actions[actionId].dependentActions ? tab.actions[actionId].dependentActions : []
        let actionsRemoved = [
          ...tab.actions[actionId].dependentActions, actionId,
          ...childActionsIds(tab, actionId), ...childActionsIds(tab, tab.actions[actionId].dependentActions[0])
        ]
        for (let aId of actionsRemoved) {
          deleteFile(tab, aId)
          delete tab.actions[aId]
          if (action.parentId) {
            if (tab.actions[action.parentId]) {
              tab.actions[action.parentId].subActions = tab.actions[action.parentId].subActions.filter(id => id !== aId)
            }
          } else {
            tab.sequence = tab.sequence.filter(id => id !== aId)
          }
        }
      }
    }
    tab.selectedActions = []
  }
  else{
    tab.actions[actionId].dependentActions = tab.actions[actionId].dependentActions ? tab.actions[actionId].dependentActions : []
    let actionsRemoved = [
      ...tab.actions[actionId].dependentActions, actionId,
      ...childActionsIds(tab, actionId), ...childActionsIds(tab, tab.actions[actionId].dependentActions[0])
    ]
    for (let actionId of actionsRemoved) {
      deleteFile(tab, actionId)
      tab.currentAction = ""
      delete tab.actions[actionId]
      tab.sequence = tab.sequence.filter(id => id !== actionId)
    }
  }
  return tab
}

/**
 * This method returns all subActions ids
 * @param {*} tab 
 * @param {*} actionId    
 */
export const  childActionsIds = (tab, actionId) => {
  let temp = []
  let action = tab.actions[actionId]
  let actionsRemoved = action && action.subActions ? action.subActions : []
  temp = [...temp, ...actionsRemoved]
  for (const id of actionsRemoved) {
    temp = [...temp, ...childActionsIds(tab, id)]
  }
  return temp
}

export const parseActionFlows = (tab, actionId, parentId, utilityActions) => {
  let id = uuid()
  let { actions } = utilityActions
  tab.actions[parentId].subActions ? tab.actions[parentId].subActions = [...tab.actions[parentId].subActions] : tab.actions[parentId].subActions = []
  let index = tab.actions[parentId].subActions.indexOf(actionId)
  if (index != -1) {
    tab.actions[parentId].subActions[index] = id
  }
  
  let obj = Object.assign({}, actions[actionId])
  tab.actions[id] = obj
  tab.actions[id].id = id
  tab.actions[id].parentId = parentId
  tab.actions[id].dependentActions ? tab.actions[id].dependentActions = [...tab.actions[id].dependentActions] : tab.actions[id]["dependentActions"] = []
  if (tab.actions[id].dependentActions.length > 0 & tab.actions[id].key == "catch") {
    let try_action_id = tab.actions[parentId].subActions[tab.actions[parentId].subActions.length -1]
    tab.actions[id].dependentActions = [try_action_id]
    tab.actions[try_action_id].dependentActions = [id]
  }
  tab.actions[id].subActions ? tab.actions[id].subActions = [...tab.actions[id].subActions] : tab.actions[id]["subActions"] = []
  if (tab.actions[id].subActions.length > 0){
    for(let act of tab.actions[id].subActions){
      tab = parseActionFlows(tab, act, id, utilityActions)
    }
  }
  return tab
}
