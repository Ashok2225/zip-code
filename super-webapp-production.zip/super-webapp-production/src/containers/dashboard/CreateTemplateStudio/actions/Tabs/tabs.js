
// import * as tabsConstants from '../../constants'
// import { childActionsIds, removeActionsFromTab, parseActionFlows, addActionInTab } from './actionUtils'
// import uuid from 'uuid/v1'
// import { openDialog , saveChangeDialog } from '../openDialog';
// import { editScopePath } from "../General/Excel/editScope"
// import path from 'path'
// import {isSave } from '../../utilities'
// import fs from 'fs'

// export const updateTab = (currentTab, data) => {
//   return(dispatch,getState) =>{
//       let tab= currentTab
//       if(tab==null){
//       let { tabs,currentTab } = getState()
//       tab = tabs[currentTab]
//       fs.readdirSync(tab.dirPath).forEach((file)=>{
//           fs.copyFileSync(path.join(tab.dirPath,file),path.join(data.dirPath,file))
//           if(path.parse(file).name == tab.dirPath.split("/").pop()){
//               fs.renameSync(path.join(data.dirPath,file),path.join(data.dirPath,data.destination+path.parse(file).ext))
//           }
//       })
//       tab.flowPath = data.filePath
//       tab.dirPath =  data.dirPath//filePath.substr(0,data.filePath.lastIndexOf("/"))
//     }
//     tab["isEdit"] = isSave(tab)
//     // let pastActions = JSON.parse(JSON.stringify(window.tabs[tab.id].present))
//     // let actionsLength = Object.keys(tab.actions).length
//     // let pastActionsLength = Object.keys(pastActions).length
//     // if (actionsLength !== pastActionsLength){
//     //   window.tabs[tab.id].past.push(pastActions)
//     //   window.tabs[tab.id].present = JSON.parse(JSON.stringify(tab.actions))
//     // }
//     dispatch({ type: tabsConstants.UPDATE_TAB, tab })
//   }
// }

// /**
// * This method is active Tab (or) current Tab
// */

// export const activeTab = (tabId) => {
//   return (dispatch,getState) => {
//       let { tabs } = getState()
//       let data = tabs[tabId]
//       ipcRenderer.send('COMMON_PROPERTY', data)
//       dispatch({
//             type: tabsConstants.CURRENT_TAB,
//             tabId: tabId
//           })
//   }
// }

// export const undoFlows = () => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState();
//     let tab = tabs[currentTab];
//     let windowTab = window.tabs[tab.id]
//     if (windowTab.past.length > 0){
//       windowTab.future.push(JSON.parse(JSON.stringify(windowTab.present))) 
//       windowTab.present = windowTab.past.pop();
//       tab.actions = JSON.parse(JSON.stringify(windowTab.present)) 
//       dispatch({ type: tabsConstants.UPDATE_TAB, tab })
//     }
//   }
// }

// export const redoFlows = () => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState();
//     let tab = tabs[currentTab];
//     let windowTab = window.tabs[tab.id]
//     if(windowTab.future.length > 0){
//       windowTab.past.push(JSON.parse(JSON.stringify(windowTab.present)));
//       windowTab.present = windowTab.future.shift();
//       tab.actions = JSON.parse(JSON.stringify(windowTab.present))
//       dispatch({ type: tabsConstants.UPDATE_TAB, tab })
//     }
//   }
// }

// export const addTab = (path, tab=null) => {
//   return (dispatch) => {

//     if (path) {
//       let action = {
//         type: tabsConstants.ADD_TAB,
//         tab: {
//           id: tab ? tab.id : uuid(),
//           actions: tab ? tab.actions:{},
//           variables : tab ? tab.variables: {},
//           parameters : tab && tab.parameters ? tab.parameters : {},
//           ftpConfig : tab ? (tab.ftpConfig ? tab.ftpConfig : {}) : {},
//           connect_tree : tab ? (tab.connect_tree ? tab.connect_tree : {}) : {},
//           sequence: tab ? tab.sequence : [],
//           selectedActions : tab ? tab.selectedActions : [],
//           logs : tab ? tab.logs : '',
//           flowPath: path.filePath,
//           dirPath: path.dirPath,
//           currentAction:tab ? tab.currentAction : "",
//           isEdit:false
//         }
//       }
//       window.tabs = {}
//       window.tabs[action.tab.id] = {
//         present : {},
//         future : [],
//         past : []
//       }
//       if(!tab) {
//         let sequenceAction = {
//           id: uuid(),
//           type: tabsConstants.ADD_SEQUENCE,
//           label: "Sequence",
//           key: "sequence",
//           title: "Stage-" + 1,
//           allowNesting: true,
//           expanded: true,
//           subActions: []
//         }
//         action.tab = addActionInTab(action.tab, sequenceAction)
//         window.tabs[action.tab.id].present = JSON.parse(JSON.stringify(action.tab.actions))
//       }
//       else{
//         window.tabs[tab.id].present = JSON.parse(JSON.stringify(action.tab.actions))
//       }
//       dispatch(action)
//       dispatch(activeTab(action.tab.id))
//     }else {
//       dispatch(openDialog("actions"))
//     }
//   }
// }

// export const clearTabs = () => {
//   return dispatch => {
//     dispatch({type:tabsConstants.CLEAR_CURRENT_TAB})
//     dispatch({type:tabsConstants.CLEAR_ALL_TABS})
//   }
// }

// export const closeTab = (index, f=false) => {
//   return (dispatch,getState) => {
//     let { tabs , currentTab } = getState();
//     let { sequence } = tabs;
//     let tabId = sequence[index];
//     let { isEdit } = tabs[tabId];

//     // "isEdit" to check whether any changes made to the flow , if yes then prompt user to save flow or close the tab directly.
//     // "f" will be true if user wants to forcibly close the flow without saving the flow.
    
//     if(!isEdit | f){
//       delete tabs[tabId];
//       sequence.splice(index, 1)
//       if(currentTab === tabId){
//         if(index===0){
//           dispatch({type: tabsConstants.CLEAR_CURRENT_TAB})
//           if(sequence.length !== 0)
//             dispatch(activeTab(sequence[0]))
//         }
//         else if(index <= sequence.length) {
//           dispatch({type: tabsConstants.CLEAR_CURRENT_TAB})
//           dispatch(activeTab(sequence[index-1]))
//         }
//       }
//       else{
//         if(index === 0 ){
//           dispatch({type: tabsConstants.CLEAR_CURRENT_TAB})
//           dispatch(activeTab(currentTab))
//         }
//         else{
//           dispatch({type: tabsConstants.CLEAR_CURRENT_TAB})
//           dispatch(activeTab(sequence[index-1]))
//         }
//       }
//     }
//     else{
//       dispatch(saveChangeDialog(index, tabId))
//     }
//     dispatch({ type: tabsConstants.CLEAR_UTILITY_ACTIONS })
//   }
// }

// /**
// * This method is active action (or) current action (or) current flow
// */
// export const activeAction = (actionId) => ({
//   type: tabsConstants.CURRENT_ACTION,
//   actionId
// })

// export const closeAction = (actionId) => ({
//   type: tabsConstants.CLEAR_CURRENT_ACTION,
//   actionId
// })

// export const pasteFlows = (parentId) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab, utilityActions } = getState()
//     let tab = tabs[currentTab]
//     let sftp = ['FTP_GET','FTP_PUT','FTP_MGET','FTP_MPUT','FTP_R_MOVE_FILES','FTP_R_MOVE_FILE','FTP_DELETE','FTP_M_DELETE','FTP_CREATE_FOLDER','FTP_DELETE_FOLDER']
//     let index
//     let parentAction = tab.actions[parentId]
//     // condition to check whether parent Action has allownesting true or false.
//     if(!parentAction.allowNesting){

//       //If parentAction has allownesting as false, then we need to find the parent action of this ParentId which has subActions.
//       let actions = tab.actions[parentAction.parentId].subActions
//       index = actions.indexOf(parentId) + 1 

//       // Here we are setting parentId to the parentAction which has subActions to insert copied flows.
//       parentId = parentAction.parentId
//     }
//     // This condition is to paste actions in "then" action if parent action is If else.
//     else if (parentAction.key == "ifelse"){
//       parentId = parentAction.subActions[0];
//       index = tab.actions[parentId].subActions.length
//     }
//     else{
//       index = parentAction.subActions.length
//     }
//     //It will iterate through the utility actions were the copies actions were stored
//     for (let act of utilityActions.sequence){
//       let id = uuid()
//       let obj = JSON.parse(JSON.stringify(utilityActions.actions[act]));
//       if(sftp.includes(obj.type) && parentAction.type!=='FTP_CONNECT'){
//          continue;
//       }
//       tab.actions[id] = obj
//       tab.actions[id].id = id
//       tab.actions[id].dependentActions ?  tab.actions[id].dependentActions = [...tab.actions[id].dependentActions] : tab.actions[id]["dependentActions"] = []
//       tab.actions[id].parentId = parentId
//       if (tab.actions[id].dependentActions.length > 0 & tab.actions[id].key == "catch"){
//         let try_action_id = tab.actions[parentId].subActions[tab.actions[parentId].subActions.length - 1]
//         tab.actions[id].dependentActions = [try_action_id]
//         tab.actions[try_action_id].dependentActions = [id]
//       }
//       tab.actions[id].subActions ? tab.actions[id].subActions = [...tab.actions[id].subActions] : tab.actions[id]["subActions"] = []
//       tab.actions[parentId].subActions.splice(index++,0,id)
//       if (tab.actions[id].subActions.length > 0) {
//         for (let action of tab.actions[id].subActions) {
//           tab = parseActionFlows(tab, action, id, utilityActions)
//         }
//       }
//     }
//     dispatch(updateTab(tab))
//   }
// }

// export const copyFlows = (actionId) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let tab = tabs[currentTab]
//     let obj = {
//       actions : {},
//       sequence : []
//     }
//     if(tab.selectedActions.length > 0){
//       tab.selectedActions.forEach((action, index) => {
//         action = { ...tab.actions[action]}
//         if (action.key == "catch") {
//             if (index == 0 || tab.selectedActions[index - 1] != action.dependentActions[0] ) {
//               obj.sequence.push(action.dependentActions[0])
//               obj.sequence.push(action.id)
//             } 
//         }
//         else if(action.key == "try"){
//           if (index == 0 || !obj.sequence.find(obj => obj == action.id )){
//             obj.sequence.push(action.id)
//             obj.sequence.push(action.dependentActions[0])
//           }
//         }
//         else{
//           obj.sequence.push(action.id)
//         }
        
//         tab.actions[action.id].dependentActions = tab.actions[action.id].dependentActions ? tab.actions[action.id].dependentActions : []
//         let actionsCopied = [
//           ...tab.actions[action.id].dependentActions, action.id,
//           ...childActionsIds(tab, action.id), ...childActionsIds(tab, tab.actions[action.id].dependentActions[0])
//         ]

//         for (let act of actionsCopied) {
//           obj.actions[act] = tab.actions[act]
//         }
//       });
//     }
//     dispatch({
//       type: tabsConstants.UPDATE_UTILITY_ACTIONS,
//       data : JSON.parse(JSON.stringify(obj))
//     })
//   }
// }

// export const cutFlows = () => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let tab = tabs[currentTab]
//     dispatch(copyFlows());
//     tab = removeActionsFromTab(tab, null);
//     dispatch(updateTab(tab))
//   }
// }


// /**
// * This method closes the current action in the flow
// */
// export const closeFlow = (actionId) => {
//   return (dispatch, getState) => {
//     let { tabs, currentTab} = getState()
//     let tab = tabs[currentTab]
//     if(tab.connect_tree[actionId] != undefined) delete tab.connect_tree[actionId]
//     tab = removeActionsFromTab(tab, actionId)
//     dispatch(updateTab(tab))
//   }
// }



// const getSequence = (tab, parentId) => {
//   let parentAction = tab.actions[parentId]
//   if (parentAction.parentId) {
//     return getSequence(tab, parentAction.parentId)
//   } else {
//     return parentAction
//   }
// }


// /**
//  * This function will be called when we move any action inside flows.
//  *   @param {*} action : The action which user is trying to drag or move.
//  *   @param {*} parentId : The action which user is trying to draggged on.
//  */

// export const moveAction = (action, parentId=null)=>{
//   return (dispatch, getState)=>{
//     let { tabs, currentTab } = getState()
//     let tab = tabs[currentTab]
//     if(parentId){
//       // checking whether parent action is If else, then pushing the moved action into "then action".
//       if(tab.actions[parentId].key === "ifelse"){

//         if(action.key == "ElseIf"){
//           let index = tab.actions[parentId].subActions.length - 1;
//           tab.actions[action.id].parentId = parentId;
//           tab.actions[parentId].subActions.splice(index, 0, action.id)
//         }
//         else{
//           console.log("inside move action", tab.actions[parentId])
//           let thenId = tab.actions[parentId].subActions[0]
//           tab.actions[action.id].parentId = thenId
//           tab.actions[thenId].subActions.push(action.id)
//           if(action.dependentActions && action.dependentActions.length > 0){
//            tab.actions[thenId].subActions.push(action.dependentActions[0])
//           }
//         }
//       }
//       else{
//             if(tab.actions[parentId].subActions){
//                 tab.actions[action.id].parentId= parentId
//                 tab.actions[parentId].subActions.push(action.id)
//             }
//             else{
//                 let pAction = getSequence(tab, parentId)
//                 if (pAction.allowNesting) {
//                   let index = pAction.subActions.indexOf(parentId)
//                   tab.actions[action.id].parentId= pAction.id
//                   tab.actions[pAction.id].subActions.splice(index, 0, action.id)
//                 }
//                 //throw new Error('move error')
//             }
//         if(action.dependentActions && action.dependentActions.length > 0){
//           tab.actions[parentId].subActions.push(action.dependentActions[0])
//         }

//         if(tab.actions[parentId].type==="OPEN_SPREADSHEET" && tab.actions[parentId].subActions.length){
//           let payload = {
//             path:tab.actions[parentId].path ? tab.actions[parentId].path : ""
//           }
//           dispatch(editScopePath(action, payload))
//         }
//     }
//       dispatch(updateTab(tab))
//     }
//   }
// }

// export const reMoveActionIdInSequence = (action, parentId=null)=>{
//   return (dispatch, getState)=>{
//     let { tabs, currentTab } = getState()
//     let tab = tabs[currentTab]
//     if (parentId) {
//       tab.actions[parentId].subActions = tab.actions[parentId].subActions.filter(id => ((id !== action.id) && (action.dependentActions?id !==action.dependentActions[0]:true)))
//       }
//     else{
//       tab.sequence = tab.sequence.filter(id => ((id !== action.id) && (action.dependentActions?id !==action.dependentActions[0]:true)))
//     }
//     dispatch(updateTab(tab))
//   }
// }

// export const updateRunningProcess = (running_status) => ({
//   type: tabsConstants.IS_RUNNING,
//   isRunning: running_status
// })
