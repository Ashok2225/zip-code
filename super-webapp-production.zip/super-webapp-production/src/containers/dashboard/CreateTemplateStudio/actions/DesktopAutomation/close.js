import { addActionInTab, updateTab } from "../Tabs";
import * as constants from '../../constants'
import uuid from 'uuid/v1'
import { SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION } from "constants";

export const addClose= (parentId =null)=>{
          return (dispatch,getState)=>{
                    let {tabs,currentTab}= getState()
                    let tab = tabs[currentTab]
                    let action = {
                              id:uuid(),
                              type:constants.CLOSE,
                              label : "Close File",
                              key : "close",
                              app:"",
                              instruction : "",
                              description: "",
                              parentId:parentId,
                              status:false,
                              logMessage:"",
                              breakpoint:false,
                              description:""
                    }
                  tab =   addActionInTab(tab,action,parentId)
                  dispatch(updateTab(tab))
          }
}

export const editClose = (payload = {})=>{    
   return (dispatch,getState)=>{
      let  {tabs,currentTab}= getState()
      let tab = tabs[currentTab]
      let {currentAction} = tab
      let closeAction = tabs[currentTab].actions[currentAction]
      let temp = {
        ...closeAction,
        ...payload
      }
      temp.app!=""?temp.status=true:temp.status=false
     let instruction = `vision begin\nSleep, 2000\nIfWinExist, ${temp.app}\n{\nWinActivate  ; Automatically uses the window found above.\nWinMaximize  ; same\nSleep, 1000\nSend, !{F4}\nSend, {Enter}\n}\nvision finish`
      tabs[currentTab].actions[currentAction]={
        ...temp,
        instruction,
        description:`close ${temp.app}`
      }

      dispatch(updateTab(tab))
   }
}