import * as screenshotconstants from "../../constants/DesktopAutomation"
import { updateTab, addActionInTab } from "../Tabs"
import uuid from 'uuid/v1'

export const addScreenshot = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            id: uuid(),
            type: screenshotconstants.SCREENSHOT,
            label: "Screenshot",
            key: "screenshot",
            path: "",
            instruction: "",
            parentId: parentId,
            description: '',
            status: "",
            breakpoint:false
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}

export const editScreenshot = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let screeshotAction = tab["actions"][tab.currentAction]
        let temp = {
            ...screeshotAction,
            ...payload
        }
        temp.path != "" ? temp.status = true : temp.status = false
        let instruction = `screenshot ${temp.path}`
        tab["actions"][tab.currentAction] = {
            ...temp,
            instruction: instruction,
            description: "screenshot to folder specified"
        }
        dispatch(updateTab(tab))
    }
}
