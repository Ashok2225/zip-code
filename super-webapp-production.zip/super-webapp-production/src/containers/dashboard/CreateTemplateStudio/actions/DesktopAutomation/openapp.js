import * as OpenAppConstants from "../../constants/DesktopAutomation"
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'

export const addOpenApp = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : OpenAppConstants.OPENAPP,
      label : "Open App",
      key : "openapp",
      path: "",
      instruction : "",
      parentId:parentId,
      description: '',
      status:"",
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editOpenApp = (payload)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let openappAction = tab["actions"][tab.currentAction]
    let temp = {
      ...openappAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
     let instruction = `vision Run, "${temp.path.replace(/\\/g,'\\\\' )}"`
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction : instruction,
      description: temp.path
    }
    dispatch(updateTab(tab))
  }
}
