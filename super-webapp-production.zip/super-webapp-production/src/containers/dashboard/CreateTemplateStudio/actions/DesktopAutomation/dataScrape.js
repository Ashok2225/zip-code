import uuid from 'uuid/v1'
import {addActionInTab,updateTab} from '../Tabs'
import * as DesktopConstants from '../../constants/DesktopAutomation'

import path from 'path'
import os from 'os'
export const addDataScrape = (parentId=null)=>{
          return (dispatch,getState)=>{
                    let {tabs,currentTab} = getState()
                    let tab = tabs[currentTab]
                    let action = {
                              id:uuid(),
                              label:"Data Scrape",
                              key: "dataScrape",
                              type:DesktopConstants.DATA_SCRAPE,
                              description:"",
                              status:false,
                              selectorType:"screenSelector",
                              path:"",
                              parentId:parentId,
                              instruction:"",
                              variableName:"",
                              source : {
                                        selectorType : "imgSelector",
                                        imgSelector : "",
                                        x1 : "",
                                        y1 : "",
                                        x2 : "",
                                        y2 : "",
                              },
                              breakpoint:false
                    }
                    tab = addActionInTab(tab,action, parentId)  
                    dispatch(updateTab(tab))
          }
}
export const editDataScrape = (payload= {})=>{
          return (dispatch,getState) =>{
                //     let {tabs,currentTab} = getState()
                //     let tab = tabs[currentTab]
                //     let {currentAction} = tab
                //     let action = tabs[currentTab].actions[currentAction] 
                //     let temp_img_data={}
                //    if(payload.childType){
                //     temp_img_data={
                //               [payload.childType]: {
                //                         x1: Math.round(payload.x),
                //                         y1: Math.round(payload.y),
                //                         x2: Math.round(payload.w),
                //                         y2: Math.round(payload.h),
                //               }
                //     }
                //   }
                //  let temp = {
                //               ...action,
                //               ...payload,
                //               ...temp_img_data
                //             }
                //     let req_body = {
                //                   "ImagePath":path.join(tab.dirPath, temp.imgSelector),
                //                       "rect": {                                        
                //                        "x1" : temp.x,
                //                        "y1": temp.y,
                //                        "x2": temp.x + temp.w,
                //                        "y2": temp.y + temp.h,
                //                        "width": temp.w,
                //                        "height": temp.h
                //                       }  
                //       }
                //     temp.variableName !== "" ? temp.status=true : temp.status=false
                //     let instruction = `api_config = {method:'POST', header:['Content-Type:application/json'], body:${JSON.stringify(req_body)}}
                //     api ${remote.process.env.RPA_PYTHON_API}/api/v1/dataScrapping/\n ${temp.variableName}= api_json.data`
                //     tab.actions[currentAction] = {
                //               ...temp,
                //               instruction: instruction,
                //               description: "Scrape data from current screen"
                //     }
                //     dispatch(updateTab(tab))
          }

}
