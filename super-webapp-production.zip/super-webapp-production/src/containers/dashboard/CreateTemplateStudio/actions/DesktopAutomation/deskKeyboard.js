import uuid from 'uuid/v1'
import * as deskKeyboardConstants from '../../constants/DesktopAutomation'
import { updateTab , addActionInTab} from "../Tabs"

export const addDeskKeyboard = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      label : "Keyboard ShortCuts",
      key : "keyboardshortcuts",
      type : deskKeyboardConstants.KEY_STROKES,
      parentId : parentId,
      win: false,
      alt: false,
      ctrl: false,
      shift: false,
      selector : "custom",
      keyValue : "",
      value : "",
      status:"",
      description: "",
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
    }
  }

export const editDeskKeyboard = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let deskKeyboardAction = tab["actions"][tab.currentAction]
    let temp = {
      ...deskKeyboardAction,
      ...payload
    }
    let inCombination = temp.win || temp.alt || temp.ctrl || temp.shift
    let instruction = 'vision Send, '
    let description = ''
    if(temp.win){
      instruction += `#`
      description += `Win+`
    }
    if(temp.alt){
      instruction += `!`
      description += `Alt+`
    }
    if (temp.ctrl) {
      instruction += `^`
      description += `Ctrl+`
    }
    if (temp.shift) {
      instruction += `+`
      description += `Shift+`
    }
    
    if (temp.selector === 'keys') {
      (temp.win||temp.alt||temp.ctrl||temp.shift)||(temp.keyValue!="")?temp.status=true:temp.status=false
      payload.keyValue = temp.keyValue ? temp.keyValue : ''
      instruction += `{${temp.keyValue}} `
      description += `${temp.keyValue}`
    } else {
      ((temp.win||temp.alt||temp.ctrl||temp.shift)||(temp.value!=""))?temp.status=true:temp.status=false
      payload.value = temp.value ? temp.value : ''
      instruction += `${payload.value}`
      description += `${payload.value}`
    }
    
    instruction = instruction.replace(/} {/g, '}+{').trim()
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction: instruction,
      description: description
    }
    dispatch(updateTab(tab))
  }
}
