import * as SwitchAppConstants from "../../constants/DesktopAutomation"
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'

export const addSwitchApp = (parentId = null)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    console.log("tabtab",tab);
    let action = {
      id : uuid(),
      type : SwitchAppConstants.SWITCHAPP,
      label : "Switch App",
      key : "switchapp",
      path:"",
      instruction : "",
      parentId:parentId,
      description: '',
      status:"",
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editSwitchApp = (payload)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let switchappAction = tab["actions"][tab.currentAction]
    let temp = {
      ...switchappAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
     let instruction = `vision WinActivate, ${temp.path.replace(/\\/g,'\\\\' )}`
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction : instruction,
      description: temp.path
    }
    dispatch(updateTab(tab))
  }
}
