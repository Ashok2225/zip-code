import uuid from 'uuid/v4'
import upath from 'upath'
import { convertPath } from '../../utilities'
import * as deskKeyboardConstants from '../../constants/DesktopAutomation'
import { updateTemplateAcions} from "../../../../../redux/actions/template"

export const addDesktopAction = () => {
  return (dispatch, getState) => {
   
    let action = {
      id : uuid(),
      label : "Desktop Automation",
      key : "desktop",
      type : "desktop",
      isShow:true
    }
   
    dispatch(updateTemplateAcions(action))
    }
  }

export const editDragDrop = (payload) => {
  return (dispatch, getState) => {
    // let { tabs, currentTab } = getState()
    // let tab = tabs[currentTab]
    // let dragDropAction = tab["actions"][tab.currentAction]
    // let temp
    // let description = ``
    // if(payload.childType === 'from'){
    //   let from = {
    //               from: {
    //                         selectorType : payload.from.selectorType,
    //                         imgSelector : payload.imgSelector,
    //                         x : Math.round(payload.x),
    //                         y : Math.round(payload.y),
    //                     }
    //                }
    //   temp = {
    //     ...dragDropAction,
    //     ...from
    //   }
    //  if(temp.from.selectorType==='imgSelector'){
    //     //temp.from["instruction"] = `${upath.join(tab.dirPath, temp.from.imgSelector)}`
    //     // temp.from["instruction"] = `"${convertPath(tab.dirPath)}\\\\${temp.from.imgSelector}"`.replace(/\\/g, '/')
    //     temp.from["instruction"] = `\`dirPath\`${temp.from.imgSelector}`
    //     temp.from['description'] = `From ${temp.from.imgSelector}`
    //   }else{
    //      temp.from["instruction"] = `${temp.from.x}, ${temp.from.y}`
    //      temp.from['description'] = `From ${temp.from.x}, ${temp.from.y}`
    //   }
    // }
    // else if(payload.childType === 'to'){
    //   let to = {
    //               to: {
    //                       selectorType : payload.to.selectorType,
    //                       imgSelector : payload.imgSelector,
    //                       x : Math.round(payload.x),
    //                       y : Math.round(payload.y)
    //                    }
    //                }
    //   temp = {
    //     ...dragDropAction,
    //     ...to
    //   }
    //   if(temp.to.selectorType==='imgSelector'){
    //      //temp.to["instruction"] = `${upath.join(tab.dirPath, temp.to.imgSelector)}`
    //     // temp.to["instruction"] = `"${convertPath(tab.dirPath)}\\\\${temp.from.imgSelector}"`.replace(/\\/g, '/')
    //     temp.to["instruction"] = `\`dirPath\`${temp.to.imgSelector}`
    //     temp.to['description'] = ` to ${temp.to.imgSelector}`
    //   }else{
    //      temp.to["instruction"] = `${temp.to.x}, ${temp.to.y}`
    //      temp.to['description'] = ` to ${temp.to.x}, ${temp.to.y}`
    //   }
    // }else{
    //   temp = {
    //     ...dragDropAction,
    //     ...payload
    //   }
    // }
    // if(temp.from.imgSelector!=""&&temp.to.imgSelector!=""){
    //   temp.status=true
    // }
    // else{
    //   temp.status=false
    // }
    // let instruction=``
    // if(temp.from.instruction && temp.to.instruction){
    //   instruction = `vision MouseClickDrag, L, ${temp.from.instruction}, ${temp.to.instruction}`
    //   description = temp.from['description'] +  temp.to['description']
    // }
    // tab["actions"][tab.currentAction] = {
    //   ...temp,
    //   instruction: instruction,
    //   description : description
    // }
    // dispatch(updateTab(tab))
  }
}
