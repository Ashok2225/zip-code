import * as CloseAppConstants from "../../constants/DesktopAutomation"
import { updateTab , addActionInTab} from "../Tabs"
import uuid from 'uuid/v1'

export const addCloseApp = (parentId = null)=>{
  return (dispatch, getState) => {    
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : CloseAppConstants.CLOSEAPP,
      label : "Close App",
      key : "closeapp",
      path:"",
      instruction : "",
      description: "",
      parentId:parentId,
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editCloseApp = (payload)=>{
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let closeappAction = tab["actions"][tab.currentAction]
    let temp = {
      ...closeappAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
    let instruction = `vision WinClose, ${temp.path.replace(/\\/g,'\\\\' )}`
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction : instruction,
      description: temp.path
    }
    dispatch(updateTab(tab))
  }
}
