import uuid from 'uuid/v1'
import * as SuperResolutionConstants from '../../constants/Cognitive'
import { updateTab,addActionInTab } from "../Tabs"

/* adding SuperResolution action to currentTab*/
export const addSuperResolution = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : SuperResolutionConstants.SUPERRESOLUTION,
      label : "Super Resolution",
      key : "superresolution",
      allowNesting : false,
      api : "http://cloud.speedops.com:8334/api/v1/SuperResolution/",
      base64 : '',
      path:"",
      name:"",
      parentId:parentId,
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
/* updating the SuperResolution action to the currentTab */
export const editSuperResolution = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let superresolutionAction = tab["actions"][currentAction]
    let temp = {
      ...superresolutionAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
    let object = {
      method: 'POST',
      header: ['Content-Type: application/json','Accept: application/json'],
      body: {
        FileName:temp.name,
        data: temp.base64
      }
    }
    // let instruction = `api_config = ${JSON.stringify(object)};\napi ${temp.api}`
    let instruction= `api_config = ${JSON.stringify(object)};\napi ${temp.api}\necho api_result`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description : `${temp.path}`
    }
    dispatch(updateTab(tab))
  }
}
