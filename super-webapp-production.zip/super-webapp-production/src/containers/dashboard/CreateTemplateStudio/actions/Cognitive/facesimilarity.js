import uuid from 'uuid/v1'
import * as FaceSimilarityConstants from '../../constants/Cognitive'
import { updateTab,addActionInTab } from "../Tabs"

/* adding FaceSimilarity action to currentTab*/
export const addFaceSimilarity = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : FaceSimilarityConstants.FACESIMILARITY,
      label : "Face Similarity",
      key : "facesimilarity",
      allowNesting : false,
      api : "http://cloud.speedops.com:8334/api/v1/FaceSimilarity/",
      base641 : '',
      path1:"",
      name1:"",
      base642 : '',
      path2:"",
      name2:"",
      parentId:parentId,
      breakpoint:false,
      status:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
 /* updating the FaceSimilarity action to the currentTab and
  check the images are same or not and give the percentage of similarity*/
export const editFaceSimilarity = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let facesimilarityAction = tab["actions"][currentAction]
    let temp = {
      ...facesimilarityAction,
      ...payload
    }
    temp.path1&&temp.path2!=""?temp.status=true:temp.status=false
    let object = {
      method: 'POST',
      header: ['Content-Type: application/json','Accept: application/json'],
      body: {
        FileName1:temp.name1,
        FileName2:temp.name2,
        data1: temp.base64,
        data2: temp.base64
      }
    }
    let instruction = `api_config = ${JSON.stringify(object)};\napi ${temp.api}\necho api_result`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description : `${temp.path1} to ${temp.path2}`
    }
    dispatch(updateTab(tab))
  }
}
