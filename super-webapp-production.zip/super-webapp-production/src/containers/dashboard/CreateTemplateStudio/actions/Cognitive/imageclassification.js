import uuid from 'uuid/v1'
import * as ImageClassificationConstants from '../../constants/Cognitive'
import { updateTab,addActionInTab } from "../Tabs"

/* adding ImageClassification action to currentTab*/
export const addImageClassification = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : ImageClassificationConstants.IMAGECLASSIFICATION,
      label : "Image Classification",
      key : "imageclassification",
      allowNesting : false,
      api : "http://cloud.speedops.com:8334/api/v1/ImageClassification/",
      base64 : '',
      path:"",
      name:"",
      parentId:parentId,
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
/* updating the ImageClassification action to the currentTab and
 check the image and give percentage of classifications in that*/
export const editImageClassification = (payload,actionId=null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab} = getState()
    let tab = tabs[currentTab]
    let {currentAction} = tab
    let imageclassificationAction = tab["actions"][currentAction]
    let temp = {
      ...imageclassificationAction,
      ...payload
    }
    temp.path!=""?temp.status=true:temp.status=false
    let object = {
      method: 'POST',
      header: ['Content-Type: application/json','Accept: application/json'],
      body: {
        FileName:temp.name,
        data: temp.base64
      }
    }
    let instruction = `api_config = ${JSON.stringify(object)};\napi ${temp.api}\necho api_result`
    tab["actions"][currentAction] = {
      ...temp,
      instruction: instruction,
      description : `${temp.path}`
    }
    dispatch(updateTab(tab))
  }
}
