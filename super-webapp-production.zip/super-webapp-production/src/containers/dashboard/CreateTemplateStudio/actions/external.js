// import fs from 'fs'
// import { updateTab, addTab } from "./Tabs"
// import { validateTab, objToArr } from '../utilities'
// import { openDialog } from './openDialog';
// import uuid from 'uuid/v1'
// import * as sequenceConstants from '../constants'

// /**
//  * This method convert,  array object to actions object and generate tab object, after call updateTab action  
//  * @param {*} recordedFlow objet //this is array
//  */

// export function addWebRecordedFlow (recordedFlow) {
//   return (dispatch, getState) => {
//     let actions ={}
//     let { tabs, currentTab } = getState()
//     let tab = tabs[currentTab]
//     let ides = [], stage_id
//     let count = tab.sequence.length
//     if(count === 0){
//       stage_id = uuid()
//       recordedFlow.forEach(flow => {
//         actions ={
//           ...actions,
//           [flow.id]:{
//             ...flow,
//             parentId:stage_id
//           }
//         }
//         ides.push(flow.id)
//       });
//       let stage = {
//           id: stage_id,
//           type: sequenceConstants.ADD_SEQUENCE,
//           label: "Sequence",
//           key: "sequence",
//           title : "Stage-"+(count+1),
//           allowNesting: true,
//           expanded:true,
//           subActions:[...ides]
//       }
//       tab.actions= {
//         ...tab.actions,
//         ...actions,
//         [stage_id]:stage
//       }
//       tab.sequence.push(stage_id)
//     }else{
//       stage_id = tab.sequence[count - 1]
//       recordedFlow.forEach(flow => {
//         actions ={
//           ...actions,
//           [flow.id]:{
//             ...flow,
//             parentId:stage_id
//           }
//         }
//         ides.push(flow.id)
//       });
//       tab.actions= {
//         ...tab.actions,
//         ...actions
//       }
//       tab.actions[stage_id]={
//         ...tab.actions[stage_id],
//         subActions:[ ...tab.actions[stage_id].subActions, ...ides]
//       }
//     }
//     dispatch(updateTab(tab))
//    }
// }

// /**
//  * This method take two parameters
//  * @param {*} recordedFlow this is tab object
//  * @param {*} path this is save path
//  */
// export function openWebRecordedFlow(recordedFlow,path) {
//   return (dispatch, getState) => {
//     let { tabs , sequence } = getState()
//     let tabsArray = objToArr(tabs, sequence)
//     let tab = tabsArray.find(tab => (tab.dirPath === path.dirPath ))
//     if(validateTab(recordedFlow) && !tab )
//     {
//       let tab = tabsArray.find(tab =>(tab.id === recordedFlow.id))
//       if(tab){
//         recordedFlow.id = uuid()
//       }
//       let actionKeys = Object.keys(recordedFlow.actions)
//       let flow = objToArr(recordedFlow.actions, actionKeys)
//       let isNewFlow=true
//       for(let obj of flow){
//         if(obj.type === sequenceConstants.ADD_SEQUENCE){
//           isNewFlow = false;
//           break;
//         }
//       }
//       if(isNewFlow){
//           let stage_id = uuid()
//           let ides = []
//           let actions = {}
//           recordedFlow.sequence.forEach(id =>{
//               recordedFlow.actions[id].parentId = stage_id
//           })
//           let stage = {
//               id: stage_id,
//               type: sequenceConstants.ADD_SEQUENCE,
//               label: "Sequence",
//               key: "sequence",
//               title : "Stage-1",
//               allowNesting: true,
//               expanded:true,
//               subActions:[ ...recordedFlow.sequence]
//           }
//           recordedFlow.actions[stage_id] = stage
//           recordedFlow.sequence=[stage_id]
//         }
      
//       recordedFlow["selectedActions"] = []
//       dispatch(addTab(path,recordedFlow))
//     }
//     else
//     {
//       if(tab)
//        ""
//       else
//         dispatch(openDialog("fileCorrupted"))
//     }
//   }
// }

// export function updateCropSelection(id, payload){
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let index = tabs.findIndex(obj=>(obj.id===currentTab.id))
//     tabs[index].flow = tabs[index].flow.map((instruction, index) => {
//       if (id === instruction.id) {
//         let { imgSelector } = payload
//         if (!imageExists(imgSelector)) {
//           payload.imgSelector = null
//         }
//         return {
//           ...instruction,
//           ...payload
//         }
//       } else {
//         return instruction
//       }
//     })
//     dispatch(updateTab(tabs))
//   }
// }

// export function updateImgSelection (id, payload) {
//   return (dispatch, getState) => {
//     let { tabs, currentTab } = getState()
//     let index = tabs.findIndex(obj=>(obj.id===currentTab.id))
//     tabs[index].flow = tabs[index].flow.map((instruction, index) => {
//       if (id === instruction.id) {
//         let { imgSelector } = payload
//         if (!imageExists(imgSelector)) {
//           payload.imgSelector = null
//         }
//         return {
//           ...instruction,
//           ...payload,
//           instruction: `${payload.subType} ${payload[payload.selectorType]}`
//         }
//       } else {
//         return instruction
//       }
//     })
//     dispatch(updateTab(tabs))
//   }
// }


// const imageExists = (imgPath) => {
//   try {
//     fs.accessSync(imgPath, fs.constants.R_OK)
//     return true
//   } catch (e) {
//     return false
//   }
// }
