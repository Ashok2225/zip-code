import * as pathConstants from '../constants/flowPath'
import { updateTab } from "./Tabs/tabs"

export const savePath = (path) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let index = tabs.findIndex(obj=>(obj.id===currentTab.id))
    tabs[index].flowPath=path
    dispatch(updateTab(tabs))
  }
}

export const clearPath = () => ({
  type: pathConstants.CLEAR_PATH
})
