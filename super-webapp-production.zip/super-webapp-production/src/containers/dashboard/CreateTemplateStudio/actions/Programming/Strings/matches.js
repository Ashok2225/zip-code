import uuid from 'uuid/v1'
import * as stringConstants from '../../../constants/Programming'
import { updateTab, addActionInTab } from "../../Tabs"

export const addMatches = (parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id: uuid(),
      type: stringConstants.MATCHES,
      parentId: parentId,
      label: "Matches",
      key: "matches",
      allowNesting: false,
      input: "",
      pattern: "",
      variableName: "",
      ignoreCase: false,
      description : "",
      breakpoint:false,
      status:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editMatches = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let matchesAction = tab["actions"][tab.currentAction]
    let temp = {
      ...matchesAction,
      ...payload
    }
    temp.pattern&&temp.input!=""?temp.status=true:temp.status=false
    let instruction = `${temp.variableName ? temp.variableName : ""} = ${temp.input}.match(${temp.pattern})`
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction: instruction,
      description : `Compare ${temp.input} with ${temp.pattern}` + (temp.variableName?` and store in ${temp.variableName}`:'')
    }
    dispatch(updateTab(tab))
  }
}
