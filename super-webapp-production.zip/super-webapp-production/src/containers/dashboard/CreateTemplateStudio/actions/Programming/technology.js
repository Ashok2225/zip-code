import uuid from 'uuid/v1'
import * as technologyConstants from '../../constants/Programming'
import { updateTab , addActionInTab} from "../Tabs"
import os from "os"

export const addTechnology = (node, parentId = null) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let action = {
      id : uuid(),
      type : technologyConstants.TECHNOLOGY,
      parentId : parentId,
      label : node.label,
      key : node.key,
      allowNesting : false,
      code : node.code,
      description : "",
      status:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}

export const editTechnology = (payload) => {
  return (dispatch, getState) => {
    let { tabs, currentTab } = getState()
    let tab = tabs[currentTab]
    let technologyAction = tab["actions"][tab.currentAction]
    let temp = {
      ...technologyAction,
      ...payload
    }
    temp.code!=""?temp.status=true:temp.status=false
    let instruction = temp.code
    tab["actions"][tab.currentAction] = {
      ...temp,
      instruction: instruction,
      description : `${temp.key} program`
    }
    dispatch(updateTab(tab))
  }
}