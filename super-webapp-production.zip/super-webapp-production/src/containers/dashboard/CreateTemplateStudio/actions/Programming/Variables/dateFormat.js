import uuid from 'uuid/v1'
import * as stringConstants from '../../../constants/Programming'
import { updateTab, addActionInTab } from "../../Tabs"

export const addDateFormat = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            id: uuid(),
            type: stringConstants.DATE_FORMAT,
            parentId: parentId,
            label: "Date Format",
            key: "dateformat",
            variable : "",
            dateFormat : "",
            selectedDay : "",
            allowNesting: false,
            description: "",
            status: false
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}

export const editDateFormat = (payload) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let dateFormatAction = tab["actions"][tab.currentAction]
        let temp = {
            ...dateFormatAction,
            ...payload
        }
        let instruction = ''
        let description = ''
        temp.variable !== ""&& temp.dateFormat !== "" ? temp.status = true : temp.status = false
        console.log("temp in edit date format", temp)
        if (temp.variable !== ""&& temp.dateFormat !== ""){
            instruction = `date ${temp.variable} = dateParser('${temp.dateFormat}~${temp.selectedDay}')`
            description = `${temp.variable} = ${temp.dateFormat}`
        }
        tab["actions"][tab.currentAction] = {
            ...temp,
            instruction: instruction,
            description: description
        }
        dispatch(updateTab(tab))
    }
}
