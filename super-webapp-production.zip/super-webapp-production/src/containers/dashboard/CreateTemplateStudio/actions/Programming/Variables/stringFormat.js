import uuid from 'uuid/v1'
import * as stringConstants from '../../../constants/Programming'
import { updateTab, addActionInTab } from "../../Tabs"
import { ELSEIF } from '../../../constants';

export const addString = (parentId = null) => {
    return (dispatch, getState) => {
        let { tabs, currentTab } = getState()
        let tab = tabs[currentTab]
        let action = {
            id: uuid(),
            type: stringConstants.STRING_FORMAT,
            parentId: parentId,
            label : "String",
            key : "string",
            variable1 : 0,
            variable2 : 0,
            substr1 : '',
            substr2 : '',
            split1: '',
            split2 : '',
            custom : "",
            replace1 : "",
            replace2 : "",
            match : '',
            stringMethod : 0,
            allowNesting: false,
            description: "",
            status: false
        }
        tab = addActionInTab(tab, action, parentId)
        dispatch(updateTab(tab))
    }
}

function validateRegex(pattern) {
    let parts = pattern.split('/');
    let regex = '';
    let type = '';
    let options = '';
    if (parts.length > 1) {
        regex = parts[1];
        options = parts[2];
        type = "regex"
    }
    else{
        regex = pattern
        options = "";
        type = "string"
    }
    try {
        new RegExp(regex, options);
        return {type, isValid : true};
    }
    catch (e) {
        console.log(e)
        return { type, isValid: false };
    }
}

// export const editString = (payload) => {
//     return (dispatch, getState) => {
//         let { tabs, currentTab } = getState()
//         let tab = tabs[currentTab]
//         let stringActions = tab["actions"][tab.currentAction]
//         let temp = {
//             ...stringActions,
//             ...payload
//         }
//         let instruction = ''
//         temp.status = false
//         // temp.variable1 !== 0 && temp.stringMethod !== 0 ? temp.status = true : temp.status = false
//         if (temp.variable1 !== 0 && temp.stringMethod !== 0){
//             let variable = ''
//             temp.variable2 !== 0 ? variable = temp.variable2 : variable = temp.variable1

//             if (temp.stringMethod === "match" && temp.match !== ""&&temp.variable2!=""){
//                 let regCheck = validateRegex(temp.match)
//                 if (regCheck.isValid){
//                     temp.status = true
//                     if (regCheck.type === 'string'){
//                         instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}("${temp.match}")`
//                         temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}("${temp.match}")`
//                     }
//                     else{
//                         instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.match})`
//                         temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.match})`
//                     }
//                 }
//             }
//             else if (temp.stringMethod === "split" && temp.split1 !== ""&&temp.variable2!=""){
//                 let regCheck = validateRegex(temp.split1)
//                 if (regCheck.isValid){
//                     let var1 = ''
//                     regCheck.type === "string" ? var1 = `"${temp.split1}"` : var1 = `${temp.split1}`
//                     if (temp.split2 !== "") {
//                         instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1},${temp.split2})`
//                         temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1},${temp.split2})`
//                     } else {
//                         instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1})`
//                         temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1})`
//                     }
//                     temp.status = true
//                 }
//             }
//             else if (temp.stringMethod === "substring" && temp.substr1 !== ""&&temp.variable2!=""){
//                 if (temp.substr2 !== ""){
//                     instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.substr1},${temp.substr2})`
//                     temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.substr1},${temp.substr2})`
//                 }else{
//                     instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.substr1})`
//                     temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${temp.substr2})`
//                 }
//                 temp.status = true
//             }
//             else if (temp.stringMethod === "replace" && temp.replace1 !== "" && temp.replace2  !== "" &&temp.variable2!="") {
//                 let regCheck = validateRegex(temp.replace1)
//                 if (regCheck.isValid) {
//                     let var1 = ''
//                     regCheck.type === "string" ? var1 = `"${temp.replace1}"` : var1 = `${temp.replace1}`
//                     instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1}, "${temp.replace2}")`
//                     temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}(${var1}, "${temp.replace2}")`
//                     temp.status = true
//                 }
//             }
//             else if(temp.stringMethod === 'trim'&&temp.variable2!=""){
//                 instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}()`
//                 temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}()`
//                 temp.variable1&&temp.variable2==0?status=false:temp.status=true
//             }
//             else if(temp.stringMethod === 'toUpperCase' ||temp.stringMethod === 'toLowerCase' &&temp.variable2!=""){
//                 instruction = `${variable} = ${temp.variable1}.${temp.stringMethod}()`
//                 temp.description = `${variable} = ${temp.variable1}.${temp.stringMethod}()`
//                 temp.variable1&&temp.variable2==0?status=false:temp.status=true
//             }
         
//         }
//         tab["actions"][tab.currentAction] = {
//             ...temp,
//             instruction: instruction
//         }
//         dispatch(updateTab(tab))
//     }
// }
