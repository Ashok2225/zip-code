import * as outlookConstants from "../../../constants/MailIntegration"
import uuid from 'uuid/v1'
import { addTab, updateTab } from "../../Tabs"
import { addActionInTab } from "../../Tabs"
import { updateTemplateAcions} from "../../../../../../redux/actions/template"

import path from 'path'
import { node } from "prop-types"
export const getMail = (node, parentId = null) => {

  return async (dispatch, getState) => {

    let action = {
      id: uuid(),
      type: node.key,
      label: node.label,
      key: node.key,
      isShow: false
    }
   
    dispatch(updateTemplateAcions(action))
  }
}

export const updateGetMail = (payload = {}) => {
  return (dispatch, getState) => {
    //  let {tabs, currentTab} = getState()
    //  let tab = tabs[currentTab]
    //  let {currentAction} = tab

    //  let temp = {
    //            ...tab.actions[currentAction],
    //            ...payload
    //  }
    //  let folder = temp.folder=="custom"?temp.custom:temp.folder
    //  let instr =`"${temp.top}" "${folder}" "${temp.sender}" "${temp.unRead}" "${temp.read}" "${temp.moveTo}"`
    //  if(temp.folder==="Inbox"){       
    //    temp.top!="" && temp.variableName!="" ?temp.status=true:temp.status=false
    //    //instr =`"${temp.top}" "${folder}" "${temp.sender}" "${temp.unRead}" "${temp.read}"`
    //   }
    //   else if(temp.folder==="Sent Items"){
    //     instr = `"${temp.top}" "${folder}" ""  "" "" "${temp.moveTo}"`
    //     temp.status = temp.top!="" && temp.variableName!=""
    //     }
    //  else if(temp.folder === "custom"){
    //    temp.custom&&temp.top!=""&& temp.variableName!=""?temp.status=true:temp.status=false
    //  }
    //  else{
    //    temp.top!=""&&temp.variableName!=""?temp.status=true:temp.status=false
    //  }
    //  let execPath = path.join(__static, 'Configs\\outlook\\ReadMail\\ReadOutlookMail.exe')
    // // let instruction = `vision RunWait %ComSpec% /c ""${execPath}" ${instr} | clip ",,hide
    //   //  \n${temp.variableName}= JSON.parse(fetch_autohotkey_text().replace(/\\u0007/g,"•"))`
    //   let instruction = `vision FileDelete, techforce.autohotkey\\techforce_autohotkey.txt
    //   \nvision RunWait %ComSpec% /c ""${execPath}" ${instr} | clip ",,hide
    //   \nvision FileAppend, %clipboard%, techforce.autohotkey\\techforce_autohotkey.txt
    //   \n${temp.variableName}= JSON.parse(fetch_autohotkey_text().replace(/\\u0007/g,"•"))`
    //       tab.actions[currentAction]={
    //           ...temp,
    //           instruction : instruction,
    //           description: `reading  mails from ${temp.sender}`
    //        }
    //  dispatch(updateTab(tab))
  }
}