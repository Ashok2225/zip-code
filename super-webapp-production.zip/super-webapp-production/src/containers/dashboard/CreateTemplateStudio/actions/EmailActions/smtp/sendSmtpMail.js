import {addActionInTab} from "../../Tabs"
import {updateTab} from "../../Tabs"
import uuid from 'uuid/v1' 

import * as smtpConstants from "../../../constants/MailIntegration"
import { node } from "prop-types"

export const sendSmtpMail = (node,parentId=null)=>{
  return (dispatch,getState)=>{
            let{tabs,currentTab} = getState()
           let  tab = tabs[currentTab]
  let action = {
          id: uuid(),
          type: smtpConstants.SEND_SMTP_MAIL,
          label:node.label,
          key:node.key,
          subActions: [],
          allowNesting:true,
          to:"",
          email:"",
          subject:"",
          body:"",
          cc:"",
          bcc:"",
          attachments:"",
         api:`http://localhost:5555/v1/rpa/metadata/smtp/sendMail`,
         parentId:parentId,
         description : "",
         status:false,
         breakpoint:false
    }
    tab  =  addActionInTab(tab,action,parentId)
    dispatch(updateTab(tab))
  }
}
export const updateSmtpMail = (payload={})=>{
   return (dispatch,getState)=>{
     let {tabs, currentTab} = getState()
        let tab = tabs[currentTab]
        let {currentAction} = tab
        let smtpAction = tab.actions[currentAction]
        let temp = {
                  ...smtpAction,
                  ...payload
        }
     
       // delete temp["instruction"]
       let attachmentPath = temp.attachments.replace(/\\/g,'\\\\' )
        temp.host&&temp.port&&temp.to&&temp.subject&&temp.body!=""?temp.status=true:temp.status=false
        let instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{'email':'${temp.email}','password':'${temp.password}','host':'${temp.host}','port':'${temp.port}','to':'${temp.to}','subject':'${temp.subject}','body':'${temp.body.split("\n").join("\\n")}','cc':'${temp.cc}','bcc':'${temp.bcc}','attachments':'${attachmentPath}'}}
   \napi ${temp.api} \n ${temp.variableName} = api_json`
        tabs[currentTab].actions[currentAction ] = {
                  ...temp,
                  instruction:instruction,
                  description:`send mail to ${temp.to} using SMTP protocol`
        }
        dispatch(updateTab(tab))
          }
}