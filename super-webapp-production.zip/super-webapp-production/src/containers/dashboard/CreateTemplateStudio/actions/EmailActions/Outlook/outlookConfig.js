import * as outlookConstants from "../../../constants/MailIntegration"
import {addTab, updateTab,addActionInTab} from "../../Tabs"

import uuid from 'uuid/v1'

/*ading outlook config to the currentTab*/
export const outlookConfig = (parentId = null)=>{
   return(dispatch,getState) =>{
      let {tabs, currentTab,currentAction} = getState()
      let tab = tabs[currentTab]
      let action = {
        id:uuid(),
        type:outlookConstants.OUTLOOK_CONFIG,
        subActions:[],
        label:"outlookconfig",
        appId:"",
        password:"",
        redirectUri:"",
        instruction:"",
        signin:"",
        signout:"",
        parentId:parentId,
        description:"configure office 365"
      }
      tab = addActionInTab(tab,action,parentId)
      dispatch(updateTab(tab))
    }
  }
  /* updating the outlook configuration data  to the currentTab*/
export const editOutlookConfig = (payload={}) => {
     return(dispatch,getState) =>{
       let {tabs, currentTab,currentAction} = getState()
       let tab = tabs[currentTab]
       let readAction = tabs[currentTab].actions[currentAction]
       let temp = {
         ...readAction,
         ...payload
       }
       tab.actions[currentAction] = {
         ...temp,
         }
       dispatch(updateTab(tab))
    }
}
