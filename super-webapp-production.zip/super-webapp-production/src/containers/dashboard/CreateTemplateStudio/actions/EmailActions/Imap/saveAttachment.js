import uuid from 'uuid/v1'
import * as imapConstants from '../../../constants/MailIntegration'
import {
  addTab,
  updateTab,
  addActionInTab
} from "../../Tabs"
import os from 'os'
import path from 'path'


export const saveAttachment = (parentId = null) => {
  return (dispatch, getState) => {
    let {
      tabs,
      currentTab
    } = getState()
    let tab = tabs[currentTab]
    let action = {
      id: uuid(),
      type: imapConstants.SAVE_ATTACHMENT,
      filePath: "",
      data: "",
      instruction: "",
      label: "Save Attachment",
      subActions: [],
      parentId: parentId,
      description:"",
      mailType:"outlook",
      status:false,
      breakpoint:false
    }
    tab = addActionInTab(tab, action, parentId)
    dispatch(updateTab(tab))
  }
}
export const editSaveAttachment = (payload = {}) => {

  return (dispatch, getState) => {
    // let {tabs, currentTab} = getState()
    // let tab = tabs[currentTab]
    // let currentAction = tab.currentAction
    // let editSaveAttachment = tabs[currentTab].actions[currentAction]
    // let temp = {
    //   ...editSaveAttachment,
    //   ...payload
    // }
    // temp.filePath,temp.data!=""?temp.status=true:temp.status=false
    // let fpath = ''
    // if (os.platform() == "win32") {
    //   console.log("eneterd in windows--", path.sep);

    //   if (path.sep == '\\') {
    //     fpath = temp.filePath.replace(/\\/g, '\\\\')
    //   }
    // } else {
    //   fpath = temp.filePath
    // }
    // let parentId = temp.parentId
    // let parentAction =tab.actions[parentId]
    // let instruction=""
    // let execPath = path.join(__static, 'Configs\\outlook\\SaveAttachment\\SaveAttachment.exe')
    // // while(parentAction){
    // //    if( parentAction.type == "OUTLOOK_GET_MAIL"){
    // //     instruction = `vision RunWait %ComSpec% /c ""${execPath}" "\`${temp.data}.ConversationID\`" "${temp.filePath}" "\`${temp.data}.EntryID\`" ",,hide`
    // //     break;
    // //    }
    // //     let  gpid = parentAction.parentId
    // //     parentAction  = tab["actions"][gpid]
    // //    // parentAction = gpAction
    // //    /* else{
    // //        continue;
    // //         } */
    // //   }    
    //        if(temp.mailType === "outlook"){
    //          instruction = `vision RunWait %ComSpec% /c ""${execPath}" "\`${temp.data}.ConversationID\`" "${temp.filePath}" "\`${temp.data}.EntryID\`" ",,hide`
    //        }
    //        else{
    //          instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{"filePath":"${fpath}","data":\`${temp.data}\`}}
    //         \napi http://localhost:5555/v1/rpa/metadata/outlook/attachment \n result = api_json\n`
    //        }
    //   tab["actions"][currentAction] = {
    //   ...temp,
    //   instruction: instruction,
    //   description : `save attachments  in${temp.filePath}`
    // }
    // dispatch(updateTab(tab))
  }
}
