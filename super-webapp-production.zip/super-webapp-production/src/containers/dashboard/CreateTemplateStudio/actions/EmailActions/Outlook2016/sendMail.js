import {addActionInTab} from "../../Tabs"
import {updateTab} from "../../Tabs"
import * as outlookConstants from "../../../constants/MailIntegration"
import uuid from 'uuid/v1' 


import { updateTemplateAcions} from "../../../../../../redux/actions/template"

export const sendOutlookMail = (node,parentId=null)=>{
   return(dispatch,getState) =>{
 
   let action = {
          id: uuid(),
          type: "sendOutlookMail",
          label:node.label,
          key:node.key,
         isShow:false
      }
     
    dispatch(updateTemplateAcions(action))
}
}
export const updateSendMail = (payload={})=>{
 return(dispatch,getState)=>{
   // let {tabs,currentTab} = getState()
   // let currentAction = tabs[currentTab].currentAction
   // let tab = tabs[currentTab]   
   // let temp = {
   //          ...tabs[currentTab].actions[currentAction],
   //          ...payload
   // }
   // temp.to&&temp.subject&&temp.body!=""?temp.status=true:temp.status=false
   // let body = temp.body.replace(/,/g, ' `,');
   // body = body.replace(/\"/g, '\\\"')
   // let subject = temp.subject.replace(/\"/g, '\\\"').replace(/,/g,"`,")   
   // let execPath = path.join(__static, 'Configs\\outlook\\sendMail\\SendMail.exe')
   // let instruction = `vision RunWait %ComSpec% /c ""${execPath}" "${temp.to}" "${subject}" "${body.split("\n").join(" \\n")}" "${temp.attachments}" "${temp.cc}" "${temp.bcc}"",,hide`
   // tab.actions[currentAction]={
   //             ...temp,
   //             instruction:instruction,
   //             description: `sending mails to ${temp.to}`
   // }
   // dispatch(updateTab(tab))
  }
}