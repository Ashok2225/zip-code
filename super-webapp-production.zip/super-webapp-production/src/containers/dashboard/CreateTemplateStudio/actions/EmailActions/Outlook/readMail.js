import * as outlookConstants from "../../../constants/MailIntegration"
import uuid from 'uuid/v1'
import {addTab, updateTab} from "../../Tabs"

export const updateAccessToken = (id,payload = {})=>{
   return(dispatch,getState) =>{
      let {tabs, currentTab} = getState()
      let {currentFlow}  = currentTab

      if(currentTab.id && tabs.length>0){
          let index = tabs.findIndex((obj) => obj.id === currentTab.id)
          let flow_index = tabs[index].flow.findIndex((flow)=>flow.id === id )
          tabs[index].flow[flow_index]={
            ...tabs[index].flow[flow_index],
            ...payload
          }
          tabs[index].currentFlow = {
            ...tabs[index].currentFlow,
            ...payload
          }

      }else{
     }
     dispatch(updateTab(tabs))
   }
}

/* adding readMail action to the currentTab*/
export const readMail = (parentId = null)=>{
 return(dispatch,getState) =>{
      let {tabs, currentTab} = getState()
      let tab = tabs[currentTab]
      let action = {
        id: uuid(),
        type: outlookConstants.OUTLOOK_READ_MAIL,
        label:"ReadOutlookMail",
        subActions: [],
        nested:true,
        folder:"inbox",
        fromMail:"",
        mailId:"",
      
        top:"",
        unRead:false,
        instruction: '',
        selectorType:"",
        variableName:"",
        mailSpec:"",
        parentId:parentId,
        description:"read mails from office 365",
        status:false
        }
      // if (parentId) {
      //   let read = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
      //   read = JSON.parse(read)
      //   if (read.access_token) {
      //      tab = addActionInTab(tab, action, parentId)
      //     dispatch(updateTab(tab))
      //   } else {
      //     dispatch(openDialog("config"))
      //   }
      // } else {
      //   tab = addActionInTab(tab, action, parentId)
      //   dispatch(updateTab(tab))
      // }
   }
}

export const editMailRead = (payload = {}) => {
  return (dispatch, getState) => {
  //   let {
  //     tabs,
  //     currentTab
  //   } = getState()
  //   let tab = tabs[currentTab]
  //   let currentAction = tab.currentAction
  //   let readAction = tabs[currentTab].actions[currentAction]
  //   let queryString = "https://graph.microsoft.com/v1.0/me/mailFolders/"
  //   let temp = {
  //     ...readAction,
  //     ...payload
  //   }
  //  temp.top!=""?temp.status=true:temp.status=false
  //   /*Getting the access token from token.json*/
  //   let read = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
  //   let accessToken
  //   read = JSON.parse(read)
  //   let refresht = read.refresh_token
  //   console.log("Refresh token=====", refresht);
  //   /**
  //   checking the expired time of access token, if expired time less
  //   than the current time,genarating the new accessToken
  //   */
  //   console.log("time difference", ((read.expired_at - new Date().getTime()) / 1000) / 60);
  //   if (read.expired_at <= new Date().getTime()) {
  //     let accessToken = refresh(refresht, __static)
  //     //let newToken = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
  //     //let readToken =  JSON.parse(newToken)
  //     //accessToken = readToken.access_token
  //   } else {
  //     accessToken = read.refresh_token
  //   }
  //   /**
  //     checking the paramteres to form the url with query parameters
  //   */
  //   if (temp.folder) {
  //     if (temp.folder == "inbox") {
  //       queryString = queryString.concat(`${temp.folder}/messages?$orderby=receivedDateTime desc&$filter=receivedDateTime ge 2018-02-01T09:23:00Z`)
  //     } else {
  //       queryString = queryString.concat(`${temp.folder}/messages?$orderby=sentDateTime desc&$filter=sentDateTime ge 2018-02-01T09:23:00Z`)
  //     }
  //   }
  //   if (temp.unRead) {
  //     queryString = queryString.concat(` and isRead eq false`)
  //   }
  //   if (temp.mailSpec && temp.mailSpec === 'fromMail') {
  //     queryString = queryString.concat(` and from/emailAddress/address eq %27${temp.mailId}%27`)
  //   }
  //   if (temp.top) {
  //     queryString = queryString.concat(`&$top=${temp.top}`)
  //   }

  //   let instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{'api':'${queryString}','token':'${accessToken}'}};
  //         \napi http://localhost:5555/v1/rpa/metadata/outlook/read  \n${temp.variableName} = api_json `


  //   tab["actions"][currentAction] = {
  //     ...temp,
  //     instruction: instruction,
  //     description:temp.description
  //   }
  //   dispatch(updateTab(tab))
  }
}
