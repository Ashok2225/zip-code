import uuid from 'uuid/v1'
import * as outlookConstants from '../../../constants/MailIntegration'

/* adding sendMail action to currentTab*/
export const sendMail = (parentId = null)=>{
   return async(dispatch,getState)=>{
       let {tabs,currentTab} = getState()
       let tab = tabs[currentTab]
     let action = {
        id: uuid(),
        subActions:[],
        label:"SendOutlookMail",
        to:"",
        subject:"",
        body:"",
        type: outlookConstants.OUTLOOK_SEND_MAIL,
        instruction: "",
        parentId:parentId,
        description:"",
        status:false
     }
  //  if (parentId) {
  //          let read = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
  //          read = JSON.parse(read)
  //          if (read.access_token) {
  //            tab = addActionInTab(tab, action, parentId)
  //            dispatch(updateTab(tab))
  //          } else {
  //            dispatch(openDialog("config"))
  //          }
  //        } else {
  //          tab = addActionInTab(tab, action, parentId)
  //          dispatch(updateTab(tab))
  //        }
   }
}

/* updating the data of sendMail to the currentTab*/ 
export const submitSendMail = (payload={})=>{
 return (dispatch,getState) => {
   
      //   let {tabs, currentTab} = getState()
      //   let tab = tabs[currentTab]
      //   let currentAction = tab.currentAction
      //   let sendAction = tabs[currentTab].actions[currentAction]
      //   let temp = {
      //     ...sendAction,
      //     ...payload
      //   }
      //   temp.to&&temp.subject&&temp.body!=""?temp.status=true:temp.status=false
      //   /*Getting the access token from token.json*/
      //   let read = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
      //   let accessToken
      //   read = JSON.parse(read)
      //   let refresht = read.refresh_token
      //   console.log("Refresh token=====", refresht);
      //   /**
      //   checking the expired time of access token, if expired time less
      //   than the current time,genarating the new accessToken
      //   */
      //   console.log("time difference", ((read.expired_at - new Date().getTime()) / 1000) / 60);
      //   if (read.expired_at <= new Date().getTime()) {
      //      accessToken = refresh(refresht, __static)
      //     //let newToken = fs.readFileSync(`${__static}/outlook/token.json`, 'utf8')
      //     //let readToken =  JSON.parse(newToken)
      //     //accessToken = readToken.access_token
      //   } else {
      //     accessToken = read.access_token
      //   }
        
      //   let instruction = `api_config = { method:'POST', header:['Authorization: Bearer ${accessToken}','Content-Type:application/json'],body:{
      //   "message": {"subject": ${temp.subject},"body": {"contentType": "Text","content": ${temp.body.split("\n").join(" \\n")}},"toRecipients": [{"emailAddress": {"address": ${temp.to}}}]},"saveToSentItems": "true"}}
      //   \napi https://graph.microsoft.com/v1.0/me/sendMail \nresult = api_json`
      //   tab.actions[currentAction]={
      //       ...temp,
      //       instruction : instruction,
      //       description: `sending mails to ${temp.to}`
      //    }
      //  dispatch(updateTab(tab))
   }
}
