import {addTab, updateTab,addActionInTab} from "../../Tabs"
import  * as imapConstants from '../../../constants/MailIntegration'
import uuid from 'uuid/v1'
import { log } from "util";

export const readImapMail = (node,parentId=null)=>{
  return(dispatch,getState) =>{
    let {tabs, currentTab} = getState()
    let tab = tabs[currentTab]
   let action = {
    id: uuid(),
    type:imapConstants.IMAP_READ_MAIL,
    label:node.label,
    key:node.key,
    subActions:[],
    email:"",
    password:"",
    host:"",
    port:"",
    unread:false,
    select:"",
    attachmentPath:"",
    past:"today",
    instruction:"",
    variableName:"",
    specDate:"",
    parentId:parentId,
    api:"http://localhost:5555/v1/rpa/metadata/IMAP/read",
    description:"",
    status:false,
    breakpoint:false
   }
   tab = addActionInTab(tab,action,parentId)
   dispatch(updateTab(tab))
  }
}
export const saveAttachmentPath = (id,data) => {
  return(dispatch,getState) =>{
    //  let {tabs,currentTab} = getState()
    //  let {currentFlow} = currentTab
    //  let index = tabs.findIndex((obj) => obj.id === currentTab.id)
    //  let currentFlowId = tabs[index].flow.findIndex((flow) => flow.id === id)
    //  tabs[index].flow[currentFlowId] = {
    //      ...tabs[index].flow[currentFlowId],
    //      attachmentPath:data.filePath
    //  }
    //  tabs[index].currentFlow = {
    //    ... tabs[index].currentFlow,
    //    attachmentPath:data.filePath
    //  }
    //   innerConditionFind(tabs[index],tabs[index].flow,id,tabs[index].currentFlow)
    //   dispatch(updateTab(tabs))
  }
}
export const editImapMailRead = (payload={}) => {
  
   return(dispatch,getState) =>{
  //  let {tabs,currentTab} = getState()
  //  let tab = tabs[currentTab]
  //  let currentAction = tab.currentAction
  //  let readAction = tabs[currentTab].actions[currentAction]
  //  let temp = {
  //    ...readAction,
  //    ...payload
  //  }
  //  temp.email&&temp.password&&temp.host&&temp.port!=""&&temp.variableName!=""?temp.status=true:temp.status=false
       
  // delete temp["instruction"]
  //  let instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{'email':'${temp.email}','password':'${temp.password}','unread':'${temp.unread}','specDate':'${temp.specDate}','past':'${temp.past}'}}
  //  \napi ${temp.api} \n ${temp.variableName} = api_json`
  //  tab["actions"][currentAction] = {
  //    ...temp,
  //    instruction : instruction,
  //    description :`reading  mails from ${temp.email}`
  //  }
  //  dispatch(updateTab(tab))

  }
}
