import {updateTab,addActionInTab} from '../../Tabs'
import uuid from 'uuid/v1'
import * as pop3constants from '../../../constants/MailIntegration'
import { node } from 'prop-types'

export const readPop3Mail=(node,parentId = null)=>{
  return(dispatch,getState) =>{
  let {tabs, currentTab} = getState()
  let tab = tabs[currentTab]
  let action = {
    id : uuid(),
    subActions:[],
    label:node.label,
    key:node.key,
    type:pop3constants.POP3_READ_MAIL,
    email:"",
    password:"",
    host:"",
    port:"",
    select:"",
    attachmentPath:"",
    top:"",
    instruction:"",
    variableName:"",
    specDate:"",
    parentId:parentId,
    api:"http://localhost:8002/api/v1/pop3",
    description:"",
    status:false,
    breakpoint:false
  }
  tab = addActionInTab(tab, action,parentId)
  dispatch(updateTab(tab))
}
}
export const editPop3mail = (payload = {})=>{
  return (dispatch, getState) =>{
    let {tabs,currentTab} = getState()
    let tab = tabs[currentTab]
    let currentAction = tab.currentAction
    let readAction = tabs[currentTab].actions[currentAction]
    let temp = {
      ...readAction,
      ...payload
    }
    temp.email&&temp.password&&temp.host&&temp.port&&temp.top!=""&&temp.variableName!=""?temp.status=true:temp.status=false
    let email =`reading  mails from ${temp.email}`
    delete temp["instruction"]
    let instruction = `api_config = { method:'POST', header:['Content-Type:application/json'],body:{"email":"${temp.email}","password":"${temp.password}","specDate":"${temp.specDate}","host":"${temp.host}","port":"${temp.port}","top":"${temp.top}"}}
    \napi ${temp.api} \n ${temp.variableName} = api_json.data`
    
    tab["actions"][currentAction] = {
      ...temp,
      instruction : instruction,
      description : email
    }
    dispatch(updateTab(tab))
  }
}
