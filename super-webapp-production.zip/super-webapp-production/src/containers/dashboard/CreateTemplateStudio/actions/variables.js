import { updateTab, addTab, updateTabs } from "./Tabs"
import { warningMsg } from "./openDialog"

export const updateVariable = (payload,id) => {
  return (dispatch, getState) => {
    let { currentTab , tabs } = getState()
    if (currentTab && tabs ) {
        let tab =  tabs[currentTab]
        tab.variables[id] = {
          ...tab.variables[id],
          ...payload
      }
      dispatch(updateTab(tab))
    } 
  }
}
export const addVariable = (payload) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    if (currentTab && tabs.sequence.length > 0) {
      tab.variables[payload.id] = payload
    } else {
      dispatch(addTab())
    }
    dispatch(updateTab(tab))
  }
}

export const removeVariables = (variables) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    for (const iterator of variables) {
      delete tab.variables[iterator.id]
    }
    dispatch(updateTab(tab))
  }
}

export const selectAllVariables = (flag) => {
  return (dispatch, getState) => {
    let { currentTab, tabs } = getState()
    let tab = tabs[currentTab]
    let keys = Object.keys(tab.variables)
    for (const iterator of keys) {
      tab.variables[iterator]["checked"] = flag
    }
    // let variables = objToArr(tab.variables)
    // tab.variables = tab.variables.map((variable, index) => {
    //   if (index === editIndex) {
    //     return {
    //       ...variable,
    //       ...payload
    //     }
    //   } else {
    //     return variable
    //   }
    // })
    dispatch(updateTab(tab))
  }
}

