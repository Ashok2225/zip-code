// // import {remote , ipcRenderer} from 'electron'
// import { saveFlow } from './flow'
// import { closeTab, updateTab } from './Tabs'
// import { objToArr } from '../utilities'
// const dialog = remote.dialog

// /**
//  * open the dialog box 
//  * @param {} type is [ open (or) save (or) saveChanges (or) fileCorrupted (or)  actions (or) config ]
//  */
// export function openDialog (type, action=null) {
//   return (dispatch,getState) => {
//   //   let { tabs, currentTab } = getState()
//   //   let flag=false

//   //  // if(type ==="save"){
//   //   //  let current_tab = tabs[currentTab]
//   //   //  let {currentAction} = current_tab
//   //   //  let current_action =tabs[currentTab].actions[currentAction]
//   //   //  let flowActions=objToArr(tabs[currentTab].actions)
//   //   //  console.log("flowActions=======",flowActions);    
//   //   //  (flowActions.some((action)=>{return action.status == false;}))? dispatch(warningMsg("flow has some validation errors, please resolve them first")): ipcRenderer.send('open-dialog',type,action)
//   //   //  }else{
//   //     // if((type ==="open" || type ==="new") &&(tabs.sequence.length>4)){
//   //     //   ipcRenderer.send('open-dialog',"exceeded",action)
//   //     // }else{
//   //       ipcRenderer.send('open-dialog',type,action)
//       //}
//      }
//      //}
//    }




// export const saveChangeDialog =(index, tabId=null)=>{ 
//   return async (dispatch) => { 
//     // let WIN = remote.getCurrentWindow()
//     // let buttons =  ["Yes","No", "Cancel"]
//     // let result = dialog.showMessageBox(WIN, {
//     //   type: "question",
//     //   title: "Techforce.ai Studio",
//     //   message: "Do you want to save changes?",
//     //   buttons:  buttons
//     // })
    
//     // switch (buttons[result]) {
//     //   case "Yes":
//     //     try {
//     //       await dispatch(saveFlow(tabId))
//     //       dispatch(closeTab(index))
//     //     }
//     //     catch (error) {}
//     //     break;

//     //   case "No":
//     //     if(tabId){
//     //       dispatch(closeTab(index, true))
//     //     }
//     //     break;

//     //   case "Cancel":
//     //     break;

//     //   default:
//     //     break;
//     // }
//   }
// }

// export const warningMsg =(msg)=>{ 
//   return async (dispatch, getState) => { 
//     // let WIN = remote.getCurrentWindow()
//     // let result = dialog.showMessageBox(WIN, {
//     //   type: "warning",
//     //   title: "Techforce.ai Studio",
//     //   message: msg,
//     //   buttons: ["Ok"]
//     // })
//   }
// }
