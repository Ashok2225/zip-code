import React, { Component } from "react";
import { connect } from "react-redux";
import { Switch, Route, withRouter } from "react-router-dom";
import { compose } from "redux";
import MyTasks from "./myTasks";
import MyKnowledge from "./myKnowledge";
import MySkills from "./mySkills";
import Search from "./search";
// import $ from "jquery";
import SkillStore from "./skillStore";

import "../../css/app.css";
import "../../css/responsive.css";
import Snacks from "../../components/snacks";
import NotFound from "../../components/notFound";
import Article from "./myKnowledge/components/Article";
import QandA from "./myKnowledge/components/QA";
import View from "./myKnowledge/components/View";
import CreateTemplate from "./CreateTemplate";
import Platforms from "./Platforms";
import Analytics from "./Analytics";
// import FlowEditor from "./CreateTemplateStudio/components/FlowEditor";
import ActionLibrary from "./CreateTemplateStudio/components/ActionLibrary";
import TemplateModal from "./CreateTemplate/TemplateModal";
import Schedules from "./Schedules";
import CreateYourTemplate from "./CreateYourTemplate";
import TemplateFlowScreen from "./CreateYourTemplate/components/index";
import SnippetCode from "./snippetCode";
class DashboardContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  onMessage = (message) => {};

  render() {
    let email =
      this.props &&
      this.props.userReducer.user &&
      this.props.userReducer.user.email
        ? this.props.userReducer.user.email
        : null;

    const { currentOrganization } = this.props.organization;
    return (
      <div className="right-content">
        <TemplateModal />

        <Switch>
          {process.env.REACT_APP_SHOWMYTASK === "true" ? (
            <Route
              exact
              path="/dashboard/search"
              component={(props) => <Search {...props} />}
            />
          ) : (
            ""
          )}

          {/* {process.env.REACT_APP_SHOWMYTASK === "true" ? (
            <Route
              path="/dashboard/tasks"
              component={(props) => <MyTasks {...props} />}
            />
          ) : (
            ""
          )} */}
          {process.env.REACT_APP_ADMIN1 === email ||
          process.env.REACT_APP_ADMIN2 === email ||
          process.env.REACT_APP_ADMIN3 === email ||
          process.env.REACT_APP_ADMIN4 === email ? (
            <Route
              path="/dashboard/tasks"
              component={(props) => <MyTasks {...props} />}
            />
          ) : (
            ""
          )}

          {process.env.REACT_APP_SHOWMYTASK === "true" ? (
            <Route
              path="/dashboard/knowledge"
              component={(props) => <MyKnowledge {...props} />}
            />
          ) : (
            ""
          )}

          {/* <Route
            exact
            path="/dashboard/knowledge/view/:id"
            component={(props) => <View {...props} />}
          /> */}

          {process.env.REACT_APP_SHOWMYTASK === "true" ? (
            <Route
              exact
              path="/dashboard/createNote"
              component={(props) => <Article {...props} />}
            />
          ) : (
            ""
          )}

          {/* <Route
            exact
            path="/dashboard/knowledge/createQA"
            component={(props) => <QandA {...props} />}
          /> */}
          <Route
            path="/dashboard/create"
            component={(props) => <CreateTemplate {...props} />}
          />

          <Route
            path="/dashboard/skills"
            component={(props) => <MySkills {...props} />}
          />

          <Route
            path="/dashboard/skill-store"
            component={(props) => <SkillStore {...props} />}
          />
          <Route
            path="/dashboard/platforms"
            component={(props) => <Platforms {...props} />}
          />

          {currentOrganization.isAdmin ? (
            <Route
              path="/dashboard/analytics/:id"
              component={(props) => <Analytics {...props} />}
            />
          ) : (
            ""
          )}
          <Route
            path="/dashboard/schedule"
            component={(props) => <Schedules {...props} />}
          />
          <Route exact
               path="/dashboard/snippetCode"  
               component={SnippetCode}
            />
          <Route
            path="/dashboard/createYourTemplate"
            component={(props) => <CreateYourTemplate {...props} />}
          />
          <Route
            exact
            path="/dashboard/configureYourTemplate/:id"
            component={(props) => <TemplateFlowScreen {...props} />}
          />
          <Route
            path="/dashboard/*"
            component={(props) => <NotFound {...props} />}
          />
        </Switch>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  userReducer: state.userReducer,
  organization: state.organizationReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {})
)(DashboardContainer);
