import React, { Component } from "react";
import { connect } from "react-redux";
import { getKeycloackToken } from "../../../redux/actions/auth";
import { loadNotifications, deleteNotifications } from "../../../redux/actions/appActions";
import axios from "axios";

class Notifications extends Component {

    deleteNotification = async () => {
        // let token = await getKeycloackToken()
        // var config = {
        //   method: 'delete',
        //   url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/deleteNotifications`,
        //   headers: {
        //     'Content-Type': 'application/json',
        //     'Authorization': `Bearer ${token}`
        //   },
        //   data: this.props.notifications
        // };
        try {
        //   const result = await axios(config)
          await this.props.deleteNotifications(this.props.notifications)
          this.props.loadNotifications(this.props.user)
        } catch (err) {
          console.log(err.toString())
        }
    }

    render(){
        let { notifications } = this.props;
        return(
            <div></div>
            // <div id="notification" className={"task-list"} id="task-list">
            //     <div className="flex-title">
            //         <h3 className="title">Notifications</h3>
            //             { 
            //                 notifications.length > 0 ?
            //                     <button className="btn btn-danger" onClick={this.deleteNotification} >Clear</button> : null
            //             }
            //     </div>
            //     <div className="task-block nt-block scrollable">
            //         {
            //             notifications.length > 0 ?
            //             notifications.map((notify) => {
            //                 return(
            //                 <div className="nf-blck">
            //                     <div className="nf-inner">
            //                     <p className="nf-title">{notify.message}</p>
            //                     <span className="nf-date">{notify.created_at.slice(0, 10)}</span>
            //                     </div>
            //                 </div>
            //                 )
            //             }) :
            //             null
            //         }
            //     </div>
            // </div>
    );    
    }
};

const mapStateToProps = (state) => ({
    notifications: state.appReducer.notifications,
    user: state.userReducer.user
});

export default connect(mapStateToProps,{ loadNotifications, deleteNotifications })(Notifications);
