import React, { Component } from "react";

import generateImg from "../../../images/generate-img.png";
import bulbIcon from "../../../images/modal-icons/bulb.png";
import copyBtn from "../../../images/copy-btn.png";
import deleteIcon from "../../../images/deleteRed.png";
import { compose } from "underscore";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {
  generateApiAccessToken,
  getAllApiTokens,
  deleteToken,
} from "../../../redux/actions/auth";
import CopyToClipboard from "react-copy-to-clipboard";
const exampleExecuteCmd =
  "curl --location --request POST https://superappbot.development.techforce.ai/botapi/draftSkills/extension/execute  --ssl-no-revoke --header 'X-API-TOKEN: [Your Generated Token]' --header 'X-API-ORG: [Your OrgId]' --header 'Content-Type: application/json' --data-raw '{deviceId: 1134,skillId: 2893,orgId: 381,bulk: true}'";
class SnippetCode extends Component {
  constructor() {
    super();
    this.state = {
      apiAccessToken: [],
      allTokensList: [],
      code: [],
      showing: false,
      copied: false,
    };
  }
  getAccessToken = async () => {
    let code = await this.props.generateApiAccessToken();
    this.setState({ showing: true, code: code });
  };
  deleteApiToken = async (id) => {
    await this.props.deleteToken(id);
  };
  componentDidMount() {
    this.props.getAllApiTokens();
  }

  render() {
    const { showing, code } = this.state;
    const encodedToken = encodeURIComponent(code?.token);
    const uri = `https://${process.env.REACT_APP_PUBLIC_BUCKET}/$web/super.js?sa=${encodedToken}&orgId=${code.orgId}&color=%230000ff`;

    const getCode = `<script src="${uri}" async></script>`;
    const dummyCode = `<script src="https://${process.env.REACT_APP_PUBLIC_BUCKET}/$web/super.js?sa=9mbojwy2oCQV/51kR66J9A==&orgId=123&color=%230000ff" async></script>`;
    return (
      <div className="snippet-page">
        <div className="template-box scrollable">
          <div className="tp-title flex-title">
            <h3>Skill Snippet</h3>
          </div>
          <div className="snippet-block tp-boxes">
            <div className="row">
              <div className="col-md-6 snp-left">
                <div className="snippet-inner">
                  <div className="snp-block-1">
                    <div className="flex-snp">
                      <div className="flex-btns-snp">
                        {/* { !showing? (
                          <div className="snp-row-1">
                            <button
                              className="btn btn-primary snp-btn"
                              onClick={() => {
                                this.getAccessToken();
                              }}
                            >
                              Generate
                            </button>
                          </div>
                        ) : null} */}
                      </div>
                      {this.props?.authReducer?.allTokensList?.length > 0 ? (
                        <div className="table-token scrollable">
                          {!showing ? (
                            <div className="snp-row-1">
                              <button
                                className="btn btn-primary snp-btn"
                                onClick={() => {
                                  this.getAccessToken();
                                }}
                              >
                                Generate
                              </button>
                            </div>
                          ) : null}
                          <table className="table table-bordered table-task token-generator">
                            {!showing ? (
                              <thead>
                                <tr>
                                  <th>S.No</th>
                                  <th>Token No</th>
                                  {/* <th>View Code</th> */}
                                  <th>Delete</th>
                                </tr>
                              </thead>
                            ) : null}
                            <tbody>
                              {!showing &&
                                this.props.authReducer.allTokensList.map(
                                  (item, index) => {
                                    return (
                                      <tr key={index}>
                                        <td>{index + 1}</td>
                                        <td>
                                          <p>{item.token}</p>
                                        </td>
                                        {/* <td>
                                          <button
                                            type="button"
                                            className="btn btn-primary btn-sm btn-rounded"
                                            onClick={() => {
                                              this.setState({
                                                showing: true,
                                                code: item,
                                              });
                                            }}
                                          >
                                            View Code
                                          </button>
                                        </td> */}
                                        <td>
                                          <div className="del-btn">
                                            <button
                                              type="button"
                                              data-target="#myDeleteModal"
                                              data-toggle="modal"
                                            >
                                              <span>
                                                <img src={deleteIcon} />
                                              </span>
                                            </button>
                                          </div>
                                          {/* Delete modal */}
                                          <div
                                            className="modal fade qa-modal1"
                                            id="myDeleteModal"
                                            role="dialog"
                                          >
                                            <div className="modal-dialog modal-sm">
                                              <div className="modal-content share-modal">
                                                <button
                                                  type="button"
                                                  className="close"
                                                  data-dismiss="modal"
                                                >
                                                  &times;
                                                </button>
                                                <div className="modal-body">
                                                  <h3 className="qa-modal-title">
                                                    Delete
                                                  </h3>
                                                  <div>
                                                    <h5>
                                                      Please confirm delete
                                                      action.
                                                    </h5>
                                                  </div>

                                                  <div className="frm-btns fb-right">
                                                    <button
                                                      className="btn-outline"
                                                      data-dismiss="modal"
                                                    >
                                                      Cancel
                                                    </button>
                                                    <button
                                                      className="primary-btn"
                                                      data-dismiss="modal"
                                                      onClick={() => {
                                                        this.deleteApiToken(
                                                          item.id
                                                        );
                                                      }}
                                                    >
                                                      Delete
                                                    </button>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </td>
                                      </tr>
                                    );
                                  }
                                )}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div>
                          {!showing ? (
                            <>
                              <div className="snp-title">
                                <p className="snp-main-title">
                                  Generate Skill Snippet
                                </p>
                                <p>
                                  Generate Skill Snippet that can be added to
                                  web applications/websites to facilitate skill
                                  execution
                                </p>
                              </div>
                              <div className="snp-row-1">
                                <div className="snp-img">
                                  <img src={generateImg} />
                                </div>
                                <button
                                  className="btn btn-primary snp-btn"
                                  onClick={() => {
                                    this.getAccessToken();
                                  }}
                                >
                                  Generate
                                </button>
                              </div>
                            </>
                          ) : null}
                        </div>
                      )}
                      {showing && code ? (
                        <div className="snp-row-2">
                          <div id="div1" className="snp-code scrollable">
                            <code>
                              {/* {`<script src="https://${process.env.REACT_APP_PUBLIC_BUCKET}/$web/super.js?sa=${code.token}&orgId=${code.orgId}&color=%230000ff" async></script>`}{" "} */}
                              {getCode}
                              <br />
                            </code>
                          </div>
                          <CopyToClipboard
                            text={getCode}
                            onCopy={() => this.setState({ copied: true })}
                          >
                            <button className="btn btn-primary snp-rounded-btn">
                              <img src={copyBtn} />
                              Copy Code
                            </button>
                          </CopyToClipboard>
                          {this.state.copied ? (
                            <span style={{ color: "green" }}>Copied.</span>
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 snp-right">
                <div className="instruct-snp">
                  <div className="instruct-title">
                    <div className="instruct-click">
                      <div className="inst-ico">
                        <img src={bulbIcon} />
                      </div>
                      <h5>Instructions</h5>
                    </div>
                  </div>
                  <div className="instruct-snp-list">
                    <ul class="ist-block">
                      <li>
                        <span>01</span>
                        <p>
                          Add the generated script tag in the html page of your
                          website/webapplication that has walkthrough steps.
                          Note that this script needs to added in body tag just
                          before the closing &lt;/body&gt; tag. Color attribute
                          value can be replaced with your application specific
                          color code value.
                        </p>
                      </li>
                      <li>
                        <span>02</span>
                        <p>
                          To trigger In-App walkthroughs, please follow the
                          instructions below:
                          <br />
                          Below is an example:
                          <br />
                          <code>{dummyCode}</code>
                          <br />
                          <br />
                          Replace sa=[Your Generated Token]==&orgId=[Your OrgId]
                        </p>
                      </li>
                      <li>
                        <span>03</span>
                        <p>
                          Add the below attribute to any button/link/div/span
                          element by mentioning the skill name.
                          <br />
                          Below is an example:
                          <br />
                          <code>
                            {
                              "<button data-super-skill='Super Embedded Test'>Get Walkthrough</button>"
                            }
                          </code>
                          <br />
                          Where the "Super Embedded Test" is the skill name
                        </p>
                      </li>
                      <li>
                        <span>04</span>
                        <p>
                          To trigger Automation Skills from external
                          applications, please follow the instructions below:
                          <br />
                          Below is an example:
                          <br />
                          <code>{exampleExecuteCmd}</code>
                          <br />
                        </p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  authReducer: state.authReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    generateApiAccessToken,
    getAllApiTokens,
    deleteToken,
  })
)(SnippetCode);
