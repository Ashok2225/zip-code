// import React from "react";
// import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
// import MyProfileSetting from "./components/MyProfileSetting";
// import OrganizationSetting from "./components/OrganisationSetting";

// const Settings = () => {
//   return (
//     <>
//       {/* <FixedTaskbar
//         updateComponent={this.updateComponent}
//         enable={this.enableProfile}
//         enableNotify={this.enableNotifyTab}
//         notified={this.state.notified}
//       /> */}
//       <div className="main-body">
//         <ul>
//           <li>
//             <Link to={`/settings/myprofile-settings/`}>My Profile Setting</Link>
//           </li>
//           <li>
//             <Link to={`/settings/organization-settings/`}>
//               OrganizationSetting
//             </Link>
//           </li>
//         </ul>
//       </div>
//       <div>
//         <Switch>
//           {/* <Route path="/settings/" exact component={MyProfileSetting} /> */}
//           <Route
//             // exact
//             path="/settings/myprofile-settings/"
//             component={MyProfileSetting}
//           />
//           <Route
//             exact
//             path="/settings/organization-settings/"
//             component={OrganizationSetting}
//           />
//         </Switch>
//       </div>
//     </>
//   );
// };
// export default Settings;
