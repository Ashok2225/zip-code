import React, { useEffect, useState } from "react";
import DeleteAccount from "../OrganisationSetting/DeleteAccount";
import Building from "../../../../../images/building.png";
import People from "../../../../../images/exp/group.png";
import {
  Breadcrumb,
  BreadcrumbItem,
  Nav,
  NavItem,
  FormGroup,
  Input,
  Form,
} from "reactstrap";
import { Link, useLocation } from "react-router-dom";
import { useParams, useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  getTeamById,
  updateTeam,
} from "../../../../../redux/actions/organizationAction";
import FormikErrorMessage from "../../../../../common/FormikErrorMessage";
import { validationSchemaProfileTeam } from "../../../../../common/ValidationSchemas/ProfileTeamSchema";
import { useFormik } from "formik";
import avatar from "../../../../../images/avatar.png";
import Camera from "../../../../../images/camera@3x.png";
import { getKeycloackToken } from "../../../../../redux/actions/auth";
import Axios from "axios";
import { logout } from "../../../../../redux/actions/user";
import Loader from "../../../../../components/loader";
import { changeActiveTab } from "../../../../../redux/actions/skill";
import home from "../../../../../images/home.png";

const ProfileTeam = () => {
  const [deleteAccountModal, setDeleteAccountModal] = useState(false);
  const params = useParams();
  const history = useHistory();
  const { id, teamId } = params;
  const dispatch = useDispatch();
  const location = useLocation();
  const teamDetails = useSelector(
    (state) => state.organizationReducer.teamDetails
  );
  const {
    values,
    errors,
    touched,
    handleSubmit,
    handleChange,
    handleBlur,
    setFieldValue,
  } = useFormik({
    initialValues: {
      id: teamId,
      name: teamDetails?.name,
      profilePic: teamDetails?.profilePic,
    },
    enableReinitialize: true,
    validationSchema: validationSchemaProfileTeam,
    onSubmit: async (values) => {
      await dispatch(updateTeam(values));
    },
  });
  const userDetails = useSelector((state) => state.userReducer.user);
  const isLoading = useSelector((state) => state.organizationReducer.isLoading);
  useEffect(() => {
    dispatch(getTeamById(teamId));
  }, []);
  const teamCreatedBy = teamDetails && teamDetails.user_id;
  const isOwner = userDetails && teamCreatedBy === userDetails.sub;

  const deleteAccountModalToggle = () =>
    setDeleteAccountModal(!deleteAccountModal);

  const handleFileChange = async (e) => {
    try {
      let token = await getKeycloackToken();
      var data = new FormData();
      data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: data,
      };

      const res = await Axios(config);
      const imgId = res.data.data.image_id;
      let url = `${process.env.REACT_APP_BOT_SERVICE_URL}/image/${imgId}`;
      setFieldValue("profilePic", url);
    } catch (err) {
      console.log(err.toString());
    }
  };

  const renderDeleteButton = () => {
    if (isOwner)
      return (
        <div className="delete-profile">
          <button
            className="btn btn-outline-danger mt-auto"
            onClick={deleteAccountModalToggle}
          >
            Delete Account
          </button>
        </div>
      );
    return null;
  };

  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            {/* <h5 className="mb-0">Organization</h5> */}
            <h5 className="mb-0">Teams</h5>

            <Breadcrumb className="mb-0">
              <BreadcrumbItem>
                {/* <Link to="/settings/organization-settings">Home</Link> */}
                <Link to="/settings/teams-settings">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbItem>
                {/* <Link to="/settings/organization-settings/">Organization</Link> */}

                <Link to="/settings/teams-settings/">Teams</Link>
              </BreadcrumbItem>
              <BreadcrumbItem active>Team’s Profile</BreadcrumbItem>
            </Breadcrumb>
          </div>
          {/* <OrganizationSettingSidebar /> */}

          {/* Commented  Teams under Organization and renamed organization label and route to teams */}

          {/* <Nav className="secondary-nav" vertical>
            <NavItem
              className={
                location.pathname ==
                `/settings/organization/${id}/team/${teamId}/profile`
                  ? "active"
                  : null
              }
            >
              <Link
                // to={`settings/organization/${id}/team/${teamId}/profile`}
                to={`profile`}
                active
                className="text-dark"
              >
                <div className="d-flex align-items-center">
                  <div className="holder-label mr-3">
                    <img src={Building} alt="Profile" />
                  </div>
                  <span>Team’s Profile</span>
                </div>
              </Link>
            </NavItem>

            <NavItem
              className={
                location.pathname ==
                `/settings/organization/${id}/team/${teamId}/people`
                  ? "active"
                  : null
              }
            >
              <Link
                // to={`settings/organization/${id}/team/${teamId}/people`}
                to={`people`}
                active
                className="text-dark"
              >
                <div className="d-flex align-items-center">
                  <div className="holder-label mr-3">
                    <img src={People} alt="Organization" />
                  </div>
                  <span>People</span>
                </div>
              </Link>
            </NavItem>
          </Nav> */}

          <div className="logout-btn">
            <button
              className="home-btn"
              onClick={() => {
                dispatch(changeActiveTab("Create"));
                history.push("/dashboard/create");
              }}
            >
              <img src={home} />
            </button>
            <button
              onClick={() => {
                dispatch(changeActiveTab("Settings"));
                dispatch(logout());
              }}
            >
              Logout
            </button>
          </div>
        </div>
        {/* Left end */}

        {/* Right */}
        {isLoading ? (
          <div className="org-loader">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : (
          <div className="inner-right bg-grey">
            <div>
              <div className="row mx-0 pl-3 my-3">
                <div className="col-md-6">
                  <h5 className="org-heading">Team’s Profile</h5>
                </div>
              </div>

              <div className="row org-profile-content mx-0 px-3 vh100-80">
                <div className="col-lg-10 mb-4 mb-lg-0">
                  <div className="card border-0 px-4 py-5 h-100">
                    <Form onSubmit={handleSubmit} noValidate>
                      <div
                        className="row pt-2 h-100 org-profile-content"
                        id="mt-0"
                      >
                        <div className="col-md-6 offset-xl-3 form-group">
                          <FormGroup>
                            <label>Company Name</label>
                            <Input
                              name="name"
                              onChange={handleChange}
                              onBlur={handleBlur}
                              value={values.name}
                              type="text"
                              disabled={!isOwner}
                            />
                            <FormikErrorMessage
                              errors={errors}
                              touched={touched}
                              field="description"
                            />
                          </FormGroup>
                          <div className="mt-4 mt-auto text-right">
                            <button
                              type="submit"
                              className="btn btn-primary"
                              disabled={!isOwner}
                            >
                              Update
                            </button>
                          </div>
                        </div>
                      </div>
                    </Form>
                  </div>
                </div>
                <div className="col-lg-2">
                  <div className="card org-profile-card border-0 text-center">
                    <div className="upld-avatar m-auto">
                      <img
                        src={values.profilePic ? values.profilePic : avatar}
                        alt="Avatar"
                      />
                      <div
                        onClick={() =>
                          isOwner && document.getElementById("profile").click()
                        }
                        className="upld-hover"
                      >
                        {isOwner && <img src={Camera} alt="camera" />}
                        <input
                          type="file"
                          accept="image/*"
                          id="profile"
                          style={{ display: "none" }}
                          onChange={(e) => handleFileChange(e)}
                        />
                      </div>
                    </div>
                    <div className="my-3">
                      <p className="font-weight-600 mb-0">Profile Photo</p>
                      <span className="text-muted f-12">20kb max</span>
                    </div>
                    {renderDeleteButton()}
                  </div>
                </div>
              </div>
            </div>
            <DeleteAccount
              deleteAccountModalToggle={deleteAccountModalToggle}
              deleteAccountModal={deleteAccountModal}
              team={true}
              profilePic={teamDetails?.profilePic}
            />
          </div>
        )}

        {/* Right End */}
      </div>
    </>
  );
};

export default ProfileTeam;
