import React, { Component } from "react";
import { connect } from "react-redux";

import ApproveHelper from "./components/ApproveHelper";


import "../../../../../css/app.css";


class AnalyticsPeople extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() { }

  render() {
    return (
      <div className=""> {/* align-row class is removed */}
        {/* <SideBar />
        <HelperEdit /> */}

        <ApproveHelper />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(AnalyticsPeople);
