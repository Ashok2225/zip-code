/*global chrome*/
import React, { Component } from "react";
import { connect } from "react-redux";


import Loader from "../../../../../../../components/loader";
import EmptyLoader from "../../../../../../../components/emptyLoader";

import { withRouter } from "react-router";
import { compose } from "redux";



class ApproveHelper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      userList:[]
  
    };
  }

  componentDidMount() {
    
    this.getUsers();
  }

  getUsers = async () => {
    var id=this.props.match.params.id
    const userList = this.props.analytics.analyticsRecord.data[parseInt(id)].usersInfo
    

    if (userList) {
      this.setState({
        userList,
        isLoading: false,
      
      });
    } else {
      this.setState({
        isLoading: false,
       
      });
    }
  };


  render() {
    

    return (
      <div className="fw-screen">
        <div
          className={
            false ? "right-content rm-margin" : "right-content"
          }
        >
          <div className="task-col">
            <div className="title-btn">
              <h1 className="title">User Information</h1>

            </div>

            <div
              id="scrollableDiv"
              className="scrollable tl-scroll task-tb-scroll"
              style={{ height: "75vh" }}
            >

              {this.state.isLoading ? (
                <Loader
                  styles={{ width: "50px", margin: "auto" }}
                  root={{ display: "flex" }}
                />
              ) : this.state.userList.length + this.state.userList.length ===
                0 ? (
                <EmptyLoader message="No Data found" />
              ) : (
                <div className="tab-content task-tabs ">
                  <div id="waiting" className="tab-pane fade in active">
                    <div className="table-responsive tt-block">
                      <table className=" table-striped table table-task">
                        <thead>
                          <tr>
                            
                            <th style={{ width: "30%" }}>User Id</th>
                            <th style={{ width: "12%" }}>First Name</th>
                            <th style={{ width: "12%" }}>Last Name</th>
                            <th style={{ width: "20%" }}>Email</th>
                           
                           
                          </tr>
                        </thead>

                        <tbody>
                          {this.state.userList.map((user, i) =>
                          (
                            <tr key={i}>

                              <td>{user.id}</td>
                              <td>{user.first_name}</td>
                              <td>{user.last_name}</td>
                              <td>{user.email}</td>

                            </tr>
                          )
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {/* )} */}
                </div>
              )}

            </div>
          </div>

        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  knowledge: state.knowledgeReducer,
  user: state.userReducer,
  skill: state.skillReducer,
  analytics:state.analyticsReducer
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
   
  })
)(ApproveHelper);
