import React, { useState } from "react";
import { useDispatch } from "react-redux";
import {
  Link,
  useRouteMatch,
  NavRoute,
  NavLink,
  useHistory,
} from "react-router-dom";
import { Nav, NavItem, Collapse } from "reactstrap";
import Organization from "../../../../../images/building.png";
import Profile from "../../../../../images/user.png";
import { logout } from "../../../../../redux/actions/user";
import Team from "../../../../../images/exp/group.png";
import { changeActiveTab } from "../../../../../redux/actions/skill";
import home from "../../../../../images/home.png";
import deviceIcon from "../../../../../images/devices.svg"
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";

const SettingSidebar = (props) => {
  const [isOpen, setIsOpen] = useState(true);

  const toggle = async () => {
    await setIsOpen(!isOpen);
  };
  const history = useHistory();
  const { path } = useRouteMatch();
  const dispatch = useDispatch();
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  let email =
    props &&
      props.userReducer.user &&
      props.userReducer.user.email
      ? props.userReducer.user.email
      : null;
  return (
    <>
      <Nav className="secondary-nav" vertical>
        <NavItem>
          <Link
            // onClick={toggle}
            // to="/settings/myprofile-settings/my-profile"
            to="/settings/myprofile-settings/account-setting"
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label">
                <img src={Profile} alt="Profile" />
              </div>
              <span>My Profile Settings</span>
            </div>
          </Link>
          <Collapse isOpen={true}>
            <Nav className="profile-setting-link" vertical>
              {/* <NavItem>
                <NavLink
                  className=""
                  to="/settings/myprofile-settings/my-profile"
                >
                  My Profile
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className="pl-5"
                  to="/assistant-setting"
                  isActive={(match) => match}
                >
                  Assistant Setting
                </NavLink>
              </NavItem> */}
              <NavItem>
                <NavLink
                  className="pl-5"
                  to="/settings/myprofile-settings/account-setting"
                  isActive={(match) => match}
                >
                  {/* Account Setting */}
                  Edit Profile
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className="pl-5"
                  to="/settings/myprofile-settings/change-password"
                  isActive={(match) => match}
                >
                  Change Password
                </NavLink>
              </NavItem>
              {/* <NavItem>
                <NavLink
                  className="pl-5"
                  to="/notification-setting"
                  isActive={(match) => match}
                >
                  Notification Setting
                </NavLink>
              </NavItem> */}
            </Nav>
          </Collapse>
        </NavItem>
        {/* Renaming Organization to Teams */}

        <NavItem
          className={path == "/settings/teams-settings/" ? "active" : ""}
        >
          <Link
            // onClick={() => setIsOpen(false)}
            onClick={toggle}
            to="/settings/teams-settings"
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label">
                <img src={Organization} alt="Organization" />
              </div>
              <span>Teams Settings</span>
            </div>
          </Link>
        </NavItem>

        {process.env.REACT_APP_ADMIN1 === email ||
          process.env.REACT_APP_ADMIN2 === email ||
          process.env.REACT_APP_ADMIN3 === email ||
          process.env.REACT_APP_ADMIN4 === email ? (
          <NavItem
            className={path == "/settings/myprofile-settings/analytics/admin" ? "active" : ""}
          >
            <Link
              // onClick={() => setIsOpen(false)}
              onClick={toggle}
              to="/settings/myprofile-settings/analytics/admin"
              className="text-dark"
            >
              <div className="d-flex align-items-center">
                <div className="holder-label">
                  <img src={Organization} alt="Organization" />
                </div>
                <span>Analytics</span>
              </div>
            </Link>
          </NavItem>
        ) : (
          ""
        )}
       
        <NavItem
          className={path == "/settings/device" ? "active" : ""}
        >
          <Link
            // onClick={() => setIsOpen(false)}
            onClick={toggle}
            to="/settings/device"
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label dc-icon">
                <img src={deviceIcon} alt="Organization" />
              </div>
              <span>Device Settings</span>
            </div>
          </Link>
        </NavItem>
    

        {/* <NavItem
          className={path == "/settings/organization-settings/" ? "active" : ""}
        >
          <Link
            // onClick={() => setIsOpen(false)}
            onClick={toggle}
            to="/settings/organization-settings"
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={Organization} alt="Organization" />
              </div>
              <span>Organization Settings</span>
            </div>
          </Link>
        </NavItem> */}

        {/* {orgId && (
          <React.Fragment>
            <NavItem
              className={
                path === `/settings/organization/${orgId}/team` ? "active" : ""
              }
            >
              <Link
                to={`/settings/organization/${orgId}/team`}
                active
                className="text-dark"
              >
                <div className="d-flex align-items-center">
                  <div className="holder-label mr-3">
                    <img src={Team} alt="Organization" />
                  </div>
                  <span>Team</span>
                </div>
              </Link>
            </NavItem>
          </React.Fragment>
        )} */}
      </Nav>
      <div className="logout-btn">
        <button
          className="home-btn"
          onClick={() => {
            dispatch(changeActiveTab("Create"));
            history.push("/dashboard/create");
          }}
        >
          <img src={home} />
        </button>
        <button
          onClick={() => {
            dispatch(changeActiveTab("Settings"));
            dispatch(logout());
          }}
        >
          Logout
        </button>
      </div>
    </>
  );
};

const mapStateToProps = (state) => ({
  organizationReducer: state.organizationReducer,
  userReducer: state.userReducer,
  notifications: state.appReducer.notifications,
  notified: state.appReducer.notified,
  skillReducer: state.skillReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {

  })
)(SettingSidebar);
