/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useState } from "react";
import FormikErrorMessage from "../../../../../common/FormikErrorMessage";
import { validationSchemaProfileTeam } from "../../../../../common/ValidationSchemas/ProfileTeamSchema";
import { useFormik } from "formik";
import Close from "../../../../../images/close.png";
import avatar from "../../../../../images/avatar.png";
import { useDispatch, useSelector } from "react-redux";
import {
  addMemberToTeam,
  getUsersOfAnOrganization,
} from "../../../../../redux/actions/organizationAction";
import { useParams } from "react-router";
import addImg from "../../../../../images/add-icon.jpg";
import { Form, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";

const AddMemberModal = (props) => {
  const {
    modalTeamMemberToggle,
    addMemberToggle,
    className,
    profilePic,
    teamMembers,
    searchRef,
    teamId,
  } = props;
  const params = useParams();
  const [pplAdded, setPplAdded] = useState([]);
  const { id, teamId: tId } = params;
  const dispatch = useDispatch();
  const organizationPeople = useSelector(
    (state) => state.organizationReducer.organizationPeople
  );
  const availableMembers =
    organizationPeople !== undefined &&
    organizationPeople.filter(
      ({ email: id1 }) => !teamMembers.some(({ email: id2 }) => id2 === id1)
    );

  const { values, handleSubmit, setFieldValue } = useFormik({
    initialValues: {
      organizationPeople: availableMembers,
      roleId: "",
    },
    validationSchema: validationSchemaProfileTeam,
    enableReinitialize: true,
  });

  useEffect(() => {
    dispatch(getUsersOfAnOrganization(id));
  }, []);

  const addMembers = (data) => {
    const { email, organization_id, name, role_id } = data;
    const payload = {
      email,
      organization_id,
      name,
      team_id: teamId ? teamId.toString() : tId,
      roleId: role_id,
    };
    dispatch(addMemberToTeam(payload));
    if (searchRef.current) searchRef.current.value = "";
    // modalTeamMemberToggle();
  };
  const renderOrgPeopleList = () => {
    const { organizationPeople } = values;
    return (
      organizationPeople &&
      organizationPeople.map((item, index) => (
        <li
          className="border-bottom"
          hidden={pplAdded.find((ele) => ele === item.id)}
        >
          <div className="d-flex align-items-center justify-content-between">
            <div className="d-flex align-items-center">
              <div className="text-white custom-badge bg-primary">
                {item.name.charAt(0).toUpperCase()}
              </div>
              <div className="pl-4 font-weight-bold pt-1">
                <p className="mb-0">{item.name}</p>
                <small className="text-muted f-12">{item.email}</small>
              </div>
            </div>
            <div>
              <span
                className={
                  item.role_id === "2"
                    ? "badge badge-pill badge-primary-light cursor-pointer px-3 py-1"
                    : "badge badge-pill badge-light cursor-pointer px-3 py-1"
                }
                onClick={() => {
                  organizationPeople[index].role_id = "2";
                  setFieldValue("organizationPeople", [...organizationPeople]);
                }}
              >
                Admin
              </span>
              <span
                className={
                  item.role_id === "1"
                    ? " badge badge-pill badge-primary-light cursor-pointer px-3 py-1"
                    : "badge badge-pill badge-light cursor-pointer px-3 py-1"
                }
                onClick={() => {
                  organizationPeople[index].role_id = "1";
                  setFieldValue("organizationPeople", [...organizationPeople]);
                }}
              >
                Member
              </span>
            </div>
            <div>
              {" "}
              <img
                onClick={() => {
                  addMembers(item);
                  setPplAdded((prevState) => [...prevState, item.id]);
                }}
                className="add-icon"
                src={addImg}
              />
            </div>
          </div>
        </li>
      ))
    );
  };

  const handleUserChange = (e) => {
    const { value } = e.target;
    let found =
      availableMembers !== undefined &&
      availableMembers.filter((o) => o.name.includes(value));
    // let found = organizationPeople.filter((o) => o.name.includes(value));
    setFieldValue("organizationPeople", found);
  };
  return (
    <>
      <Modal
        isOpen={addMemberToggle}
        modalTeamMemberToggle={modalTeamMemberToggle}
        className="org-setting"
      >
        <Form onSubmit={handleSubmit} noValidate>
          <ModalHeader
            modalTeamMemberToggle={modalTeamMemberToggle}
            className="team-model-header"
          >
            <div className="d-flex justify-content-between">
              <div>Invite People</div>
              <div className="close teams-close">
                <img
                  src={Close}
                  alt="close Btn"
                  onClick={modalTeamMemberToggle}
                />
              </div>
            </div>
          </ModalHeader>
          <ModalBody>
            <div className="modal-avatar">
                <div className="pr-info">
                  <div className="upld-avatar">
                    <img src={profilePic ? profilePic : avatar} alt="Avatar" />
                  </div>
              </div>

              <div className="col-sm-12 form-group">
                <input
                  type="text"
                  className="form-control search-type border-0 rounded-0"
                  placeholder="Search people and invite new user"
                  onChange={(e) => handleUserChange(e)}
                />
              </div>
              <div className="col-sm-12 form-group ">
                <ul className="overflow-auto-200 list-with-bottom-border mt-3">
                  {renderOrgPeopleList()}
                </ul>
              </div>
            </div>
          </ModalBody>
          <ModalFooter className="px-0 pt-0 border-0 mb-4">
            <div id="mt-0">
              {/* <div className="col-sm-6">
                <button
                  type="button"
                  className="btn btn-block btn-outline-primary"
                  onClick={modalTeamMemberToggle}
                >
                  Cancel
                </button>
              </div> */}
              <div>
                <button
                  type="button"
                  className="btn btn-block btn-primary"
                  onClick={modalTeamMemberToggle}
                >
                  Done
                </button>
              </div>
            </div>
          </ModalFooter>
        </Form>
      </Modal>
    </>
  );
};

export default AddMemberModal;
