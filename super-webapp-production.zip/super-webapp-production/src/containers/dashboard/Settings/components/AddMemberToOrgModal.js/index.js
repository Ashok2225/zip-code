import React, { useState } from "react";
import {
  Form,
  FormGroup,
  Input,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from "reactstrap";
import Close from "../../../../../images/close.png";
import avatar from "../../../../../images/avatar.png";

import { useParams } from "react-router";
import { useFormik } from "formik";
import { validationSchemaOrganizationMember } from "../../../../../common/ValidationSchemas/OrganizationMemberSchema";
import FormikErrorMessage from "../../../../../common/FormikErrorMessage";
import {
  addMemberToOrganization,
  updateUserOfOrg,
} from "../../../../../redux/actions/organizationAction";
import { useDispatch } from "react-redux";
import { notify } from "../../../../../redux/actions/snack";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";

const AddMemberToOrgModal = (props) => {
  const {
    modalTeamMemberToggle,
    createTeamToggle,
    profilePic,
    organizationPeople,
    searchRef,
    orgId,
    editUserInfo,
  } = props;
  const params = useParams();
  const [isNameAvailable, setAvailability] = useState(true);
  const dispatch = useDispatch();
  const { id } = params;
  const {
    values,
    handleSubmit,
    setFieldValue,
    handleChange,
    handleBlur,
    handleReset,
    errors,
    touched,
    resetForm,
  } = useFormik({
    initialValues: {
      name: editUserInfo ? editUserInfo.name : "",
      email: editUserInfo ? editUserInfo.email : "",
      roleId: editUserInfo ? editUserInfo.role_id : "",
    },
    validationSchema: validationSchemaOrganizationMember,
    enableReinitialize: true,
    onSubmit: async (values, { resetForm }) => {
      let payload;
      if (editUserInfo) {
        payload = {
          id: editUserInfo.id,
          organization_id: orgId ? orgId.toString() : id,
          email: values.email,
          name: values.name,
          role_id: values.roleId,
        };
        if (organizationPeople.length === 1 && values.roleId === "1") {
          dispatch(notify("error", "Please add more members to assign roles."));
        } else {
          await dispatch(updateUserOfOrg(payload));
        }
      } else {
        payload = {
          organization_id: orgId ? orgId.toString() : id,
          email: values.email,
          name: values.name,
          role_id: values.roleId,
        };
        await dispatch(addMemberToOrganization(payload));
      }
      modalTeamMemberToggle();
      resetForm();
      searchRef.current.value = "";
    },
  });

  const checkAvailability = (e) => {
    const { value } = e.target;
    setFieldValue("email", value);
    var found =
      organizationPeople !== undefined &&
      organizationPeople.filter(function (o) {
        return o.email === value;
      });
    found.length > 0 ? setAvailability(false) : setAvailability(true);
  };
  return (
    <>
      <Modal
        isOpen={createTeamToggle}
        modalTeamMemberToggle={modalTeamMemberToggle}
        className=""
      >
        <Form onSubmit={handleSubmit} noValidate>
          <ModalHeader
            modalTeamMemberToggle={modalTeamMemberToggle}
            className="team-model-header"
          >
            <div className="d-flex justify-content-between">
              {values.email != props.userReducer.user.email ? (
                <div>{editUserInfo ? "Edit Member" : "Invite People"}</div>) : null}
              <button className="close teams-close">
                <img
                  src={Close}
                  alt="close Btn"
                  onClick={() => {
                    resetForm();
                    modalTeamMemberToggle();
                  }}
                />
              </button>
            </div>
          </ModalHeader>
          <ModalBody>
            <div className="modal-avatar">
              <div className="pr-info">
                <div className="upld-avatar">
                  <img src={profilePic ? profilePic : avatar} alt="Avatar" />
                </div>
              </div>

              <div className="form-contain">
                <FormGroup>
                  <div className="ip-tl-label">
                    <span className="tl-label">Name</span>
                    <Input
                      name="name"
                      placeholder="Enter"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.name}
                      type="text"
                      disabled={editUserInfo}
                    />
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="name"
                    />
                  </div>
                </FormGroup>
                <FormGroup>
                  <div className="ip-tl-label">
                    <span className="tl-label">Email Address</span>
                    <Input
                      name="email"
                      placeholder="Enter"
                      // onChange={handleChange}
                      onChange={(e) => checkAvailability(e)}
                      onBlur={handleBlur}
                      value={values.email}
                      type="text"
                      disabled={editUserInfo}
                    />
                    <div className="d-flex justify-content-between align-items-center">
                      <span className={isNameAvailable ? "exist" : "not-exist"}>
                        {values.email.length > 0
                          ? isNameAvailable
                            ? ""
                            : "Email already Exists"
                          : ""}
                      </span>
                    </div>
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="email"
                    />
                  </div>
                </FormGroup>
                <FormGroup>
                  {values.email != props.userReducer.user.email ? (
                    <><label className="d-block text-dark">Assign role</label><span
                      className={values.roleId === "2"
                        ? "badge badge-pill badge-primary-light cursor-pointer"
                        : "badge badge-pill badge-light cursor-pointer"}
                      onClick={() => setFieldValue("roleId", "2")}
                    >
                      Admin
                    </span>
                      <span
                        className={values.roleId === "3"
                          ? " badge badge-pill badge-primary-light cursor-pointer"
                          : "badge badge-pill badge-light cursor-pointer1"}
                        onClick={() => setFieldValue("roleId", "3")}
                      >
                        View & Edit
                      </span>
                      <span
                        className={values.roleId === "1"
                          ? " badge badge-pill badge-primary-light cursor-pointer"
                          : "badge badge-pill badge-light cursor-pointer1"}
                        onClick={() => setFieldValue("roleId", "1")}
                      >
                        View Only
                      </span></>) : null}
                </FormGroup>
              </div>
            </div>
          </ModalBody>
          <ModalFooter className="frm-btns">
            <div className="col-sm-6">
              <button
                type="button"
                className="btn-outline"
                onClick={modalTeamMemberToggle}
              >
                Cancel
              </button>
            </div>
            {/* <button className="btn-outline" data-dismiss="modal">
              Cancel
            </button> */}
            <button
              type="submit"
              disabled={!isNameAvailable}
              className="primary-btn text-center"
            >
              {editUserInfo ? "Update" : "Done"}
            </button>
          </ModalFooter>
        </Form>
      </Modal>
    </>
  );
};
const mapStateToProps = (state) => ({
  userReducer: state.userReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {

  })
)(AddMemberToOrgModal);

