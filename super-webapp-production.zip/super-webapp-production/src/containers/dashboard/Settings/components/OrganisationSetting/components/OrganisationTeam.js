import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import Dots from "../../../../../../images/dot.png";

import Edit from "../../../../../../images/edit.png";
import Delete from "../../../../../../images/delete.png";
import Filter from "../../../../../../images/filter.png";
import SearchIcon from "../../../../../../images/search.png";
import Close from "../../../../../../images/close.png";
import Banner from "../../../../../../images/empty.png";
import CreateTeamModal from "../../CreateTeamModal/CreateTeamModal";
import AddMemberToTeam from "../../AddMemberToTeam/index";
import OrganizationSettingSidebar from "../components/OrganisationSettingSidebar";
import { useDispatch, useSelector } from "react-redux";
import {
  getMembersOfTeam,
  getTeamsOfAnOrganization,
  removeTeamFromOrganization,
} from "../../../../../../redux/actions/organizationAction";
import { useHistory, useParams } from "react-router-dom";
import moment from "moment";
import { useFormik } from "formik";
import Loader from "../../../../../../components/loader";

const OrganizationTeam = () => {
  const [teamId, setTeamId] = useState();
  const [createTeamToggle, setCreateTeam] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectIndex, setSelectIndex] = useState(null);
  const [addMemberToggle, setAddMemberToggle] = useState(false);

  const searchRef = useRef();

  const history = useHistory();

  const params = useParams();
  const { id } = params;
  const dispatch = useDispatch();
  const organizationTeams = useSelector(
    (state) => state.organizationReducer.organizationTeams
  );
  const teamMembers = useSelector(
    (state) => state.organizationReducer.teamMembers
  );
  const userDetails = useSelector((state) => state.userReducer.user);
  const isLoading = useSelector((state) => state.organizationReducer.isLoading);
  const { values, setFieldValue } = useFormik({
    initialValues: {
      search: "",
      organizationTeams,
    },
    enableReinitialize: true,
  });
  useEffect(() => {
    dispatch(getTeamsOfAnOrganization(id));
  }, []);
  const modalTeamMemberToggle = () => setAddMemberToggle(!addMemberToggle);
  const modalTeamToggle = () => setCreateTeam(!createTeamToggle);
  const dropdownToggle = (item, index) => {
    setSelectIndex(index);
    setDropdownOpen((prevState) => !prevState);
  };

  const renderEditDeleteTeam = (item, index) => {
    const orgCreatedBy = item.user_id;
    if (userDetails && orgCreatedBy === userDetails.sub)
      return (
        <Dropdown
          className="dropdown_menu"
          isOpen={dropdownOpen && index === selectIndex}
          toggle={() => dropdownToggle(item, index)}
        >
          <DropdownToggle>
            <img src={Dots} alt="more" />
          </DropdownToggle>
          <DropdownMenu>
            <DropdownItem
              onClick={() =>
                history.push(
                  `/settings/organization/${id}/team/${item.id}/profile`
                )
              }
            >
              <span>
                <img src={Edit} alt="Edit" />
              </span>
              Edit
            </DropdownItem>
            <DropdownItem
              onClick={() => {
                dispatch(removeTeamFromOrganization(item.id));
                document.getElementById("searchField").value = "";
              }}
            >
              <span>
                <img src={Delete} alt="Delete" />
              </span>
              Delete
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      );
    return null;
  };

  const handleSearch = (e) => {
    const { value } = e.target;
    let found =
      organizationTeams !== undefined &&
      organizationTeams.filter((o) =>
        o.name.toLowerCase().includes(value.toLowerCase())
      );
    setFieldValue("organizationTeams", found);
  };
  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            {/* <h5 className="mb-0">Organization</h5> */}

            <h5 className="mb-0">Teams</h5>

            <Breadcrumb className="mb-0">
              <BreadcrumbItem>
                {/* <Link to="/settings/organization-settings">Home</Link> */}
                {/* Renaming organization to teams */}
                <Link to="/settings/teams-settings">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbItem>
                {/* <Link to={`/settings/organization/${id}`}>Organization</Link> */}
                <Link to={`/settings/teams/${id}`}>Teams</Link>
              </BreadcrumbItem>
              {/* <BreadcrumbItem active>Teams</BreadcrumbItem> */}
            </Breadcrumb>
          </div>
          <OrganizationSettingSidebar />
        </div>
        {/* Left end */}

        {/* Right */}
        {isLoading ? (
          <div className="org-loader">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : (
          <div className="inner-right bg-grey">
            {organizationTeams && organizationTeams.length ? (
              <div>
                <div className="row mx-0 setting-search bg-white py-3 border-left">
                  <div className="col-md-8">
                    <div className="position-relative search">
                      <input
                        ref={searchRef}
                        id="searchField"
                        type="search"
                        placeholder="Search"
                        className="form-control border-0"
                        onChange={handleSearch}
                      />
                      <img src={SearchIcon} alt="Search" />
                    </div>
                  </div>
                </div>

                <div className="row mx-0 pl-3 my-3">
                  <div className="col-md-6">
                    <h5 className="org-heading">Team</h5>
                  </div>

                  <div className="col-md-6 text-right">
                    {/* <button className="btn bg-white mr-3">
                      <img
                        src={Filter}
                        alt="filter"
                        width="16"
                        className="mr-2"
                      />
                      Filter
                    </button> */}
                    <button
                      className="btn btn-primary"
                      onClick={modalTeamToggle}
                    >
                      + Team
                    </button>
                  </div>
                </div>

                <div className="row mx-0 px-3 vh100-160">
                  {values.organizationTeams.map((item, index) => {
                    return (
                      <div
                        className="col-sm-12 col-lg-4 col-xl-4 mb-4"
                        key={index}
                      >
                        <div className="card border-0 org-card">
                          <div className="card-body">
                            <div className="row" id="mt-0">
                              <div className="col-sm-5">
                                <Link to={`team/${item.id}/profile`}>
                                  <div className="custom-badge mb-4 bg-primary text-white">
                                    {item.name.charAt(0).toUpperCase()}
                                    {/* {item.name} */}
                                  </div>
                                </Link>
                              </div>
                              <div className="col-sm-7 text-right">
                                {renderEditDeleteTeam(item, index)}
                              </div>
                            </div>

                            <h5
                              className="card-title f-14 font-weight-600 mb-3"
                              style={{ textTransform: "capitalize" }}
                            >
                              <Link to={`team/${item.id}/profile`}>
                                {item.name}
                              </Link>
                            </h5>
                            <h6 className="card-subtitle text-light f-12 mb-3 text-muted">
                              {moment(item.created_at).format("DD-MM-YYYY")}
                              {/* {item.date} */}
                            </h6>
                            <hr className="my-3" />

                            {item.user_id === userDetails.sub ? (
                              <ul className="color-circle mb-0">
                                <li
                                  className="bg-white cursor-pointer"
                                  onClick={() => {
                                    modalTeamMemberToggle();
                                    setTeamId(item.id);
                                    dispatch(getMembersOfTeam(item.id));
                                  }}
                                >
                                  <img
                                    src={Close}
                                    alt="Plus"
                                    className="rotate-45"
                                    width="10"
                                  />
                                </li>
                              </ul>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        {/* </Link> */}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="d-flex h-100">
                <div className="m-auto text-center">
                  <img src={Banner} className="m-auto" alt="Banner" />
                  <h4 className="my-5">You don’t have any Teams yet</h4>

                  <button
                    type="button"
                    className="btn btn-primary"
                    data-toggle="modal"
                    data-target="#teamModal"
                    onClick={modalTeamToggle}
                  >
                    + Team
                  </button>
                </div>
              </div>
            )}

            <CreateTeamModal
              modalTeamToggle={modalTeamToggle}
              createTeamToggle={createTeamToggle}
              organizationTeams={organizationTeams}
              searchRef={searchRef}
            />
            {addMemberToggle && (
              <AddMemberToTeam
                modalTeamMemberToggle={modalTeamMemberToggle}
                addMemberToggle={addMemberToggle}
                teamMembers={teamMembers}
                searchRef={searchRef}
                teamId={teamId}
              />
            )}
          </div>
        )}

        {/* Right End */}
      </div>
    </>
  );
};
export default OrganizationTeam;
