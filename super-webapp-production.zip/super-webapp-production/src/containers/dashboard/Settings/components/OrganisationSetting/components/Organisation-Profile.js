import React, { useEffect, useState } from "react";
import { useFormik } from "formik";

import {
  Breadcrumb,
  BreadcrumbItem,
  Form,
  FormGroup,
  Input,
  Label,
} from "reactstrap";
import { Link } from "react-router-dom";
import OrganizationSettingSidebar from "./OrganisationSettingSidebar";
import { $ } from "jquery";
import DeleteAccount from "../DeleteAccount";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  getOrganizationById,
  updateOrganization,
} from "../../../../../../redux/actions/organizationAction";
import FormikErrorMessage from "../../../../../../common/FormikErrorMessage";
import { validationSchemaOrganization } from "../../../../../../common/ValidationSchemas/OrganizationSchema";
import avatar from "../../../../../../images/avatar.png";
import Camera from "../../../../../../images/camera@3x.png";
import Axios from "axios";
import { getKeycloackToken } from "../../../../../../redux/actions/auth";
import Loader from "../../../../../../components/loader";

const OrganizationProfile = () => {
  const [deleteAccountModal, setDeleteAccountModal] = useState(false);
  const [fileContents, setFileContents] = useState({});
  const [chequeFileName, setChequeFileName] = useState("");

  const deleteAccountModalToggle = () =>
    setDeleteAccountModal(!deleteAccountModal);
  const params = useParams();
  const { id } = params;
  const dispatch = useDispatch();
  const organizationDetails = useSelector(
    (state) => state.organizationReducer.organizationDetails
  );
  const {
    values,
    errors,
    touched,
    isSubmitting,
    handleSubmit,
    handleChange,
    handleBlur,
    resetForm,
    setFieldValue,
  } = useFormik({
    initialValues: {
      id,
      name: organizationDetails?.name,
      email: organizationDetails?.email,
      location: organizationDetails?.location,
      url: organizationDetails?.url,
      billingEmail: organizationDetails?.billingEmail,
      description: organizationDetails?.description,
      profilePic: organizationDetails?.profilePic,
      displayName: organizationDetails?.displayName,
    },
    enableReinitialize: true,
    validationSchema: validationSchemaOrganization,
    onSubmit: async (values) => {
      dispatch(updateOrganization(values));
    },
  });

  const userDetails = useSelector((state) => state.userReducer.user);
  const isLoading = useSelector((state) => state.organizationReducer.isLoading);

  useEffect(() => {
    dispatch(getOrganizationById(id));
  }, []);
  const orgCreatedBy = organizationDetails && organizationDetails.user_id;
  const isOwner = userDetails && orgCreatedBy === userDetails.sub;

  const handleFileChange = async (e) => {
    try {
      let token = await getKeycloackToken();
      var data = new FormData();
      data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: data,
      };

      const res = await Axios(config);
      const imgId = res.data.data.image_id;
      let url = `${process.env.REACT_APP_BOT_SERVICE_URL}/image/${imgId}`;
      setFieldValue("profilePic", url);
    } catch (err) {
      console.log(err.toString());
    }
  };

  // Rename organization Profile to Team profile
  const renderOrganizationDetails = () => {
    if (organizationDetails)
      return (
        <div className="col-lg-9">
          <div className="card org-profile-card border-0">
            <div className="row pt-2 org-profile-content" id="mt-0">
              <div className="col-sm-12 col-lg-6 offset-xl-3">
                <Form onSubmit={handleSubmit} noValidate>
                  <div>
                    {/* <FormGroup>
                      <Label>Company Name</Label>
                      <Input
                        type="name"
                        name="name"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.name}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="name"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label> Company Email</Label>
                      <Input
                        type="email"
                        name="email"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.email}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="email"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label>Location</Label>
                      <Input
                        type="location"
                        name="location"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.location}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="location"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label>Website</Label>
                      <Input
                        type="text"
                        name="url"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.url}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="url"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label>Billing Email</Label>
                      <Input
                        type="email"
                        name="billingEmail"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.billingEmail}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="billingEmail"
                      />
                    </FormGroup>
                    <FormGroup>
                      <label>Description</label>
                      <Input
                        name="description"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.description}
                        rows="3"
                        type="textarea"
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="description"
                      />
                    </FormGroup> */}

                    <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">Team Name</span>
                        <Input
                          type="name"
                          name="name"
                          placeholder="Enter Team Name"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={
                            values?.displayName
                              ? values.displayName
                              : values?.name
                          }
                          // disabled={!isOwner}
                          disabled={true}
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="name"
                        />
                      </div>
                      {/* <Label>Team Name</Label>
                      <Input
                        type="name"
                        name="name"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.name}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="name"
                      /> */}
                    </FormGroup>
                    {/* <FormGroup>
                      <Label> Team Email</Label>
                      <Input
                        type="email"
                        name="email"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.email}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="email"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label>Location</Label>
                      <Input
                        type="location"
                        name="location"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.location}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="location"
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label>Website</Label>
                      <Input
                        type="text"
                        name="url"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.url}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="url"
                      />
                    </FormGroup> */}
                    {/* <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">Billing Email</span>
                        <Input
                          type="email"
                          name="billingEmail"
                          placeholder="Enter email"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.billingEmail}
                          disabled={!isOwner}
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="billingEmail"
                        />
                      </div> */}
                      {/* <Label>Billing Email</Label>
                      <Input
                        type="email"
                        name="billingEmail"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.billingEmail}
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="billingEmail"
                      /> */}
                    {/* </FormGroup> */}
                    <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">Description</span>
                        <Input
                          name="description"
                          placeholder="Enter description"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.description}
                          rows="3"
                          type="textarea"
                          disabled={!isOwner}
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="description"
                        />
                      </div>
                      {/* <label>Description</label>
                      <Input
                        name="description"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.description}
                        rows="3"
                        type="textarea"
                        disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="description"
                      /> */}
                    </FormGroup>
                  </div>
                  {renderUpdateButton()}
                </Form>
              </div>
            </div>
          </div>
        </div>
      );
    return null;
  };

  const renderDeleteButton = () => {
    if (isOwner)
      return (
        <div className="delete-profile-setting">
          <button
            className="btn btn-outline-danger mt-auto"
            onClick={deleteAccountModalToggle}
          >
            Delete Account
          </button>
        </div>
      );
    return null;
  };

  const renderUpdateButton = () => {
    if (isOwner)
      return (
        <div className="text-right">
          <button className="btn  btn-primary" type="submit">
            Update
          </button>
        </div>
      );
    return null;
  };
  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            {/* <h5 className="mb-0">Organization</h5> */}
            <h5 className="mb-0">Teams</h5>

            <Breadcrumb className="mb-0">
              {/* <BreadcrumbItem>
                <Link to="/settings/organization-settings">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbItem active>Organization</BreadcrumbItem> */}
              <BreadcrumbItem>
                {/* Renaming Organization to  Teams */}
                <Link to="/settings/teams-settings">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbItem active>Teams</BreadcrumbItem>
            </Breadcrumb>
          </div>
          <OrganizationSettingSidebar />
        </div>
        {/* Left end */}

        {/* Right */}
        {isLoading ? (
          <div className="org-loader">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : (
          <div className="inner-right bg-grey">
            <div className="scrollable logout-setting">
              <div className="col-md-12 log-inner">
                <div className="title-btn">
                  {/* <h5 className="org-heading">Organization Profile</h5> */}
                  <h1 className="title">
                    {organizationDetails?.displayName
                      ? organizationDetails?.displayName
                      : organizationDetails?.name}
                    Profile
                  </h1>
                </div>

                <div className="row d-flex">
                  {renderOrganizationDetails()}
                  <div className="col-lg-3">
                    <div className="card org-profile-card border-0 text-center">
                      <div className="upld-avatar m-auto">
                        <img
                          src={values.profilePic ? values.profilePic : avatar}
                          alt="Avatar"
                        />
                        <div
                          onClick={() =>
                            isOwner &&
                            document.getElementById("profile").click()
                          }
                          className="upld-hover"
                        >
                          {isOwner && <img src={Camera} alt="camera" />}
                          <input
                            type="file"
                            accept="image/*"
                            id="profile"
                            style={{ display: "none" }}
                            onChange={(e) => handleFileChange(e)}
                          />
                        </div>
                      </div>
                      <div className="my-3">
                        <p className="font-weight-600 mb-0">Profile Photo</p>
                        <span className="text-muted f-12">20kb max</span>
                      </div>
                      {renderDeleteButton()}
                    </div>
                  </div>
                </div>
              </div>
              <DeleteAccount
                deleteAccountModalToggle={deleteAccountModalToggle}
                deleteAccountModal={deleteAccountModal}
              />
            </div>
          </div>
        )}

        {/* Right End */}
      </div>
    </>
  );
};

export default OrganizationProfile;
