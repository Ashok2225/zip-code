import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useFormik } from "formik";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Input,
  Label,
} from "reactstrap";
import Axios from "axios";
import { createOrganization } from "../../../../../../redux/actions/organizationAction";
import FormikErrorMessage from "../../../../../../common/FormikErrorMessage";
import { validationSchemaOrganization } from "../../../../../../common/ValidationSchemas/OrganizationSchema";
import Close from "../../../../../../images/close.png";
import Camera from "../../../../../../images/camera@3x.png";
import avatar from "../../../../../../images/avatar.png";
import { getKeycloackToken } from "../../../../../../redux/actions/auth";

const CreateOrganization = (props) => {
  const {
    modalToggle,
    createOrganizationToggle,
    className,
    organizationList,
    searchRef,
  } = props;
  const dispatch = useDispatch();
  const [isNameAvailable, setNameAvailability] = useState("");
  const [isEmailAvailable, setEmailAvailability] = useState("");

  const {
    values,
    errors,
    touched,
    isSubmitting,
    handleSubmit,
    handleChange,
    handleBlur,
    resetForm,
    setFieldValue,
  } = useFormik({
    initialValues: {
      name: "",
      // email: "",
      // location: "",
      // url: "",
      billingEmail: "",
      description: "",
      profilePic: "",
    },
    validationSchema: validationSchemaOrganization,
    onSubmit: async (values, { resetForm }) => {
      console.log(values, "val");
      modalToggle();
      await dispatch(createOrganization(values));
      resetForm();
      searchRef.current.value = "";
    },
  });

  const checkNameAvailability = (e) => {
    const { value } = e.target;
    setFieldValue("name", value);
    var found =
      organizationList !== undefined &&
      organizationList.filter(function (o) {
        return o.name === value;
        // return o.name === values.name;
      });
    found.length > 0 ? setNameAvailability(false) : setNameAvailability(true);
  };
  const checkEmailAvailability = (e) => {
    const { value } = e.target;
    setFieldValue("email", value);
    var found =
      organizationList !== undefined &&
      organizationList.filter(function (o) {
        return o.email === value;
        // return o.name === values.name;
      });
    found.length > 0 ? setEmailAvailability(false) : setEmailAvailability(true);
  };

  const handleFileChange = async (e) => {
    try {
      let token = await getKeycloackToken();
      var data = new FormData();
      data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: data,
      };

      const res = await Axios(config);
      const imgId = res.data.data.image_id;
      let url = `${process.env.REACT_APP_BOT_SERVICE_URL}/image/${imgId}`;
      setFieldValue("profilePic", url);
    } catch (err) {
      console.log(err.toString());
    }
  };

  const onDone=()=>{

    handleSubmit()
  }
  return (
    <div className="crt-skill">
      <Modal
        isOpen={createOrganizationToggle}
        modalToggle={modalToggle}
        className="org-setting"
      >
        {/* <ModalHeader modalToggle={modalToggle}>
          Create a Organizations
        </ModalHeader> */}
        <ModalHeader className="team-model-header">
          <div className="d-flex justify-content-between">
            {/* Rename create organization to create team  */}
            {/* <div> Create an Organization</div> */}

            <div>Team Name</div>

            <button className="close teams-close">
              <img
                src={Close}
                alt="close Btn"
                className=""
                onClick={modalToggle}
              />
            </button>
          </div>
        </ModalHeader>
        <Form onSubmit={handleSubmit} noValidate>
          <ModalBody>
          <div className="modal-avatar">
              <div className="pr-info">
                <div className="d-flex">
                  <div className="upld-avatar mx-auto">
                    <img
                      src={values.profilePic ? values.profilePic : avatar}
                      alt="Avatar"
                    />
                    <div
                      onClick={() => document.getElementById("profile").click()}
                      className="upld-hover"
                    >
                      <img src={Camera} alt="camera" />
                      <input
                        type="file"
                        accept="image/*"
                        id="profile"
                        style={{ display: "none" }}
                        onChange={(e) => handleFileChange(e, props)}
                      />
                    </div>
                  </div>
                  <div className="pr-text pt-3 pl-1">
                    <p>Profile Photo</p>
                    <span>20kb max</span>
                  </div>
                </div>
              </div>
            </div>            
            <div className="form-contain">
              {/* <FormGroup>
                <Label>Company Name</Label>
                <Input
                  type="name"
                  name="name"
                  onChange={(e) => checkNameAvailability(e)}
                  // onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.name}
                />
                <div className="d-flex justify-content-between align-items-center">
                  <span className={isNameAvailable ? "exist" : "not-exist"}>
                    {values.name.length > 0
                      ? isNameAvailable
                        ? "Name Available"
                        : "Name already Exists"
                      : ""}
                  </span>
                </div>
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="name"
                />
              </FormGroup>
              <FormGroup>
                <Label> Company Email</Label>
                <Input
                  type="email"
                  name="email"
                  onChange={(e) => checkEmailAvailability(e)}
                  // onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.email}
                />
                <div className="d-flex justify-content-between align-items-center">
                  <span className={isEmailAvailable ? "exist" : "not-exist"}>
                    {values.email.length > 0
                      ? isEmailAvailable
                        ? "Email Available"
                        : "Email already Exists"
                      : ""}
                  </span>
                </div>
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="email"
                />
              </FormGroup>
              <FormGroup>
                <Label>Location</Label>
                <Input
                  type="location"
                  name="location"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.location}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="location"
                />
              </FormGroup>
              <FormGroup>
                <Label>Website</Label>
                <Input
                  type="text"
                  name="url"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.url}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="url"
                />
              </FormGroup>
              <FormGroup>
                <Label>Billing Email</Label>
                <Input
                  type="email"
                  name="billingEmail"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.billingEmail}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="billingEmail"
                />
              </FormGroup>
              <FormGroup>
                <label>Description</label>
                <Input
                  name="description"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.description}
                  rows="3"
                  type="textarea"
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="description"
                />
              </FormGroup> */}

              {/* RENAME ORGANIZATION MODAL LABELs And Fields TO TEAMS  */}

              <FormGroup>
                {/* <Label>Team Name</Label>
                <Input
                  type="name"
                  name="name"
                  onChange={(e) => checkNameAvailability(e)}
                  // onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.name}
                />
                <div className="d-flex justify-content-between align-items-center">
                  <span className={isNameAvailable ? "exist" : "not-exist"}>
                    {values.name.length > 0
                      ? isNameAvailable
                        ? "Name Available"
                        : "Name already Exists"
                      : ""}
                  </span>
                </div>
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="name"
                /> */}

                  <div className="ip-tl-label">
                      <span className="tl-label">Create Team</span>
                      <Input
                        type="name"
                        name="name"
                        placeholder="Enter team name"
                        onChange={(e) => checkNameAvailability(e)}
                        // onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.name}
                      />
                      <div className="error-block">
                        <span className={isNameAvailable ? "exist" : "not-exist"}>
                          {values.name.length > 0
                            ? isNameAvailable
                              ? "Name Available"
                              : "Name already Exists"
                            : ""}
                        </span>
                      </div>
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="name"
                      />
                    </div>

              </FormGroup>
              {/* <FormGroup>
                <Label> Team Email</Label>
                <Input
                  type="email"
                  name="email"
                  onChange={(e) => checkEmailAvailability(e)}
                  // onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.email}
                />
                <div className="d-flex justify-content-between align-items-center">
                  <span className={isEmailAvailable ? "exist" : "not-exist"}>
                    {values.email.length > 0
                      ? isEmailAvailable
                        ? "Email Available"
                        : "Email already Exists"
                      : ""}
                  </span>
                </div>
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="email"
                />
              </FormGroup>
              <FormGroup>
                <Label>Location</Label>
                <Input
                  type="location"
                  name="location"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.location}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="location"
                />
              </FormGroup>
              <FormGroup>
                <Label>Website</Label>
                <Input
                  type="text"
                  name="url"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.url}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="url"
                />
              </FormGroup> */}
              <FormGroup>
                {/* <Label>Billing Email</Label>
                <Input
                  type="email"
                  name="billingEmail"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.billingEmail}
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="billingEmail"
                /> */}
                   <div className="ip-tl-label">
                    <span className="tl-label">Billing Email</span>
                    <Input
                      type="email"
                      name="billingEmail"
                      placeholder="Enter email"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.billingEmail}
                    />
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="billingEmail"
                    />
                  </div> 
              </FormGroup>
              <FormGroup>
                {/* <label>Description</label>
                <Input
                  name="description"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.description}
                  rows="3"
                  type="textarea"
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="description"
                /> */}
                  <div className="ip-tl-label">
                      <span className="tl-label">Description</span>
                      <Input
                  name="description"
                  placeholder="Enter description"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  value={values.description}
                  rows="3"
                  type="textarea"
                />
                <FormikErrorMessage
                  errors={errors}
                  touched={touched}
                  field="description"
                />
                    </div>
              </FormGroup>
            </div>
          </ModalBody>
          <ModalFooter className="frm-btns">
              <button
                type="button"
                className="btn-outline"
                onClick={modalToggle}
              >
                Cancel
              </button>
              <button
                className="btn-primary"
                type="submit"
                onClick={onDone}
                // disabled={isSubmitting || !isNameAvailable || !isEmailAvailable}
              >
                Done
              </button>
          </ModalFooter>
        </Form>
      </Modal>
    </div>
  );
};

export default CreateOrganization;
