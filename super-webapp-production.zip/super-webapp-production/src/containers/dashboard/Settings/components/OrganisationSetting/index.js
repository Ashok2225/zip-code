import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import Edit from "../../../../../images/edit.png";
import Delete from "../../../../../images/delete.png";
import Filter from "../../../../../images/filter.png";
import SearchIcon from "../../../../../images/search.png";
import Close from "../../../../../images/close.png";
import Dots from "../../../../../images/dot.png";
import Banner from "../../../../../images/empty.png";
import CreateOrganization from "./components/CreateOrganisation";
import SettingSidebar from "../SettingSidebar/SettingSidebar";
import {
  deleteOrganization,
  getOrganizations,
  getUsersOfAnOrganization,
} from "../../../../../redux/actions/organizationAction";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import moment from "moment";
import { useFormik } from "formik";
import AddMemberToOrgModal from "../AddMemberToOrgModal.js";
import Loader from "../../../../../components/loader";
import getColors from "../../../../../components/colors";

const OrganizationSetting = () => {
  const [createOrganizationToggle, setCreateOrganization] = useState(false);
  const [orgId, setOrgId] = useState();
  const [profilePic, setProfilePic] = useState("");
  const [createTeamToggle, setCreateTeam] = useState(false);

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectIndex, setSelectIndex] = useState(null);

  const searchRef = useRef();
  const history = useHistory();
  const modalToggle = () => setCreateOrganization(!createOrganizationToggle);

  const dropdownToggle = (item, index) => {
    setSelectIndex(index);
    setDropdownOpen((prevState) => !prevState);
  };

  const dispatch = useDispatch();
  const organizationList = useSelector(
    (state) => state.organizationReducer.organizationList
  );
  const organizationPeople = useSelector(
    (state) => state.organizationReducer.organizationPeople
  );
  const userDetails = useSelector((state) => state.userReducer.user);

  const isLoading = useSelector((state) => state.organizationReducer.isLoading);

  const { values, setFieldValue } = useFormik({
    initialValues: {
      search: "",
      organizationList,
    },
    enableReinitialize: true,
  });
  useEffect(() => {
    dispatch(getOrganizations());
  }, []);

  const modalTeamMemberToggle = () => setCreateTeam(!createTeamToggle);

  const renderEditDeleteOrganization = (item, index) => {
    const orgCreatedBy = item.user_id;
    if (userDetails && orgCreatedBy === userDetails.sub)
      return (
        <Dropdown
          className="dropdown_menu "
          isOpen={dropdownOpen && index === selectIndex}
          toggle={() => dropdownToggle(item, index)}
        >
          <DropdownToggle>
            <img src={Dots} alt="more" />
          </DropdownToggle>
          <DropdownMenu right>
            <DropdownItem
              // Rename organization route to teams
              // onClick={() => history.push(`/settings/organization/${item.id}`)}
              onClick={() => history.push(`/settings/teams/${item.id}`)}
            >
              <span>
                <img src={Edit} alt="Edit" />
              </span>
              Edit
            </DropdownItem>
            <DropdownItem
              onClick={() => {
                dispatch(deleteOrganization(item.id));
                document.getElementById("searchField").value = "";
              }}
            >
              <span>
                <img src={Delete} alt="Delete" />
              </span>
              Delete
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      );
    return null;
  };

  const handleSearch = (e) => {
    const { value } = e.target;
    let found =
      organizationList !== undefined &&
      organizationList.filter((o) =>
        o.name.toLowerCase().includes(value.toLowerCase())
      );
    setFieldValue("organizationList", found);
  };
  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            <h5 className="mb-0">Setting</h5>
            {/* <Breadcrumb className="mb-0">
              <BreadcrumbItem> */}
            {/* <Link to="/settings/organization-settings">Home</Link> */}
            {/* Renaming Organization to  Teams */}
            {/* <Link to="/settings/teams-settings">Home</Link>
              </BreadcrumbItem> */}
            {/* <BreadcrumbItem active>Organizations</BreadcrumbItem> */}
            {/* <BreadcrumbItem active>Teams</BreadcrumbItem>
            </Breadcrumb> */}
          </div>
          <SettingSidebar />
        </div>
        {/* Left end */}

        {/* Right */}
        {isLoading ? (
          <div className="org-loader">
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </div>
        ) : (
          <div className="inner-right bg-grey">
            {organizationList && organizationList.length > 0 ? (
              <div className="h-100">
                <div className="row mx-0 setting-search bg-white py-3 border-left">
                  <div className="col-md-8">
                    <div className="position-relative search">
                      <input
                        ref={searchRef}
                        id="searchField"
                        type="search"
                        placeholder="Search"
                        className="form-control border-0"
                        onChange={handleSearch}
                      />
                      <img src={SearchIcon} alt="Search" />
                    </div>
                  </div>
                </div>

                <div className="flex-title mx-0 pl-3 my-3">
                  <h5 className="mt-1 org-heading">Teams Setting</h5>
                  <div className="btn-flex">
                    {/* <button className="btn btn-filter bg-white mr-3">
                      <img
                        src={Filter}
                        alt="filter"
                        width="16"
                        className="mr-2"
                      />
                      Filter
                    </button> */}
                    {/* <button className="btn btn-primary" onClick={modalToggle}>
                        + Organization
                      </button> */}
                    {/* Rename create Organization label to teams */}
                    {/* <button className="btn btn-primary" onClick={modalToggle}>
                        + Teams
                      </button> */}
                    <button
                      data-target="#teamModal"
                      data-toggle="modal"
                      className="btn btn-primary"
                    >
                      + Teams
                    </button>
                  </div>
                </div>

                <div className="row team-setting scrollable">
                  {values.organizationList.map((item, index) => {
                    if (item.disabled) {
                      return (
                        <div className="col-sm-4 col-xl-4 mb-4" key={index}>
                          <div className="card border-0 org-card">
                            <div className="card-body">
                              <div className="row" id="mt-0">
                                <div className="col-sm-5">
                                  {/* <Link to={`/settings/organization/${item.id}`}> */}
                                  {/* Rename Organization to teams */}
                                  <Link
                                    to={`/settings/teams/${item.id}/people`}
                                  >
                                    <div
                                      className="ss-ico ss-text"
                                      style={{
                                        backgroundColor: getColors(
                                          item?.displayName
                                            ? item.displayName
                                            : item.name
                                        ),
                                      }}
                                    >
                                      {item.displayName
                                        ? item.displayName
                                            .charAt(0)
                                            .toUpperCase()
                                        : item.name.charAt(0).toUpperCase()}
                                    </div>
                                  </Link>
                                </div>
                                <div className="col-sm-7 text-right">
                                  {renderEditDeleteOrganization(item, index)}
                                </div>
                              </div>

                              <h5
                                className="card-title f-14 font-weight-600 mb-3"
                                style={{ textTransform: "capitalize" }}
                              >
                                {/* <Link to={`/settings/organization/${item.id}`}> */}
                                <Link to={`/settings/teams/${item.id}/people`}>
                                  {item?.displayName
                                    ? item?.displayName
                                    : item?.name}
                                </Link>
                              </h5>
                              <h6 className="card-subtitle text-light f-12 mb-3 text-muted">
                                {moment(item.created_at).format("DD-MM-YYYY")}
                              </h6>
                              <hr className="my-3" />
                              <ul className="color-circle mb-0">
                                {/* <li className="bg-primary">MA</li>
                                  <li className="bg-success">AI</li>
                                  <li className="bg-danger">SC</li>
                                  <li className="bg-info">SC</li> */}
                                <li
                                  className="bg-white cursor-pointer"
                                  onClick={() => {
                                    modalTeamMemberToggle();
                                    setProfilePic(item.profilePic);
                                    setOrgId(item.id);
                                    dispatch(getUsersOfAnOrganization(item.id));
                                  }}
                                >
                                  <img
                                    src={Close}
                                    alt="Plus"
                                    className="rotate-45"
                                    width="10"
                                  />
                                </li>
                              </ul>
                            </div>
                          </div>
                          {/* </Link> */}
                        </div>
                      );
                    }
                  })}
                </div>
              </div>
            ) : (
              //               <div className="d-flex h-100">
              //                 <div className="m-auto text-center">
              //                   <img src={Banner} className="m-auto" alt="Banner" />
              //                   <h4 className="my-5">You don’t have any organizations yet</h4>
              //
              //                   <button
              //                     type="button"
              //                     className="btn btn-primary"
              //                     data-toggle="modal"
              //                     data-target="#CreateOrganization"
              //                     onClick={modalToggle}
              //                   >
              //                     + Organization
              //                   </button>
              //                 </div>
              //               </div>
              <div className="d-flex h-100">
                <div className="m-auto text-center">
                  <img src={Banner} className="m-auto" alt="Banner" />
                  <h4 className="my-5">You don’t have any teams yet</h4>

                  <button
                    type="button"
                    className="btn btn-primary"
                    data-toggle="modal"
                    data-target="#teamModal"
                    onClick={createTeamToggle}
                  >
                    + Teams
                  </button>
                </div>
              </div>
            )}

            <CreateOrganization
              modalToggle={modalToggle}
              organizationList={organizationList}
              createOrganizationToggle={createOrganizationToggle}
              searchRef={searchRef}
            />
            <AddMemberToOrgModal
              modalTeamMemberToggle={modalTeamMemberToggle}
              createTeamToggle={createTeamToggle}
              profilePic={profilePic}
              organizationPeople={organizationPeople}
              orgId={orgId}
            />
          </div>
        )}

        {/* Right End */}
      </div>
    </>
  );
};

export default OrganizationSetting;
