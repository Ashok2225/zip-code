import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import { useHistory } from "react-router-dom";
import Dots from "../../../../../../images/dot.png";

import Edit from "../../../../../../images/edit.png";
import Delete from "../../../../../../images/delete.png";
import Filter from "../../../../../../images/filter.png";
import SearchIcon from "../../../../../../images/search.png";
import Banner from "../../../../../../images/empty.png";
import OrganizationSettingSidebar from "../components/OrganisationSettingSidebar";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import editTitleIcon from "../../../../../../images/edit-title.png";

import {
  getOrganizationById,
  getUsersOfAnOrganization,
  removeMemberFromAnOrganization,
  toggleUserOfOrg,
  updateOrganization,
  setCurrentOrganization,
  getOrganizations,
  removeInviteMemberFromAnOrganization,
} from "../../../../../../redux/actions/organizationAction";
import Switch from "react-switch";
import AddMemberToOrgModal from "../../AddMemberToOrgModal.js";
import { useFormik } from "formik";
import Loader from "../../../../../../components/loader";
import getColors from "../../../../../../components/colors";
import { changeActiveTab } from "../../../../../../redux/actions/skill";
import { setCurrentUser } from "../../../../../../redux/actions/user";

const OrganizationPeople = () => {
  const [createTeamToggle, setCreateTeam] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectIndex, setSelectIndex] = useState(null);
  const [editUserInfo, setEditUserInfo] = useState("");
  const [editDisplayName, setDisplayName] = useState("");
  const [isEditingDname, setIsEditingDname] = useState(false);
  const searchRef = useRef();

  const modalTeamMemberToggle = () => setCreateTeam(!createTeamToggle);
  const dropdownToggle = (item, index) => {
    setSelectIndex(index);
    setDropdownOpen((prevState) => !prevState);
  };

  const params = useParams();
  const { id } = params;
  const dispatch = useDispatch();
  const history = useHistory();
  const organizationPeople = useSelector(
    (state) => state.organizationReducer.organizationPeople
  );
  const organizationDetails = useSelector(
    (state) => state.organizationReducer.organizationDetails
  );

  const userDetails = useSelector((state) => state.userReducer.user);
  const isLoading = useSelector((state) => state.organizationReducer.isLoading);

  const isAdmin =
    organizationPeople &&
    organizationPeople.some(
      (e) => e.email === userDetails.email && e.role_id == "2"
    );

  const { values, setFieldValue } = useFormik({
    initialValues: {
      search: "",
      organizationPeople,
    },
    enableReinitialize: true,
  });

  useEffect(() => {
    dispatch(getUsersOfAnOrganization(id));
    dispatch(getOrganizationById(id));
  }, []);
  const orgCreatedBy = organizationDetails && organizationDetails.user_id;
  const isOwner = userDetails && orgCreatedBy === userDetails.sub;

  const setUserToEditInfo = (data) => {
    const { id, name, email, role_id } = data;
    const userData = {
      id,
      name,
      email,
      role_id,
    };
    setEditUserInfo(userData);
  };
  const handleChange = (item) => {
    dispatch(toggleUserOfOrg(item));
  };
  const renderEditDeleteButton = (item, index) => {
    if (isOwner || isAdmin)
      return (
        <Dropdown
          className="dropdown_menu"
          isOpen={dropdownOpen && index === selectIndex}
          toggle={() => dropdownToggle(item, index)}
        >
          {isAdmin && !item.hash ? (
            <DropdownToggle>
              <img src={Dots} alt="more" />
            </DropdownToggle>
          ) : null}
          <DropdownMenu right>
            {isAdmin && (
              <DropdownItem
                onClick={() => {
                  modalTeamMemberToggle();
                  setUserToEditInfo(item);
                }}
              >
                <span>
                  <img src={Edit} alt="Edit" />
                </span>
                Edit
              </DropdownItem>
            )}
            <DropdownItem
              onClick={() => {
                if (item.user_id) {
                  dispatch(removeMemberFromAnOrganization(item.id));
                } else {
                  dispatch(removeInviteMemberFromAnOrganization(item.id));
                }
                document.getElementById("searchField").value = "";
              }}
            >
              <span>
                <img src={Delete} alt="Delete" />
              </span>
              Delete
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      );
    return null;
  };

  const renderAddMemberButton = () => {
    if (isOwner || isAdmin)
      return (
        <button
          className="btn btn-primary"
          data-toggle="modal"
          data-target="#inviteModal"
        >
          + Invite Member
        </button>
      );
    return null;
  };

  const renderAddMemberButtonForNoData = () => {
    if (isOwner || isAdmin)
      return (
        <button
          type="button"
          className="btn btn-primary"
          data-toggle="modal"
          data-target="#inviteModal"
        >
          + Invite Member
        </button>
      );
    return null;
  };

  const handleSearch = (e) => {
    const { value } = e.target;
    let found =
      organizationPeople !== undefined &&
      organizationPeople.filter((o) =>
        o.name.toLowerCase().includes(value.toLowerCase())
      );
    setFieldValue("organizationPeople", found);
  };

  const changeDisplayName = async (e) => {
    var org = JSON.parse(localStorage.getItem("orgDetails"));
    org.displayName = e.target.value;
    await dispatch(updateOrganization(org));
    await localStorage.setItem("orgDetails", JSON.stringify(org));
    dispatch(setCurrentOrganization(org));
    var results = await dispatch(getOrganizations());
    history.push("/dashboard/create");
    dispatch(changeActiveTab("Create"));
  };

  const renderMembersCard = (members) => {
    // members = members.sort(function (a, b) {
    //   return new Date(b.created_at) - new Date(a.created_at);
    // })
    return members.map((item, index) => {
      return (
        <div className="col-sm-12 col-lg-4 col-xl-4 mb-4" key={index}>
          <div className="card border-0">
            <div className="card-body pb-1">
              <div className="row" id="mt-0">
                <div className="col-sm-5">
                  {/* <Link to="/settings/profile-team"> */}
                  {/* <div className="custom-badge mb-4 bg-primary text-white"> */}
                  <div
                    className="ss-ico ss-text"
                    style={{
                      backgroundColor: getColors(item?.name),
                    }}
                  >
                    {item?.name?.charAt(0)?.toUpperCase()}
                  </div>
                  {/* </Link> */}
                </div>
                <div className="col-sm-7 text-right">
                  {renderEditDeleteButton(
                    item,
                    item.user_id ? item.id : item.hash
                  )}
                </div>
              </div>

              <h5 className="card-title f-14 font-weight-600 mb-3">
                {/* <Link to="/settings/profile-team"> */}
                {item.displayName ? item.displayName : ""}
                {/* </Link> */}
              </h5>
              <h6 className="card-subtitle text-light f-12 mb-3 text-muted">
                {item?.email}
              </h6>
              <hr className="my-3" />
              <div className="d-flex justify-content-between">
                <div>
                  {item.role_id ?(
                  <span className="member-chip">
                    {item.role_id === "2" ? "Admin" : item.role_id=== "1"? "View Only":item.role_id=== "3"? "View & Edit": null}
                  </span>) : null}
                </div>
                  <span>
                    {item.hash? (
                      <label>Invitation Sent</label>
                    ):null}
                  </span>
                  {!item.hash?(
                <div>
                  <Switch
                    checked={!item.disabled}
                    onChange={() => handleChange(item)}
                    onColor="#86d3ff"
                    onHandleColor="#02ce9d"
                    handleDiameter={30}
                    uncheckedIcon={false}
                    checkedIcon={false}
                    boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
                    activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
                    height={20}
                    width={48}
                    className="react-switch"
                    id="material-switch"
                    disabled={isAdmin ? false : true}
                  />
                </div>) : null}
              </div>
            </div>
          </div>
          {/* </Link> */}
        </div>
      );
    });
  };

  return (
    <div className="d-flex">
      {/* Left */}
      <div className="inner-left-sidebar">
        <div className="px-4 pt-4">
          {/* <h5 className="mb-0">Organization</h5> */}
          <h5 className="mb-0">Teams</h5>

          {/* <Breadcrumb className="mb-0">
            <BreadcrumbItem> */}
          {/* <Link to="/settings/organization-settings">Home</Link> */}

          {/* <Link to="/settings/teams-settings">Home</Link>
            </BreadcrumbItem> */}
          {/* <BreadcrumbItem>
              <Link to={`/settings/organization/${id}`}>Organization</Link>

              Renaming Organization profile to teams profile settings

              <Link to={`/settings/teams/${id}`}>Teams</Link>
            </BreadcrumbItem> */}
          {/* <BreadcrumbItem active>People</BreadcrumbItem>
          </Breadcrumb> */}
        </div>
        <OrganizationSettingSidebar />
      </div>
      {/* Left end */}

      {/* Right */}
      {isLoading ? (
        <div className="org-loader">
          <Loader
            styles={{ width: "80px", margin: "auto" }}
            root={{ display: "flex" }}
          />
        </div>
      ) : (
        <div className="inner-right bg-grey">
          {organizationPeople && organizationPeople.length ? (
            <div className="h-100">
              <div className="row mx-0 setting-search bg-white py-3 border-left">
                <div className="col-md-8">
                  <div className="position-relative search">
                    <input
                      ref={searchRef}
                      id="searchField"
                      type="search"
                      placeholder="Search"
                      className="form-control border-0"
                      onChange={handleSearch}
                    />
                    <img src={SearchIcon} alt="Search" />
                  </div>
                </div>
              </div>

              <div className="flex-title mx-0 pl-3 my-3">
                {/* <h1 className="title">People</h1> */}
                <div className="title-input-flex">
                  <h1
                    className="title"
                    style={{
                      cursor: "pointer",
                      textTransform: "capitalize",
                    }}
                  >
                    {isEditingDname == true ? (
                      <>
                        {isAdmin ? (
                          <input
                            type="text"
                            autoFocus
                            defaultValue={
                              organizationDetails.displayName
                                ? organizationDetails.displayName
                                : organizationDetails.name
                            }
                            onBlur={(e) => changeDisplayName(e)}
                          />
                        ) : null}
                      </>
                    ) : (
                      <>
                        {organizationDetails.displayName
                          ? organizationDetails.displayName
                          : organizationDetails.name}
                      </>
                    )}
                  </h1>

                  {isAdmin ? (
                    <span
                      className="edit-title"
                      onClick={(e) =>
                        setIsEditingDname(isEditingDname == true ? false : true)
                      }
                    >
                      <img src={editTitleIcon} />
                    </span>
                  ) : null}
                </div>
                <div className="col-md-6 text-right">
                  {/* <button className="btn btn-default btn-filter bg-white mr-3">
          <img
            src={Filter}
            alt="filter"
            width="16"
            className="mr-2"
          />
          Filter
        </button> */}
                  {renderAddMemberButton()}
                </div>
              </div>
              <div className="row team-setting scrollable">
                <div className="row m-1">
                  {renderMembersCard(
                    values.organizationPeople.filter((item) => item.user_id)
                  )}
                </div>
                <div className="row m-1">
                  {renderMembersCard(
                    values.organizationPeople.filter((item) => !item.user_id)
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="d-flex h-100">
              <div className="m-auto text-center">
                <img src={Banner} className="m-auto" alt="Banner" />
                <h4 className="my-5">You don’t have any users yet</h4>

                {renderAddMemberButtonForNoData()}
              </div>
            </div>
          )}
          {createTeamToggle && (
            <AddMemberToOrgModal
              modalTeamMemberToggle={modalTeamMemberToggle}
              createTeamToggle={createTeamToggle}
              profilePic={organizationDetails?.profilePic}
              organizationPeople={organizationPeople}
              searchRef={searchRef}
              editUserInfo={editUserInfo}
            />
          )}
        </div>
      )}

      {/* Right End */}
      {/* </div> */}
    </div>
  );
};
export default OrganizationPeople;
