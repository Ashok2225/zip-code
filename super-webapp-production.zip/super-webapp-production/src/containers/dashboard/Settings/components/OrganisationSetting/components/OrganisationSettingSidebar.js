import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Nav, NavItem } from "reactstrap";
import Building from "../../../../../../images/building.png";
import Team from "../../../../../../images/exp/group.png";
import People from "../../../../../../images/user.png";
import Dashboard from "../../../../../../images/dashboard.png";
import home from "../../../../../../images/home.png";
import { useParams, useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../../../../../redux/actions/user";
import { changeActiveTab } from "../../../../../../redux/actions/skill";

const OrganizationSettingSidebar = () => {
  const history = useHistory();
  const params = useParams();
  const { id } = params;
  const location = useLocation();
  const dispatch = useDispatch();
  const organizationDetails = useSelector(
    (state) => state.organizationReducer.organizationDetails
  );

  // Rename Organization settings route and labels to teams setting
  return (
    <>
      <Nav className="secondary-nav" vertical>
        {/* <NavItem
          className={
            location.pathname === `/settings/organization/${id}` ? "active" : ""
          }
        >
          <Link
            to={`/settings/organization/${id}`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={Building} alt="Profile" />
              </div>
              <span>{organizationDetails.name} Profile</span>
            </div>
          </Link>
        </NavItem> */}

        {/* 
        <NavItem
          className={
            location.pathname === `/settings/organization/${id}/team`
              ? "active"
              : ""
          }
        >
          <Link
            to={`/settings/organization/${id}/team`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={Team} alt="Organization" />
              </div>
              <span>Team</span>
            </div>
          </Link>
        </NavItem> */}

        {/* Rename organization People route to teams people  */}
        {/* <NavItem
          className={
            location.pathname === `/settings/organization/${id}/people`
              ? "active"
              : ""
          }
        >
          <Link
            to={`/settings/organization/${id}/people`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={People} alt="Organization" />
              </div>
              <span>People</span>
            </div>
          </Link>
        </NavItem>
        <NavItem
          className={
            location.pathname === `/settings/organization/${id}/categories`
              ? "active"
              : ""
          }
        >
          <Link
            to={`/settings/organization/${id}/categories`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={Dashboard} alt="Organization" />
              </div>
              <span>Categories</span>
            </div>
          </Link>
        </NavItem> */}

        <NavItem
          className={
            location.pathname === `/settings/teams/${id}/people` ? "active" : ""
          }
        >
          <Link
            to={`/settings/teams/${id}/people`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label">
                <img src={People} alt="Organization" />
              </div>
              <span style={{ textTransform: "capitalize" }}>
                {organizationDetails.displayName
                  ? organizationDetails.displayName
                  : organizationDetails.name}
              </span>
            </div>
          </Link>
        </NavItem>
        {/* <NavItem
          className={
            location.pathname === `/settings/teams/${id}/categories`
              ? "active"
              : ""
          }
        >
          <Link
            to={`/settings/teams/${id}/categories`}
            active
            className="text-dark"
          >
            <div className="d-flex align-items-center">
              <div className="holder-label mr-3">
                <img src={Dashboard} alt="Organization" />
              </div>
              <span>Categories</span>
            </div>
          </Link>
        </NavItem> */}
      </Nav>
      <div className="logout-btn">
        <button
          className="home-btn"
          onClick={() => {
            dispatch(changeActiveTab("Create"));
            history.push("/dashboard/create");
          }}
        >
          <img src={home} />
        </button>
        <button
          onClick={() => {
            dispatch(changeActiveTab("Settings"));
            dispatch(logout());
          }}
        >
          Logout
        </button>
      </div>
    </>
  );
};
export default OrganizationSettingSidebar;
