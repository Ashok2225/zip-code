import React from "react";
import { Modal, ModalBody } from "reactstrap";
import Alarm from "../../../../../images/alarm.png";
import { useParams, useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  deleteOrganization,
  removeTeamFromOrganization,
} from "../../../../../redux/actions/organizationAction";
import { Refresh } from "@material-ui/icons";

const DeleteAccount = (props) => {
  const params = useParams();
  const { id, teamId } = params;
  const dispatch = useDispatch();
  const history = useHistory();
  const { deleteAccountModalToggle, deleteAccountModal, className, team } =
    props;
  const deleteAccount = async () => {
    if (team) dispatch(removeTeamFromOrganization(teamId));
    else dispatch(deleteOrganization(id));
    deleteAccountModalToggle();
    localStorage.removeItem("orgDetails");
    history.push(`/dashboard/create`);
  };
  return (
    <>
      <Modal
        isOpen={deleteAccountModal}
        deleteAccountModalToggle={deleteAccountModalToggle}
        className="org-setting"
      >
        <ModalBody className="text-center">
          <img src={Alarm} alt="Alarm" width="80" className="mt-5" />
          <h4 className="modal-title mt-4 mb-1" id="CreateOrganizationLabel">
            Are you sure, you want delete?
          </h4>
          <p className="mb-5 text-light">
            You will not able to recover this account
          </p>
          <div className="row mb-5">
            <div className="col-sm-6">
              <button
                className="btn btn-outline-default btn-block mt-auto mr-4"
                onClick={deleteAccountModalToggle}
              >
                No, Cancel Please
              </button>
            </div>
            <div className="col-sm-6">
              <button
                className="btn btn-danger btn-block mt-auto"
                onClick={() => deleteAccount()}
              >
                Yes, I want
              </button>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default DeleteAccount;
