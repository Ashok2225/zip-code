import React, { useEffect, useState } from "react";
import {
  Form,
  FormGroup,
  Input,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
} from "reactstrap";
import Close from "../../../../../images/close.png";

import { useParams } from "react-router";
import { useFormik } from "formik";
import { validationSchemaCategory } from "../../../../../common/ValidationSchemas/CategorySchema";
import FormikErrorMessage from "../../../../../common/FormikErrorMessage";
import { addCategoryToOrganization } from "../../../../../redux/actions/organizationAction";
import { useDispatch } from "react-redux";

const AddCategoryToOrgModal = (props) => {
  const {
    modalCreateCategoryToggle,
    createCategoryToggle,
    organizationCategories,
    searchRef,
  } = props;
  const params = useParams();
  const [isNameAvailable, setAvailability] = useState("");
  const dispatch = useDispatch();
  const { id } = params;
  const {
    values,
    handleSubmit,
    setFieldValue,
    handleBlur,
    errors,
    touched,
    resetForm,
  } = useFormik({
    initialValues: {
      name: "",
    },
    validationSchema: validationSchemaCategory,
    enableReinitialize: true,
    onSubmit: async (values, { resetForm }) => {
      const payload = {
        organization_id: id,
        name: values.name,
      };
      modalCreateCategoryToggle();
      resetForm();
      await dispatch(addCategoryToOrganization(payload));
      searchRef.current.value = "";
    },
  });

  const checkAvailability = (e) => {
    const { value } = e.target;
    setFieldValue("name", value);
    var found =
      organizationCategories !== undefined &&
      organizationCategories.filter(function (o) {
        return o.name === value;
      });
    found.length > 0 ? setAvailability(false) : setAvailability(true);
  };
  return (
    <>
      <Modal
        isOpen={createCategoryToggle}
        modalCreateCategoryToggle={modalCreateCategoryToggle}
        className="org-setting"
      >
        <Form onSubmit={handleSubmit} noValidate>
          <ModalHeader
            modalCreateCategoryToggle={modalCreateCategoryToggle}
            className="team-model-header"
          >
            <div className="d-flex justify-content-between">
              <div>Add Category</div>
              <div>
                <img
                  src={Close}
                  alt="close Btn"
                  className="teams-close-btn"
                  onClick={() => {
                    resetForm();
                    modalCreateCategoryToggle();
                  }}
                />
              </div>
            </div>
          </ModalHeader>
          <ModalBody>
            <div className="row pt-2" id="mt-0">
              <div className="col-sm-12 form-group">
                <FormGroup>
                  <Input
                    name="name"
                    placeholder="Name"
                    onChange={(e) => checkAvailability(e)}
                    onBlur={handleBlur}
                    value={values.name}
                    type="text"
                  />
                  <div className="d-flex justify-content-between align-items-center">
                    <span className={isNameAvailable ? "exist" : "not-exist"}>
                      {values.name.length > 0
                        ? isNameAvailable
                          ? ""
                          : "Email already Exists"
                        : ""}
                    </span>
                  </div>
                  <FormikErrorMessage
                    errors={errors}
                    touched={touched}
                    field="name"
                  />
                </FormGroup>
              </div>
            </div>
          </ModalBody>
          <ModalFooter className="px-0 pt-0 border-0 mb-4">
            <div id="mt-0">
              <div>
                <button
                  type="submit"
                  disabled={!isNameAvailable}
                  className="btn btn-block btn-primary"
                >
                  Done
                </button>
              </div>
            </div>
          </ModalFooter>
        </Form>
      </Modal>
    </>
  );
};

export default AddCategoryToOrgModal;
