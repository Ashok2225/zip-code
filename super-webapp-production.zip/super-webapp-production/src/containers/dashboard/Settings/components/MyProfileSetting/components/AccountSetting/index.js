import React, { useState, useMemo, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Form, FormGroup, Input, Label } from "reactstrap";
import FormikErrorMessage from "../../../../../../../common/FormikErrorMessage";
import { useFormik } from "formik";
import { AccountSettingSchema } from "../../../../../../../common/ValidationSchemas/AccountSettingSchema";
import avatar from "../../../../../../../images/avatar.png";
import Camera from "../../../../../../../images/camera@3x.png";
import { logout, updateProfile } from "../../../../../../../redux/actions/user";
import { getKeycloackToken } from "../../../../../../../redux/actions/auth";
import axios from "axios";
import Select from "react-select";
import PhoneInput from 'react-phone-number-input'
import 'react-phone-number-input/style.css'
import { changeActiveTab } from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snack";
import $ from "jquery"

// import 'react-phone-number-input/style.css'
// import PhoneInput from 'react-phone-number-input'

const AccountSetting = () => {
  const userDetails = useSelector((state) => state.userReducer.user);
  const dispatch = useDispatch();

   const [value, setValue] = useState("");
   
  useEffect(() => {
    setValue(userDetails?.contactNumber);
  }, [userDetails]);

  //const options = useMemo(() => PhoneInput().getData(), []);
  const changeHandler = (value) => {
    setValue(value.label);
  };
  
  const {
    values,
    errors,
    touched,
    isSubmitting,
    handleSubmit,
    handleChange,
    handleBlur,
    resetForm,
    setFieldValue,
  } = useFormik({
    initialValues: {
      firstName: userDetails ? userDetails.given_name : "",
      lastName: userDetails ? userDetails.family_name : "",
      email: userDetails ? userDetails.email : "",
      contactNumber: userDetails ? userDetails.contactNumber : "",
      profilePic: userDetails ? userDetails.profilePic : "",
      // country: userDetails ? userDetails.country : "",
    },
    enableReinitialize: true,
    validationSchema: AccountSettingSchema,
    onSubmit: async (values) => {
      const { firstName, lastName, country, phoneInput, profilePic } =
        values;
      const payload = {
        firstName,
        lastName,
        attributes: {
          profilePic,
          // country: value,
          contactNumber:value,
          subscription_id: 1,
          check_plan: "",
          check_user: true,
          role: "",
        },
      };
      await dispatch(updateProfile(payload));
    },
    
  });

  $('input#profile').bind('change', function() {
    var maxSizeKB = 20; 
    var maxSize = maxSizeKB * 1024;
    if (this.files[0].size > maxSize) {
      $(this).val("");
      dispatch(notify("error", "Size should be 20KB or less than 20KB" ))
      return false;
    }
  });

  const handleFileChange = async (e) => {
    try {
      let token = await getKeycloackToken();
      var data = new FormData();
      data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: data,
      };

      const res = await axios(config);
      const imgId = res.data.data.image_id;
      let url = `${process.env.REACT_APP_BOT_SERVICE_URL}/image/${imgId}`;
      setFieldValue("profilePic", url);
      handleSubmit();
    } catch (err) {
      console.log(err.toString());
    }
  };

  const handleDeleteUser = async () => {
    try {
      let token = await getKeycloackToken();

      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/deleteUser`,
        method: "delete",
        headers: {
          // "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        // data: data,
      };

      const res = await axios(config);

      if (res.status) {
        dispatch(changeActiveTab("Settings"));
        dispatch(logout());
      }
    } catch (err) {
      console.log(err.toString());
    }
  };
  
  return (
    <>
      <div className="row d-flex">
        <div className="col-lg-9 ">
          <div className="card org-profile-card border-0">
            <div className="row  org-profile-content">
              <div className="col-sm-12 col-lg-6 offset-xl-3">
                <Form noValidate onSubmit={handleSubmit}>
                  <div>
                    <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">First Name</span>
                        <Input
                          type="text"
                          name="firstName"
                          placeholder="Enter First Name"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.firstName}
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="firstName"
                        />
                      </div>
                      {/* <Label>First Name</Label>
                      <Input
                        type="text"
                        name="firstName"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.firstName}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="firstName"
                      /> */}
                    </FormGroup>
                    <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">Last Name</span>
                        <Input
                          type="text"
                          name="lastName"
                          placeholder="Enter Last Name"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.lastName}
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="lastName"
                        />
                      </div>
                      {/* <Label> Last Name</Label>
                      <Input
                        type="text"
                        name="lastName"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        value={values.lastName}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="lastName"
                      /> */}
                    </FormGroup>
                    <FormGroup>
                      <div className="ip-tl-label">
                        <span className="tl-label">Email Address</span>
                        <Input
                          type="text"
                          name="email"
                          placeholder="Enter Email"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.email}
                          disabled
                        />
                        <FormikErrorMessage
                          errors={errors}
                          touched={touched}
                          field="email"
                        />
                      </div>
                    </FormGroup>
                      <FormGroup>
                        <div className="ip-tl-label">
                          <span className="tl-label">Phone Number</span>
                          <PhoneInput
                            className="form-control"
                            international
                            countryCallingCodeEditable={false}
                            placeholder="Enter Phone Number"
                            id="phoneInput"
                            name="phoneInput"
                            onChange={setValue}
                            onBlur={handleBlur}
                            value={values.contactNumber}
                          />
                        </div>
                      </FormGroup>
                    <div className="mt-4 mt-auto text-right">
                      <button type="submit" className="btn btn-primary">
                        Update
                      </button>
                    </div>
                  </div>
                </Form>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="card org-profile-card border-0 text-center">
            <div className="upld-avatar m-auto">
              <img
                src={values.profilePic ? values.profilePic : avatar}
                alt="Avatar"
              />
              <div
                onClick={() => document.getElementById("profile").click()}
                className="upld-hover"
              >
                <img src={Camera} alt="camera" />
                <input
                  type="file"
                  accept="image/*"
                  id="profile"
                  style={{ display: "none" }}
                  onChange={(e) => handleFileChange(e)}
                />
              </div>
            </div>
            <div className="my-3">
              <p className="font-weight-600 mb-0">Profile Photo</p>
              {/* <span className="text-muted f-12">20kb max</span> */}
            </div>
            <div className="delete-profile-setting">
              <button
                className="btn btn-outline-danger mt-auto"
                onClick={() => handleDeleteUser()}
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default AccountSetting;
