import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Form, FormGroup, Input, Label } from "reactstrap";
import FormikErrorMessage from "../../../../../../../common/FormikErrorMessage";
import { useFormik } from "formik";
import avatar from "../../../../../../../images/avatar.png";
import Camera from "../../../../../../../images/camera@3x.png";
import { UpdatePasswordSchema } from "../../../../../../../common/ValidationSchemas/UpdatePasswordSchema";
import {
  logout,
  updatePassword,
} from "../../../../../../../redux/actions/user";
import { getKeycloackToken } from "../../../../../../../redux/actions/auth";
import axios from "axios";
import { changeActiveTab } from "../../../../../../../redux/actions/skill";
import { notify } from "../../../../../../../redux/actions/snackActions"
var qs = require("qs");

const ChangePassword = () => {
  const userDetails = useSelector((state) => state.userReducer.user);
  const dispatch = useDispatch();
 
  const {
    values,
    errors,
    touched,
    isSubmitting,
    handleSubmit,
    handleChange,
    handleBlur,
    resetForm,
    setFieldValue,
  } = useFormik({
    initialValues: {
      oldpassword: "",
      newpassword: "",
      confirmpassword: "",
    },
    enableReinitialize: true,
    validationSchema: UpdatePasswordSchema,
    onSubmit: async (values) => {
      let checkPwdPayload = {
        username: userDetails?.preferred_username,
        password: values.oldpassword,
        client_id: "admin-cli",
        grant_type: "password",
      };
      let updatePwdPayload = {
        temporary: false,
        type: "password",
        value: values.newpassword,
      };
      if (values.oldpassword !== values.newpassword) {
        await dispatch(
          updatePassword(qs.stringify(checkPwdPayload), updatePwdPayload)
        );
      }
      else {
        dispatch(notify("error", "New password should not equal to old password"));
      }
    },
  });
  
  const handleDeleteUser = async () => {
    try {
      let token = await getKeycloackToken();

      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/deleteUser`,
        method: "delete",
        headers: {
          // "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        // data: data,
      };

      const res = await axios(config);

      if (res.status) {
        dispatch(changeActiveTab("Settings"));
        dispatch(logout());
      }
    } catch (err) {
      console.log(err.toString());
    }
  };
  return (
    <div className="row d-flex">
      <div className="col-lg-9">
        <div className="card org-profile-card border-0">
          <div className="row org-profile-content">
            <div className="col-sm-12 col-lg-6 offset-xl-3">
              <Form noValidate onSubmit={handleSubmit}>
                <div>
                  <FormGroup>
                    <div className="ip-tl-label">
                      <span className="tl-label">Old Password</span>
                      <Input
                        type="password"
                        name="oldpassword"
                        placeholder="Enter Old Password"
                        onChange={handleChange}
                        onBlur={handleBlur}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="oldpassword"
                      />
                    </div>
                    {/* <Label>Old Password</Label>
                    <Input
                      type="password"
                      name="oldpassword"
                      onChange={handleChange}
                      onBlur={handleBlur}
                    />
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="oldpassword"
                    /> */}
                  </FormGroup>
                  <FormGroup>
                    <div className="ip-tl-label">
                      <span className="tl-label">New Password</span>
                      <Input
                        type="password"
                        name="newpassword"
                        placeholder="Enter New Password"
                        onChange={handleChange}
                        onBlur={handleBlur}
                      // value={values.billingEmail}
                      // disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="newpassword"
                      />
                    </div>
                    {/* <Label>New Password</Label>
                    <Input
                      type="password"
                      name="newpassword"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      // value={values.billingEmail}
                      // disabled={!isOwner}
                    />
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="newpassword"
                    /> */}
                  </FormGroup>
                  <FormGroup>
                    <div className="ip-tl-label">
                      <span className="tl-label">Confirm Password</span>
                      <Input
                        type="password"
                        name="confirmpassword"
                        placeholder="Enter"
                        onChange={handleChange}
                        onBlur={handleBlur}
                      // value={values.billingEmail}
                      // disabled={!isOwner}
                      />
                      <FormikErrorMessage
                        errors={errors}
                        touched={touched}
                        field="confirmpassword"
                      />
                    </div>
                    {/* <Label>Confirm Password</Label>
                    <Input
                      type="password"
                      name="confirmpassword"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      // value={values.billingEmail}
                      // disabled={!isOwner}
                    />
                    <FormikErrorMessage
                      errors={errors}
                      touched={touched}
                      field="confirmpassword"
                    /> */}
                  </FormGroup>
                  <div className="mt-4 mt-auto text-right">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn btn-primary"
                    >
                      Update
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </div>
      <div className="col-lg-3">
        <div className="card org-profile-card border-0 text-center">
          <div className="upld-avatar m-auto">
            <img
              src={values.profilePic ? values.profilePic : avatar}
              alt="Avatar"
            />
            <div className="upld-hover">
              <img src={Camera} alt="camera" />
              <input
                type="file"
                accept="image/*"
                id="profile"
                style={{ display: "none" }}
              // onChange={(e) => handleFileChange(e)}
              />
            </div>
          </div>
          <div className="my-3">
            <p className="font-weight-600 mb-0">Profile Photo</p>
            <span className="text-muted f-12">20kb max</span>
          </div>
          <div className="delete-profile-setting">
            <button
              className="btn btn-outline-danger mt-auto"
              onClick={() => handleDeleteUser()}
            >
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;
