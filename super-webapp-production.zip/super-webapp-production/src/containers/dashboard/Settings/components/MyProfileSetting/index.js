import React from "react";
import { Link, Switch, Route } from "react-router-dom";
import { Breadcrumb, BreadcrumbItem } from "reactstrap";
import SettingSidebar from "../SettingSidebar/SettingSidebar";
import SearchIcon from "../../../../../images/search.png";
import MyProfile from "./components/MyProfile";
import AccountSetting from "./components/AccountSetting";
import ChangePassword from "./components/ChangePassword";
import Device from "./components/Device";
import Analytics from "../../../Analytics";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import AnalyticsPeople from "../AnalyticsPeople";


const MyProfileSetting = (props) => {
  let email =
      props &&
      props.userReducer.user &&
      props.userReducer.user.email
        ? props.userReducer.user.email
        : null;
  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            <h5 className="mb-0">Settings</h5>
            {/* <Link to="/settings/organization-settings">Home</Link> */}
                {/* Renaming Organization settings to Teams  */}
            {/* <Breadcrumb className="mb-0">
              <BreadcrumbItem>
                
                <Link to="/settings/teams-settings">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbItem active>My Profile</BreadcrumbItem>
            </Breadcrumb> */}
          </div>
          <SettingSidebar />
        </div>
        {/* Left end */}

        {/* Right */}
        <div className="inner-right bg-grey">
          <div className="row mx-0 setting-search bg-white py-3 border-left">
            <div className="col-md-8">
              <div className="position-relative search">
                <input
                  type="search"
                  placeholder="Search"
                  className="form-control border-0"
                />
                <img src={SearchIcon} alt="Search" />
              </div>
            </div>
          </div>

          <div className="scrollable logout-setting">
            <div className="col-md-12 log-inner">
              {/* <h5 className="org-heading">My Profile Setting</h5> */}
              <Switch>
                <Route path="/settings/myprofile-settings/my-profile">
                  <div className="title-btn">
                    <h1 className="title">My Profile</h1>
                  </div>
                  <MyProfile />
                </Route>
                <Route path="/settings/myprofile-settings/account-setting">
                  <div className="title-btn">
                    <h1 className="title">Account Settings</h1>
                  </div>
                  <AccountSetting />
                </Route>
                <Route path="/settings/myprofile-settings/change-password">
                  <div className="title-btn">
                    <h1 className="title">Change Password</h1>
                  </div>
                  <ChangePassword />
                </Route>
                <Route path="/settings/device">
                  <div className="title-btn">
                    <h1 className="title">Device</h1>
                  </div>
                  <Device />
                </Route>





                {process.env.REACT_APP_ADMIN1 === email ||
                  process.env.REACT_APP_ADMIN2 === email ||
                  process.env.REACT_APP_ADMIN3 === email ||
                  process.env.REACT_APP_ADMIN4 === email ? (
                  <Route path="/settings/myprofile-settings/analytics/:id">

                    <Analytics />
                  </Route>
                ) : (
                  ""
                )}


{process.env.REACT_APP_ADMIN1 === email ||
                  process.env.REACT_APP_ADMIN2 === email ||
                  process.env.REACT_APP_ADMIN3 === email ||
                  process.env.REACT_APP_ADMIN4 === email ? (
                  <Route path="/settings/myprofile-settings/viewPeople/:id">

                    <AnalyticsPeople/>
                  </Route>
                ) : (
                  ""
                )}
              </Switch>
            </div>
          </div>
        </div>

        {/* Right End */}
      </div>
    </>
  );
};
const mapStateToProps = (state) => ({
  organizationReducer: state.organizationReducer,
  userReducer: state.userReducer,
  notifications: state.appReducer.notifications,
  notified: state.appReducer.notified,
  skillReducer: state.skillReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {

  })
)(MyProfileSetting);
