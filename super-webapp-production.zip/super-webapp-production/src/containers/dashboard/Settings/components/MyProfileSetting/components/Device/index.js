import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import {
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";

import Delete from "../../../../../../../images/delete.png";
import SearchIcon from "../../../../../../../images/search.png";
import Dots from "../../../../../../../images/dot.png";
import deviceIcon from "../../../../../../../images/device-icon.svg";

import getColors from "../../../../../../../components/colors";
import SettingSidebar from "../../../SettingSidebar/SettingSidebar";
import { getSession } from "../../../../../../../redux/actions/skill";
import EmptyScreen from "../../../../../Schedules/images/Empty-Screen.png";

const Device = () => {
  const devices = useSelector((state) => state.skillReducer.devices)
  const dispatch = useDispatch();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle = () => setDropdownOpen((prevState) => !prevState);

  // let colors = ["#f54747", "#8a5fff", "#ffa933", "#ff6233", "#1d262e", "#297bff", "#ff2963", "#21b8dd"];
  // let count = 0;

  // $('.ss-ico').each(function () {
  //   $(this).css("background-color", colors[count]);
  //   count++;
  //   if (count === colors.length) {
  //     count = 0;
  //   }
  // });

  useEffect(() => {
    dispatch(getSession());
  }, []);

  return (
    <>
      <div className="d-flex">
        {/* Left */}
        <div className="inner-left-sidebar">
          <div className="px-4 pt-4">
            <h5 className="mb-0">Setting</h5>
          </div>
          <SettingSidebar />
        </div>
        {/* Left end */}


        <div className="inner-right bg-grey">
          <div className="h-100">
            <div className="row mx-0 setting-search bg-white py-3 border-left">
              <div className="col-md-8">
                <div className="position-relative search">
                  <input
                    // ref={searchRef}
                    id="searchField"
                    type="search"
                    placeholder="Search"
                    className="form-control border-0"
                  // onChange={handleSearch}
                  />
                  <img src={SearchIcon} alt="Search" />
                </div>
              </div>
            </div>

            <div className="flex-title mx-0 pl-3 my-3">
              <h5 className="mt-1 org-heading">My Device</h5>
            </div>

            <div className="row team-setting scrollable">
              {devices.length > 0 ? (
                devices.map((item, index) => {
                  return (
                    <div className="col-sm-4 col-xl-4 mb-4" key={index}>
                      <div className="card border-0 org-card">
                        <div className="card-body">
                          <div className="row" id="mt-0">
                            <div className="col-sm-5">
                              <div className="ss-ico ss-text"
                                style={{
                                  backgroundColor: getColors(
                                    item.session_name
                                  ),
                                }} >
                                <img src={deviceIcon} />
                              </div>
                            </div>
                            <div className="col-sm-7 text-right">
                              <Dropdown
                                className="dropdown_menu "
                                isOpen={dropdownOpen} toggle={toggle}
                              >
                                <DropdownToggle>
                                  <img src={Dots} alt="more" />
                                </DropdownToggle>
                                <DropdownMenu right>
                                  <DropdownItem>
                                    <span>
                                      <img src={Delete} alt="Delete" />
                                    </span>
                                    Delete
                                  </DropdownItem>
                                </DropdownMenu>
                              </Dropdown>
                            </div>
                          </div>

                          <h5
                            className="card-title f-14 font-weight-600 mb-3"
                          //style={{ textTransform: "capitalize" }}
                          >
                            {item.session_name}
                          </h5>
                          <h6 className="card-subtitle text-light f-12 mb-3 text-muted">
                            {item.user_email}
                          </h6>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="empty-skill text-center">
                  <img src={EmptyScreen} alt="empty Screen"></img>
                  <p>Seems like you don't have any linked devices yet.</p>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </>
  );
};


export default Device;