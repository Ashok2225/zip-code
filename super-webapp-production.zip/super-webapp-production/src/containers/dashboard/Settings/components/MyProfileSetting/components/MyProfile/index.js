import React from "react";
import { Card } from "reactstrap";
import smileicon from "../../../../../../../images/mail-icon.png";
import avatar from "../../../../../../../images/avatar.png";
import edit from "../../../../../../../images/edit.png";
import { useSelector } from "react-redux";

const MyProfile = () => {
  const userDetails = useSelector((state) => state.userReducer.user);
  if (userDetails)
    return (
      <>
        <Card>
          <div className="profile-setting">
            <div className="profile-image">
              <img src={avatar}></img>
            </div>
            <div className="tag-line">
              {/* <img src={profile} alt=""></img> */}
            </div>
          </div>

          <div className="user-profile">
            <button className="edit-profile-button">
              <img src={edit} alt=""></img>
            </button>
            {/* <h3>Ritesh Agrawal</h3> */}
            <h3>{userDetails.name}</h3>
            <p>Founder & CEO-OYO Hotels & Homes</p>
            <span className="user-email-location">
              {" "}
              <img className="mail-image" src={smileicon} alt="" />
              {/* ritesh@oyo.com */}
              {userDetails.email}
            </span>
            <span className="user-email-location">
              {" "}
              <img className="mail-image" src={smileicon} alt="" />
              Mumbai,India
            </span>
          </div>
        </Card>
      </>
    );
  return null;
};

export default MyProfile;
