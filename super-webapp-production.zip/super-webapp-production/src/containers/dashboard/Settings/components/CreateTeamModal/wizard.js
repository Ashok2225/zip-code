import React from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import { Button } from "reactstrap";
import { createTeam } from "../../../../../redux/actions/organizationAction";
import { connect } from "react-redux";

const Step1Schema = Yup.object().shape({
  name: Yup.string().required("Name Is Required"),
});
const Step2Schema = Yup.object().shape({
  // email: Yup.string().required("Email Is Required"),
  // favoriteColor: Yup.string().required("Favorite color required"),
});

const schemaArray = [Step1Schema, Step2Schema];

const required = (value) => (value ? undefined : "Required");

export class Wizard extends React.Component {
  static Page = ({ children, parentState }) => {
    return children(parentState);
  };

  constructor(props) {
    super(props);
    this.state = {
      page: 0,
      values: props.initialValues,
    };
  }

  next = (values) => {
    this.createTeamInOrganization(values);
    this.setState((state) => ({
      page: Math.min(state.page + 1, this.props.children.length - 1),
      values,
    }));
  };

  previous = () =>
    this.setState((state) => ({
      page: Math.max(state.page - 1, 0),
    }));

  validate = (values) => {
    const activePage = React.Children.toArray(this.props.children)[
      this.state.page
    ];
    return activePage.props.validate ? activePage.props.validate(values) : {};
  };

  handleSubmit = (values, bag) => {
    const { children, onSubmit } = this.props;
    const { page } = this.state;
    const isLastPage = page === React.Children.count(children) - 1;
    if (isLastPage) {
      return onSubmit(values, bag);
    } else {
      bag.setTouched({});
      bag.setSubmitting(false);
      this.next(values);
    }
  };

  createTeamInOrganization = async (values) => {
    const payload = {
      name: values.name,
      organization_id: this.props.organization_id,
      profilePic: values.profilePic,
      // roleId: values.roleId,
    };
    const res = await this.props.createTeam(payload);
    this.props.searchRef.current.value = "";
    this.props.setTeamId(res.id);
  };
  render() {
    const { children } = this.props;
    const { page, values } = this.state;
    const activePage = React.Children.toArray(children)[page];
    const isLastPage = page === React.Children.count(children) - 1;
    return (
      <Formik
        initialValues={values}
        enableReinitialize={false}
        validationSchema={schemaArray[page]}
        onSubmit={this.handleSubmit}
      >
        {(props) => {
          const { handleSubmit, isSubmitting, setFieldValue } = props;
          return (
            <form onSubmit={handleSubmit}>
              {React.cloneElement(activePage, { parentState: { ...props } })}

              <div className="buttons">
                {page > 0 && (
                  <Button
                    type="button"
                    className="secondary"
                    onClick={this.previous}
                    color="outline-primary"
                  >
                    Previous
                  </Button>
                )}

                {!isLastPage && (
                  <Button
                    type="submit"
                    color="primary"
                    className="float-right"
                    disabled={isSubmitting || !this.props.isNameAvailable}
                  >
                    {/* Next */}
                    Create Team & add members
                  </Button>
                )}

                {isLastPage && (
                  <Button
                    type="button"
                    color="primary"
                    className="float-right"
                    disabled={isSubmitting}
                    onClick={this.props.modalTeamToggle}
                  >
                    Done
                  </Button>
                )}
              </div>
            </form>
          );
        }}
      </Formik>
    );
  }
}

export default connect(null, {
  createTeam,
})(Wizard);
