import React, { useEffect, useState, Fragment } from "react";
import { Field } from "formik";

import {
  FormGroup,
  Input,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
  Col,
} from "reactstrap";
import Axios from "axios";
import { useParams } from "react-router";
import { useFormik } from "formik";

import { validationSchemaProfileTeam } from "../../../../../common/ValidationSchemas/ProfileTeamSchema";
import Close from "../../../../../images/close.png";
import { useDispatch, useSelector } from "react-redux";
import {
  addMemberToTeam,
  getUsersOfAnOrganization,
} from "../../../../../redux/actions/organizationAction";
import Camera from "../../../../../images/camera@3x.png";
import avatar from "../../../../../images/avatar.png";
import addImg from "../../../../../images/add-icon.jpg";
import { getKeycloackToken } from "../../../../../redux/actions/auth";
import Wizard from "./wizard";

const initialValues = {
  name: "",
  profilePic: "",
  roleId: "",
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const CreateTeamModal = (props) => {
  const {
    modalTeamToggle,
    createTeamToggle,
    className,
    organizationTeams,
    searchRef,
  } = props;
  const [pplAdded, setPplAdded] = useState([]);
  const [teamId, setTeamId] = useState("");
  const [isNameAvailable, setAvailability] = useState("");
  const params = useParams();
  const { id } = params;
  const dispatch = useDispatch();
  const organizationPeople = useSelector(
    (state) => state.organizationReducer.organizationPeople
  );
  const { values, setFieldValue } = useFormik({
    initialValues: {
      profilePic: "",
      organizationPeople,
    },
    validationSchema: validationSchemaProfileTeam,
    enableReinitialize: true,
  });

  useEffect(() => {
    dispatch(getUsersOfAnOrganization(id));
  }, []);

  const addMembers = (data) => {
    const { email, organization_id, name, role_id } = data;
    const payload = {
      email,
      organization_id,
      name,
      team_id: teamId.toString(),
      roleId: role_id,
    };
    dispatch(addMemberToTeam(payload));
    searchRef.current.value = "";
  };

  const renderOrgPeopleList = () => {
    const { organizationPeople } = values;
    if (organizationPeople && organizationPeople.length < 1) {
      return (
        <div className="text-center">
          <h6>No user present for the organization</h6>
        </div>
      );
    }
    return (
      organizationPeople &&
      organizationPeople.map((item, index) => (
        <li
          className="border-bottom"
          hidden={pplAdded.find((ele) => ele === item.id)}
        >
          <div className="d-flex align-items-center justify-content-between">
            <div className="d-flex align-items-center">
              <div className="text-white custom-badge bg-primary">
                {item.name.charAt(0).toUpperCase()}
              </div>
              <div className="pl-4 font-weight-bold pt-1 line-height-18">
                <p className="mb-0">{item.name}</p>
                <small className="text-muted f-12">{item.email}</small>
              </div>
            </div>
            <div>
              <span
                className={
                  item.role_id === "2"
                    ? "badge badge-pill badge-primary-light cursor-pointer px-3 py-1"
                    : "badge badge-pill badge-light cursor-pointer px-3 py-1"
                }
                onClick={() => {
                  organizationPeople[index].role_id = "2";
                  setFieldValue("organizationPeople", [...organizationPeople]);
                }}
              >
                Admin
              </span>
              <span
                className={
                  item.role_id === "1"
                    ? " badge badge-pill badge-primary-light cursor-pointer px-3 py-1"
                    : "badge badge-pill badge-light cursor-pointer px-3 py-1"
                }
                onClick={() => {
                  organizationPeople[index].role_id = "1";
                  setFieldValue("organizationPeople", [...organizationPeople]);
                }}
              >
                Member
              </span>
            </div>
            <div>
              {" "}
              <img
                onClick={() => {
                  addMembers(item);
                  setPplAdded((prevState) => [...prevState, item.id]);
                }}
                className="add-icon"
                src={addImg}
              />
            </div>
          </div>
        </li>
      ))
    );
  };

  const handleFileChange = async (e, props) => {
    try {
      let token = await getKeycloackToken();
      var data = new FormData();
      data.append("file", e.target.files[0]);
      var config = {
        url: `${process.env.REACT_APP_BOT_SERVICE_URL}/upload`,
        method: "post",
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        data: data,
      };

      const res = await Axios(config);
      const imgId = res.data.data.image_id;
      let url = `${process.env.REACT_APP_BOT_SERVICE_URL}/image/${imgId}`;
      // setFieldValue("profilePic", url);
      props.setFieldValue("profilePic", url);
    } catch (err) {
      console.log(err.toString());
    }
  };

  const handleUserChange = (e) => {
    const { value } = e.target;
    let found =
      organizationPeople !== undefined &&
      organizationPeople.filter((o) => o.name.includes(value));
    setFieldValue("organizationPeople", found);
  };

  const checkAvailability = (e, props) => {
    const { value } = e.target;
    props.setFieldValue("name", value);
    var found =
      organizationTeams !== undefined &&
      organizationTeams.filter(function (o) {
        return o.name === value;
        // return o.name === values.name;
      });
    found.length > 0 ? setAvailability(false) : setAvailability(true);
  };

  return (
    <>
      <Modal
        isOpen={createTeamToggle}
        modalTeamToggle={modalTeamToggle}
        className="org-setting"
      >
        <ModalHeader
          modalTeamToggle={modalTeamToggle}
          className="team-model-header"
        >
          <div className="d-flex justify-content-between">
            <div>Create a Team</div>
            <div>
              <img
                src={Close}
                alt="close Btn"
                className="teams-close-btn"
                onClick={modalTeamToggle}
              />
            </div>
          </div>
        </ModalHeader>
        <ModalBody>
          <div className="App">
            <Wizard
              initialValues={initialValues}
              organization_id={id}
              setTeamId={setTeamId}
              modalTeamToggle={modalTeamToggle}
              isNameAvailable={isNameAvailable}
              searchRef={searchRef}
              onSubmit={(values, actions) => {
                sleep(300).then(() => {
                  actions.setSubmitting(false);
                });
              }}
            >
              <Wizard.Page>
                {(props) => {
                  return (
                    <Fragment>
                      <div>
                        <Row>
                          <Col xs={{ size: 12 }}>
                            <div className="col-sm-12">
                              <div className="pr-info">
                                <div className="d-flex">
                                  <div className="upld-avatar mx-auto">
                                    <img
                                      src={
                                        props.values.profilePic
                                          ? props.values.profilePic
                                          : avatar
                                      }
                                      alt="Avatar"
                                    />
                                    <div
                                      onClick={() =>
                                        document
                                          .getElementById("profile")
                                          .click()
                                      }
                                      className="upld-hover"
                                    >
                                      <img src={Camera} alt="camera" />
                                      <input
                                        type="file"
                                        accept="image/*"
                                        id="profile"
                                        style={{ display: "none" }}
                                        onChange={(e) =>
                                          handleFileChange(e, props)
                                        }
                                      />
                                    </div>
                                  </div>
                                  <div className="pr-text pt-3 pl-1">
                                    <p>Profile Photo</p>
                                    <span>20kb max</span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="col-sm-12">
                              <div className="row">
                                <div className="col-sm-11">
                                  <FormGroup>
                                    <label>Name a team</label>
                                    <Input
                                      // tag={Field}
                                      type="name"
                                      name="name"
                                      onChange={(e) =>
                                        checkAvailability(e, props)
                                      }
                                      value={props.values.name}
                                    />
                                    <div className="d-flex justify-content-between align-items-center">
                                      <span
                                        className={
                                          isNameAvailable
                                            ? "exist"
                                            : "not-exist"
                                        }
                                      >
                                        {props.values.name.length > 0
                                          ? isNameAvailable
                                            ? "Name Available"
                                            : "Name already Exists"
                                          : ""}
                                      </span>
                                    </div>
                                    {props.errors.name &&
                                      props.touched.name && (
                                        <div className="errorMessage">
                                          {props.errors.name}
                                        </div>
                                      )}
                                  </FormGroup>
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Fragment>
                  );
                }}
              </Wizard.Page>
              <Wizard.Page
                validate={(values) => {
                  const errors = {};
                  if (!values.email) {
                    errors.email = "Required";
                  }
                  if (!values.favoriteColor) {
                    errors.favoriteColor = "Required";
                  }
                  return errors;
                }}
              >
                {(props) => {
                  return (
                    <Fragment>
                      <div>
                        <div className="row pt-2" id="mt-0">
                          <div className="col-sm-12 form-group">
                            <input
                              type="text"
                              className="form-control"
                              placeholder="Search people and invite new user"
                              onChange={(e) => handleUserChange(e)}
                            />
                          </div>

                          <div className="col-sm-12 form-group ">
                            <ul className="overflow-auto-200 list-with-bottom-border mt-3">
                              {renderOrgPeopleList()}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </Fragment>
                  );
                }}
              </Wizard.Page>
            </Wizard>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default CreateTeamModal;
