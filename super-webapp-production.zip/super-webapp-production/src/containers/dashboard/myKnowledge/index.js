import React, { Component } from "react";
import { connect } from "react-redux";
import { Switch, Route, withRouter } from "react-router-dom";

import SideBar from "./components/SideBar";
import View from "./components/View";
import {
  changeKnowledgeView,
  getCreatedKnowledge,
  getSharedKnowledge,
  changeViewMode
} from "../../../redux/actions/knowledge";
import { getUsersOfAnOrganization } from "../../../redux/actions/organizationAction";
import { getDraftSkills } from "../../../redux/actions/skill";
import EmptyLoader from "../../../components/emptyLoader";

class MyKnowledge extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showCreate: false,
      isLoading: true,
      emptyView: true
    };
  }

  componentDidMount() {
    const showCreate =
      this.props && this.props.location.pathname === "/dashboard/knowledge"
        ? true
        : false;

    this.setState({
      isLoading: false,
      showCreate: showCreate
    });
    this.props.getCreatedKnowledge(true);

    this.props.getSharedKnowledge();
    this.props.getUsersOfAnOrganization();
  }

  render() {
    return (
      <React.Fragment>
        <div className="align-row">
          <SideBar isLoadingSidebBar={this.state.isLoading} />
        
          <Switch>
            <Route
              path="/dashboard/knowledge/view/:id"
              render={() => <View />}
            />
          </Switch>

          {this.state.showCreate ? (
            <React.Fragment>
             
              <div className="fw-screen">
                
                <div className="chat-col art-chat ">
                  
                  <div className="empty-view">
                    
                    <EmptyLoader />
                    <div className="add-article">
                      <div className="dropdown ss-drop-menu">
                        <a
                          className="primary-btn empty-btn-add dropdown-toggle"
                          data-toggle="dropdown"
                          aria-expanded="true"
                          data-original-title="Create Note"
                          data-tip
                          data-for="create"
                          onClick={() =>
                            this.props.history.push("/dashboard/createNote")
                          }
                        >
                          Create New Note
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>
          ) : (
            <React.Fragment></React.Fragment>
          )}
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  knowledgeReducer: state.knowledgeReducer,
  userReducer: state.userReducers,
  organizationReducer: state.organizationReducer
});

export default connect(mapStateToProps, {
  changeKnowledgeView,
  getCreatedKnowledge,
  getSharedKnowledge,
  changeViewMode,
  getDraftSkills,
  getUsersOfAnOrganization
})(MyKnowledge);
