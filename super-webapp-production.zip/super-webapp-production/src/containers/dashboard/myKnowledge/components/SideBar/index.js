import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { compose } from "redux";
import $ from "jquery";
import { connect } from "react-redux";
import searchicon from "../../../../../images/serach-black.png";
import closeicon from "../../../../../images/close.png";
import menu_toggle from "../../../../../images/menu-side.png";

import qIcon from "../../../../../images/q&a-icon.png";
import artIcon from "../../../../../images/art-icon.png";
import searchDrop from "../../../../../images/search-drop.png";

import EmptyLoader from "../../../../../components/emptyLoader";
import Loader from "../../../../../components/loader";
import getColors from "../../../../../components/colors";
import {
  changeKnowledgeView,
  getCreatedKnowledge,
  getSharedKnowledge,
  changeViewMode,
} from "../../../../../redux/actions/knowledge";
import {
  getSkillsFromStore,
  getDraftSkills,
} from "../../../../../redux/actions/skill";
import ReactTooltip from "react-tooltip";

class SideBar extends Component {
  state = {
    isLoading: true,
    serachItem: "",
    filterBy: "",
    inOrgContext: false,
    orgId: null,
    colors: ["#0250ce", "#f54747", "#33d0b7", "#ffa933", "#21b8dd", "#8a5fff"],
    showKnowledge: [],
    minMode: false,
    isSearchActive: false,
  };

  shrinkSidebar = () => {
    this.setState({
      minMode: !this.state.minMode,
    });
  };

  componentDidMount() {
    const getOrgContext = JSON.parse(window.localStorage.getItem("orgDetails"));
    this.setState({
      orgId: getOrgContext,
    });
  }

  componentWillReceiveProps(nextProps) {
    let _shareKnb = nextProps.knowledgeReducer.sharedKnowledge.filter(
      (i) => this.props.userReducer.user.email !== i.created_user
    );
    this.setState({
      isLoading: nextProps.knowledgeReducer.isLoadingKnowledge,
      showKnowledge: nextProps.knowledgeReducer.knowledge.concat(_shareKnb),
    });
  }

  searchKnowledge = (e) => {
    this.setState({
      serachItem: e.target.value,
    });
  };

  viewItem = async (item) => {
    let changeView = await this.props.changeKnowledgeView(item);

    if (changeView) {
      this.props.history.push({
        pathname: `/dashboard/knowledge/view/${item.kind}=${item.id}`,

        state: { canEdit: item.viewOrEdit },
      });
    }
  };

  viewItemDraft = async (item) => {
    let changeView = await this.props.changeKnowledgeView(item);
    if (changeView) {
      this.props.history.push(
        `/dashboard/knowledge/view/${item.TYPE}=${item.id}`
      );
    }
  };

  render() {
    // const { isLoading } = this.props.isLoadingSideBar;
    return (
      <div className={this.state.minMode ? "task-list minibar" : "task-list"}>
        <div className="flex-title">
          <h3 className="title">My Notes</h3>

          <div
            className={`ls-sidebar ${
              this.state.isSearchActive ? "active" : ""
            }`}
          >
            <input
              type="text"
              value={this.state.serachItem ? this.state.serachItem : ""}
              placeholder="Search Knowledge Title"
              onChange={(e) => this.searchKnowledge(e)}
            />

            <div className="ls-icons">
              <button
                className="ls-close"
                onClick={() =>
                  this.setState({ serachItem: "", isSearchActive: false })
                }
              >
                <img src={closeicon} alt="" />
              </button>
            </div>
          </div>
          <div className="icon-list">
            <div
              className="src-icon"
              onClick={() => this.setState({ isSearchActive: true })}
            >
              <img src={searchicon} alt="" />
            </div>
            <div className="collapse-menu" onClick={() => this.shrinkSidebar()}>
              <img src={menu_toggle} alt="" />
            </div>
          </div>
        </div>

        {/* search box */}
        {/* <div className="sb-search">
          <input
            type="text"
            value={this.state.serachItem ? this.state.serachItem : ""}
            placeholder="Search Knowledge Title"
            onChange={(e) => this.searchKnowledge(e)}
          />
        </div> */}
        <div className="task-block h-100">
          <div className="tl-list h-100">
            <div className="tabs-skill h-100">
              <ul className="nav nav-tabs"></ul>
              <div className="tab-content qa-skill scrollable">
                <div id="created" className="tab-pane fade in active">
                  <div className="scrollable qa-list-scroll">
                    {this.state.isLoading ? (
                      <Loader
                        styles={{ width: "50px", margin: "auto" }}
                        root={{ display: "flex" }}
                      />
                    ) : (
                      <>
                        {this.props.knowledgeReducer.knowledge.length == 0 &&
                        this.props.knowledgeReducer.sharedKnowledge.length ==
                          0 &&
                        this.props.skillReducer.draft_skills == 0 ? (
                          <EmptyLoader message="No Knowledge found" />
                        ) : (
                          <>
                            {this.state.showKnowledge
                              .filter((item, i) => {
                                if (this.state.serachItem === "") {
                                  return item;
                                } else {
                                  if (item.question !== null) {
                                    return item.question
                                      .toLowerCase()
                                      .includes(
                                        this.state.serachItem.toLocaleLowerCase()
                                      );
                                  }
                                }
                              })
                              .sort((a, b) => {
                                return (
                                  new Date(b.updated_at) -
                                  new Date(a.updated_at)
                                );
                              })
                              .map((item, i) => (
                                <div
                                  onClick={(e) => {
                                    this.viewItem(item);
                                  }}
                                  className={`tl-block  ${
                                    item.id ===
                                    this.props.knowledgeReducer.myKnowledgeArea
                                      .id
                                      ? "active"
                                      : ""
                                  }`}
                                >
                                  <div className="tl-icon">
                                    {item.kind === "qa" ? (
                                      <div
                                        className="cts-avatar"
                                        style={{
                                          backgroundColor: getColors(
                                            item.question
                                          ),
                                        }}
                                      >
                                        <span>
                                          {item.question.substring(0, 2)}
                                        </span>
                                      </div>
                                    ) : (
                                      <div
                                        className="cts-avatar"
                                        style={{
                                          backgroundColor: getColors(
                                            item.question
                                          ),
                                        }}
                                      >
                                        <span>
                                          {item.question.substring(0, 2)}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                  <div
                                    className="tl-cont"
                                    title={item.question}
                                  >
                                    {item.question !== null &&
                                    item.question.length > 20 ? (
                                      <p
                                        style={{
                                          textTransform: "capitalize",
                                        }}
                                        title={item.question}
                                      >
                                        {item.question.substring(0, 20)}
                                        ...
                                        <ReactTooltip
                                          id={item.question}
                                          type="error"
                                          backgroundColor="white"
                                        >
                                          <span>{item.question}</span>
                                        </ReactTooltip>
                                        <span>Category: {item.category}</span>
                                      </p>
                                    ) : (
                                      <p
                                        style={{
                                          textTransform: "capitalize",
                                        }}
                                      >
                                        {item.question}
                                        <span>Category: {item.category}</span>
                                      </p>
                                    )}
                                  </div>
                                </div>
                              ))}
                          </>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  item: state.item,
  skillReducer: state.skillReducer,
  knowledgeReducer: state.knowledgeReducer,
  userReducer: state.userReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getCreatedKnowledge,
    getSharedKnowledge,
    changeKnowledgeView,
    getSkillsFromStore,
    changeViewMode,
    getDraftSkills,
  })
)(SideBar);
