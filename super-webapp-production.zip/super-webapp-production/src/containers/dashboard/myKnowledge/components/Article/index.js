import React, { Component } from "react";
import deleteRed from "../../../../../images/deleteRed.png";
import imagePic from "../../../../../images/image-pic.png";
import video from "../../../../../images/video.png";
import audio from "../../../../../images/audio.png";
import file from "../../../../../images/file-drop.png";
import { connect } from "react-redux";
import { notify } from "../../../../../redux/actions/snack";
import arrow from "../../../../../images/arrow-qst.png";
import send from "../../../../../images/training/send-white.png";
import { v4 as uuid } from "uuid";
import { Editor } from "react-draft-wysiwyg";
import "../../../../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import dottedBg from "../../../../../images/dotted.png";
import Loader from "../../../../../components/loader";
import EmptyLoader from "../../../../../components/emptyLoader";
import Draft from "draft-js";
import ReactTooltip from "react-tooltip";
import { WithContext as ReactTags } from "react-tag-input";
import {
  createArticle,
  getSuggestedTags,
  shareKnowledge,
} from "../../../../../redux/actions/knowledge";
import {
  getCategoriesOfAnOrganization,
  getTeamsOfAnOrganization,
  getMembersOfTeam,
} from "../../../../../redux/actions/organizationAction";
import { getFileUrl } from "../../../../../redux/actions/fileUpload";
import {
  getDraftSkills,
  getSkillsFromStore,
} from "../../../../../redux/actions/skill";
import { loadNotifications } from "../../../../../redux/actions/appActions";

const KeyCodes = {
  comma: 188,
  enter: [10, 13],
};

const delimiters = [...KeyCodes.enter, KeyCodes.comma];

const { EditorState, convertToRaw, convertFromRaw, AtomicBlockUtils } = Draft;

class Article extends Component {
  constructor(props) {
    super(props);
    this.state = {
      alter_questions: [],
      question: "",
      answers: [{ data: null, type: "richText", id: uuid() }],
      visibility: "",
      contentState: null,
      category: "",
      isLoading: false,
      kind: "article",
      isLoadingImage: false,
      editorState: EditorState.createEmpty(),
      showURLInput: false,
      urlValue: "",
      urlType: "",
      isLoadingRichFile: "",
      connectedSkills: "",
      tags: [],
      suggestions: [],
      categoryItems: [],
      skillTags: [],
      helperSkillTags: [],
      urlId: "",
      orgTeams: [],
      suggestionsTeams: [],
      teamTags: [],
      viewOrEdit: "",
      membersEmail: [],
    };

    this.onChange = (editorState) => {
      this.setState({ editorState }, () => {
        let contentState = this.state.editorState.getCurrentContent();
        let contentData = { content: convertToRaw(contentState) };
        contentData["content"] = contentData.content;
        this.updateElement(
          contentData.content,
          this.state.answers,
          this.state.answers[0].id
        );
      });
    };

    this.toggleMediaType = this._toggleMediaType.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleAddition = this.handleAddition.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  componentDidMount() {
    this.props.getCategoriesOfAnOrganization();
    this.props.getDraftSkills("SkillHub");
    this.props.getSkillsFromStore();
    this.props.getTeamsOfAnOrganization();
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      membersOfTeam: nextProps.organizationReducer.teamMembers,
      orgTeams: nextProps.organizationReducer.organizationTeams,
      categoryItems: nextProps.organizationReducer.organizationCategories,
      skillTags: nextProps.skillReducer.skills,
      helperSkillTags: nextProps.skillReducer.draft_skills,
    });
    this.getSuggestion();
  }
  // get suggestions for tag
  getSuggestion = () => {
    var suggestedTagsParsed = [];
    var suggestedTeams = [];
    if (this.state.skillTags) {
      this.state.skillTags.forEach((item, i) => {
        let data = {
          id: `${item.id}`,
          text: item.skill_name,
          type: "automationSkill",
        };
        suggestedTagsParsed.push(data);
      });
    }
    if (this.state.helperSkillTags) {
      this.state.helperSkillTags.forEach((item, i) => {
        let data = { id: `${item.id}`, text: item.SKILL_NAME, type: item.TYPE };
        suggestedTagsParsed.push(data);
      });
    }
    if (this.state.orgTeams) {
      this.state.orgTeams.forEach((item, i) => {
        let data = {
          id: `${item.id}`,
          text: item.name,
          orgId: `${item.organization_id}`,
        };
        suggestedTeams.push(data);
      });
    }

    if (suggestedTeams) {
      this.setState({
        suggestionsTeams: suggestedTeams,
      });
    }
    if (suggestedTagsParsed) {
      this.setState({
        suggestions: suggestedTagsParsed,
      });
    }
  };

  _toggleMediaType(mediaType) {
    this._promptForMedia(mediaType);
  }

  pastedContentBranch(blob, id) {
    if (blob.length > 1) {
    } else {
      this.handleChangeImgFiles(blob[0], id);
    }
  }

  pastedContent(blob, id) {
    if (blob.length > 1) {
    } else {
      this.handleChangeImgOuter(blob[0], id);
    }
  }

  // visiblity for publishing article

  onChangeVisiblity(e) {
    this.setState({
      visibility: e.target.value,
    });
  }

  onDropDownChange(e) {
    this.setState({
      visibility: e,
    });
  }

  addAlternate() {
    this.setState((prevState) => ({
      alter_questions: [
        ...prevState.alter_questions,
        { data: null, type: "text", id: uuid() },
      ],
    }));
  }

  handleChangeCategory(event, index) {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }

  handleChange(i, event) {
    let alter_questions = [...this.state.alter_questions];
    alter_questions[i].data = event.target.value;
    this.setState({ alter_questions });
  }

  removeClick(i) {
    let values = [...this.state.alter_questions];
    let index = i;

    values.splice(index, 1);
    this.setState({ alter_questions: values });
  }

  handleChangeQue(event, index) {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  handleChangeAltQue(event, index) {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }

  handleChangeCat(e) {
    this.setState({
      category: e.target.value,
    });
  }

  getMediaUrl = (key, data) => {
    let editorImageObj = data.entityMap[key];
    const url = editorImageObj.data.src;
    return url;
  };

  updateElement = (value, ans, elementId) => {
    const answers = [...ans];
    let updatedElement;
    this.getUpdatedElement = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type !== "branch") {
          if (ele.id === elemId) {
            updatedElement = ele;
            return;
          }
        }
      });
    };

    this.getUpdatedElement(answers, elementId);
    if (updatedElement) {
      updatedElement.data = value;

      this.setState({ answers });
    }
  };

  validateBlocks = (data) => {
    var validateText = 0;
    data.blocks.map((item) => {
      if (item.text.trim() !== "") {
        validateText++;
      }
    });
    return validateText;
  };
  submitHandler = async (e) => {
    var orgName = null;
    if (this.state.visibility === "") {
      this.props.notify("error", "  Please select the visibility");
      return;
    }

    if (this.state.category == "") {
      this.props.notify("error", "  Please select the category");
      return;
    }
    if (
      this.state.question === null ||
      this.state.question.trim().length === 0
    ) {
      this.props.notify("error", "Title cannot be empty");
      return;
    }

    if (this.state.question.includes("/")) {
      this.props.notify("error", "' / ' is not allowed in title ");
      return;
    }

    if (this.state.answers[0].data) {
      const validateBlocks = this.validateBlocks(this.state.answers[0].data);
      const entityLen = Object.keys(
        this.state.answers[0].data.entityMap
      ).length;

      if (validateBlocks == 0 && entityLen == 0) {
        this.props.notify("error", "Please add answer");
        return;
      } else {
        this.setState({
          isLoading: true,
        });
        var parsedEditorData = [];
        var newAns = [];
        var entityCopy;
        var blocksCopy;
        this.state.answers.map((ans, i) => {
          if (ans.type === "richText") {
            entityCopy = ans.data.entityMap;
            blocksCopy = ans.data.blocks;

            if (ans.data.blocks) {
              ans.data.blocks.forEach((blockAns) => {
                if (blockAns.text !== "") {
                  if (blockAns.text === " ") {
                    blockAns.entityRanges.forEach((en) => {
                      let keyforItem = en.key;
                      let url = this.getMediaUrl(keyforItem, ans.data);
                      if (url) {
                        parsedEditorData.push({
                          data: url,
                          type: "richText",
                          id: ans.id,
                          blockStyle: "",
                          textStyle: "",
                          depth: "",
                        });
                        if (parsedEditorData.length > 0) {
                          parsedEditorData.forEach((p) => {
                            newAns.push(p);
                          });
                        }
                      }
                    });
                  } else {
                    parsedEditorData.push({
                      data: blockAns.text,
                      type: "richText",
                      id: ans.id,
                      blockStyle: blockAns.type,
                      textStyle: blockAns.inlineStyleRanges,
                      depth: blockAns.depth,
                    });

                    if (parsedEditorData.length > 0) {
                      parsedEditorData.forEach((p) => {
                        newAns.push(p);
                      });
                    }
                  }
                }
              });
            }
          }
        });

        let final = {
          answers: parsedEditorData,
          question: this.state.question,
          alter_questions: this.state.alter_questions,
          category: this.state.category,
          kind: "article",
          entityMap: entityCopy,
          blocks: blocksCopy,
          visibility:
            this.state.visibility === "team" ? "self" : this.state.visibility,
          connectedSkills: this.state.tags,
        };
        var createRes = await this.props.createArticle(final);
        if (createRes) {
          if (this.state.visibility === "team") {
            let _id = createRes.data.data.id;
            let _memberEmails = this.state.membersEmail.toString();
            let data = {
              share_to: _memberEmails.trim(),
              view_or_edit_option: this.state.viewOrEdit,
              data: {
                id: createRes.data.data.id,
              },
            };

            const shareResponse = await this.props.shareKnowledge(data);
            if (shareResponse) {
              this.setState({
                isLoading: false,
              });
              this.props.notify(
                "success",
                "Your Note is being processed. You will be notified upon completion."
              );
              this.setState({
                alter_questions: [],
                question: "",
                answers: [{ data: null, type: "richText", id: uuid() }],
                kind: "article",
                editor: false,
                contentState: {},
                category: "",
                editorState: EditorState.createEmpty(),
                connectedSkills: [],
                tags: [],
                visibility: "",
              });
              this.props.loadNotifications(this.props.user);
            }
          } else {
            this.setState({
              isLoading: false,
            });
            this.props.notify(
              "success",
              "Your Note is being processed. You will be notified upon completion."
            );
            this.setState({
              alter_questions: [],
              question: "",
              answers: [{ data: null, type: "richText", id: uuid() }],
              kind: "article",
              editor: false,
              contentState: {},
              category: "",
              editorState: EditorState.createEmpty(),
              connectedSkills: [],
              tags: [],
              visibility: "",
            });
            this.props.loadNotifications(this.props.user);
          }
        } else {
          this.props.notify("error", "Something went wrong !");
        }
      }
    }
  };

  openMediaModal = () => {
    this._promptForMedia();
  };

  _promptForMedia(type) {
    this.setState({
      showURLInput: true,
      urlValue: "",
      urlType: type,
    });
  }

  onURLChange = async (e) => {
    if (
      this.state.urlType.toLowerCase() === e.target.files[0].type.split("/")[0]
    ) {
      this.setState({
        isLoadingRichFile: true,
      });
      let url = await this.props.getFileUrl(e.target.files[0]);
      if (!this.props.fileUploadReducer.isLoading) {
        if (this.props.fileUploadReducer.fileDetails)
          this.setState({
            // urlId: this.props.fileUploadReducer.fileDetails.fileId,
            // urlValue: this.props.fileUploadReducer.fileDetails.fileUrl,
            urlValue: this.props.fileUploadReducer.fileDetails,

            isLoadingRichFile: false,
          });
      }
      this.props.notify("success", "Media Uploaded Succesfully");
    } else {
      if (this.state.urlType === "File") {
        {
          this.setState({
            isLoadingRichFile: true,
          });
          let url = await this.props.getFileUrl(e.target.files[0]);
          if (!this.props.fileUploadReducer.isLoading) {
            if (this.props.fileUploadReducer.fileDetails)
              this.setState({
                urlValue: this.props.fileUploadReducer.fileDetails,

                isLoadingRichFile: false,
              });
          }
          this.props.notify("success", "Media Uploaded Succesfully");
        }
      } else {
        this.props.notify("error", ` Please upload ${this.state.urlType} `);
        return;
      }
    }
  };

  addUrl = (e) => {
    let url = e.target.value;
    let fileType = url.split(".");
    let arrLen = fileType.length - 1;
    let fileExt = fileType[arrLen];
    if (this.state.urlType === "Image") {
      if (
        fileExt === "jpg" ||
        fileExt === "jpeg" ||
        fileExt === "png" ||
        fileExt === "svg"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Image Link!");
      }
    } else if (this.state.urlType === "Video") {
      if (
        fileExt === "mp4" ||
        fileExt === "webm" ||
        fileExt === "ts" ||
        fileExt === "mpeg" ||
        fileExt === "ogv"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Video Link!");
      }
    } else if (this.state.urlType === "Audio") {
      if (
        fileExt === "mp3" ||
        fileExt === "mp4" ||
        fileExt === "m4a" ||
        fileExt === "mpeg"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Audio Link!");
      }
    } else if (this.state.urlType === "File") {
      this.setState({
        urlValue: e.target.value,
      });
    } else {
      this.props.notify("error", "Something went wrong!");
    }
  };
  confirmMedia(e) {
    if (!this.state.urlValue) {
      this.props.notify("error", "Please upload file or add url");
      return;
    }
    const editorState = this.state.editorState;
    const urlValue = this.state.urlValue;
    const urlType = this.state.urlType;
    const urlId = this.state.urlId;
    const contentState = editorState.getCurrentContent();

    const contentStateWithEntity = contentState.createEntity(
      urlType,
      "IMMUTABLE",
      { src: urlValue, height: "auto", width: "auto", id: urlId }
    );

    const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
    const newEditorState = EditorState.set(editorState, {
      currentContent: contentStateWithEntity,
    });

    this.setState({
      editorState: AtomicBlockUtils.insertAtomicBlock(
        newEditorState,
        entityKey,
        " "
      ),
      showURLInput: false,
      urlValue: "",
    });
  }

  handleDelete(i) {
    const { tags } = this.state;
    this.setState({
      tags: tags.filter((tag, index) => index !== i),
    });
  }

  handleAddition(tag) {
    if (this.state.tags.length <= 2) {
      this.state.suggestions.map((item, i) => {
        if (item.text === tag.text) {
          this.setState((state) => ({ tags: [...state.tags, tag] }));
        }
      });
    } else {
      this.props.notify("error", "You can only add 3 tags");
    }
  }

  handleDeleteEmail = (i) => {
    const { teamTags } = this.state;
    this.setState({
      teamTags: teamTags.filter((tag, index) => index !== i),
    });
  };

  addToEmailList = async (id) => {
    var _emailListTeam = this.state.membersEmail;

    const teamData = await this.props.getMembersOfTeam(id);
    if (teamData.length > 0) {
      teamData.map((people, i) => {
        if (!_emailListTeam.includes(people.email))
          _emailListTeam.push(people.email);
      });
    }
  };
  handleAdditionEmail = (tag) => {
    this.state.suggestionsTeams.map((item, i) => {
      if (item.text === tag.text) {
        this.setState((state) => ({
          teamTags: [...state.teamTags, tag],
        }));
        this.addToEmailList(item.id);
      }
    });
  };

  handleDrag(tag, currPos, newPos) {
    const tags = [...this.state.tags];
    const newTags = tags.slice();

    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);

    // re-render
    this.setState({ tags: newTags });
  }

  handleDragTeamOrder = (tag, currPos, newPos) => {
    const teamTags = [...this.state.teamTags];
    const newTags = teamTags.slice();

    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);

    // re-render
    this.setState({ teamTags: newTags });
  };
  validateInput() {
    if (this.state.question && this.state.question.includes("/")) {
      this.props.notify("error", "' / ' are not allowed in title ");
    }
  }

  ViewOrEdit = (e) => {
    if (e.target.value == "ViewAndEdit") {
      this.setState({ viewOrEdit: "viewAndEdit" });
    } else {
      this.setState({ viewOrEdit: "viewOnly" });
    }
  };

  render() {
    const { tags, suggestions, suggestionsTeams, teamTags } = this.state;

    const { editorState } = this.state;

    var editorData;
    if (this.state.answers.length) {
      this.state.answers.map((a, i) => {
        if (a.data !== null && a.type === "richText") {
          editorData = EditorState.createWithContent(convertFromRaw(a.data));
        }
      });
    }

    const handlePastedFiles = async (files) => {
      let url = await this.props.getFileUrl(files[0]);
      if (url) {
        this.setState(
          {
            urlValue: url,
            urlType: "Image",
          },
          () => {
            this.confirmMedia();
          }
        );
        this.props.notify("success", "Media Pasted Succesfully");
      }
    };
    return (
      <div
        className="right-content search-content full-width-chat"
        style={{
          backgroundImage: "url(" + dottedBg + ")",
          backgroundSize: "cover",
        }}
      >
        <div class="chat-col art-chat">
          <div class="knb-title">
            <div class="back-title"></div>

            <div class="upload-publish">
              {/* <button
                class="lg-btn preview-btn"
                data-toggle="modal"
                data-target="#previewModal"
              >
                <img src={visibility} alt="" />
                <span>Preview</span>
              </button> */}

              <button
                class="lg-btn"
                data-toggle="modal"
                data-target="#visibility"
              >
                <img src={send} alt="" />
                <span>Publish</span>
              </button>
            </div>
          </div>

          {this.state.isLoading ? (
            <>
              <Loader
                styles={{ width: "80px", margin: "auto" }}
                root={{ display: "flex" }}
              />
            </>
          ) : (
            <>
              <div class="col-md-12 qa-block">
                <div class="flex-title-cat">
                  {this.state.categoryItems.length ? (
                    <div class="qst-category cat-dropper">
                      <div className="custom-select">
                        <span className="txt-danger">*</span>
                        <select
                          value={this.state.category}
                          onChange={this.handleChangeCat.bind(this)}
                        >
                          <option value="">Please select Category</option>
                          {this.state.categoryItems.map((item, i) => {
                            return <option key={i}>{item.name}</option>;
                          })}
                        </select>
                      </div>
                    </div>
                  ) : (
                    // <div className="dropdown drop-cat">
                    //   <button className="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">{this.state.category ? this.state.category : "Please select Category" }
                    //   <span className="caret"></span></button>
                    //   <ul className="dropdown-menu">
                    //     {this.state.categoryItems.map((item, i) => {
                    //       return <li onClick={this.handleChangeCat.bind(this)} key={i}><a>{item.name}</a></li>;
                    //     })}
                    //   </ul>
                    // </div>
                    <div class="qst-category cat-dropper">
                      <span className="txt-danger">*</span>

                      <input
                        type="text"
                        placeholder="Enter category name"
                        class="ctg-title"
                        name="category"
                        value={this.state.category || ""}
                        onChange={(e) => this.handleChangeCat(e)}
                      ></input>
                    </div>
                  )}

                  <div class="qst-connectedSkill">
                    <ReactTags
                      id="tagSkill"
                      tags={tags}
                      placeholder={
                        "Tag Automation Skill / Helper Skill (optional)"
                      }
                      suggestions={suggestions}
                      handleDelete={this.handleDelete}
                      handleAddition={this.handleAddition}
                      handleDrag={this.handleDrag}
                      minQueryLength={1}
                      maxLength={50}
                      autofocus={true}
                      allowDeleteFromEmptyInput={true}
                      autocomplete={true}
                      readOnly={false}
                      allowUnique={true}
                      allowDragDrop={true}
                      inline={true}
                      allowAdditionFromPaste={true}
                      editable={true}
                      delimiters={delimiters}
                    />
                  </div>
                </div>
                <div class="scrollable qa-inner">
                  <div class="qa-title">{/* <p>1. Question</p> */}</div>
                  <div class="qst-block">
                    <div class="qst-line">
                      {/* <span class="circle-start"></span> */}
                    </div>
                    <div class="qst-input">
                      <div class="label-add">
                        <label>Title</label>
                        <div class="qst-add">
                          <img src="img/info.png" alt="" />
                          <div className="alt-title">
                            <p>Alternative Title</p>
                            <span>
                              Alternative Titles are highly recommended to
                              improve your Super search experience
                            </span>
                          </div>
                          <button onClick={() => this.addAlternate()}>+</button>
                        </div>
                      </div>

                      <div class="qst-input">
                        <span className="txt-danger">*</span>
                        <input
                          id="question"
                          type="text"
                          placeholder="Enter Title "
                          value={this.state.question}
                          name="question"
                          onChange={this.handleChangeQue.bind(this)}
                          onBlur={(e) => {
                            this.validateInput();
                          }}
                        />
                      </div>
                    </div>

                    <div>
                      <div>
                        {this.state.alter_questions.map((el, i) => (
                          <div class="qst-input alternate-qst">
                            <div class="alt-lineQa">
                              <img src={arrow} alt="" />
                            </div>
                            <div className="input-del" key={i}>
                              <div class="qst-input">
                                <input
                                  type="text"
                                  placeholder="Alternative Title (optional)"
                                  value={el.data || ""}
                                  onChange={this.handleChange.bind(this, i)}
                                />
                              </div>
                              <div class="qst-del-alt">
                                <button
                                  onClick={this.removeClick.bind(this, i)}
                                >
                                  <img src={deleteRed} alt="" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div class="your-ans">
                    <div style={{ width: "100%" }}>
                      {this.state.answers.map((subData, index) => {
                        return (
                          <div key={subData.id}>
                            <div class="ans-img">
                              <div class="ans-data text-mandatory">
                                <span className="txt-danger">*</span>
                                <div class="data-extract">
                                  {subData.type === "richText" && (
                                    <>
                                      <div className="RichEditor-root">
                                        <Editor
                                          toolbarOnFocus={true}
                                          wrapperClassName="demo-wrapper"
                                          editorClassName="demo-editor"
                                          blockRendererFn={mediaBlockRenderer}
                                          editorState={this.state.editorState}
                                          onEditorStateChange={this.onChange}
                                          placeholder="Type Something..."
                                          ref="editor"
                                          spellCheck={true}
                                          handlePastedFiles={handlePastedFiles}
                                          hashtag={{
                                            separator: " ",
                                            trigger: "#",
                                          }}
                                          toolbar={{
                                            options: [
                                              "inline",
                                              "blockType",
                                              "fontSize",
                                              "fontFamily",
                                              "list",
                                              "textAlign",
                                              "colorPicker",
                                              "link",
                                              "emoji",
                                              "remove",
                                              "history",
                                            ],
                                          }}
                                        />
                                        <MediaControls
                                          editorState={this.state.editorState}
                                          onToggle={this.toggleMediaType}
                                          onClick={this.openMediaModal.bind(
                                            this,
                                            index
                                          )}
                                        />
                                      </div>

                                      {this.state.showURLInput && (
                                        <React.Fragment>
                                          <div
                                            class="rdw-image-modal"
                                            role="dialog"
                                          >
                                            <div class="rdw-image-modal-header">
                                              <button
                                                type="button"
                                                className="close"
                                                onClick={(e) => {
                                                  this.setState({
                                                    showURLInput: false,
                                                  });
                                                }}
                                              >
                                                &times;
                                              </button>
                                            </div>
                                            <div>
                                              <div class="rdw-image-modal-upload-option">
                                                <label
                                                  for="file"
                                                  class="rdw-image-modal-upload-option-label"
                                                >
                                                  {this.state.urlValue && (
                                                    <React.Fragment>
                                                      {this.state.urlType ===
                                                        "Image" && (
                                                        <img
                                                          src={
                                                            this.state.urlValue
                                                          }
                                                          style={{
                                                            width: "100%",
                                                            height: "100%",
                                                          }}
                                                        ></img>
                                                      )}
                                                      {this.state.urlType ===
                                                        "Video" && (
                                                        <video
                                                          controls
                                                          src={
                                                            this.state.urlValue
                                                          }
                                                          style={{
                                                            width: "100%",
                                                            height: "100%",
                                                          }}
                                                        ></video>
                                                      )}
                                                      {this.state.urlType ===
                                                        "Audio" && (
                                                        <audio
                                                          controls
                                                          src={
                                                            this.state.urlValue
                                                          }
                                                          style={{
                                                            width: "100%",
                                                            height: "100%",
                                                          }}
                                                        ></audio>
                                                      )}
                                                      {this.state.urlType ===
                                                        "File" && (
                                                        <React.Fragment>
                                                          {this.state.urlValue.substring(
                                                            this.state.urlValue.lastIndexOf(
                                                              "/"
                                                            ) + 1
                                                          )}
                                                        </React.Fragment>
                                                      )}
                                                    </React.Fragment>
                                                  )}
                                                  {!this.state.urlValue && (
                                                    <React.Fragment>
                                                      {this.state.urlType ===
                                                        "Image" && (
                                                        <React.Fragment>
                                                          Click to upload image
                                                          file or enter URL
                                                          below
                                                        </React.Fragment>
                                                      )}
                                                      {this.state.urlType ===
                                                        "Video" && (
                                                        <React.Fragment>
                                                          Click to upload video
                                                          file or enter URL
                                                          below
                                                        </React.Fragment>
                                                      )}
                                                      {this.state.urlType ===
                                                        "Audio" && (
                                                        <React.Fragment>
                                                          Click to upload audio
                                                          file or enter URL
                                                          below
                                                        </React.Fragment>
                                                      )}
                                                      {this.state.urlType ===
                                                        "File" && (
                                                        <React.Fragment>
                                                          Click to upload file
                                                          or enter URL below
                                                        </React.Fragment>
                                                      )}
                                                    </React.Fragment>
                                                  )}
                                                </label>
                                              </div>
                                              <input
                                                type="file"
                                                id="file"
                                                class="rdw-image-modal-upload-option-input"
                                                onChange={this.onURLChange.bind(
                                                  this
                                                )}
                                              />
                                            </div>

                                            <div class="rdw-image-modal-url-section-option">
                                              <input
                                                id="url"
                                                class="rdw-image-modal-url-input"
                                                name="urlValue"
                                                defaultValue={
                                                  this.state.urlValue
                                                    ? this.state.urlValue
                                                    : ""
                                                }
                                                placeholder="Enter URL"
                                                onChange={this.addUrl.bind(
                                                  this
                                                )}
                                              />
                                            </div>

                                            <span class="rdw-image-modal-btn-section">
                                              <button
                                                class="btn btn-small btn-primary"
                                                onClick={this.confirmMedia.bind(
                                                  this
                                                )}
                                              >
                                                Add
                                              </button>
                                              <button
                                                class="btn btn-small btn-danger"
                                                data-dismiss="modal"
                                                onClick={(e) => {
                                                  this.setState({
                                                    showURLInput: false,
                                                  });
                                                }}
                                              >
                                                Cancel
                                              </button>
                                            </span>
                                            {this.state.isLoadingRichFile ? (
                                              <div class="rdw-image-modal-spinner">
                                                <div class="rdw-spinner">
                                                  <div class="rdw-bounce1"></div>
                                                  <div class="rdw-bounce2"></div>
                                                  <div class="rdw-bounce3"></div>
                                                </div>
                                              </div>
                                            ) : (
                                              ""
                                            )}
                                          </div>
                                        </React.Fragment>
                                      )}
                                      {this.state.answers.length > 1 ? (
                                        <div class="img-delete1">
                                          <button
                                            class="myBtn"
                                            id="myBtn"
                                            onClick={() =>
                                              this.deleteAnswerField(
                                                null,
                                                null,
                                                index
                                              )
                                            }
                                          >
                                            <img src={deleteRed} alt="" />
                                          </button>
                                        </div>
                                      ) : (
                                        ""
                                      )}
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Preview Modal */}
                  <div
                    className="modal fade qa-modal"
                    id="previewModal"
                    role="dialog"
                  >
                    <div className="modal-dialog modal-lg">
                      <div className="modal-content">
                        <button
                          type="button"
                          className="close"
                          data-dismiss="modal"
                        >
                          &times;
                        </button>

                        <div className="modal-body md-edit">
                          {!this.state ? (
                            <>
                              <EmptyLoader
                                message="Please create article to preview"
                                styles={{ width: "80px", margin: "auto" }}
                                root={{ display: "flex" }}
                              />
                            </>
                          ) : (
                            <>
                              <div class="pm-modal">
                                <div class="knb-title">
                                  {/* <h3>Preview</h3> */}
                                  <div class="flex-qa-title">
                                    <div class="qst-input">
                                      <div className="tl-cont">
                                        <h4>
                                          Title:{" "}
                                          {this.state.question
                                            ? this.state.question
                                            : ""}
                                        </h4>
                                        <span>
                                          Category:{" "}
                                          {this.state.category
                                            ? this.state.category
                                            : ""}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div class="pm-edit-block">
                                  <div class="scrollable qa-inner">
                                    {this.state.alter_questions &&
                                      this.state.alter_questions.map(
                                        (alt, i) => (
                                          <div key={i}>
                                            <div>
                                              <div>
                                                <div className="alt-pm">
                                                  <h5>
                                                    Alternate Title :
                                                    {alt.data ? alt.data : " "}
                                                  </h5>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        )
                                      )}

                                    {!this.state.answers.length == 0 &&
                                      this.state.answers.map(
                                        (subData, index) => {
                                          return (
                                            <div key={index} class="ans-img">
                                              <div class="ans-data">
                                                <div class="data-extract1">
                                                  <div class="in-data">
                                                    {subData.type ===
                                                      "richText" && (
                                                      <>
                                                        {/* {this.openEditor(subData.data)} */}
                                                        {/* <ViewEditor
                                                                                                    blockRendererFn={mediaBlockRenderer}
                                                                                                    editorState={editorData}
                                                                                                /> */}

                                                        <Editor
                                                          toolbarHidden={true}
                                                          editorState={
                                                            editorData
                                                          }
                                                          wrapperClassName="demo-wrapper"
                                                          editorClassName="demo-editor"
                                                          readOnly="true"
                                                          blockRendererFn={
                                                            mediaBlockRenderer
                                                          }
                                                          hashtag={{
                                                            separator: " ",
                                                            trigger: "#",
                                                          }}
                                                          toolbar={{
                                                            options: [
                                                              "inline",
                                                              "blockType",
                                                              "fontSize",
                                                              "fontFamily",
                                                              "list",
                                                              "textAlign",
                                                              "colorPicker",
                                                              "link",
                                                              "emoji",
                                                              "remove",
                                                              "history",
                                                            ],
                                                          }}
                                                        />
                                                      </>
                                                    )}
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          );
                                        }
                                      )}
                                  </div>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Visibility Modal */}
                  <div class="modal fade" id="visibility" role="dialog">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                        >
                          &times;
                        </button>
                        <div class="modal-body vb-modal">
                          <p>Choose Visibility type </p>
                          <div className="d-flex vb-modal-select">
                            <div className="vb-item">
                              <label for="self">
                                <input
                                  type="radio"
                                  id="self"
                                  name="self"
                                  value={"self"}
                                  checked={this.state.visibility === "self"}
                                  onChange={this.onChangeVisiblity.bind(this)}
                                />
                                Self
                              </label>
                            </div>
                            <div className="vb-item">
                              <label for="team">
                                <input
                                  type="radio"
                                  id="team"
                                  name="team"
                                  value={"team"}
                                  checked={this.state.visibility === "team"}
                                  onChange={this.onChangeVisiblity.bind(this)}
                                />
                                Team
                              </label>
                            </div>
                            <div className="vb-item">
                              <label for="organization">
                                <input
                                  type="radio"
                                  id="organization"
                                  name="organization"
                                  value={"organization"}
                                  checked={
                                    this.state.visibility === "organization"
                                  }
                                  onChange={this.onChangeVisiblity.bind(this)}
                                />
                                Organization
                              </label>
                            </div>
                          </div>

                          {this.state.visibility === "team" ? (
                            <React.Fragment>
                              <div className="qst-input email-tags-input">
                                <ReactTags
                                  id="emailTags"
                                  tags={teamTags}
                                  placeholder={"Search Team"}
                                  suggestions={suggestionsTeams}
                                  handleDelete={(e) =>
                                    this.handleDeleteEmail(e)
                                  }
                                  handleAddition={(tag) => {
                                    this.handleAdditionEmail(tag);
                                  }}
                                  handleDrag={(tag, currPos, newPos) => {
                                    this.handleDragTeamOrder(
                                      tag,
                                      currPos,
                                      newPos
                                    );
                                  }}
                                  minQueryLength={1}
                                  maxLength={50}
                                  autofocus={true}
                                  allowDeleteFromEmptyInput={true}
                                  autocomplete={true}
                                  readOnly={false}
                                  allowUnique={true}
                                  allowDragDrop={true}
                                  inline={true}
                                  allowAdditionFromPaste={true}
                                  editable={true}
                                  delimiters={delimiters}
                                />
                              </div>
                              <div
                                className="assign-roles"
                                onChange={(e) => this.ViewOrEdit(e)}
                              >
                                <p>Assign Roles</p>
                                <div className="roles-check">
                                  <label>
                                    <input
                                      type="radio"
                                      value="ViewAndEdit"
                                      name="JustViewOrEdit"
                                    />
                                    <span>View & Edit</span>
                                  </label>
                                  <label>
                                    <input
                                      type="radio"
                                      value="ViewOnly"
                                      name="JustViewOrEdit"
                                    />
                                    <span>View Only</span>
                                  </label>
                                </div>
                              </div>
                            </React.Fragment>
                          ) : (
                            ""
                          )}

                          {/* <input type="radio" id="public" name="public" value={"public"} checked={this.state.visibility === "public"}
                                                        onChange={this.onChangeVisiblity.bind(this)} /> {""}

                                                    <label>Public</label> &nbsp;<br></br> */}

                          {/* <button class="btn filled-btn" data-dismiss="modal" onClick={() => this.getValidation()}>Done</button> */}

                          <button
                            class="btn filled-btn"
                            data-dismiss="modal"
                            onClick={() => this.submitHandler()}
                          >
                            Done
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }
}

function mediaBlockRenderer(block) {
  if (block.getType() === "atomic") {
    return {
      component: Media,
      editable: false,
    };
  }
  return null;
}
const Audio = (props) => {
  return <audio controls src={props.src} style={styles.media} />;
};
const Image = (props) => {
  return <img src={props.src} style={styles.media} />;
};
const Video = (props) => {
  return <video controls src={props.src} style={styles.media} />;
};

const File = (props) => {
  return (
    <a href={props.src} style={styles.media}>
      {props.src.substring(props.src.lastIndexOf("/") + 1)}
    </a>
  );
};
const Media = (props) => {
  const entity = props.contentState.getEntity(props.block.getEntityAt(0));
  const { src } = entity.getData();
  const type = entity.getType();
  let media;
  if (type === "Audio") {
    media = <Audio src={src} />;
  } else if (type === "Image") {
    media = <Image src={src} />;
  } else if (type === "Video") {
    media = <Video src={src} />;
  } else if (type === "File") {
    media = <File src={src} />;
  }
  return media;
};
const styles = {
  root: {
    fontFamily: "'Georgia', serif",
    padding: 20,
    width: 600,
  },
  buttons: {
    marginBottom: 10,
  },
  urlInputContainer: {
    marginBottom: 10,
  },
  urlInput: {
    fontFamily: "'Georgia', serif",
    marginRight: 10,
    padding: 3,
  },
  editor: {
    border: "1px solid #ccc",
    cursor: "text",
    minHeight: 100,
    padding: 10,
  },
  button: {
    marginTop: 10,
    textAlign: "center",
  },
  media: {
    width: "35%",

    whiteSpace: "initial",
  },
};

class StyleButton extends React.Component {
  constructor() {
    super();
    this.onToggle = (e) => {
      e.preventDefault();
      this.props.onToggle(this.props.style);
    };
  }
  render() {
    var editorData;
    if (this.state) {
      this.state.answers.map((a, i) => {
        if (a.type === "richText") {
          editorData = EditorState.createWithContent(convertFromRaw(a.data));
        }
      });
    }

    let className = "RichEditor-styleButton";
    if (this.props.active) {
      className += " RichEditor-activeButton";
    }
    return (
      <span
        className={className}
        onMouseDown={this.onToggle}
        data-tip
        data-for={this.props.label}
      >
        {this.props.src ? <img src={this.props.src} /> : this.props.label}

        <ReactTooltip
          id={this.props.label}
          type="error"
          backgroundColor="black"
        >
          <span>{this.props.label}</span>
        </ReactTooltip>
      </span>
    );
  }
}

const MEDIA_TYPES = [
  { label: "Image", style: "Image", src: imagePic },
  { label: "Video", style: "Video", src: video },
  { label: "Audio", style: "Audio", src: audio },
  { label: "File", style: "File", src: file },
];

const MediaControls = (props) => {
  const { editorState } = props;
  const selection = editorState.getSelection();
  const MediaType = editorState
    .getCurrentContent()
    .getBlockForKey(selection.getStartKey())
    .getType();
  const currentStyle = props.editorState.getCurrentInlineStyle();

  return (
    <div className="RichEditor-controls">
      {MEDIA_TYPES.map((type) => (
        <StyleButton
          src={type.src}
          key={type.label}
          active={currentStyle.has(type.style)}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </div>
  );
};

const mapStateToProps = (state) => ({
  knowledgeReducer: state.knowledgeReducer,
  userReducer: state.userReducer,
  fileUploadReducer: state.fileUploadReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer,
  skillReducer: state.skillReducer,
  notifications: state.appReducer.notifications,
});

export default connect(mapStateToProps, {
  notify,
  getSuggestedTags,
  createArticle,
  getFileUrl,
  getCategoriesOfAnOrganization,
  getDraftSkills,
  getSkillsFromStore,
  loadNotifications,
  getTeamsOfAnOrganization,
  getMembersOfTeam,
  shareKnowledge,
})(Article);
