import React, { Component } from "react";
import { connect } from "react-redux";
import arrow from "../../../../../images/arrow-qst.png";
import { Editor } from "react-draft-wysiwyg";
import "../../../../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import Loader from "../../../../../components/loader";
import EmptyLoader from "../../../../../components/emptyLoader";
import SideBar from "../SideBar";
import deleteRed from "../../../../../images/deleteRed.png";
import imagePic from "../../../../../images/image-pic.png";
import video from "../../../../../images/video.png";
import audio from "../../../../../images/audio.png";
import file from "../../../../../images/file-drop.png";
import url from "../../../../../images/url.png";
import text from "../../../../../images/training/text-edit.png";
import branching from "../../../../../images/branching.png";
import edit from "../../../../../images/edit.png";
import share from "../../../../../images/share.png";

import {
  FacebookIcon,
  FacebookMessengerIcon,
  FacebookShareButton,
  LinkedinIcon,
  LinkedinShareButton,
  TwitterIcon,
  TwitterShareButton,
} from "react-share";

import {
  getSharedKnowledge,
  updateKnowledge,
  getCreatedKnowledge,
  changeViewMode,
  changeKnowledgeView,
  viewKnowledge,
  shareKnowledge,
  deleteKnowledge,
} from "../../../../../redux/actions/knowledge";
import { notify } from "../../../../../redux/actions/snack";
import { getFileUrl } from "../../../../../redux/actions/fileUpload";
import camera3x from "../../../../../images/camera@3x.png";
import TextareaAutosize from "react-textarea-autosize";
import ReactTooltip from "react-tooltip";
import { v4 as uuid } from "uuid";
import Lightbox from "react-image-lightbox";

import "react-image-lightbox/style.css";
import Draft from "draft-js";
import { withRouter } from "react-router";
import { compose } from "redux";
import {
  getDraftSkillsById,
  getDraftSkills,
  deleteDraftSkill,
  updateDraftSkill,
} from "../../../../../redux/actions/skill";
import {
  getCategoriesOfAnOrganization,
  getTeamsOfAnOrganization,
  getMembersOfTeam,
} from "../../../../../redux/actions/organizationAction";
import { WithContext as ReactTags } from "react-tag-input";
import NotFound from "../../../../../components/notFound";

import Zoom from "react-medium-image-zoom";
import "react-medium-image-zoom/dist/styles.css";

const KeyCodes = {
  comma: 188,
  enter: [10, 13],
  tab: 9,
};

const delimiters = [...KeyCodes.enter, KeyCodes.comma, KeyCodes.tab];
const path = window.location.pathname;
const shareUrl = process.env.REACT_APP_WEB_APP_URL + path;
const { EditorState, convertFromRaw, convertToRaw, AtomicBlockUtils } = Draft;
class View extends Component {
  constructor(props) {
    super(props);
    this.state = {
      alter_questions: [],
      question: null,
      answers: [],
      visibility: "",
      contentState: {},
      article: [],
      visible: 10,
      hasMore: true,
      isEditing: false,
      itemDetail: [],
      itemId: "",
      isLoading: true,
      isLoadingImage: false,
      childInner: false,
      qa: [],
      sharedData: [],
      shareEmail: "",
      item: [],
      isUpdating: false,
      kind: "",
      category: "",
      isOpen: false,
      currentIndexRichText: "",
      currentImg: "",
      viewOrEdit: "",
      editorState: EditorState.createEmpty(),
      editorStateEditing: EditorState.createEmpty(),
      showURLInput: false,
      urlValue: "",
      urlType: "",
      isLoadingRichFile: "",
      mediaFilesData: "",
      editorView: false,
      editorViewData: "",
      itemData: [],
      isLoadingView: true,
      tags: [],
      suggestions: [],
      categoryItems: [],
      notFound: false,
      emailData: "",
      membersOfTeam: [],
      orgPeople: [],
      orgTeams: [],
      suggestionsTeams: [],
      teamTags: [],
      shareVisibility: "email",
      membersEmail: [],
    };

    this.onChange = (editorState) => {
      this.setState({ editorState }, () => {
        let contentState = this.state.editorState.getCurrentContent();
        let contentData = { content: convertToRaw(contentState) };

        contentData["content"] = contentData.content;
        this.state.answers.map((subData, id) => {
          if (subData.type === "richText") {
            this.updateElement(
              contentData.content,
              this.state.answers,
              subData.id
            );
          }
        });
      });
    };

    this.onChangeEditor = (editorState) => {
      this.setState({ editorState: editorState });
    };

    this.toggleMediaType = this._toggleMediaType.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleAddition = this.handleAddition.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
    // this.handleInputChange = this.handleInputChange.bind(this);
    this.handleInputBlur = this.handleInputBlur.bind(this);
  }

  componentDidMount = () => {
    this.view();
    this.props.getCategoriesOfAnOrganization();
    this.props.getTeamsOfAnOrganization();
  };

  componentWillReceiveProps(nextProps) {
    this.setState({
      categoryItems: nextProps.organizationReducer.organizationCategories,
      orgPeople: nextProps.organizationReducer.organizationPeople,
      membersOfTeam: nextProps.organizationReducer.teamMembers,
      orgTeams: nextProps.organizationReducer.organizationTeams,
    });
    this.getSuggestion();
  }

  getSuggestion = () => {
    var suggestedTagsParsed = [];
    var suggestedTeams = [];
    if (this.state.orgPeople.length > 0) {
      this.state.orgPeople.forEach((item, i) => {
        let data = { id: `${item.id}`, text: item.name, email: item.email };
        suggestedTagsParsed.push(data);
      });
    }

    if (this.state.orgTeams) {
      this.state.orgTeams.forEach((item, i) => {
        let data = {
          id: `${item.id}`,
          text: item.name,
          orgId: `${item.organization_id}`,
        };
        suggestedTeams.push(data);
      });
    }

    if (suggestedTeams) {
      this.setState({
        suggestionsTeams: suggestedTeams,
      });
    }
    if (suggestedTagsParsed) {
      this.setState({
        suggestions: suggestedTagsParsed,
      });
    }
  };

  view = async () => {
    let viewId = this.props.match.params.id.split("=")[1];
    let viewItemType = this.props.match.params.id.split("=")[0];

    const viewItem = await this.props.viewKnowledge(viewId);
    this.setState({
      isLoadingView: false,
    });
    if (viewItem !== undefined) {
      try {
        if (viewItem.blocks) {
          let newContent = {
            blocks: viewItem.blocks,
            entityMap: viewItem.entityMap,
          };
          this.setState({
            editorState: EditorState.createWithContent(
              convertFromRaw(newContent)
            ),
            editorStateEditing: EditorState.createWithContent(
              convertFromRaw(newContent)
            ),
          });
        } else {
          viewItem.answers.map((item, i) => {
            if (item.type === "richText") {
              this.setState({
                editorState: EditorState.createWithContent(
                  convertFromRaw(item.data)
                ),
                editorStateEditing: EditorState.createWithContent(
                  convertFromRaw(item.data)
                ),
              });
            }
          });
        }

        this.setState({
          itemId: viewId,
          answers: viewItem.answers,
          question: viewItem.question,
          kind: viewItem.kind && viewItem.kind,
          visibility: viewItem.visibility,
          alter_questions: viewItem.alter_questions,
          category: viewItem.category,
          itemData: viewItem,
        });
      } catch (err) {
        this.setState({
          isLoadingView: false,
        });
        this.props.notify("error", "Something went wrong");
      }
    } else {
      this.setState({
        notFound: true,
      });
    }
  };

  _toggleMediaType(mediaType) {
    this._promptForMedia(mediaType);
  }

  openMediaModal = () => {
    this._promptForMedia();
  };

  _promptForMedia(type) {
    this.setState({
      showURLInput: true,
      urlValue: "",
      urlType: type,
    });
  }

  onURLChange = async (e) => {
    if (
      this.state.urlType.toLowerCase() === e.target.files[0].type.split("/")[0]
    ) {
      this.setState({
        isLoadingRichFile: true,
      });
      let url = await this.props.getFileUrl(e.target.files[0]);
      if (url) {
        this.setState({
          urlValue: url,
          isLoadingRichFile: false,
        });
        this.props.notify("success", "Media Uploaded Succesfully");
      }
    } else {
      if (this.state.urlType === "File") {
        {
          this.setState({
            isLoadingRichFile: true,
          });
          let url = await this.props.getFileUrl(e.target.files[0]);
          if (url) {
            this.setState({
              urlValue: url,
              isLoadingRichFile: false,
            });
            this.props.notify("success", "Media Uploaded Succesfully");
          }
        }
      } else {
        this.props.notify("error", ` Please upload ${this.state.urlType} `);
        return;
      }
    }
  };

  addUrl = (e) => {
    let url = e.target.value;
    let fileType = url.split(".");
    let arrLen = fileType.length - 1;
    let fileExt = fileType[arrLen];
    if (this.state.urlType === "Image") {
      if (
        fileExt === "jpg" ||
        fileExt === "jpeg" ||
        fileExt === "png" ||
        fileExt === "svg"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Image Link!");
      }
    } else if (this.state.urlType === "Video") {
      if (
        fileExt === "mp4" ||
        fileExt === "webm" ||
        fileExt === "ts" ||
        fileExt === "mpeg" ||
        fileExt === "ogv"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Video Link!");
      }
    } else if (this.state.urlType === "Audio") {
      if (
        fileExt === "mp3" ||
        fileExt === "mp4" ||
        fileExt === "m4a" ||
        fileExt === "mpeg"
      ) {
        this.setState({
          urlValue: e.target.value,
        });
      } else {
        this.props.notify("error", "Invalid Audio Link!");
      }
    } else if (this.state.urlType === "File") {
      this.setState({
        urlValue: e.target.value,
      });
    } else {
      this.props.notify("error", "Something went wrong!");
    }
  };

  addAlternate() {
    this.setState((prevState) => ({
      alter_questions: [
        ...prevState.alter_questions,
        { data: null, type: "text", id: uuid() },
      ],
    }));
  }

  confirmMedia(e) {
    // e.preventDefault();
    if (!this.state.urlValue) {
      this.props.notify("error", "Please upload file or add url");
      return;
    }
    const editorState = this.state.editorState;
    const urlValue = this.state.urlValue;
    const urlType = this.state.urlType;

    const contentState = editorState.getCurrentContent();

    const contentStateWithEntity = contentState.createEntity(
      urlType,
      "IMMUTABLE",
      { src: urlValue, height: "auto", width: "auto" }
    );

    const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
    const newEditorState = EditorState.set(editorState, {
      currentContent: contentStateWithEntity,
    });

    this.setState(
      {
        editorState: AtomicBlockUtils.insertAtomicBlock(
          newEditorState,
          entityKey,
          " "
        ),
        showURLInput: false,
        urlValue: "",
      },
      () => {
        let mediaData = this.state.editorState.getCurrentContent();
      }
    );
  }

  onDropDownChange(e) {
    this.setState({
      visibility: e,
    });
  }

  setRichTextIndex = (index) => {
    this.setState({
      currentIndexRichText: index,
    });
  };

  handleChangeShare = (e) => {
    this.setState({
      shareEmail: e,
    });
  };

  deleteKnowledge = (id) => {
    this.setState({
      itemDelete: id,
    });
  };

  handleChangeCat(e) {
    this.setState({
      category: e.target.value,
    });
  }

  loadMore() {
    if (this.state.visible === this.state.article.length) {
      this.setState({
        hasMore: false,
      });
    } else {
      if (this.state.hasMore === true) {
        setTimeout(() => {
          this.setState((prev) => {
            return {
              visible: prev.visible + 10,
            };
          });
        }, 500);
      }
    }
  }

  handleChange(i, event) {
    let alter_questions = [...this.state.alter_questions];

    alter_questions[i].data = event.target.value;
    this.setState({ alter_questions });
  }

  handleAnswerChangeOuter = (e, id) => {
    const answers = [...this.state.answers];
    answers.forEach((ele) => {
      if (ele.type === "branch") {
        if (ele.text.id === id) {
          ele.text.data = e;
          this.setState({
            answers,
          });
        }
      }
    });
  };

  handleAnswerChangeRichText(data, elementId) {
    this.updateElement(data, this.state.answers, elementId);
  }

  handleChangeFiles = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        (value.type !== "" && value.type === "application/pdf") ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        value.type === "application/msword"
      ) {
        this.props.notify("info", "Uploading File");

        const fileDetails = await this.props.getFileUrl(value);

        this.updateElement(fileDetails, this.state.answers, elementId);
      } else {
        this.props.notify(
          "error",
          "Only docx, xlxs,pdf are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeFilesOuter = async (value, elementId, index) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        (value.type !== "" && value.type === "application/pdf") ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        value.type === "application/msword"
      ) {
        const fileDetails = await this.props.getFileUrl(value);
        this.props.notify("info", "Uploading File");

        this.updateElement(fileDetails, this.state.answers, elementId);
      } else {
        this.props.notify(
          "error",
          "Only docx, xlxs,pdf are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeFilesInnerBranch = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        (value.type !== "" && value.type === "application/pdf") ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        value.type === "application/msword"
      ) {
        this.props.notify("info", "Uploading File");

        const fileDetails = await this.props.getFileUrl(value);

        this.updateElementBranch(fileDetails, this.state.answers, elementId);
      } else {
        this.props.notify(
          "error",
          "Only docx, xlxs,pdf are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeImgOuter = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "image/jpeg" ||
        value.type === "image/png" ||
        value.type === "image/jpg"
      ) {
        this.props.notify("info", "Uploading Image");

        const fileDetails = await this.props.getFileUrl(value);

        if (fileDetails) {
          this.updateElement(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only jpeg/jpg/png images are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeVidOuter = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "video/mp4" ||
        value.type === "video/ogg" ||
        value.type === "video/mpeg " ||
        value.type === "video/webm" ||
        value.type === "video/quicktime" ||
        value.type === "video/x-msvideo"
      ) {
        this.props.notify("info", "Uploading Video");
        const fileDetails = await this.props.getFileUrl(value);

        if (fileDetails) {
          this.updateElement(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only mp4/webm/mov video formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeAudioOuter = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "audio/mpeg" ||
        value.type === "audio/mp4" ||
        value.type === "audio/x-m4a"
      ) {
        this.props.notify("info", "Uploading Audio");
        const fileDetails = await this.props.getFileUrl(value);

        if (fileDetails) {
          this.updateElement(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only m4a/mp3/mp4 audio formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeImgFiles = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "image/jpeg" ||
        value.type === "image/png" ||
        value.type === "image/jpg"
      ) {
        this.props.notify("info", "Uploading Image");

        const fileDetails = await this.props.getFileUrl(value);

        if (fileDetails) {
          this.updateElementBranch(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only jpeg/jpg/png images are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeVidFiles = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "video/mp4" ||
        value.type === "video/ogg" ||
        value.type === "video/mpeg " ||
        value.type === "video/webm" ||
        value.type === "video/quicktime" ||
        value.type === "video/x-msvideo"
      ) {
        this.props.notify("info", "Uploading Video");

        const fileDetails = await this.props.getFileUrl(value);
        if (fileDetails) {
          this.updateElementBranch(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only mp4/webm/mov video formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeAudioFiles = async (value, elementId) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "audio/mpeg" ||
        value.type === "audio/mp4" ||
        value.type === "audio/x-m4a"
      ) {
        this.props.notify("info", "Uploading Audio");

        const fileDetails = await this.props.getFileUrl(value);

        if (fileDetails) {
          this.updateElementBranch(fileDetails, this.state.answers, elementId);
        }
      } else {
        this.props.notify(
          "error",
          "Only m4a/mp3/mp4 audio formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  openEditor = (editorData) => {
    this.content = editorData;
  };

  handleChangeQue(event, index) {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }

  handleChangeCategory(event, index) {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }

  handleAnswerChange = (value, elementId) => {
    this.updateElement(value, this.state.answers, elementId);
  };

  handleAnswerChange1 = (value, elementId) => {
    this.updateElementBranch(value, this.state.answers, elementId);
  };

  getBranchData = (branchId, elements, field, index, isDelete) => {
    let updateAnswer = [...(elements || [])];
    let branchToUpdate;
    this.getBranch = (branchId, element = []) => {
      return element.forEach((ele) => {
        if (ele.type === "branch") {
          if (ele.text.id === branchId) {
            branchToUpdate = ele.text;
            return;
          }
          return this.getBranch(branchId, ele.text.child);
        }
      });
    };

    this.getBranch(branchId, updateAnswer);

    if (isDelete) {
      branchToUpdate && branchToUpdate.child.splice(index, 1);
    } else {
      const fieldNode = this.generateFeild(field, branchId);

      branchToUpdate && branchToUpdate.child.splice(index + 1, 0, fieldNode);
    }

    return updateAnswer;
  };

  getBranchDataChild = (
    branchId,
    elements,
    field,
    index,
    isDelete,
    childId
  ) => {
    let updateAnswer = [...(elements || [])];
    let branchToUpdate;
    this.getBranch = (branchId, element = []) => {
      return element.forEach((ele) => {
        if (ele.type === "branch") {
          if (ele.text.id === branchId) {
            // branchToUpdate = ele.text;
            return this.getBranchChild(childId, ele.text.child);
          }
          return this.getBranch(branchId, ele.text.child);
        }
      });
    };

    this.getBranchChild = (childId, element = []) => {
      return element.forEach((ele, i) => {
        if (ele.id === childId) {
          if (field === "branch") {
            if (isDelete) {
              branchToUpdate = element;
              return;
            } else {
              branchToUpdate = ele;
              return;
            }
          } else {
            branchToUpdate = element;
            return;
          }
        }
        return this.getBranchChild(childId, ele.child);
      });
    };
    this.getBranchChild(childId, updateAnswer);
    this.getBranch(branchId, updateAnswer);

    if (isDelete) {
      if (branchToUpdate[0].child && branchToUpdate[0].child.length > 0) {
        branchToUpdate.pop();
      }

      branchToUpdate.forEach((ele, i) => {
        if (ele.id === childId) {
          if (ele.child && ele.child.length !== 0) {
            branchToUpdate.splice(i, 1);
          } else {
            branchToUpdate.splice(i, 1);
          }
        }
      });
    } else {
      const fieldNode = this.generateFeild(field, branchId);
      if (field === "branch") {
        let newFieldNode = { data: null, type: "text", id: uuid() };

        branchToUpdate.child = [newFieldNode];
      } else {
        branchToUpdate && branchToUpdate.splice(index + 1, 0, fieldNode);
      }
    }

    return updateAnswer;
  };

  generateFeild = (field, branchId) => {
    let fieldNode;
    if (field === "branch" && branchId === null) {
      fieldNode = {
        type: "branch",
        text: {
          type: "branch",
          id: uuid(),
          data: null,
          child: [{ data: null, type: "text", id: uuid() }],
        },
      };
    } else if (field === "branch" && branchId !== null) {
      fieldNode = { child: [{ data: null, type: "text", id: uuid() }] };
    } else {
      fieldNode = { data: null, type: field, id: uuid() };
    }
    return fieldNode;
  };

  addAnswerField = (field, branchId, index) => {
    const fieldNode = this.generateFeild(field, branchId);
    if (branchId) {
      const answers = this.getBranchData(
        branchId,
        this.state.answers,
        field,
        index
      );
      this.setState((prevState) => ({
        answers,
      }));
    } else {
      const answers = [...this.state.answers];
      if (answers.length !== 0 && answers.length > index + 1) {
        answers.splice(index + 1, 0, fieldNode);
      } else {
        answers.push(fieldNode);
      }
      this.setState((prevState) => ({
        answers,
      }));
    }
  };

  addAnswerFieldBranch = (field, branchId, index, childId) => {
    const fieldNode = this.generateFeild(field, branchId);
    if (field) {
      const answers = this.getBranchDataChild(
        branchId,
        this.state.answers,
        field,
        index,
        false,
        childId
      );
      this.setState((prevState) => ({
        answers,
      }));
    }
  };

  deleteAnswerField = (field, branchId, index) => {
    if (branchId) {
      const answers = this.getBranchData(
        branchId,
        this.state.answers,
        field,
        index,
        true
      );
      this.setState((prevState) => ({
        answers,
      }));
    } else {
      const answers = [...this.state.answers];
      if (answers.length !== 0 && answers.length > index + 1) {
        answers.splice(index, 1);
      } else {
        answers.pop();
      }
      this.setState((prevState) => ({
        answers,
      }));
    }
  };

  deleteAnswerFieldBranch = (field, branchId, index, childId) => {
    if (branchId) {
      const answers = this.getBranchDataChild(
        branchId,
        this.state.answers,
        "branch",
        index,
        true,
        childId
      );
      this.setState((prevState) => ({
        answers,
      }));
    }
  };

  updateElement = (value, ans, elementId) => {
    const answers = [...ans];
    let updatedElement;
    this.getUpdatedElement = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type !== "branch") {
          if (ele.id === elemId) {
            updatedElement = ele;
            return;
          }
        }
      });
    };

    this.getUpdatedElement(answers, elementId);
    if (updatedElement) {
      // updatedElement.text = value
      updatedElement.data = value;

      //

      this.setState({ answers });
    }
  };

  updateElementBranch = (value, ans, elementId) => {
    const answers = [...ans];
    let updatedElementBranch;
    let updatedElementChildBranch;

    this.getUpdatedElementBranch = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type === "branch") {
          return this.getUpdatedElementBranchChild(ele.text.child, elementId);
        } else {
          if (ele.id === elemId) {
            updatedElementBranch = ele;
            return;
          }
        }
      });
    };

    this.getUpdatedElementBranchChild = (answ, elemId) => {
      answ.forEach((ele) => {
        if (ele.id === elemId) {
          updatedElementChildBranch = ele;
          return;
        } else {
          if (ele.child) {
            this.getUpdatedElementBranchChild(ele.child, elementId);
          }
        }
      });
    };

    this.getUpdatedElementBranch(answers, elementId);
    if (updatedElementBranch) {
      updatedElementBranch.data = value;

      //

      this.setState({ answers });
    }

    this.getUpdatedElementBranchChild(answers, elementId);
    if (updatedElementChildBranch) {
      updatedElementChildBranch.data = value;
      this.setState({ answers });
    }
  };

  ViewOrEdit = (e) => {
    if (e.target.value == "ViewAndEdit") {
      this.setState({ viewOrEdit: "viewAndEdit" });
    } else {
      this.setState({ viewOrEdit: "viewOnly" });
    }
  };

  getValidation = () => {
    let emptyField = null;
    var Answer = [];

    if (this.state.alter_questions.length > 0) {
      this.state.alter_questions.forEach((alt) => {
        if (alt.data === null) {
          this.props.notify("error", "All fields are mandatory");

          emptyField++;
          return;
        } else {
          if (alt.data.trim().length === 0) {
            this.props.notify("error", "Fields cannot be balnk");

            emptyField++;
            return;
          }
        }
      });
    }

    if (this.state.answers.length > 0) {
      this.state.answers.forEach((ans) => {
        if (ans.type === "text") {
          if (ans.data === null) {
            this.props.notify("error", "Text cannot be empty");

            emptyField++;

            return;
          }
          if (ans.data && ans.data.trim().length === 0) {
            this.props.notify("error", "Text cannot be blank");

            emptyField++;

            return;
          }
          if (ans.data === "") {
            this.props.notify("error", "Text cannot be blank");

            emptyField++;

            return;
          }
        }

        // if (ans.type === "richText") {

        //     if (ans.data) {
        //         if (ans.data !== null) {
        //             let richTextLen = ans.data.blocks[0].text
        //             let textWithoutSpace = richTextLen.trim()
        //             if (textWithoutSpace.length === 0) {
        //                 if (ans.data.entityMap.length === 0) {
        //                     this.props.notify("error", " Rich Text cannot be blank")

        //                     emptyField++

        //                     return
        //                 }

        //             }
        //         }

        //     }
        //     else {
        //         this.props.notify("error", "Please add something in rich text editor")

        //         emptyField++
        //         return

        //     }

        // }

        if (
          ans.type === "image" ||
          ans.type === "video" ||
          ans.type === "audio" ||
          ans.type === "file"
        ) {
          if (ans.data === null) {
            this.props.notify("error", "Please select file");
            emptyField++;

            return;
          }
        }

        if (ans.type === "url") {
          //    /^(ht|f)tp(s?)\:\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%\$#_]*)?$/
          var regExpTest =
            /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;
          if (ans.data === null) {
            this.props.notify("error", " URL cannot be empty");

            emptyField++;

            return;
          }
          if (ans.data !== null && ans.data.trim().length === 0) {
            this.props.notify("error", "  URL cannot be blank");

            emptyField++;

            return;
          }

          if (!regExpTest.test(ans.data)) {
            emptyField++;
            this.props.notify("error", "Please enter valid URL");
          }
        }

        if (ans.type === "branch") {
          if (ans.text.data !== null && ans.text.data.trim().length === 0) {
            this.props.notify("error", "Branch Question cannot be blank");

            emptyField++;

            return;
          }
          if (ans.text.data === null) {
            this.props.notify("error", "Branch Question cannot be blank");

            emptyField++;

            return;
          }

          if (ans.text.child.length) {
            let childData = ans.text.child;

            this.branchChildValidation = (childData = []) => {
              return childData.forEach((ch) => {
                if (ch.type === "text") {
                  if (ch.data === null || ch.data.trim().length === 0) {
                    this.props.notify("error", "Fields cannot be blank");

                    emptyField++;
                    return;
                  }
                }

                if (
                  ch.type === "image" ||
                  ch.type === "video" ||
                  ch.type === "audio" ||
                  ch.type === "file"
                ) {
                  if (ch.data === null) {
                    this.props.notify("error", "Please select file");
                    emptyField++;

                    return;
                  }
                }

                if (ch.type === "url") {
                  //    /^(ht|f)tp(s?)\:\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%\$#_]*)?$/
                  var regExpTest =
                    /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;
                  if (ch.data === null) {
                    this.props.notify("error", " URL cannot be empty");

                    emptyField++;

                    return;
                  }
                  if (ch.data !== null && ch.data.trim().length === 0) {
                    this.props.notify("error", "  URL cannot be blank");

                    emptyField++;

                    return;
                  }
                  if (ch.data) {
                    let res = regExpTest.test(ch.data);
                    if (res == false) {
                      emptyField++;
                      this.props.notify("error", "Please enter valid URL");
                    }
                  }
                }

                if (ch.child && ch.child.length > 0) {
                  return this.branchChildValidation(ch.child);
                }
              });
            };

            return this.branchChildValidation(childData);
          }
        }
      });
    } else {
      this.props.notify("error", "  Please add answer");

      emptyField++;
      return;
    }

    return emptyField;
  };

  getMediaUrl = (key, data) => {
    let editorImageObj = data[key];
    const url = editorImageObj.data.src;
    return url;
  };

  removeClick(i) {
    let values = [...this.state.alter_questions];
    let index = i;

    values.splice(index, 1);
    this.setState({ alter_questions: values });
  }

  validateBlocks = (itemData) => {
    var validateText = 0;
    itemData.map((item) => {
      if (item.text.trim() !== "") {
        validateText++;
      }
    });
    return validateText;
  };

  updateStatusEditor = async (itemId) => {
    var contentState = this.state.editorState.getCurrentContent();
    var contentData = { content: convertToRaw(contentState) };
    var parsedEditorData = [];
    var newAns = [];
    var entityCopy = contentData.content.entityMap;
    var blocksCopy = contentData.content.blocks;
    if (this.state.category == "") {
      this.props.notify("error", "  Please select the category");
      return;
    }
    if (
      this.state.question === null ||
      this.state.question.trim().length === 0
    ) {
      this.setState({
        question: this.props.knowledgeReducer.myKnowledgeArea.question,
      });
      this.props.notify("error", "Title cannot be empty");
      return;
    }
    if (this.state.question.includes("/")) {
      this.props.notify("error", "' / ' are not allowed in title ");
      return;
    }

    if (this.state.answers[0].data) {
      const validateBlocks = this.validateBlocks(blocksCopy);
      const entityLen = Object.keys(entityCopy).length;

      if (validateBlocks == 0 && entityLen == 0) {
        this.props.notify("error", "Please add answer");
        return;
      } else {
        this.setState({
          isUpdating: true,
        });

        blocksCopy.forEach((b, index) => {
          if (b.text !== "") {
            if (b.text === " ") {
              b.entityRanges.forEach((en) => {
                let keyforItem = en.key;
                let url = this.getMediaUrl(keyforItem, entityCopy);
                if (url) {
                  parsedEditorData.push({
                    data: url,
                    type: "richText",
                    id: b.key,
                    blockStyle: "",
                    textStyle: "",
                    depth: "",
                  });
                }
              });
            } else {
              parsedEditorData.push({
                data: b.text,
                type: "richText",
                id: b.key,
                blockStyle: b.type,
                textStyle: b.inlineStyleRanges,
                depth: b.depth,
              });
            }
          }
        });

        let finaldata = {
          id: this.state.itemId,
          data: {
            question: this.state.question,
            answers: parsedEditorData,
            alter_questions: this.state.alter_questions,
            category: this.state.category,

            visibility: this.state.visibility,
            entityMap: contentData.content.entityMap,
            blocks: contentData.content.blocks,
          },
        };

        const updateRes = await this.props.updateKnowledge(finaldata);
        if (updateRes) {
          this.setState({
            isUpdating: false,
          });
          this.props.history.push(window.location.pathname);

          this.props.notify("success", "Succesfully Updated!");
        } else {
          this.setState({
            isUpdating: false,
          });
          this.props.notify("error", "Something went wrong.Failed to update!");
        }
      }
    }
  };

  updateStatus = async (taskId) => {
    this.setState({
      isUpdating: true,
    });
    if (
      this.state.question === null ||
      this.state.question.trim().length === 0
    ) {
      this.setState({
        isUpdating: false,
      });

      this.props.notify("error", "Title cannot be empty");
      return;
    }

    if (this.state.answers.data[0] === null) {
      this.setState({
        isUpdating: false,
      });
      this.props.notify("error", "Please add answer");
      return;
    } else {
      var finaldata;
      if (this.state.kind === "helperSkill") {
        var formatSteps = [...this.state.itemData.RAW_DATA.actions];
        formatSteps.forEach((ele, i) => {
          this.state.answers.map((step, i) => {
            const field = {
              actionType: ele.actionType,
              description: step.data,
              text: ele.text,
              timeStamp: ele.timeStamp,
              type: ele.type,
              value: ele.value,
            };
            formatSteps.splice(i, 1, field);
            return;
          });
        });
        finaldata = {
          SKILL_NAME: this.state.question,
          SKILL_DESCRIPTION: this.state.question,
          CATEGORY: this.state.category,
          RAW_DATA: {
            actions: formatSteps,
            type: "record",
            description: this.state.question,
            label: this.state.question,
          },
        };
      } else {
        finaldata = {
          id: this.state.itemId,
          data: {
            question: this.state.question,
            alter_questions: this.state.alter_questions,
            answers: this.state.answers,
            alter_questions: this.state.alter_questions,
            category: this.state.category,

            visibility: this.state.visibility,
          },
        };
      }

      try {
        if (this.state.kind === "helperSkill") {
          const updateHelper = await this.props.updateDraftSkill(
            this.state.itemId,
            { payload: finaldata }
          );
          if (updateHelper) {
            this.props.history.push(window.location.pathname);

            this.setState({
              isUpdating: false,
            });
            this.props.notify("success", "Succesfully Updated!");
          }
        } else {
          const updateRes = await this.props.updateKnowledge(finaldata);
          if (updateRes) {
            this.props.history.push(window.location.pathname);
            this.setState({
              isUpdating: false,
            });
            this.props.notify("success", "Succesfully Updated!");
          }
        }
      } catch (err) {
        this.setState({
          isUpdating: false,
        });
        this.props.notify("error", "Failed to update");
      }
    }
  };

  branchBlock1 = (child, branchId) => {
    if (child.length === 0) return;
    return child.map((childEle, index) => (
      <div key={childEle.id}>
        {childEle.type === "text" && (
          <>
            <div className="br-line">
              <span className="circle-start"></span>
            </div>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <TextareaAutosize
                    minRows={1}
                    maxRows={10}
                    placeholder="Type Something..."
                    defaultValue={childEle.data}
                    onChange={(e) =>
                      this.handleAnswerChange1(e.target.value, childEle.id)
                    }
                  />
                </div>
                {this.dropdownMenuBranch(branchId, index, childEle.id)}

                <div className="img-delete">
                  <button
                    className="myBtn"
                    id="myBtn"
                    onClick={() =>
                      this.deleteAnswerFieldBranch(
                        null,
                        branchId,
                        index,
                        childEle.id
                      )
                    }
                  >
                    <img src={deleteRed} alt="" />
                  </button>
                </div>
              </div>
            </div>
          </>
        )}

        {childEle.type === "image" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />

                  <label for={childEle.id}>
                    <div className="qst-img-video">
                      <div className="image-uploaded img-edit">
                        {childEle.data ? (
                          <>
                            <img src={childEle.data}></img>

                            <div className="upld-hover">
                              <img src={camera3x} alt="" />
                              <input
                                id={childEle.id}
                                accept="image/*"
                                type="file"
                                placeholder="Enter"
                                onChange={(e) =>
                                  this.handleChangeImgFiles(
                                    e.target.files[0],
                                    childEle.id
                                  )
                                }
                                style={{ display: "none" }}
                              />
                            </div>
                          </>
                        ) : (
                          <div className="name-input">
                            {" "}
                            <span> Please Select Image</span>
                            <input
                              id={childEle.id}
                              accept="image/*"
                              type="file"
                              placeholder="Enter"
                              onChange={(e) =>
                                this.handleChangeImgFiles(
                                  e.target.files[0],
                                  childEle.id
                                )
                              }
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  </label>
                  {this.dropdownMenuBranch(branchId, index, childEle.id)}

                  <div className="img-delete">
                    <button
                      className="myBtn"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerFieldBranch(
                          null,
                          branchId,
                          index,
                          childEle.id
                        )
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        {childEle.type === "video" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <label for={childEle.id}>
                    <div className="qst-img-video">
                      <div className="image-uploaded">
                        {childEle.data ? (
                          <video controls src={childEle.data} />
                        ) : (
                          <div className="name-input">
                            {" "}
                            <span> Edit Video </span>
                            <input
                              id={childEle.id}
                              accept="video/*"
                              type="file"
                              placeholder="Enter"
                              onChange={(e) =>
                                this.handleChangeVidFiles(
                                  e.target.files[0],
                                  childEle.id
                                )
                              }
                            />
                          </div>
                        )}
                        <input
                          id={childEle.id}
                          accept="video/*"
                          type="file"
                          placeholder="Enter"
                          onChange={(e) =>
                            this.handleChangeVidFiles(
                              e.target.files[0],
                              childEle.id
                            )
                          }
                          style={{ display: "none" }}
                        />
                      </div>
                    </div>
                    <a className="art-edit">
                      <img src={edit}></img>
                    </a>
                  </label>
                  {this.dropdownMenuBranch(branchId, index, childEle.id)}

                  <div className="img-delete">
                    <button
                      className="myBtn"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerFieldBranch(
                          null,
                          branchId,
                          index,
                          childEle.id
                        )
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </div>
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "audio" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />

                  <label for={childEle.id}>
                    <div className="qst-img-video">
                      <div className="qst-img-video">
                        <div className="image-uploaded">
                          {childEle.data ? (
                            <audio controls src={childEle.data} />
                          ) : (
                            <div className="name-input">
                              <span> Edit Audio </span>
                              <input
                                type="file"
                                accept="audio/*"
                                id={childEle.id}
                                onChange={(e) =>
                                  this.handleChangeAudioFiles(
                                    e.target.files[0],
                                    childEle.id
                                  )
                                }
                              />
                            </div>
                          )}

                          <input
                            type="file"
                            accept="audio/*"
                            id={childEle.id}
                            onChange={(e) =>
                              this.handleChangeAudioFiles(
                                e.target.files[0],
                                childEle.id
                              )
                            }
                            style={{ display: "none" }}
                          />
                        </div>
                      </div>
                    </div>
                    <a className="art-edit">
                      <img src={edit}></img>
                    </a>
                  </label>
                  {this.dropdownMenuBranch(branchId, index, childEle.id)}

                  <div className="img-delete">
                    <button
                      className="myBtn"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerFieldBranch(
                          null,
                          branchId,
                          index,
                          childEle.id
                        )
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </div>
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "file" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <label for="fileInner">
                    <div className="qst-img-video">
                      <div className="image-uploaded">
                        {childEle.data
                          ? childEle.data.substring(
                              childEle.data.lastIndexOf("/") + 1
                            )
                          : ""}
                        <input
                          type="file"
                          id="fileInner"
                          onChange={(e) =>
                            this.handleChangeFilesInnerBranch(
                              e.target.files[0],
                              childEle.id
                            )
                          }
                        />
                      </div>
                    </div>
                  </label>
                  {this.dropdownMenuBranch(branchId, index, childEle.id)}

                  <div className="img-delete">
                    <button
                      className="myBtn"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerFieldBranch(
                          null,
                          branchId,
                          index,
                          childEle.id
                        )
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </div>
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "url" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />

                  <input
                    type="text"
                    defaultValue={childEle.data}
                    onChange={(e) =>
                      this.handleAnswerChange1(e.target.value, childEle.id)
                    }
                  />
                </div>

                {this.dropdownMenuBranch(branchId, index, childEle.id)}

                <div className="img-delete">
                  <button
                    className="myBtn"
                    id="myBtn"
                    onClick={() =>
                      this.deleteAnswerFieldBranch(
                        null,
                        branchId,
                        index,
                        childEle.id
                      )
                    }
                  >
                    <img src={deleteRed} alt="" />
                  </button>
                </div>
              </div>
            </div>{" "}
          </>
        )}

        {childEle.child ? (
          <>
            <div className="br-inside">
              {this.branchBlock1(childEle.child, branchId)}
            </div>
          </>
        ) : (
          <> </>
        )}
      </div>
    ));
  };

  branchBlock = (child) => {
    if (child.length === 0) return;
    return child.map((childEle) => (
      <div>
        {childEle.type === "text" && (
          <>
            <div className="br-line">
              <span className="circle-start"></span>
            </div>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />

                  {childEle.data}
                </div>
              </div>
            </div>
          </>
        )}

        {childEle.type === "image" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <div
                    className="qst-img-video"
                    onClick={() => {
                      this.setState({
                        isOpen: true,
                        currentImg: childEle.data,
                      });
                    }}
                  >
                    <div className="image-uploaded">
                      <img src={childEle.data}></img>
                    </div>
                  </div>

                  {this.state.isOpen && (
                    <Lightbox
                      mainSrc={this.state.currentImg}
                      onCloseRequest={() => this.setState({ isOpen: false })}
                    />
                  )}
                </div>
              </div>
            </div>
          </>
        )}
        {childEle.type === "video" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  {childEle.data ? (
                    <div className="qst-img-video">
                      <div className="image-uploaded">
                        <video controls src={childEle.data} />
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "audio" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <audio controls src={childEle.data} />
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "file" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  {childEle.data ? (
                    <a
                      href={
                        childEle.data
                          ? childEle.data.substring(
                              childEle.data.lastIndexOf("/") + 1
                            )
                          : ""
                      }
                    >
                      {childEle.data.substring(
                        childEle.data.lastIndexOf("/") + 1
                      )}
                    </a>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>{" "}
          </>
        )}
        {childEle.type === "url" && (
          <>
            <div className="br-qst">
              <div className="br-qst-add" style={{ display: "flex" }}>
                <div className="br-arrow">
                  <img src={arrow} alt="" />
                  <a href={childEle.data}>{childEle.data}</a>
                </div>
              </div>
            </div>{" "}
          </>
        )}

        {childEle.child ? (
          <>
            <div className="br-inside">{this.branchBlock(childEle.child)}</div>
          </>
        ) : (
          <> </>
        )}
      </div>
    ));
  };

  dropdownMenu(i, index) {
    return (
      <div>
        <div className="your-ans">
          <div className="dropdown add-qst">
            <button
              className="dropdown-toggle"
              id="outerBlock"
              type="button"
              data-toggle="dropdown"
            >
              +
            </button>

            <ul className="dropdown-menu">
              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("text", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#ffe8c7" }}>
                    <img src={text} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Text</p>
                    <span>Type some Text</span>
                  </div>
                </div>
              </li>

              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("image", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#ffe8c7" }}>
                    <img src={imagePic} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Image</p>

                    <span>Upload and Embed with a link</span>
                  </div>
                </div>
              </li>

              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("video", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#e2efff" }}>
                    <img src={video} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Video</p>
                    <span>Embed from Youtube, Vimeo…</span>
                  </div>
                </div>
              </li>

              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("audio", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#c7ffec" }}>
                    <img src={audio} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Audio</p>
                    <span>Upload and Embed from soundcloud</span>
                  </div>
                </div>
              </li>
              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("file", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#ffe0e0" }}>
                    <img src={file} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>File</p>
                    <span>Upload and Embed file</span>
                  </div>
                </div>
              </li>
              <li>
                <div
                  className="aq-flex"
                  onClick={() => this.addAnswerField("url", i, index)}
                >
                  <div className="aq-icon" style={{ background: "#e0f9ff" }}>
                    <img src={url} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>URL</p>
                    <span>Write url and paste</span>
                  </div>
                </div>
              </li>
              {this.state.kind === "article" ? (
                <li id="branching">
                  <div
                    className="aq-flex"
                    onClick={() => this.addAnswerField("branch", i, index)}
                  >
                    <div className="aq-icon" style={{ background: "#eae0ff" }}>
                      <img src={branching} alt="" />
                    </div>
                    <div className="aq-text">
                      <p>Branching</p>

                      <span>Create a simple Branching</span>
                    </div>
                  </div>
                </li>
              ) : (
                ""
              )}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  dropdownMenuBranch(i, index, childId) {
    return (
      <div>
        <div className="your-ans">
          <div className="dropdown add-qst">
            <button
              className="dropdown-toggle"
              id="outerBlock"
              type="button"
              data-toggle="dropdown"
            >
              +
            </button>

            <ul className="dropdown-menu">
              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("text", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#ffe8c7" }}>
                    <img src={text} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Text</p>
                    <span>Type some Text</span>
                  </div>
                </div>
              </li>
              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("image", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#ffe8c7" }}>
                    <img src={imagePic} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Image</p>

                    <span>Upload and Embed with a link</span>
                  </div>
                </div>
              </li>

              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("video", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#e2efff" }}>
                    <img src={video} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Video</p>
                    <span>Embed from Youtube, Vimeo…</span>
                  </div>
                </div>
              </li>

              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("audio", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#c7ffec" }}>
                    <img src={audio} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Audio</p>
                    <span>Upload and Embed from soundcloud</span>
                  </div>
                </div>
              </li>
              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("file", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#ffe0e0" }}>
                    <img src={file} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>File</p>
                    <span>Upload and Embed file</span>
                  </div>
                </div>
              </li>
              <li>
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("url", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#e0f9ff" }}>
                    <img src={url} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>URL</p>
                    <span>Write url and paste</span>
                  </div>
                </div>
              </li>
              <li id="branching">
                <div
                  className="aq-flex"
                  onClick={() =>
                    this.addAnswerFieldBranch("branch", i, index, childId)
                  }
                >
                  <div className="aq-icon" style={{ background: "#eae0ff" }}>
                    <img src={branching} alt="" />
                  </div>
                  <div className="aq-text">
                    <p>Branching</p>

                    <span>Create a simple Branching</span>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  openArticle = () => {
    this.props.history.push("/dashboard/createNote");
  };
  // openQa = () => {
  //   this.props.history.push("/dashboard/knowledge/createQA");
  // };

  Edit = () => {
    this.setState({
      isEditing: true,
    });
    const editData = this.view();
    if (editData) {
      this.setState({
        isEditing: false,
      });
    }
  };

  updateShareStatusTeam = async () => {
    let _memberEmails = this.state.membersEmail.toString();
    let data = {
      share_to: _memberEmails.trim(),
      view_or_edit_option: this.state.viewOrEdit,
      data: {
        id: this.state.itemId,
      },
    };
    try {
      const shareResponse = await this.props.shareKnowledge(data);
      if (shareResponse) {
        this.props.notify("success", "Sharing success ");
        this.setState({
          teamTags: [],
        });
      }
    } catch (err) {
      this.props.notify("error", "Failed to share");
    }
  };

  updateShareStatus = async (taskId) => {
    var _emailList = [];

    if (!this.state.tags.length > 0 && !this.state.teamTags.length > 0) {
      this.props.notify(
        "error",
        "Please add email by hitting enter or tab or comma"
      );
      return;
    }
    if (!this.state.viewOrEdit) {
      this.props.notify("error", "Please select view or edit");
      return;
    } else {
      this.state.tags.map((item) => {
        if (item.email === this.props.userReducer.user.email) {
          this.props.notify("error", "Please enter different email ! ");
          return;
        } else {
          let reg =
            /^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$/g;
          if (!reg.test(item.email)) {
            this.props.notify("error", "Please enter valid email ! ");
            return;
          } else {
            _emailList.push(item.email);
          }
        }
      });

      let _emailIds = _emailList.length > 0 ? _emailList.toString() : "";

      if (_emailIds !== "") {
        let data = {
          share_to: _emailIds.trim(),
          view_or_edit_option: this.state.viewOrEdit,
          data: {
            id: this.state.itemId,
          },
        };
        try {
          const shareResponse = await this.props.shareKnowledge(data);
          if (shareResponse) {
            this.props.notify("success", "Sharing success ");
            this.setState({
              tags: [],
            });
          }
        } catch (err) {
          this.props.notify("error", "Failed to share");
        }
      }
    }
  };

  deleteMyKnowledge = async (id) => {
    let data = id;
    var datain = await this.props.deleteKnowledge(data);
    if (datain) {
      this.props.notify("success", "Deleted Successfully");
      this.props.history.push("/dashboard/knowledge");
    }
  };

  deleteDraft = async (data) => {
    var datain = await this.props.deleteDraftSkill(data.id);
    if (datain) {
      this.props.notify("success", "Deleted Successfully");
      this.props.history.push("/dashboard/knowledge");
    }
  };

  handleDelete(i) {
    const { tags } = this.state;
    this.setState({
      tags: tags.filter((tag, index) => index !== i),
    });
  }

  handleAddition(tag) {
    if (tag.email) {
      this.setState((state) => ({ tags: [...state.tags, tag], emailData: "" }));
    } else {
      let tagData = { id: uuid(), text: tag.text, email: tag.text };
      this.setState((state) => ({
        tags: [...state.tags, tagData],
        emailData: "",
      }));
    }
  }

  handleDrag(tag, currPos, newPos) {
    const tags = [...this.state.tags];
    const newTags = tags.slice();
    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);
    this.setState({ tags: newTags }); // re-render
  }

  handleInputBlur(tag) {
    if (tag) {
      let tagData = { id: uuid(), text: tag, email: tag };
      this.setState((state) => ({
        tags: [...state.tags, tagData],
      }));
    }
  }

  changeShareVisibility(e) {
    this.setState({
      shareVisibility: e.target.value,
    });
  }

  handleDeleteEmail = (i) => {
    const { teamTags } = this.state;
    this.setState({
      teamTags: teamTags.filter((tag, index) => index !== i),
    });
  };

  addToEmailList = async (id) => {
    var _emailListTeam = this.state.membersEmail;

    const teamData = await this.props.getMembersOfTeam(id);
    if (teamData.length > 0) {
      teamData.map((people, i) => {
        if (!_emailListTeam.includes(people.email))
          _emailListTeam.push(people.email);
      });
    }
  };
  handleAdditionEmail = (tag) => {
    this.state.suggestionsTeams.map((item, i) => {
      if (item.text === tag.text) {
        this.setState((state) => ({
          teamTags: [...state.teamTags, tag],
        }));
        this.addToEmailList(item.id);
      }
    });
  };

  handleDragTeamOrder = (tag, currPos, newPos) => {
    const teamTags = [...this.state.teamTags];
    const newTags = teamTags.slice();

    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);

    // re-render
    this.setState({ teamTags: newTags });
  };

  render() {
    const { tags, suggestions, suggestionsTeams, teamTags } = this.state;
    const handlePastedFiles = async (files) => {
      let url = await this.props.getFileUrl(files[0]);
      if (url) {
        this.setState(
          {
            urlValue: url,
            urlType: "Image",
          },
          () => {
            this.confirmMedia();
          }
        );
        this.props.notify("success", "Media Pasted Succesfully");
      }
    };
    return (
      <React.Fragment>
        {this.state.notFound === true ? (
          <React.Fragment>
            <NotFound />
          </React.Fragment>
        ) : (
          <React.Fragment>
            <div className="fw-screen">
              <div className="chat-col art-chat">
                {this.state.isLoadingView ? (
                  <>
                    <div className="empty-view">
                      <Loader
                        styles={{ width: "80px", margin: "auto" }}
                        root={{ display: "flex" }}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {this.state.itemData.length !== 0 && (
                      <React.Fragment>
                        <div className="knb-title">
                          <div className="flex-qa-title">
                            <div className="qst-input">
                              <div className="tl-cont">
                                <h4 style={{ textTransform: "capitalize" }}>
                                  {this.state.question}
                                </h4>
                                {this.state.question ? (
                                  <>
                                    <span>
                                      Created By:{" "}
                                      {this.state.itemData.created_user
                                        ? this.state.itemData.created_user
                                        : this.state.created_user}
                                    </span>
                                    <span
                                      style={{ textTransform: "capitalize" }}
                                    >
                                      Category:{" "}
                                      {this.state.category
                                        ? this.state.category
                                        : ""}
                                    </span>

                                    {/* <span
                                      style={{ textTransform: "capitalize" }}
                                    >
                                      Type:{" "}
                                      {this.state.itemData.kind
                                        ? this.state.itemData.kind
                                        : this.state.kind}
                                    </span> */}
                                  </>
                                ) : (
                                  ""
                                )}
                              </div>
                            </div>

                            {this.state.itemData.created_user ===
                            this.props.userReducer.user.email ? (
                              <>
                                <div className="btn-flex-item">
                                  <a
                                    className="art-edit"
                                    data-toggle="modal"
                                    data-target="#mytaskModal1"
                                    data-placement="left"
                                    title=""
                                    data-original-title="Edit"
                                    onClick={(e) =>
                                      this.Edit(this.state.itemData.id)
                                    }
                                    data-tip
                                    data-for="edit"
                                  >
                                    <img src={edit} alt="" />
                                  </a>

                                  <ReactTooltip
                                    id="edit"
                                    type="error"
                                    backgroundColor="black"
                                  >
                                    <span>Edit Note</span>
                                  </ReactTooltip>
                                  {this.state.kind === "helperSkill" ? (
                                    <> </>
                                  ) : (
                                    <>
                                      <a
                                        className="art-edit"
                                        data-toggle="modal"
                                        data-target="#mytaskModal2"
                                        data-placement="left"
                                        title=""
                                        data-original-title=""
                                        onClick={(e) =>
                                          this.Edit(this.state.itemData.id)
                                        }
                                        data-tip
                                        data-for="share"
                                      >
                                        <img src={share} alt="" />
                                      </a>
                                      <ReactTooltip
                                        id="share"
                                        type="error"
                                        backgroundColor="black"
                                      >
                                        <span>Share Note</span>
                                      </ReactTooltip>{" "}
                                    </>
                                  )}

                                  <a
                                    className="art-edit"
                                    data-toggle="modal"
                                    data-target="#mytaskModal3"
                                    data-placement="left"
                                    title=""
                                    data-original-title=""
                                    onClick={this.deleteKnowledge.bind(
                                      this,
                                      this.state.itemData
                                    )}
                                  >
                                    <img src={deleteRed} />
                                  </a>
                                </div>
                              </>
                            ) : this.state.itemData.view_or_edit ==
                              "viewAndEdit" ? (
                              <>
                                <div className="btn-flex-item">
                                  <a
                                    className="art-edit"
                                    data-toggle="modal"
                                    data-target="#mytaskModal1"
                                    data-placement="left"
                                    title=""
                                    data-original-title="Edit"
                                    onClick={(e) =>
                                      this.Edit(this.state.itemData.id)
                                    }
                                    data-tip
                                    data-for="edit"
                                  >
                                    <img src={edit} alt="" />
                                  </a>

                                  <ReactTooltip
                                    id="edit"
                                    type="error"
                                    backgroundColor="black"
                                  >
                                    <span>Edit Note</span>
                                  </ReactTooltip>

                                  <a
                                    className="art-edit"
                                    data-toggle="modal"
                                    data-target="#mytaskModal2"
                                    data-placement="left"
                                    title=""
                                    data-original-title=""
                                    onClick={(e) =>
                                      this.Edit(this.state.itemData.id)
                                    }
                                    data-tip
                                    data-for="share"
                                  >
                                    <img src={share} alt="" />
                                  </a>
                                  <ReactTooltip
                                    id="share"
                                    type="error"
                                    backgroundColor="black"
                                  >
                                    <span>Share Note</span>
                                  </ReactTooltip>
                                </div>
                              </>
                            ) : (
                              <> </>
                            )}
                          </div>
                          <div className="btn-right">
                            <div className="dropdown ss-drop-menu">
                              <a
                                className="primary-btn btn-add-q dropdown-toggle"
                                data-toggle="dropdown"
                                aria-expanded="true"
                                data-original-title="Add Note"
                                data-tip
                                data-for="create"
                                onClick={() => this.openArticle()}
                              >
                                +
                              </a>
                              <ReactTooltip
                                id="create"
                                type="error"
                                backgroundColor="black"
                              >
                                <span>Create New Note</span>
                              </ReactTooltip>

                              {/* <ul
                        class="dropdown-menu dropdown-menu-right qa-dropdown"
                        fole="menu"
                      >
                        <li>
                          <a onClick={() => this.openQa()}>Q&amp;A</a>
                        </li>
                        <li>
                          <a onClick={() => this.openArticle()}>Article</a>
                        </li>
                      </ul> */}
                            </div>
                          </div>
                        </div>
                        <div className="col-md-12 qa-block">
                          <div className="scrollable qa-inner">
                            {this.state.itemData.blocks ? (
                              <>
                                <div className="ans-img">
                                  <div className="ans-data">
                                    <div className="data-extract1">
                                      <div className="in-data">
                                        <Editor
                                          toolbarHidden={true}
                                          editorState={
                                            this.state.editorStateEditing
                                          }
                                          wrapperClassName="demo-wrapper"
                                          editorClassName="demo-editor"
                                          readOnly="true"
                                          blockRendererFn={mediaBlockRenderer}
                                          hashtag={{
                                            separator: " ",
                                            trigger: "#",
                                          }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </>
                            ) : (
                              <>
                                {this.state.itemData &&
                                  this.state.itemData.answers &&
                                  this.state.itemData.answers.map(
                                    (subData, index) => {
                                      return (
                                        <div key={index}>
                                          <div className="ans-img">
                                            <div className="ans-data">
                                              <div className="data-extract1">
                                                <div className="in-data">
                                                  {subData.type === "text" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      <div className="qst-input">
                                                        <p>{subData.data}</p>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type === "image" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.state
                                                        .isLoadingImage ? (
                                                        <>
                                                          <Loader
                                                            styles={{
                                                              width: "20px",
                                                              margin: "auto",
                                                            }}
                                                            root={{
                                                              display: "flex",
                                                            }}
                                                          />
                                                        </>
                                                      ) : (
                                                        <>
                                                          <div className="qst-img-video">
                                                            <div className="image-uploaded">
                                                              {" "}
                                                              <img
                                                                onClick={() =>
                                                                  this.setState(
                                                                    {
                                                                      isOpen: true,
                                                                      currentImg:
                                                                        subData.data,
                                                                    }
                                                                  )
                                                                }
                                                                src={
                                                                  subData.data
                                                                }
                                                              ></img>
                                                              {this.state
                                                                .isOpen && (
                                                                <Lightbox
                                                                  mainSrc={
                                                                    this.state
                                                                      .currentImg
                                                                  }
                                                                  onCloseRequest={() =>
                                                                    this.setState(
                                                                      {
                                                                        isOpen: false,
                                                                      }
                                                                    )
                                                                  }
                                                                />
                                                              )}
                                                            </div>
                                                          </div>
                                                        </>
                                                      )}
                                                    </>
                                                  )}

                                                  {subData.type === "video" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {subData.data ? (
                                                        <div className="image-uploaded">
                                                          <video
                                                            controls
                                                            src={subData.data}
                                                          />
                                                        </div>
                                                      ) : (
                                                        ""
                                                      )}
                                                    </>
                                                  )}

                                                  {subData.type === "audio" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {subData.data ? (
                                                        <div className="qst-img-video">
                                                          <audio
                                                            controls
                                                            src={subData.data}
                                                          />
                                                        </div>
                                                      ) : (
                                                        ""
                                                      )}
                                                    </>
                                                  )}
                                                  {subData.type === "url" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      <div className="qst-img-video">
                                                        <a
                                                          href={`${subData.data}`}
                                                          target="blank"
                                                        >
                                                          {" "}
                                                          {subData.data}
                                                        </a>
                                                      </div>
                                                    </>
                                                  )}
                                                  {subData.type === "file" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>

                                                      {subData.data ? (
                                                        <div className="qst-img-video">
                                                          <a
                                                            href={
                                                              subData.data
                                                                ? subData.data
                                                                : ""
                                                            }
                                                            target="blank"
                                                          >
                                                            {subData.data
                                                              ? subData.data.substring(
                                                                  subData.data.lastIndexOf(
                                                                    "/"
                                                                  ) + 1
                                                                )
                                                              : ""}
                                                          </a>
                                                        </div>
                                                      ) : (
                                                        ""
                                                      )}
                                                    </>
                                                  )}

                                                  {subData.type ===
                                                    "richText" && (
                                                    <>
                                                      <Editor
                                                        toolbarHidden={true}
                                                        editorState={
                                                          this.state
                                                            .editorDataEditing
                                                        }
                                                        wrapperClassName="demo-wrapper"
                                                        editorClassName="demo-editor"
                                                        readOnly="true"
                                                        blockRendererFn={
                                                          mediaBlockRenderer
                                                        }
                                                        hashtag={{
                                                          separator: " ",
                                                          trigger: "#",
                                                        }}
                                                      />
                                                    </>
                                                  )}

                                                  {subData.type ===
                                                    "branch" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>

                                                      <div className="branching-block">
                                                        <div className="br-block">
                                                          <div className="br-arrow">
                                                            {subData.text.data}
                                                          </div>

                                                          {this.branchBlock(
                                                            [subData.text],
                                                            subData.text.id
                                                          )}
                                                        </div>
                                                      </div>
                                                    </>
                                                  )}
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    }
                                  )}
                              </>
                            )}
                          </div>
                        </div>
                      </React.Fragment>
                    )}
                  </>
                )}

                <div
                  className="modal fade qa-modal"
                  id="mytaskModal1"
                  role="dialog"
                >
                  <div className="modal-dialog modal-lg">
                    <div className="modal-content">
                      <button
                        type="button"
                        className="close"
                        data-dismiss="modal"
                      >
                        &times;
                      </button>
                      <div className="modal-body md-edit">
                        {this.state.isEditing ? (
                          <>
                            <Loader
                              styles={{ width: "80px", margin: "auto" }}
                              root={{ display: "flex" }}
                            />
                          </>
                        ) : (
                          <>
                            {this.state.itemData.blocks ? (
                              <>
                                <h3 className="qa-modal-title">Edit</h3>
                                <div className="title-card md-flex">
                                  <div className="md-edit-title">
                                    <h4>
                                      {this.state.kind === "qa"
                                        ? "Question: "
                                        : "Title"}
                                    </h4>
                                    <TextareaAutosize
                                      minRows={1}
                                      maxRows={10}
                                      placeholder="Type Something..."
                                      defaultValue={this.state.question}
                                      name="question"
                                      onChange={(e) => this.handleChangeQue(e)}
                                    />

                                    <div className="ed-visible">
                                      <h4>Category:</h4>

                                      {this.state.categoryItems.length ? (
                                        <React.Fragment>
                                          <div className="dropdown">
                                            <div className="custom-select">
                                              <select
                                                value={this.state.category}
                                                onChange={this.handleChangeCat.bind(
                                                  this
                                                )}
                                              >
                                                <option value="">
                                                  Please select Category
                                                </option>
                                                {this.state.categoryItems.map(
                                                  (item, i) => {
                                                    return (
                                                      <option key={i}>
                                                        {item.name}
                                                      </option>
                                                    );
                                                  }
                                                )}
                                              </select>
                                            </div>
                                          </div>
                                        </React.Fragment>
                                      ) : (
                                        <React.Fragment>
                                          <input
                                            placeholder="Type Something..."
                                            defaultValue={this.state.category}
                                            name="category"
                                            onChange={(e) =>
                                              this.handleChangeCategory(e)
                                            }
                                          />
                                        </React.Fragment>
                                      )}
                                    </div>
                                    <div className="ed-visible">
                                      <h4>Visiblity:</h4>
                                      {/* {this.state.visibility} */}

                                      <div className="dropdown">
                                        <button
                                          disabled
                                          class="btn btn-primary dropdown-toggle"
                                          type="button"
                                          data-toggle="dropdown"
                                        >
                                          <span
                                            style={{
                                              whiteSpace: "inherit",
                                              color: "black",
                                            }}
                                          >
                                            {this.state.visibility}
                                          </span>
                                          <span className="caret"></span>
                                        </button>
                                        <ul className="dropdown-menu" disabled>
                                          <li
                                            onClick={() =>
                                              this.onDropDownChange("self")
                                            }
                                          >
                                            <span>Self</span>
                                          </li>
                                          <li
                                            onClick={() =>
                                              this.onDropDownChange(
                                                "organization"
                                              )
                                            }
                                          >
                                            <span>Organization</span>
                                          </li>
                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="qst-add edit-qst-add">
                                  <button onClick={() => this.addAlternate()}>
                                    +
                                  </button>
                                  <p>Alternative Title</p>
                                </div>{" "}
                                {this.state.alter_questions &&
                                  this.state.alter_questions.map((alt, i) => (
                                    <div key={i}>
                                      <div>
                                        <div className="title-card md-flex">
                                          <div className="md-title alternate-edit-title">
                                            <div className="input-del edit-alternate">
                                              <input
                                                type="text"
                                                placeholder="Alternative Title "
                                                value={alt.data || ""}
                                                onChange={this.handleChange.bind(
                                                  this,
                                                  i
                                                )}
                                              />

                                              <div className="qst-del-alt">
                                                <button
                                                  onClick={this.removeClick.bind(
                                                    this,
                                                    i
                                                  )}
                                                >
                                                  <img src={deleteRed} alt="" />
                                                </button>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                <Editor
                                  toolbarOnFocus={true}
                                  wrapperClassName="demo-wrapper"
                                  editorClassName="demo-editor"
                                  blockRendererFn={mediaBlockRenderer}
                                  editorState={this.state.editorState}
                                  onEditorStateChange={this.onChangeEditor}
                                  placeholder="Type Something..."
                                  ref={this.textInput}
                                  spellCheck={true}
                                  handlePastedFiles={handlePastedFiles}
                                  toolbar={{
                                    options: [
                                      "inline",
                                      "blockType",
                                      "fontSize",
                                      "fontFamily",
                                      "list",
                                      "textAlign",
                                      "colorPicker",
                                      "link",
                                      "emoji",
                                      "remove",
                                      "history",
                                    ],
                                  }}
                                />
                                {this.state.editorState && (
                                  <MediaControls
                                    editorState={this.state.editorState}
                                    onToggle={this.toggleMediaType}
                                    onClick={this.openMediaModal.bind(this)}
                                  />
                                )}
                                <div className="frm-btns fb-right">
                                  <button
                                    className="btn-outline"
                                    data-dismiss="modal"
                                  >
                                    Cancel
                                  </button>
                                  {this.state.isUpdating === true ? (
                                    <button
                                      className="primary-btn"
                                      data-dismiss="modal"
                                      onClick={() => {
                                        this.updateStatusEditor(
                                          this.state.itemId
                                        );
                                      }}
                                    >
                                      <span>Updating...</span>

                                      {/* <div class="sp sp-circle text-light"></div> */}
                                    </button>
                                  ) : (
                                    <button
                                      className="primary-btn"
                                      data-dismiss="modal"
                                      onClick={() => {
                                        this.updateStatusEditor(
                                          this.state.itemId
                                        );
                                      }}
                                    >
                                      <span>Update</span>
                                    </button>
                                  )}
                                </div>
                              </>
                            ) : (
                              <>
                                <div className="">
                                  <h3 className="qa-modal-title">Edit</h3>
                                  <div className="title-card md-flex">
                                    <div className="md-edit-title">
                                      <h4>
                                        {this.state.kind === "qa"
                                          ? "Question: "
                                          : "Title"}
                                      </h4>
                                      <TextareaAutosize
                                        minRows={1}
                                        maxRows={10}
                                        placeholder="Type Something..."
                                        defaultValue={this.state.question}
                                        name="question"
                                        onChange={(e) =>
                                          this.handleChangeQue(e)
                                        }
                                      />
                                      <div className="ed-category">
                                        <h4>Category:</h4>

                                        {this.state.categoryItems ? (
                                          <React.Fragment>
                                            <div className="qst-category cat-dropper">
                                              <div className="custom-select">
                                                <span className="txt-danger">
                                                  *
                                                </span>
                                                <select
                                                  value={this.state.category}
                                                  onChange={this.handleChangeCat.bind(
                                                    this
                                                  )}
                                                >
                                                  <option value="">
                                                    Please select Category
                                                  </option>
                                                  {this.state.categoryItems.map(
                                                    (item, i) => {
                                                      return (
                                                        <option key={i}>
                                                          {item.name}
                                                        </option>
                                                      );
                                                    }
                                                  )}
                                                </select>
                                              </div>
                                            </div>
                                          </React.Fragment>
                                        ) : (
                                          <React.Fragment>
                                            <input
                                              placeholder="Type Something..."
                                              defaultValue={this.state.category}
                                              name="category"
                                              onChange={(e) =>
                                                this.handleChangeCategory(e)
                                              }
                                            />
                                          </React.Fragment>
                                        )}
                                      </div>
                                      {this.state.kind === "helperSkill" ? (
                                        ""
                                      ) : (
                                        <div className="ed-visible">
                                          <h4>Visiblity:</h4>
                                          <div className="dropdown">
                                            <button
                                              disabled
                                              className="btn btn-primary dropdown-toggle"
                                              type="button"
                                              data-toggle="dropdown"
                                            >
                                              <span
                                                style={{
                                                  whiteSpace: "inherit",
                                                  color: "black",
                                                }}
                                              >
                                                {this.state.visibility}
                                              </span>
                                              <span className="caret"></span>
                                            </button>
                                            <ul className="dropdown-menu">
                                              <li
                                                onClick={() =>
                                                  this.onDropDownChange("self")
                                                }
                                              >
                                                <span>Self</span>
                                              </li>
                                              <li
                                                onClick={() =>
                                                  this.onDropDownChange(
                                                    "organization"
                                                  )
                                                }
                                              >
                                                <span>Organization</span>
                                              </li>
                                            </ul>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </div>

                                  {this.state.alter_questions &&
                                    this.state.alter_questions.map((alt, i) => (
                                      <div>
                                        <div key={i}>
                                          <div className="title-card md-flex">
                                            <div className="md-title">
                                              <h5>
                                                {this.state.kind === "qa"
                                                  ? "Alternative Question"
                                                  : "Alternative Title"}{" "}
                                              </h5>

                                              <TextareaAutosize
                                                minRows={1}
                                                maxRows={10}
                                                placeholder="Type Something..."
                                                defaultValue={alt.data}
                                                onChange={this.handleChange.bind(
                                                  this,
                                                  i
                                                )}
                                              />
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  {this.state.answers &&
                                    this.state.answers.map((subData, index) => {
                                      return (
                                        <div key={subData.id}>
                                          <div className="ans-img">
                                            <div className="ans-data">
                                              <div className="data-extract1">
                                                <div className="in-data">
                                                  {subData.type === "text" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.state.kind ===
                                                      "helperSkill" ? (
                                                        ""
                                                      ) : (
                                                        <>
                                                          {" "}
                                                          {this.dropdownMenu(
                                                            null,
                                                            index
                                                          )}
                                                        </>
                                                      )}

                                                      <div className="qst-input">
                                                        <TextareaAutosize
                                                          minRows={1}
                                                          maxRows={10}
                                                          placeholder="Type Something..."
                                                          defaultValue={
                                                            subData.data
                                                          }
                                                          onChange={(e) =>
                                                            this.handleAnswerChange(
                                                              e.target.value,
                                                              subData.id
                                                            )
                                                          }
                                                        />
                                                      </div>
                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type === "image" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <label for={subData.id}>
                                                        <div className="qst-img-video">
                                                          <div className="image-uploaded img-edit">
                                                            {subData.data ? (
                                                              <>
                                                                <img
                                                                  src={
                                                                    subData.data
                                                                  }
                                                                ></img>

                                                                <div className="upld-hover">
                                                                  <img
                                                                    src={
                                                                      camera3x
                                                                    }
                                                                    alt=""
                                                                  />
                                                                  <input
                                                                    accept="image/*"
                                                                    id={
                                                                      subData.id
                                                                    }
                                                                    type="file"
                                                                    placeholder="Enter"
                                                                    onChange={(
                                                                      e
                                                                    ) =>
                                                                      this.handleChangeImgOuter(
                                                                        e.target
                                                                          .files[0],
                                                                        subData.id
                                                                      )
                                                                    }
                                                                    style={{
                                                                      display:
                                                                        "none",
                                                                    }}
                                                                  />
                                                                </div>
                                                              </>
                                                            ) : (
                                                              <div className="name-input">
                                                                {" "}
                                                                <span>
                                                                  {" "}
                                                                  Please Select
                                                                  Image{" "}
                                                                </span>{" "}
                                                                <input
                                                                  id={
                                                                    subData.id
                                                                  }
                                                                  accept="image/*"
                                                                  type="file"
                                                                  placeholder="Enter"
                                                                  onChange={(
                                                                    e
                                                                  ) =>
                                                                    this.handleChangeImgOuter(
                                                                      e.target
                                                                        .files[0],
                                                                      subData.id
                                                                    )
                                                                  }
                                                                />
                                                              </div>
                                                            )}
                                                          </div>
                                                        </div>
                                                      </label>
                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type === "video" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <label for={subData.id}>
                                                        <div className="qst-img-video">
                                                          <div className="image-uploaded">
                                                            {subData.data ? (
                                                              <video
                                                                controls
                                                                src={
                                                                  subData.data
                                                                }
                                                              />
                                                            ) : (
                                                              <div className="name-input">
                                                                {" "}
                                                                <span>
                                                                  {" "}
                                                                  Please Select
                                                                  Video{" "}
                                                                </span>{" "}
                                                                <input
                                                                  id={
                                                                    subData.id
                                                                  }
                                                                  accept="video/*"
                                                                  type="file"
                                                                  placeholder="Enter"
                                                                  onChange={(
                                                                    e
                                                                  ) =>
                                                                    this.handleChangeVidOuter(
                                                                      e.target
                                                                        .files[0],
                                                                      subData.id
                                                                    )
                                                                  }
                                                                />
                                                              </div>
                                                            )}

                                                            <input
                                                              id={subData.id}
                                                              accept="video/*"
                                                              type="file"
                                                              placeholder="Enter"
                                                              onChange={(e) =>
                                                                this.handleChangeVidOuter(
                                                                  e.target
                                                                    .files[0],
                                                                  subData.id
                                                                )
                                                              }
                                                              style={{
                                                                display: "none",
                                                              }}
                                                            />
                                                          </div>
                                                          <a className="art-edit">
                                                            <img
                                                              src={edit}
                                                            ></img>
                                                          </a>
                                                        </div>
                                                      </label>
                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type === "audio" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <label for={subData.id}>
                                                        <div className="qst-img-video">
                                                          <div className="image-uploaded">
                                                            {subData.data ? (
                                                              <audio
                                                                controls
                                                                src={
                                                                  subData.data
                                                                }
                                                              />
                                                            ) : (
                                                              <div className="name-input">
                                                                {" "}
                                                                <span>
                                                                  {" "}
                                                                  Please Select
                                                                  Audio{" "}
                                                                </span>
                                                                <input
                                                                  id={
                                                                    subData.id
                                                                  }
                                                                  accept="audio/*"
                                                                  type="file"
                                                                  placeholder="Enter"
                                                                  onChange={(
                                                                    e
                                                                  ) =>
                                                                    this.handleChangeAudioOuter(
                                                                      e.target
                                                                        .files[0],
                                                                      subData.id
                                                                    )
                                                                  }
                                                                />
                                                              </div>
                                                            )}

                                                            <input
                                                              id={subData.id}
                                                              accept="audio/*"
                                                              type="file"
                                                              placeholder="Enter"
                                                              onChange={(e) =>
                                                                this.handleChangeAudioOuter(
                                                                  e.target
                                                                    .files[0],
                                                                  subData.id
                                                                )
                                                              }
                                                              style={{
                                                                display: "none",
                                                              }}
                                                            />
                                                          </div>
                                                        </div>
                                                        <a className="art-edit">
                                                          <img src={edit}></img>
                                                        </a>
                                                      </label>

                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}
                                                  {subData.type === "url" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <div className="qst-img-video">
                                                        <input
                                                          type="text"
                                                          defaultValue={
                                                            subData.data
                                                          }
                                                          name="url"
                                                          onChange={(e) =>
                                                            this.handleAnswerChange(
                                                              e.target.value,
                                                              subData.id
                                                            )
                                                          }
                                                        />
                                                      </div>
                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}
                                                  {subData.type === "file" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <label for="fileOuter">
                                                        <div className="qst-img-video">
                                                          <div className="image-uploaded">
                                                            {subData.data ? (
                                                              <a
                                                                href={
                                                                  subData.data
                                                                }
                                                              >
                                                                {" "}
                                                                {subData.data
                                                                  ? subData.data.substring(
                                                                      subData.data.lastIndexOf(
                                                                        "/"
                                                                      ) + 1
                                                                    )
                                                                  : ""}
                                                              </a>
                                                            ) : (
                                                              ""
                                                            )}
                                                            <input
                                                              id="fileOuter"
                                                              type="file"
                                                              placeholder="Enter"
                                                              onChange={(e) =>
                                                                this.handleChangeFilesOuter(
                                                                  e.target
                                                                    .files[0],
                                                                  subData.id
                                                                )
                                                              }
                                                            />
                                                          </div>
                                                        </div>
                                                      </label>

                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type ===
                                                    "richText" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}

                                                      <div className="branching-block">
                                                        <div className="br-block">
                                                          <div className="br-arrow"></div>
                                                          {this.openEditor(
                                                            subData.data
                                                          )}

                                                          <Editor
                                                            wrapperClassName="demo-wrapper"
                                                            editorClassName="demo-editor"
                                                            blockRendererFn={
                                                              mediaBlockRenderer
                                                            }
                                                            editorState={
                                                              this.state
                                                                .editorState
                                                            }
                                                            onEditorStateChange={
                                                              this.onChange
                                                            }
                                                            placeholder="Type Something..."
                                                            ref="editor"
                                                            spellCheck={true}
                                                            handlePastedFiles={
                                                              handlePastedFiles
                                                            }
                                                            toolbar={{
                                                              options: [
                                                                "inline",
                                                                "blockType",
                                                                "fontSize",
                                                                "fontFamily",
                                                                "list",
                                                                "textAlign",
                                                                "colorPicker",
                                                                "link",
                                                                "emoji",
                                                                "remove",
                                                                "history",
                                                              ],
                                                            }}
                                                          />
                                                        </div>
                                                      </div>
                                                      <div className="img-delete1">
                                                        <button
                                                          className="myBtn"
                                                          id="myBtn"
                                                          onClick={() =>
                                                            this.deleteAnswerField(
                                                              null,
                                                              null,
                                                              index
                                                            )
                                                          }
                                                        >
                                                          <img
                                                            src={deleteRed}
                                                            alt=""
                                                          />
                                                        </button>
                                                      </div>
                                                    </>
                                                  )}

                                                  {subData.type ===
                                                    "branch" && (
                                                    <>
                                                      <div className="box-curve">
                                                        <span>{index + 1}</span>
                                                      </div>
                                                      {this.dropdownMenu(
                                                        null,
                                                        index
                                                      )}
                                                      <div className="branching-block">
                                                        <div className="br-block">
                                                          <div className="br-arrow">
                                                            <textarea
                                                              type="textarea"
                                                              defaultValue={
                                                                subData.text
                                                                  .data
                                                                  ? subData.text
                                                                      .data
                                                                  : ""
                                                              }
                                                              onChange={(e) =>
                                                                this.handleAnswerChangeOuter(
                                                                  e.target
                                                                    .value,
                                                                  subData.text
                                                                    .id
                                                                )
                                                              }
                                                            />
                                                            <div className="img-delete1">
                                                              <button
                                                                className="myBtn"
                                                                id="myBtn"
                                                                onClick={() =>
                                                                  this.deleteAnswerField(
                                                                    null,
                                                                    null,
                                                                    index
                                                                  )
                                                                }
                                                              >
                                                                <img
                                                                  src={
                                                                    deleteRed
                                                                  }
                                                                  alt=""
                                                                />
                                                              </button>
                                                            </div>
                                                          </div>

                                                          {this.branchBlock1(
                                                            [subData.text],
                                                            subData.text.id
                                                          )}
                                                        </div>
                                                      </div>
                                                    </>
                                                  )}
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })}

                                  <div className="frm-btns fb-right">
                                    <button
                                      className="btn-outline"
                                      data-dismiss="modal"
                                    >
                                      Cancel
                                    </button>
                                    {this.state.isUpdating === true ? (
                                      <button
                                        className="primary-btn"
                                        onClick={() => {
                                          this.updateStatus(this.state.itemId);
                                        }}
                                      >
                                        <span>Updating...</span>

                                        {/* <div class="sp sp-circle text-light"></div> */}
                                      </button>
                                    ) : (
                                      <button
                                        className="primary-btn"
                                        onClick={() => {
                                          this.updateStatus(this.state.itemId);
                                        }}
                                      >
                                        <span>Update</span>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </>
                            )}

                            {this.state.showURLInput && (
                              <React.Fragment>
                                <div className="rdw-image-modal-edit">
                                  <div className="rdw-image-modal-header">
                                    <button
                                      type="button"
                                      className="close"
                                      data-dismiss="modal"
                                      onClick={(e) => {
                                        this.setState({
                                          showURLInput: false,
                                        });
                                      }}
                                    >
                                      &times;
                                    </button>
                                  </div>
                                  <div>
                                    <div className="rdw-image-modal-upload-option">
                                      <label
                                        for="file"
                                        className="rdw-image-modal-upload-option-label"
                                      >
                                        {this.state.urlValue && (
                                          <React.Fragment>
                                            {this.state.urlType === "Image" && (
                                              <img
                                                src={this.state.urlValue}
                                                style={{
                                                  width: "100%",
                                                  height: "100%",
                                                }}
                                              ></img>
                                            )}
                                            {this.state.urlType === "Video" && (
                                              <video
                                                controls
                                                src={this.state.urlValue}
                                                style={{
                                                  width: "100%",
                                                  height: "100%",
                                                }}
                                              ></video>
                                            )}
                                            {this.state.urlType === "Audio" && (
                                              <audio
                                                controls
                                                src={this.state.urlValue}
                                                style={{
                                                  width: "100%",
                                                  height: "100%",
                                                }}
                                              ></audio>
                                            )}
                                            {this.state.urlType === "File" && (
                                              <React.Fragment>
                                                {this.state.urlValue.substring(
                                                  this.state.urlValue.lastIndexOf(
                                                    "/"
                                                  ) + 1
                                                )}
                                              </React.Fragment>
                                            )}
                                          </React.Fragment>
                                        )}
                                        {!this.state.urlValue && (
                                          <React.Fragment>
                                            {this.state.urlType === "Image" && (
                                              <React.Fragment>
                                                Click to upload image file or
                                                enter URL below
                                              </React.Fragment>
                                            )}
                                            {this.state.urlType === "Video" && (
                                              <React.Fragment>
                                                Click to upload video file or
                                                enter URL below
                                              </React.Fragment>
                                            )}
                                            {this.state.urlType === "Audio" && (
                                              <React.Fragment>
                                                Click to upload audio file or
                                                enter URL below
                                              </React.Fragment>
                                            )}
                                            {this.state.urlType === "File" && (
                                              <React.Fragment>
                                                Click to upload file or enter
                                                URL below
                                              </React.Fragment>
                                            )}
                                          </React.Fragment>
                                        )}
                                      </label>
                                    </div>
                                    <input
                                      type="file"
                                      id="file"
                                      className="rdw-image-modal-upload-option-input"
                                      onChange={this.onURLChange.bind(this)}
                                    />
                                  </div>

                                  <div className="rdw-image-modal-url-section">
                                    <input
                                      className="rdw-image-modal-url-input"
                                      name="url"
                                      placeholder="Enter URL"
                                      defaultValue={
                                        this.state.urlValue
                                          ? this.state.urlValue
                                          : ""
                                      }
                                      onChange={this.addUrl.bind(this)}
                                    />
                                  </div>

                                  <span className="rdw-image-modal-btn-section">
                                    <button
                                      className="rdw-image-modal-btn-add"
                                      onClick={this.confirmMedia.bind(this)}
                                    >
                                      Add
                                    </button>
                                    <button
                                      className="rdw-image-modal-btn"
                                      onClick={() => {
                                        this.setState({ showURLInput: false });
                                      }}
                                    >
                                      Cancel
                                    </button>
                                  </span>
                                  {this.state.isLoadingRichFile ? (
                                    <div className="rdw-image-modal-spinner">
                                      <div className="rdw-spinner">
                                        <div className="rdw-bounce1"></div>
                                        <div className="rdw-bounce2"></div>
                                        <div className="rdw-bounce3"></div>
                                      </div>
                                    </div>
                                  ) : (
                                    ""
                                  )}
                                </div>
                              </React.Fragment>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* share popup modal */}

              {/*  */}

              <div class="modal fade" id="mytaskModal2" role="dialog">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">
                      &times;
                    </button>
                    <div class="modal-body vb-modal">
                      <h4>Share </h4>
                      <div className="d-flex vb-modal-select">
                        <div className="vb-item">
                          <label for="email">
                            <input
                              type="radio"
                              id="email"
                              name="email"
                              value={"email"}
                              checked={this.state.shareVisibility === "email"}
                              onChange={this.changeShareVisibility.bind(this)}
                            />
                            Email
                          </label>
                        </div>
                        <div className="vb-item">
                          <label for="team">
                            <input
                              type="radio"
                              id="team"
                              name="team"
                              value={"team"}
                              checked={this.state.shareVisibility === "team"}
                              onChange={this.changeShareVisibility.bind(this)}
                            />
                            Team
                          </label>
                        </div>
                      </div>

                      <React.Fragment>
                        <div className="qst-input email-tags-input">
                          {this.state.shareVisibility === "team" ? (
                            <ReactTags
                              id="emailTags"
                              tags={teamTags}
                              placeholder={"Search Team"}
                              suggestions={suggestionsTeams}
                              handleDelete={(e) => this.handleDeleteEmail(e)}
                              handleAddition={(tag) => {
                                this.handleAdditionEmail(tag);
                              }}
                              handleDrag={(tag, currPos, newPos) => {
                                this.handleDragTeamOrder(tag, currPos, newPos);
                              }}
                              minQueryLength={1}
                              maxLength={50}
                              autofocus={true}
                              allowDeleteFromEmptyInput={true}
                              autocomplete={true}
                              readOnly={false}
                              allowUnique={true}
                              allowDragDrop={true}
                              inline={true}
                              allowAdditionFromPaste={true}
                              editable={true}
                              delimiters={delimiters}
                            />
                          ) : (
                            <ReactTags
                              inputFieldPosition="top"
                              tags={tags}
                              placeholder={"Type email and hit enter"}
                              suggestions={suggestions}
                              handleDelete={this.handleDelete}
                              handleAddition={this.handleAddition}
                              handleInputBlur={this.handleInputBlur}
                              handleDrag={this.handleDrag}
                              minQueryLength={1}
                              maxLength={50}
                              autofocus={true}
                              allowDeleteFromEmptyInput={true}
                              autocomplete={true}
                              readOnly={false}
                              allowUnique={true}
                              allowDragDrop={true}
                              inline={true}
                              allowAdditionFromPaste={true}
                              editable={true}
                              delimiters={delimiters}
                            />
                          )}
                        </div>
                        <div
                          className="assign-roles"
                          onChange={(e) => this.ViewOrEdit(e)}
                        >
                          <p>Assign Roles</p>
                          <div className="roles-check">
                            <label>
                              <input
                                type="radio"
                                value="ViewAndEdit"
                                name="JustViewOrEdit"
                              />
                              <span>View & Edit</span>
                            </label>
                            <label>
                              <input
                                type="radio"
                                value="ViewOnly"
                                name="JustViewOrEdit"
                              />
                              <span>View Only</span>
                            </label>
                          </div>
                        </div>
                      </React.Fragment>

                      {/* <input type="radio" id="public" name="public" value={"public"} checked={this.state.visibility === "public"}
                                                        onChange={this.onChangeVisiblity.bind(this)} /> {""}

                                                    <label>Public</label> &nbsp;<br></br> */}

                      {/* <button class="btn filled-btn" data-dismiss="modal" onClick={() => this.getValidation()}>Done</button> */}

                      <button
                        class="btn filled-btn"
                        data-dismiss="modal"
                        onClick={() =>
                          this.state.shareVisibility === "email"
                            ? this.updateShareStatus(this.state.itemId)
                            : this.updateShareStatusTeam(this.state.itemId)
                        }
                      >
                        Done
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Delete modal */}
              <div
                className="modal fade qa-modal1"
                id="mytaskModal3"
                role="dialog"
              >
                <div className="modal-dialog modal-sm">
                  <div className="modal-content share-modal">
                    <button
                      type="button"
                      className="close"
                      data-dismiss="modal"
                    >
                      &times;
                    </button>
                    <div className="modal-body">
                      <h3 className="qa-modal-title">Delete</h3>
                      <div>
                        <h5>Please confirm delete action</h5>
                      </div>

                      <div className="frm-btns fb-right">
                        <button className="btn-outline" data-dismiss="modal">
                          Cancel
                        </button>
                        {this.state.kind === "helperSkill" ? (
                          <button
                            className="primary-btn"
                            data-dismiss="modal"
                            onClick={() => {
                              this.deleteDraft(this.state.itemDelete);
                            }}
                          >
                            Delete
                          </button>
                        ) : (
                          <button
                            className="primary-btn"
                            data-dismiss="modal"
                            onClick={() => {
                              this.deleteMyKnowledge(this.state.itemDelete);
                            }}
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>
        )}
      </React.Fragment>
    );
  }
}

function mediaBlockRenderer(block) {
  if (block.getType() === "atomic") {
    return {
      component: Media,
      editable: false,
    };
  }
  return null;
}
const Audio = (props) => {
  return <audio controls src={props.src} style={styles.media} />;
};
const Image = (props) => {
  return (
    <Zoom>
      <span class="rdw-image-alignment rdw-image-center">
        <span class="rdw-image-imagewrapper">
          <img src={props.src} style={styles.media} />
        </span>
      </span>
    </Zoom>
  );
};
const Video = (props) => {
  return <video controls src={props.src} style={styles.media} />;
};

const File = (props) => {
  return (
    <a href={props.src} style={styles.media}>
      {props.src.substring(props.src.lastIndexOf("/") + 1)}
    </a>
  );
};

const Media = (props) => {
  const entity = props.contentState.getEntity(props.block.getEntityAt(0));
  const { src } = entity.getData();
  const type = entity.getType();
  let media;
  if (type === "Audio") {
    media = <Audio src={src} />;
  } else if (type === "Image") {
    media = <Image src={src} />;
  } else if (type === "Video") {
    media = <Video src={src} />;
  } else if (type === "File") {
    media = <File src={src} />;
  }
  return media;
};

class StyleButton extends React.Component {
  constructor() {
    super();
    this.onToggle = (e) => {
      e.preventDefault();
      this.props.onToggle(this.props.style);
    };
  }
  render() {
    let className = "RichEditor-styleButton";
    if (this.props.active) {
      className += " RichEditor-activeButton";
    }
    return (
      <span className={className} onMouseDown={this.onToggle}>
        {/* {this.props.label} */}
        {/* <img src={this.props.src} /> */}

        {this.props.src ? <img src={this.props.src} /> : this.props.label}
      </span>
    );
  }
}

const MEDIA_TYPES = [
  { label: "Image", style: "Image", src: imagePic },
  { label: "Video", style: "Video", src: video },
  { label: "Audio", style: "Audio", src: audio },
  { label: "File", style: "File", src: file },
];

const MediaControls = (props) => {
  const { editorState } = props;

  const selection = editorState.getSelection();
  const MediaType = editorState
    .getCurrentContent()
    .getBlockForKey(selection.getStartKey())
    .getType();
  const currentStyle = props.editorState.getCurrentInlineStyle();
  return (
    <div className="RichEditor-controls">
      {MEDIA_TYPES.map((type) => (
        <StyleButton
          src={type.src}
          key={type.label}
          active={currentStyle.has(type.style)}
          label={type.label}
          onToggle={props.onToggle}
          style={type.style}
        />
      ))}
    </div>
  );
};

const styles = {
  root: {
    fontFamily: "'Georgia', serif",
    padding: 20,
    width: 600,
  },
  buttons: {
    marginBottom: 10,
  },
  urlInputContainer: {
    marginBottom: 10,
  },
  urlInput: {
    fontFamily: "'Georgia', serif",
    marginRight: 10,
    padding: 3,
  },
  editor: {
    border: "1px solid #ccc",
    cursor: "text",
    minHeight: 100,
    padding: 10,
  },
  button: {
    marginTop: 10,
    textAlign: "center",
  },
  media: {
    width: "35%",

    whiteSpace: "initial",
  },
};

const mapStateToProps = (state) => ({
  knowledgeReducer: state.knowledgeReducer,
  userReducer: state.userReducer,
  appReducer: state.appReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getDraftSkillsById,
    changeViewMode,
    changeKnowledgeView,
    updateKnowledge,
    getCreatedKnowledge,
    getSharedKnowledge,
    viewKnowledge,
    getFileUrl,
    shareKnowledge,
    deleteKnowledge,
    notify,
    getDraftSkills,
    deleteDraftSkill,
    updateDraftSkill,
    getCategoriesOfAnOrganization,
    getTeamsOfAnOrganization,
    getMembersOfTeam,
  })
)(View);
