import React, { Component, Fragment } from "react";
import deleteRed from "../../../../../images/deleteRed.png";
import imagePic from "../../../../../images/image-pic.png";
import video from "../../../../../images/video.png";
import audio from "../../../../../images/audio.png";
import file from "../../../../../images/file-drop.png";
import url from "../../../../../images/url.png";
import { connect } from "react-redux";
import { notify } from "../../../../../redux/actions/snack";
import text from "../../../../../images/training/text-edit.png";
import arrow from "../../../../../images/arrow-qst.png";
import send from "../../../../../images/training/send-white.png";
import { v4 as uuid } from "uuid";
import { Editor } from "react-draft-wysiwyg";
import "../../../../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import TextareaAutosize from "react-textarea-autosize";
import dottedBg from "../../../../../images/dotted.png";
import uploadIcon from "../../../../../images/upload-icon.png";

import visibility from "../../../../../images/visibility.png";
import Loader from "../../../../../components/loader";
import EmptyLoader from "../../../../../components/emptyLoader";
import Gluejar from "react-gluejar";
import { getFileUrl } from "../../../../../redux/actions/fileUpload";
import { createQA, uploadQA } from "../../../../../redux/actions/knowledge";
import { getCategoriesOfAnOrganization } from "../../../../../redux/actions/organizationAction";

class QandA extends Component {
  state = {
    questions: [
      {
        id: uuid(),
        question: "",
        answers: [],
        category: "",

        alter_questions: [
          { data: null, type: "text", id: uuid() },
          { data: null, type: "text", id: uuid() }
        ],
        kind: "qa",

        status: "pending",

        visibility: "",
        orgDetails: null
      }
    ],
    visibility: "",
    category: "",
    isLoading: false,
    isLoadingImgAns: false,
    isLoadingImgBranch: false,
    isLoadingVidAns: false,
    isLoadingVidBranch: false,
    error: false,
    isUploading: false,
    uploadPercentage: "",
    uploadLimit: "",
    profilePic: "",
    membership: "",
    categoryItems: []
  };

   componentDidMount() {
    var categoryList = this.props.getCategoriesOfAnOrganization();
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      categoryItems: nextProps.organizationReducer.organizationCategories
    });
  }

  //   Set Qa Limit pending

  removeClickQue(index) {
    const que = [...this.state.questions];

    que.splice(index, 1);
    this.setState({
      questions: que
    });
  }

  removeClick(i, index) {
    const que = [...this.state.questions];
    const questionToUpdate = que[index];
    const altToDelete = questionToUpdate.alter_questions;
    altToDelete.splice(i, 1);

    this.setState({
      questions: que
    });
  }

  addAlternate(index) {
    const alt_fieldNode = { type: "text", id: uuid(), data: null };
    const alt_que = [...this.state.questions];

    const alt_questionToUpdate = alt_que[index];
    const alt_updatedAnswer = [
      ...alt_questionToUpdate.alter_questions,
      alt_fieldNode
    ];

    const alt_updatedQuestion = {
      ...alt_questionToUpdate,
      alter_questions: alt_updatedAnswer
    };
    alt_que.splice(index, 1, alt_updatedQuestion);
    this.setState({
      questions: alt_que
    });
  }

  addQue() {
    this.setState((prevState) => ({
      questions: [
        ...prevState.questions,
        {
          id: uuid(),
          question: "",
          answers: [],
          category: "",
          alter_questions: [],
          kind: "qa",

          status: "pending",
          visibility: ""
        }
      ]
    }));
  }

  pastedContent(blob, id, index) {
    if (blob.length > 1) {
    } else {
      this.handleChangeImgOuter(blob[0], id, index);
    }
  }

  openEditor = (editorData) => {
    this.content = editorData;
  };

  generateFeild = (field) => {
    let fieldNode;
    if (field === "branch") {
      fieldNode = {
        type: "branch",
        data: null,
        child: [{ data: null, type: "text", id: uuid() }],
        id: uuid()
      };
    } else {
      fieldNode = { type: field, id: uuid(), data: null };
    }
    return fieldNode;
  };

  getBranchData = (branchId, elements, field, index, isDelete) => {
    let updateQuestion = [...(elements || [])];
    let branchToUpdate;
    this.getBranch = (branchId, element = []) => {
      return element.forEach((ele) => {
        if (ele.type === "branch") {
          if (ele.id === branchId) {
            branchToUpdate = ele;
            return;
          }
          return this.getBranch(branchId, ele.child);
        }
      });
    };
    this.getBranch(branchId, updateQuestion);

    if (isDelete) {
      branchToUpdate && branchToUpdate.child.splice(index, 1);
    } else {
      const fieldNode = this.generateFeild(field);

      branchToUpdate && branchToUpdate.child.splice(index + 1, 0, fieldNode);
    }

    return updateQuestion;
  };

  addAnswerField = (field, branchId, index, queId, indexAns) => {
    const fieldNode = this.generateFeild(field);

    if (branchId) {
      const que1 = [...this.state.questions];
      let queToUpdate;
      que1.forEach((ele) => {
        if (ele.id === queId) {
          queToUpdate = ele;
          return;
        }
      });

      const questionToUpdate = queToUpdate;
      const branchToUpdate = [...questionToUpdate.answers];

      const answers = this.getBranchData(
        branchId,
        branchToUpdate,
        field,
        index
      );
      this.setState((prevState) => ({
        answers
      }));
    } else {
      const que = [...this.state.questions];

      const questionToUpdate = que[index];

      const currentAnswer = [...questionToUpdate.answers];

      if (currentAnswer.length !== 0) {
        currentAnswer.splice(indexAns + 1, 0, fieldNode);
        this.setState((prevState) => ({
          currentAnswer
        }));
      } else {
        currentAnswer.push(fieldNode);
        this.setState((prevState) => ({
          currentAnswer
        }));
      }
      const updatedQuestion = { ...questionToUpdate, answers: currentAnswer };

      que.splice(index, 1, updatedQuestion);
      this.setState({
        questions: que
      });
    }
  };

  updateElement = (value, ans, elementId, index, questions) => {
    const answers = [...ans];
    let updatedElement;
    this.getUpdatedElement = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type !== "branch") {
          if (ele.id === elemId) {
            updatedElement = ele;
            return;
          }
        } else {
          return this.getUpdatedElement(ele.child, elementId, index);
        }
      });
    };

    this.getUpdatedElement(answers, elementId, index);
    if (updatedElement) {
      updatedElement.data = value;

      const que = [...questions];
      const questionToUpdate = que[index];
      const updatedQuestion = { ...questionToUpdate, answers: answers };
      que.splice(index, 1, updatedQuestion);
      this.setState({
        questions: que
      });
    }
  };

  updateElementAltQue = (value, ans, elementId, index, questions) => {
    const alt_que = [...ans];
    let updatedElement;
    this.getUpdatedElement = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type !== "branch") {
          if (ele.id === elemId) {
            updatedElement = ele;
            return;
          }
        } else {
          return this.getUpdatedElement(ele.child, elementId, index);
        }
      });
    };

    this.getUpdatedElement(alt_que, elementId, index);
    if (updatedElement) {
      if (
        updatedElement.type === "image" ||
        updatedElement.type === "file" ||
        updatedElement.type === "video" ||
        updatedElement.type === "audio"
      ) {
        updatedElement.data = value[0];
        updatedElement.file_name = value[1];
      } else {
        updatedElement.data = value;
      }
      const que = [...questions];
      const questionToUpdate = que[index];
      const updatedQuestion = { ...questionToUpdate, alter_questions: alt_que };
      que.splice(index, 1, updatedQuestion);
      this.setState({
        questions: que
      });
    }
  };

  updateElementBranch = (value, ans, elementId) => {
    const answers = [...ans];
    let updatedElementBranch;
    let updatedElementChildBranch;

    this.getUpdatedElementBranch = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type === "branch") {
          return this.getUpdatedElementBranchChild(ele.child, elementId);
        } else {
          if (ele.id === elemId) {
            updatedElementBranch = ele;
            return;
          }
        }
      });
    };

    this.getUpdatedElementBranchChild = (answ, elemId) => {
      answ.forEach((ele) => {
        if (ele.id === elemId) {
          updatedElementChildBranch = ele;
          return;
        } else {
          if (ele.child) {
            this.getUpdatedElementBranchChild(ele.child, elementId);
          }
        }
      });
    };

    this.getUpdatedElementBranch(answers, elementId);
    if (updatedElementBranch) {
      updatedElementBranch.data = value;

      this.setState({ answers });
    }

    this.getUpdatedElementBranchChild(answers, elementId);
    if (updatedElementChildBranch) {
      updatedElementChildBranch.data = value;
      this.setState({ answers });
    }
  };

  updateElementAltQue = (value, ans, elementId, index, questions) => {
    const alt_que = [...ans];
    let updatedElement;
    this.getUpdatedElement = (answs, elemId) => {
      answs.forEach((ele) => {
        if (ele.type !== "branch") {
          if (ele.id === elemId) {
            updatedElement = ele;
            return;
          }
        } else {
          return this.getUpdatedElement(ele.child, elementId, index);
        }
      });
    };

    this.getUpdatedElement(alt_que, elementId, index);
    if (updatedElement) {
      if (
        updatedElement.type === "image" ||
        updatedElement.type === "file" ||
        updatedElement.type === "video" ||
        updatedElement.type === "audio"
      ) {
        updatedElement.data = value[0];
        updatedElement.file_name = value[1];
      } else {
        updatedElement.data = value;
      }
      const que = [...questions];
      const questionToUpdate = que[index];
      const updatedQuestion = { ...questionToUpdate, alter_questions: alt_que };
      que.splice(index, 1, updatedQuestion);
      this.setState({
        questions: que
      });
    }
  };

  handleAnswerChange = (value, elementId, index) => {
    this.updateElement(
      value,
      [...this.state.questions[index].answers],
      elementId,
      index,
      this.state.questions
    );
  };

  handleAnswerChangeBranchChild = (value, elementId, queId) => {
    const que1 = [...this.state.questions];
    let queToUpdate;
    que1.forEach((ele) => {
      if (ele.id === queId) {
        queToUpdate = ele;
        return;
      }
    });

    const questionToUpdate = queToUpdate;
    const branchToUpdate = [...questionToUpdate.answers];

    this.updateElementBranch(value, branchToUpdate, elementId);
  };

  saveRichText = (data, elementId, index) => {
    this.updateElement(
      data,
      [...this.state.questions[index].answers],
      elementId,
      index,
      this.state.questions
    );
  };

  onContentStateChange = (elementId, index, contentState) => {
    if (contentState !== undefined) {
      this.updateElement(
        contentState,
        [...this.state.questions[index].answers],
        elementId,
        index,
        this.state.questions
      );
    }
  };

  handleAnswerChangeRichText(data, elementId) {
    this.updateElement(data, this.state.answers, elementId);
  }

  handleChangeFilesOuter = async (value, elementId, index) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        (value.type !== "" && value.type === "application/pdf") ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        value.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        value.type === "application/msword"
      ) {
        this.props.notify("info", "Uploading File");

        const fileDetails = await this.props.getFileUrl(value);
        if (!this.props.fileUploadReducer.isLoadingFile) {
          let fileName = this.props.fileUploadReducer.fileDetails;
          this.updateElement(
            fileName,
            [...this.state.questions[index].answers],
            elementId,
            index,
            this.state.questions
          );
        }
      } else {
        this.props.notify(
          "error",
          "Only docx, xlxs,pdf are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeImgOuter = async (value, elementId, index) => {
    if (value) {
      if (
        value.type === "image/jpeg" ||
        value.type === "image/png" ||
        value.type === "image/jpg"
      ) {
        this.props.notify("info", "Uploading Image");

        const fileDetails = await this.props.getFileUrl(value);
        if (!this.props.fileUploadReducer.isLoadingFile) {
          let fileName = this.props.fileUploadReducer.fileDetails;
          this.updateElement(
            fileName,
            [...this.state.questions[index].answers],
            elementId,
            index,
            this.state.questions
          );
        }
      } else {
        this.props.notify(
          "error",
          "Only jpeg/jpg/png images are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeVidOuter = async (value, elementId, index) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "video/mp4" ||
        value.type === "video/ogg" ||
        value.type === "video/mpeg " ||
        value.type === "video/webm" ||
        value.type === "video/quicktime" ||
        value.type === "video/x-msvideo"
      ) {
        this.props.notify("info", "Uploading Video");

        const fileDetails = await this.props.getFileUrl(value);
        if (!this.props.fileUploadReducer.isLoadingFile) {
          let fileName = this.props.fileUploadReducer.fileDetails;
          this.updateElement(
            fileName,
            [...this.state.questions[index].answers],
            elementId,
            index,
            this.state.questions
          );
        }
      } else {
        this.props.notify(
          "error",
          "Only mp4/webm/mov/ogg/mpeg video formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleChangeAudioOuter = async (value, elementId, index) => {
    if (value === undefined) {
      this.props.notify("error", "Please select file");
      return;
    } else {
      if (
        value.type === "audio/mpeg" ||
        value.type === "audio/mp4" ||
        value.type === "audio/x-m4a"
      ) {
        this.props.notify("info", "Uploading Audio");

        const fileDetails = await this.props.getFileUrl(value);

        if (!this.props.fileUploadReducer.isLoadingFile) {
          let fileName = this.props.fileUploadReducer.fileDetails;
          this.updateElement(
            fileDetails,
            [...this.state.questions[index].answers],
            elementId,
            index,
            this.state.questions
          );
        }
      } else {
        this.props.notify(
          "error",
          "Only m4a/mp3/mp4 audio formats are allowed. Failed to Upload"
        );
        return;
      }
    }
  };

  handleQuestionChangeBranchOuter = (value, elementId, index) => {
    this.updateElementBranch(
      value,
      [...this.state.questions[index].answers],
      elementId,
      index,
      this.state.questions
    );
  };

  handleChangeFilesBranchChild = async (value, elementId, queId) => {
    const fileDetails = await this.props.getFileUrl(value);
    if (!this.props.fileUploadReducer.isLoadingFile) {
      var fileName = this.props.fileUploadReducer.fileDetails;
    }

    const que1 = [...this.state.questions];
    let queToUpdate;
    que1.forEach((ele) => {
      if (ele.id === queId) {
        queToUpdate = ele;
        return;
      }
    });

    const questionToUpdate = queToUpdate;
    const branchToUpdate = [...questionToUpdate.answers];

    this.updateElementBranch(fileName, branchToUpdate, elementId);
  };

  handleChangeQue = (event, index) => {
    const que = [...this.state.questions];
    const questionToUpdate = que[index];

    const updatedQuestion = {
      ...questionToUpdate,
      question: event.target.value
    };

    que.splice(index, 1, updatedQuestion);
    this.setState({
      questions: que
    });
  };

  handleAltChange = (value, elementId, index) => {
    this.updateElementAltQue(
      value,
      [...this.state.questions[index].alter_questions],
      elementId,
      index,
      this.state.questions
    );
  };

  deleteAnswerField = (field, branchId, index, indexAns) => {
    if (branchId) {
      const answers = this.getBranchData(
        branchId,
        this.state.currentAnswer,
        field,
        index,
        true
      );
      this.setState((prevState) => ({
        answers
      }));
    } else {
      const que = [...this.state.questions];
      const questionToUpdate = que[index];
      const ansToDelete = questionToUpdate.answers;
      ansToDelete.splice(indexAns, 1);

      this.setState({
        questions: que
      });
    }
  };

  onChangeVisiblity(e) {
    this.setState({
      visibility: e.target.value
    });
  }

  handleCatChange(e) {
    this.setState({
      category: e.target.value
    });
  }

  validateField = () => {
    let emptyField = null;
    if (this.state.questions) {
      let questionToValidate = this.state.questions;
      questionToValidate.forEach((que) => {
        if (que.question !== null && que.question.trim().length === 0) {
          this.props.notify("error", " Question cannot be empty");

          emptyField++;
          return;
        }
        if (que.alter_questions.length > 0) {
          que.alter_questions.forEach((alt) => {
            let test = alt.data;
            if (test !== null) {
              let result = test.trim();
              if (result.length === 0) {
                this.props.notify(
                  "error",
                  " Alternate Question cannot be blank"
                );

                emptyField++;

                return;
              }
            } else {
              this.props.notify("error", " Alternate Question cannot be empty");

              emptyField++;

              return;
            }
          });
        } else {
          if (que.answers.length > 0) {
            que.answers.forEach((qans) => {
              let test = qans.data;

              if (test !== null) {
                let result = test.trim();
                if (result.length === 0) {
                  this.props.notify("error", " Answer cannot be blank");

                  emptyField++;

                  return;
                }
                if (qans.type === "url") {
                  var regExpTest =
                    /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/;

                  if (qans.data.trim().length === 0) {
                    this.props.notify("error", "  URL cannot be blank");

                    emptyField++;

                    return;
                  }
                  if (!regExpTest.test(qans.data)) {
                    this.props.notify("error", "Please enter valid URL");
                    emptyField++;

                    return;
                  }
                }
              } else {
                this.props.notify("error", "  All fields are mandatory");

                emptyField++;

                return;
              }
            });
          } else {
            emptyField++;
            this.props.notify("error", "Please add answer");
            return;
          }
        }
      });
      return emptyField;
    }
  };

  submitHandler = async (e) => {
    const validate = this.validateField();
    var orgName = null;
    if (this.state.visibility === "") {
      this.props.notify("error", "  Please select the visibility");
      return;
    }

    if (this.state.category == "") {
      this.props.notify("error", "  Please select the category");
      return;
    }
    if (validate) {
      return;
    } else {
      this.setState({
        isLoading: true
      });
      const questionsFinal = [...this.state.questions];

      questionsFinal.forEach((ele, i) => {
        if (ele) {
          // ele.orgDetails = orgName;
          ele.visibility = this.state.visibility;
          ele.category = this.state.category;
          ele.answers.map((el, i) => {
            if (el.type === "branch") {
              let field = { type: "branch", data: el };
              ele.answers.splice(i, 1, field);
              return;
            }
          });
          return;
        }
      });
      let resp = await this.props.createQA(questionsFinal);
      this.setState({
        isLoading: false
      });
      if (resp) {
        this.setState({
          questions: [
            {
              id: uuid(),
              question: "",
              answers: [],
              category: null,
              kind: "qa",
              alter_questions: [
                { data: null, type: "text", id: uuid() },
                { data: null, type: "text", id: uuid() }
              ],
              status: "pending",
              visibility: ""
            }
          ],
          visibility: "",
          category: null
        });
      }
    }
  };

  dropdownMenu = (i, index, queId, indexAns) => (
    <div class="dropdown add-qst">
      <button
        class="dropdown-toggle"
        id="outerBlock"
        type="button"
        data-toggle="dropdown"
      >
        +
      </button>
      <ul class="dropdown-menu">
        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("text", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#ffe8c7" }}>
              <img src={text} alt="" />
            </div>
            <div class="aq-text">
              <p>Text</p>
              <span>Type some Text</span>
            </div>
          </div>
        </li>

        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("image", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#ffe8c7" }}>
              <img src={imagePic} alt="" />
            </div>
            <div class="aq-text">
              <p>Image</p>

              <span>Upload and Embed with a link</span>
            </div>
          </div>
        </li>

        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("video", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#e2efff" }}>
              <img src={video} alt="" />
            </div>
            <div class="aq-text">
              <p>Video</p>
              <span>Embed from Youtube, Vimeo…</span>
            </div>
          </div>
        </li>

        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("audio", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#c7ffec" }}>
              <img src={audio} alt="" />
            </div>
            <div class="aq-text">
              <p>Audio</p>
              <span>Upload and Embed from soundcloud</span>
            </div>
          </div>
        </li>
        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("file", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#ffe0e0" }}>
              <img src={file} alt="" />
            </div>
            <div class="aq-text">
              <p>File</p>
              <span>Upload and Embed file</span>
            </div>
          </div>
        </li>
        <li>
          <div
            class="aq-flex"
            onClick={() =>
              this.addAnswerField("url", i, index, queId, indexAns)
            }
          >
            <div class="aq-icon" style={{ background: "#e0f9ff" }}>
              <img src={url} alt="" />
            </div>
            <div class="aq-text">
              <p>URL</p>
              <span>Write url and paste</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  );
  displayQuestion(question = [], index) {
    const queJsx =
      question &&
      question.map((subQue, indexQ) => (
        <div class="qst-input">
          <input
            type="text"
            placeholder="Enter Question "
            name="question"
            onChange={(e) => this.handleChangeQue(e, indexQ)}
          />
        </div>
      ));
    return queJsx;
  }

  branchBlock(data, branchId, queIdBranch) {
    return data.map((subData, index) => (
      <div>
        {subData.type === "branch" ? (
          <div>
            {subData.type === "branch" ? (
              <React.Fragment>
                <div class="br-inside">
                  <div class="br-line">
                    {/* <span class="circle-start"></span> */}
                  </div>
                  {this.branchBlock(subData.child, subData.id, queIdBranch)}
                </div>
              </React.Fragment>
            ) : null}
          </div>
        ) : (
          this.renderAnswerType(subData, branchId, index, queIdBranch)
        )}
      </div>
    ));
  }

  renderAnswerType = (subData, branchId, index, queId) => {
    switch (subData.type) {
      case "text":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />
                <TextareaAutosize
                  minRows={1}
                  maxRows={10}
                  maxCol={200}
                  placeholder="Type Something..."
                  value={subData.data || ""}
                  onChange={(e) =>
                    this.handleAnswerChangeBranchChild(
                      e.target.value,
                      subData.id,
                      queId
                    )
                  }
                />

                {/* <textarea type="text" placeholder="Type Something..." value={subData.data || ''} onChange={(e) => this.handleAnswerChangeBranchChild(e.target.value, subData.id, queId)} /> */}
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() =>
                  this.deleteAnswerField(null, branchId, index, queId)
                }
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
          </div>
        );
      case "image":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />

                <input
                  id="input"
                  type="file"
                  accept="image/*"
                  placeholder="Enter"
                  data={subData.data || ""}
                  onChange={(e) =>
                    this.handleChangeFilesBranchChild(
                      e.target.files[0],
                      subData.id,
                      queId
                    )
                  }
                />
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() => this.deleteAnswerField(null, branchId, index)}
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
            <div class="image-uploaded">
              {subData.data !== null && <img src={subData.data} width="100%" />}
            </div>
          </div>
        );

      case "video":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />

                <input
                  id="input"
                  type="file"
                  placeholder="Enter"
                  data={subData.data || ""}
                  onChange={(e) =>
                    this.handleChangeFilesBranchChild(
                      e.target.files[0],
                      subData.id,
                      queId
                    )
                  }
                />
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() => this.deleteAnswerField(null, branchId, index)}
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
            <div class="image-uploaded">
              {subData.data !== null && (
                <video controls src={subData.data} width="50%" />
              )}
            </div>
          </div>
        );

      case "audio":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />

                <input
                  id="input"
                  type="file"
                  placeholder="Enter"
                  data={subData.data || ""}
                  onChange={(e) =>
                    this.handleChangeFilesBranchChild(
                      e.target.files[0],
                      subData.id,
                      queId
                    )
                  }
                />
                {subData.data !== null && (
                  <audio controls src={subData.data} width="100%" />
                )}
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() => this.deleteAnswerField(null, branchId, index)}
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
          </div>
        );

      case "file":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />

                <input
                  id="input"
                  type="file"
                  placeholder="Enter"
                  data={subData.data || ""}
                  onChange={(e) =>
                    this.handleChangeFilesBranchChild(
                      e.target.files[0],
                      subData.id,
                      queId
                    )
                  }
                />
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() => this.deleteAnswerField(null, branchId, index)}
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
          </div>
        );

      case "url":
        return (
          <div class="br-qst">
            <div class="br-qst-add" style={{ display: "flex" }}>
              <div class="br-arrow">
                <img src={arrow} alt="" />
                <TextareaAutosize
                  minRows={1}
                  maxRows={10}
                  placeholder="https://example.com"
                  onChange={(e) =>
                    this.handleAnswerChangeBranchChild(
                      e.target.value,
                      subData.id,
                      queId
                    )
                  }
                  rows="1"
                  defaultValue={subData.data ? subData.data : ""}
                />
              </div>
              {this.dropdownMenu(branchId, index, queId)}

              <button
                class="img-delete"
                id="myBtn"
                onClick={() => this.deleteAnswerField(null, branchId, index)}
              >
                <img src={deleteRed} alt="" />
              </button>
            </div>
          </div>
        );
    }
  };

  displayAnswers(answers = [], index, queId) {
    const answersJsx =
      answers &&
      answers.map((subData, indexAns) => (
        <div key={subData.id} style={{ width: "100%" }}>
          <div class="ans-img" style={{ width: "100%" }}>
            <div class="ans-data" style={{ width: "100%" }}>
              <div class="data-extract" style={{ width: "100%" }}>
                {subData.type == "text" && (
                  <Fragment>
                    {this.dropdownMenu(null, index, queId, indexAns)}
                    <TextareaAutosize
                      minRows={1}
                      maxRows={10}
                      placeholder="Type Something..."
                      onChange={(e) =>
                        this.handleAnswerChange(
                          e.target.value,
                          subData.id,
                          index
                        )
                      }
                      rows="1"
                      defaultValue={subData.data ? subData.data : ""}
                    />

                    <button
                      class="img-delete1"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerField(null, null, index, indexAns)
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </Fragment>
                )}
                {subData.type === "url" && (
                  <Fragment>
                    {this.dropdownMenu(null, index, queId, indexAns)}
                    <TextareaAutosize
                      minRows={1}
                      maxRows={10}
                      placeholder="https://example.com"
                      onChange={(e) =>
                        this.handleAnswerChange(
                          e.target.value,
                          subData.id,
                          index
                        )
                      }
                      rows="1"
                      defaultValue={subData.data ? subData.data : ""}
                    />

                    <button
                      class="img-delete1"
                      id="myBtn"
                      onClick={() =>
                        this.deleteAnswerField(null, null, index, indexAns)
                      }
                    >
                      <img src={deleteRed} alt="" />
                    </button>
                  </Fragment>
                )}

                {subData.type === "image" && (
                  <Fragment>
                    <div class="data-img">
                      <div class="dt-img">
                        {this.dropdownMenu(null, index, queId, indexAns)}

                        <input
                          id="input"
                          type="file"
                          accept="image/*"
                          placeholder="Enter"
                          data={subData.data || ""}
                          onChange={(e) =>
                            this.handleChangeImgOuter(
                              e.target.files[0],
                              subData.id,
                              index
                            )
                          }
                        />

                        <button
                          class="img-delete"
                          id="myBtn"
                          onClick={() =>
                            this.deleteAnswerField(null, null, index, indexAns)
                          }
                        >
                          <img src={deleteRed} alt="" />
                        </button>
                      </div>
                      <div class="image-uploaded">
                        <Gluejar
                          onPaste={(files) =>
                            this.pastedContent(files, subData.id, index)
                          }
                          onError={(err) => console.error(err)}
                        >
                          {(images) =>
                            images.length > 0 && images.map((image, i) => {})
                          }
                        </Gluejar>
                        {subData.data !== null && (
                          <img src={`${subData.data}`} />
                        )}
                      </div>
                    </div>
                  </Fragment>
                )}

                {subData.type === "video" && (
                  <Fragment>
                    <div class="data-img">
                      <div class="dt-img">
                        {this.dropdownMenu(null, index, queId, indexAns)}

                        <input
                          id="input"
                          type="file"
                          accept="video/*"
                          placeholder="Enter"
                          data={subData.data || ""}
                          onChange={(e) =>
                            this.handleChangeVidOuter(
                              e.target.files[0],
                              subData.id,
                              index
                            )
                          }
                        />

                        <button
                          class="img-delete"
                          id="myBtn"
                          onClick={() =>
                            this.deleteAnswerField(null, null, index, indexAns)
                          }
                        >
                          <img src={deleteRed} alt="" />
                        </button>
                      </div>
                      <div class="image-uploaded">
                        {subData.data !== null && (
                          <video controls src={`${subData.data}`} />
                        )}
                      </div>
                    </div>
                  </Fragment>
                )}

                {subData.type === "audio" && (
                  <Fragment>
                    <div class="data-img">
                      <div class="dt-img">
                        {this.dropdownMenu(null, index, queId, indexAns)}

                        <input
                          id="input"
                          type="file"
                          accept="audio/*"
                          placeholder="Enter"
                          data={subData.data || ""}
                          onChange={(e) =>
                            this.handleChangeAudioOuter(
                              e.target.files[0],
                              subData.id,
                              index
                            )
                          }
                        />

                        <button
                          class="img-delete1"
                          id="myBtn"
                          onClick={() =>
                            this.deleteAnswerField(null, null, index, indexAns)
                          }
                        >
                          <img src={deleteRed} alt="" />
                        </button>
                      </div>
                      <div class="image-uploaded">
                        {subData.data !== null && (
                          <audio controls src={` ${subData.data}`} />
                        )}
                      </div>
                    </div>
                  </Fragment>
                )}

                {subData.type === "file" && (
                  <Fragment>
                    <div class="data-img">
                      <div class="dt-img">
                        {this.dropdownMenu(null, index, queId, indexAns)}

                        <input
                          id="input"
                          type="file"
                          placeholder="Enter"
                          data={subData.data || ""}
                          onChange={(e) =>
                            this.handleChangeFilesOuter(
                              e.target.files[0],
                              subData.id,
                              index
                            )
                          }
                        />

                        <button
                          class="img-delete"
                          id="myBtn"
                          onClick={() =>
                            this.deleteAnswerField(null, null, index, indexAns)
                          }
                        >
                          <img src={deleteRed} alt="" />
                        </button>
                      </div>
                      <div class="image-uploaded">
                        {subData.data
                          ? subData.data.substring(
                              subData.data.lastIndexOf("/") + 1
                            )
                          : ""}
                      </div>
                    </div>
                  </Fragment>
                )}

                {subData.type === "branch" && (
                  <Fragment>
                    <div class="branching-block">
                      <div class="br-block">
                        <div class="br-arrow">
                          {/* <img src={arrow} alt="" /> */}

                          <input
                            type="text"
                            placeholder="Questions"
                            onChange={(e) =>
                              this.handleQuestionChangeBranchOuter(
                                e.target.value,
                                subData.id,
                                index
                              )
                            }
                          />

                          <button
                            class="img-delete1"
                            id="myBtn"
                            onClick={() =>
                              this.deleteAnswerField(
                                null,
                                null,
                                index,
                                indexAns
                              )
                            }
                          >
                            <img src={deleteRed} alt="" />
                          </button>
                        </div>

                        {this.branchBlock([subData], subData.id, queId)}
                      </div>
                    </div>
                  </Fragment>
                )}

                {subData.type === "richText" && (
                  <>
                    {this.dropdownMenu(null, index, queId)}

                    <Editor
                      wrapperClassName="demo-wrapper"
                      editorClassName="demo-editor"
                      onContentStateChange={this.onContentStateChange}
                    />
                    <div class="img-delete1">
                      <button
                        class="myBtn"
                        id="myBtn"
                        onClick={() =>
                          this.deleteAnswerField(null, null, index)
                        }
                      >
                        <img src={deleteRed} alt="" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      ));

    return answersJsx;
  }

  //   update Extraction limit pending

  //UploadQA
  handleChangeQaFile = async (file) => {
    if (file) {
      const upload = await this.props.uploadQA(file);
      this.setState({
        isUploading: true
      });

      this.props.notify("info", "Uploading please wait..");
      if (upload.data) {
        const qnaDocuments = upload.data.data.qnaDocuments;
        const currentQueState = [...qnaDocuments];
        let parsedNo = null;
        currentQueState.forEach((ele, i) => {
          if (ele) {
            if (ele.questions.length >= 1) {
              let altLen = ele.questions.length;
              let alterQue = [
                {
                  data: ele.questions[1] ? ele.questions[1] : "",
                  type: "text",
                  id: uuid()
                },
                {
                  data: ele.questions[2] ? ele.questions[2] : "",
                  type: "text",
                  id: uuid()
                }
              ];

              for (let i = 3; i < altLen; i++) {
                alterQue = [
                  ...alterQue,
                  { type: "text", id: uuid(), data: ele.questions[i] }
                ];
              }
              ele.alter_questions = alterQue;
            }
            ele.question = ele.questions[0];
            ele.answers = [{ type: "text", id: uuid(), data: ele.answer }];
            ele.kind = "qa";

            ele.status = "pending";
            ele.category = "";
            ele.visibility = "";

            return parsedNo++;
          }
        });

        if (currentQueState.length === parsedNo) {
          this.setState({
            questions: currentQueState
          });
        }
        this.props.notify("success", "  Document Uploaded");
        this.setState({
          isUploading: false
        });

        // this.updateExtractionLimit()
      } else {
        this.props.notify(
          "error",
          "Something went wrong.Failed to upload! Only docx/pdf are supported"
        );
      }
    }
  };

  render() {

    return (
      <div
        className="right-content search-content full-width-chat"
        style={{
          backgroundImage: "url(" + dottedBg + ")",
          backgroundSize: "cover"
        }}
      >
        <div class="chat-col qa-chat">
          <div class="knb-title">
            <div class="back-title"></div>
            <div class="upload-publish">
              <button
                class="btn btn-info preview-btn"
                data-toggle="modal"
                data-target="#previewModal"
              >
                <img src={visibility} alt="" />
                <span>Preview</span>
              </button>

              {this.state.uploadLimit > 0 ? (
                <>
                  {this.state.isUploading === true ? (
                    <>
                      <label
                        for="fileUpload"
                        className="btn btn-primary btn-outlined "
                      >
                        Import PDF/DOC
                        <div class="sp sp-circle"></div>
                      </label>
                      <input
                        id="fileUpload"
                        disabled
                        type="file"
                        placeholder="Enter"
                        onChange={(e) =>
                          this.handleChangeQaFile(e.target.files[0])
                        }
                        style={{ display: "none" }}
                      />
                    </>
                  ) : (
                    <>
                      <label
                        for="fileUpload"
                        className="btn btn-primary btn-outlined"
                      >
                        Import PDF/DOC <img src={uploadIcon}></img>
                      </label>
                      <input
                        id="fileUpload"
                        disabled
                        type="file"
                        placeholder="Enter"
                        onChange={(e) =>
                          this.handleChangeQaFile(e.target.files[0])
                        }
                        style={{ display: "none" }}
                      />
                    </>
                  )}
                </>
              ) : (
                <>
                  <>
                    <label
                      for="fileUpload"
                      className="btn btn-primary btn-outlined "
                    >
                      Import PDF/DOC
                    </label>
                    <input
                      id="fileUpload"
                      disabled
                      type="file"
                      placeholder="Enter"
                      style={{ display: "none" }}
                    />
                  </>
                </>
              )}

              <button
                class="lg-btn"
                data-toggle="modal"
                data-target="#visibility"
              >
                <img src={send} alt="" />
                <span>Publish</span>
              </button>
            </div>
          </div>
          {this.state.isLoading ? (
            <>
              <Loader
                styles={{ width: "80px", margin: "auto" }}
                root={{ display: "flex" }}
              />
            </>
          ) : (
            <>
              <div class="col-md-12 qa-block">
                <div className="scrollable qa-scrollable">
                  <div class="qst-category">
                    {this.state.categoryItems.length ? (
                      <select
                        value={this.state.category}
                        onChange={this.handleCatChange.bind(this)}
                      >
                        <option value="">Please select Category</option>
                        {this.state.categoryItems.map((item, i) => {
                          return <option key={i}>{item.name}</option>;
                        })}
                      </select>
                    ) : (
                      <input
                        type="text"
                        placeholder="Enter category name"
                        class="ctg-title"
                        name="category"
                        value={this.state.category || ""}
                        onChange={(e) => this.handleCatChange(e)}
                      ></input>
                    )}
                  </div>
                  {this.state.questions.map((el, index) => (
                    <div class="qa-inner">
                      {index === 0 ? (
                        ""
                      ) : (
                        <div class="qst-del">
                          <button
                            onClick={this.removeClickQue.bind(this, index)}
                          >
                            <img src={deleteRed} alt="" />
                          </button>
                        </div>
                      )}

                      <div class="qst-block">
                        <div class="qst-line"></div>
                        <div class="qst-input">
                          <div class="label-add">
                            <label>Question</label>
                            <div class="qst-add">
                              <img src="img/info.png" alt="" />
                              <span>Alternative Question</span>
                              <button onClick={() => this.addAlternate(index)}>
                                +
                              </button>
                            </div>
                          </div>
                          <div class="qst-input">
                            <input
                              type="text"
                              placeholder="Enter Question "
                              name="question"
                              value={el.question}
                              onChange={(e) => this.handleChangeQue(e, index)}
                            />
                          </div>
                        </div>
                      </div>
                      {el.alter_questions &&
                        el.alter_questions.map((altQue, i) => (
                          <div class="qst-input alternate-qst">
                            <div class="alt-lineQa">
                              <img src={arrow} alt="" />
                            </div>
                            <div className="input-del" key={i}>
                              <div class="qst-input">
                                <input
                                  type="text"
                                  placeholder="Enter Alternative Question"
                                  value={altQue.data || ""}
                                  onChange={(e) =>
                                    this.handleAltChange(
                                      e.target.value,
                                      altQue.id,
                                      index
                                    )
                                  }
                                />
                              </div>
                              {i === 0 || i === 1 ? (
                                <></>
                              ) : (
                                <>
                                  <div class="qst-del-alt">
                                    <button
                                      onClick={this.removeClick.bind(
                                        this,
                                        i,
                                        index
                                      )}
                                    >
                                      <img src={deleteRed} alt="" />
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        ))}

                      <div class="your-ans">
                        <div class="dropdown add-qst">
                          <button
                            class="dropdown-toggle"
                            id="outerBlock"
                            type="button"
                            data-toggle="dropdown"
                          >
                            +
                          </button>
                          <ul class="dropdown-menu">
                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("text", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#ffe8c7" }}
                                >
                                  <img src={text} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>Text</p>
                                  <span>Type some Text</span>
                                </div>
                              </div>
                            </li>

                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("image", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#ffe8c7" }}
                                >
                                  <img src={imagePic} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>Image</p>

                                  <span>Upload and Embed with a link</span>
                                </div>
                              </div>
                            </li>

                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("video", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#e2efff" }}
                                >
                                  <img src={video} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>Video</p>
                                  <span>Embed from Youtube, Vimeo…</span>
                                </div>
                              </div>
                            </li>

                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("audio", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#c7ffec" }}
                                >
                                  <img src={audio} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>Audio</p>
                                  <span>Upload and Embed from soundcloud</span>
                                </div>
                              </div>
                            </li>
                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("file", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#ffe0e0" }}
                                >
                                  <img src={file} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>File</p>
                                  <span>Upload and Embed file</span>
                                </div>
                              </div>
                            </li>
                            <li>
                              <div
                                class="aq-flex"
                                onClick={() =>
                                  this.addAnswerField("url", null, index)
                                }
                              >
                                <div
                                  class="aq-icon"
                                  style={{ background: "#e0f9ff" }}
                                >
                                  <img src={url} alt="" />
                                </div>
                                <div class="aq-text">
                                  <p>URL</p>
                                  <span>Write url and paste</span>
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <div style={{ width: "100%" }}>
                          <label>Your Answer</label>

                          {this.displayAnswers(el.answers, index, el.id)}
                        </div>
                      </div>
                    </div>
                  ))}

                  <div class="qst-add-new">
                    <button onClick={() => this.addQue()}>+</button>
                    <span>Add New Question</span>
                  </div>

                  <div
                    className="modal fade qa-modal"
                    id="previewModal"
                    role="dialog"
                  >
                    <div className="modal-dialog modal-lg">
                      <div className="modal-content">
                        <button
                          type="button"
                          className="close"
                          data-dismiss="modal"
                        >
                          &times;
                        </button>
                        <div className="modal-body md-edit">
                          {!this.state ? (
                            <>
                              {" "}
                              <EmptyLoader
                                message="Please create article to preview"
                                styles={{ width: "80px", margin: "auto" }}
                                root={{ display: "flex" }}
                              />
                            </>
                          ) : (
                            <>
                              {this.state.questions.map((el, index) => (
                                <div className="pm-modal">
                                  <div class="knb-title">
                                    {/* <h3>Preview</h3> */}
                                    <div class="flex-qa-title">
                                      <div class="qst-input">
                                        <div className="tl-cont">
                                          {}
                                          <h4>
                                            Question:
                                            {el.question ? el.question : ""}
                                          </h4>
                                          <span>
                                            Category:{" "}
                                            {this.state.category
                                              ? this.state.category
                                              : ""}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="pm-edit-block">
                                    <div class="scrollable qa-inner">
                                      {el.alter_questions &&
                                        el.alter_questions.map((alt, i) => (
                                          <div>
                                            <div key={i}>
                                              <div>
                                                <div className="alt-pm">
                                                  <h5>
                                                    Alternative Question :
                                                    {alt.data ? alt.data : ""}{" "}
                                                  </h5>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        ))}

                                      {!el.answers.length == 0 &&
                                        el.answers.map((subData, index) => {
                                          return (
                                            <div class="ans-img">
                                              <div class="ans-data">
                                                <div class="data-extract1">
                                                  <div class="in-data">
                                                    {subData.type ===
                                                      "text" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>
                                                        <div class="qst-input">
                                                          <p>
                                                            {subData.data
                                                              ? subData.data
                                                              : " "}
                                                          </p>
                                                        </div>
                                                      </>
                                                    )}

                                                    {subData.type ===
                                                      "image" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>
                                                        {subData.data ? (
                                                          <>
                                                            <div class="qst-img-video">
                                                              <div class="image-uploaded">
                                                                {" "}
                                                                <img
                                                                  src={
                                                                    subData.data
                                                                  }
                                                                ></img>{" "}
                                                              </div>
                                                            </div>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </>
                                                    )}

                                                    {subData.type ===
                                                      "video" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>

                                                        {subData.data ? (
                                                          <>
                                                            <div class="qst-img-video">
                                                              <div class="image-uploaded">
                                                                <video
                                                                  controls
                                                                  src={
                                                                    subData.data
                                                                  }
                                                                />
                                                              </div>
                                                            </div>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </>
                                                    )}

                                                    {subData.type ===
                                                      "audio" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>

                                                        {subData.data ? (
                                                          <>
                                                            <div class="qst-img-video">
                                                              <audio
                                                                controls
                                                                src={
                                                                  subData.data
                                                                }
                                                              />
                                                            </div>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </>
                                                    )}
                                                    {subData.type === "url" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>

                                                        {subData.data ? (
                                                          <>
                                                            <div class="qst-img-video">
                                                              {subData.data}
                                                            </div>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </>
                                                    )}
                                                    {subData.type ===
                                                      "file" && (
                                                      <>
                                                        <div class="box-curve">
                                                          <span>
                                                            {index + 1}
                                                          </span>
                                                        </div>

                                                        {subData.data ? (
                                                          <>
                                                            <div class="qst-img-video">
                                                              {subData.data
                                                                ? subData.data.substring(
                                                                    subData.data.lastIndexOf(
                                                                      "/"
                                                                    ) + 1
                                                                  )
                                                                : ""}
                                                            </div>
                                                          </>
                                                        ) : (
                                                          ""
                                                        )}
                                                      </>
                                                    )}
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          );
                                        })}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="modal fade" id="visibility" role="dialog">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                        >
                          &times;
                        </button>
                        <div class="modal-body">
                          <p>Choose Visibility type </p>
                          <div class="vb-input">
                            <input
                              type="radio"
                              id="self"
                              name="self"
                              value={"self"}
                              checked={this.state.visibility === "self"}
                              onChange={this.onChangeVisiblity.bind(this)}
                            />{" "}
                            {""}
                            <label for="self">Self</label>
                          </div>
                          <div class="vb-input">
                            <input
                              type="radio"
                              id="organization"
                              name="organization"
                              value={"organization"}
                              checked={this.state.visibility === "organization"}
                              onChange={this.onChangeVisiblity.bind(this)}
                            />{" "}
                            {""}
                            <label for="organization">Organization</label>
                          </div>

                          <button
                            class="btn filled-btn"
                            data-dismiss="modal"
                            onClick={() => this.submitHandler()}
                          >
                            Done
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer,
  knowledgeReducer: state.knowledgeReducer,
  userReducer: state.userReducer,
  fileUploadReducer: state.fileUploadReducer,
  snackReducer: state.snackReducer,
  organizationReducer: state.organizationReducer
});

export default connect(mapStateToProps, {
  notify,
  getFileUrl,
  createQA,
  uploadQA,
  getCategoriesOfAnOrganization
})(QandA);
