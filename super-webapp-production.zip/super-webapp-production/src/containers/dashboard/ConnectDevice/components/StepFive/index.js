import React, { useState } from "react";
import { Modal, ModalBody } from "reactstrap";
import Connection from "../../../../../images/connection.png";

const StepFive = (stepFive) => {
  return (
    <>
      <Modal isOpen={stepFive} className="cdModal">
        <ModalBody>
          {" "}
          <div className="cdm-block cdm-fifth-step ">
            <div className="col-md-4 col-sm-4 cdm-list">
              <div className="cdm-list-1">
                <ul>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Enable bot agent</p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Install bot agent</p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Connect your computer</p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Connection Successful</p>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-8 col-sm-8">
              <div className="cdm-content">
                <h4 className="cdm-title">
                  Your device is successful connected
                </h4>
                <div className="center-spinner">
                  <div className="cdm-ico">
                    <img src="img/checked-green.png" alt="" />
                  </div>
                </div>
                <div className="cdm-btns">
                  <button
                    className="btn btn-sm btn-primary"
                    data-dismiss="modal"
                  >
                    Completed
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default StepFive;
