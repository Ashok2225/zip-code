/*global chrome*/
import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { Modal, ModalBody } from "reactstrap";
import { Store } from "react-notifications-component";
import axios from "axios";
//
import VersionUpdatePromptModal from "../../common/VersionUpdatePromptModal";
import { getKeycloackToken } from "../../../../../redux/actions/auth";
import Connection from "../../../../../images/connection.png";
import { extractVersionFromBlobName, notificationPopUp } from "./../../util";
import { getSuperAgent } from "../../../../../redux/actions/user";
// import Connection from "../../../../../images/check-green.png";

const StepTwo = ({
  stepTwo,
  stepTwoToggle,
  stepThreeToggle,
  stepFourToggle,
}) => {
  const [blobURL, setBlobURL] = useState({});
  const [latestBlobVersion, setLatestBlobVersion] = useState();
  const [versionCheckModal, setVersionCheckModal] = useState(false);
  const dispatch = useDispatch();
  useEffect(() => {
    downloadExeFile();
  }, []);

  async function downloadExeFile() {
    let token = await getKeycloackToken();
    axios
      .get(`${process.env.REACT_APP_BOT_SERVICE_URL}/download`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then(async (res) => {
        const {
          data: { url, blobName },
        } = res;
        setBlobURL(url);
        setLatestBlobVersion(blobName);
        dispatch(getSuperAgent(url));
      })
      .catch((e) => console.log(e));
  }

  const verifyVersion = async () => {
    let token = await getKeycloackToken();
    let conf = {
      method: "GET",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const sessionRes = await axios(conf);

    if (sessionRes && sessionRes.data && sessionRes.data.uniqueDevices.length) {
      let _storedVersion;
      let _versionNumber;
      let deviceList = sessionRes?.data?.uniqueDevices[0];
      let checkOldVersion = deviceList?.meta_data?.version.includes("v");
      if (checkOldVersion) {
        _storedVersion = deviceList?.meta_data?.version.split("v");
        _versionNumber = _storedVersion[1];
      } else {
        _versionNumber = deviceList?.meta_data?.version;
      }

      const latestStudioVersion = extractVersionFromBlobName(latestBlobVersion);
      if (_versionNumber !== latestStudioVersion) {
        setVersionCheckModal(true);
      } else {
        stepThreeToggle(false);
        stepFourToggle(true);
      }
    } else {
      window.open(blobURL, "_self");

      stepThreeToggle(true);
    }
  };

  const checkChromeExtension = () => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            notificationPopUp();
          } else {
            verifyVersion();
          }
        }
      );
    } catch (error) {
      notificationPopUp();
    }
  };

  return (
    <>
      <Modal className="cdModal" isOpen={stepTwo}>
        <ModalBody>
          {" "}
          <div className="cdm-block cdm-second-step ">
            <div className="col-md-4 col-sm-4 cdm-list">
              <div className="cdm-list-1">
                <ul>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Enable Extension</p>
                    </a>
                  </li>

                  <li>
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">
                        Install Super Assistant For Windows
                      </p>
                    </a>
                  </li>

                  <li>
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Connection Successful</p>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-8 col-sm-8">
              <div className="cdm-content">
                <h4 className="cdm-title">Enable Chrome extension</h4>
                <p>
                  Chrome extension enables Super Assistant to create or execute
                  web based automations. Once you add extension to the chrome
                  browser, click on 'I enabled it' button to proceed to next
                  step.
                </p>
                <p>
                  <a
                    target={"_blank"}
                    rel="noreferrer"
                    href={`https://chrome.google.com/webstore/detail/super/${process.env.REACT_APP_CHROME_TAB_ID}/related`}
                  >
                    Click here
                  </a>{" "}
                  to open extension page in a new tab if not opened
                  automatically.
                </p>
                <div className="cdm-btns">
                  <button
                    onClick={() => {
                      stepTwoToggle(false);
                    }}
                    className="btn btn-sm btn-danger"
                    data-dismiss="modal"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      checkChromeExtension();
                    }}
                    className="btn btn-sm btn-primary"
                  >
                    I enabled it
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </Modal>
      {versionCheckModal && (
        <VersionUpdatePromptModal
          setVersionCheckModal={setVersionCheckModal}
          blobURL={blobURL}
          stepThreeToggle={stepThreeToggle}
          stepFourToggle={stepFourToggle}
        />
      )}
    </>
  );
};

export default StepTwo;
