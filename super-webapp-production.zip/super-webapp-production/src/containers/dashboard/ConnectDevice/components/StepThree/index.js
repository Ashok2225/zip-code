import React from "react";
import { Modal, ModalBody } from "reactstrap";
import Connection from "../../../../../images/check-green.png";
import Connection1 from "../../../../../images/connection.png";
import { useSelector } from "react-redux";
const StepThree = ({ stepThree, stepThreeToggle, stepFourToggle }) => {
  const agentDownloadUrl = useSelector((state) => state.userReducer.agentUrl);

  return (
    <>
      <Modal isOpen={stepThree} className="cdModal">
        <ModalBody>
          {" "}
          <div className="cdm-block cdm-third-step">
            <div className="col-md-4 col-sm-4 cdm-list">
              <div className="cdm-list-1">
                <ul>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Enable Extension</p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection1} alt="" />
                      </div>
                      <p className="cdm-list-title">
                        {" "}
                        Install Super Assistant For Windows
                      </p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Connection Successful</p>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-8 col-sm-8">
              <div className="cdm-content">
                <h4 className="cdm-title">
                  Install Super Assistant For Windows
                </h4>
                <div className="cdm-center scrollable">
                  {/* <div className="cdm-ico">
                    <img src={Connection} alt="" />
                  </div> */}
                  <div className="cdm-title">
                    <p>
                      Download has started. Once downloaded, double click on the
                      exe file to install super assistant app on your desktop.
                    </p>

                    <p>
                      <a
                        target={"_blank"}
                        rel="noreferrer"
                        href={agentDownloadUrl}
                      >
                        Click here
                      </a>{" "}
                      to download the exe if not started automatically.
                    </p>

                    <p>
                      Once installation is completed (may take up to 5 minutes),
                      click on 'I installed it' button to complete the setup.
                    </p>
                  </div>
                </div>
                <div className="cdm-btns">
                  <button
                    onClick={() => {
                      stepThreeToggle(false);
                    }}
                    className="btn btn-sm btn-danger"
                    data-dismiss="modal"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      stepFourToggle(true);
                    }}
                    className="btn btn-sm btn-primary"
                  >
                    I installed it
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default StepThree;
