import React, { useEffect, useState } from "react";
import axios from "axios";
import { Modal, ModalBody } from "reactstrap";
import Connection from "../../../../../images/check-green.png";
import { getKeycloackToken } from "../../../../../redux/actions/auth";
import { setSuperWindowDeviceName } from "../../../../../redux/actions/user";
import { useDispatch } from "react-redux";

const StepFour = ({
  stepFour,
  stepFourToggle,
  superWindowDeviceNameToggle,
  connectDeviceToggle,
}) => {
  const dispatch = useDispatch();
  useEffect(() => {
    verifyVersion();
  }, []);

  const verifyVersion = async () => {
    let token = await getKeycloackToken();
    let conf = {
      method: "GET",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const sessionRes = await axios(conf);

    if (sessionRes && sessionRes.data && sessionRes.data.uniqueDevices.length) {
      const { session_name } = sessionRes.data.uniqueDevices[0];
      dispatch(setSuperWindowDeviceName(session_name));
      setTimeout(() => {
        stepFourToggle(false);
        connectDeviceToggle(false);
      }, 500);
    }
  };

  return (
    <>
      <Modal isOpen={stepFour} className="cdModal">
        <ModalBody>
          {" "}
          <div className="cdm-block cdm-fifth-step ">
            <div className="col-md-4 col-sm-4 cdm-list">
              <div className="cdm-list-1">
                <ul>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Enable Extension</p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">
                        {" "}
                        Install Super Assistant For Windows
                      </p>
                    </a>
                  </li>
                  <li className="active">
                    <a href="#">
                      <div className="cdm-list-ico">
                        <img src={Connection} alt="" />
                      </div>
                      <p className="cdm-list-title">Connection Successful</p>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-8 col-sm-8">
              <div className="cdm-content">
                <h4 className="cdm-title">
                  Your device is connected successfully.
                </h4>
                <div className="center-spinner">
                  <div className="cdm-ico">
                    <img src={Connection} alt="" />
                  </div>
                </div>
                <div className="cdm-btns">
                  <button
                    onClick={() => {
                      stepFourToggle(false);
                    }}
                    className="btn btn-sm btn-primary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default StepFour;
