/*global chrome*/
import React, { useState } from "react";
import { Modal, ModalBody } from "reactstrap";
import { Store } from "react-notifications-component";
import Connection from "../../../../../images/connection.png";

const StepOne = ({ stepOne, stepOneToggle, stepTwoToggle }) => {
  const checkChromeExtension = () => {
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            notificationPopUp();
          } else {
            stepTwoToggle(true);
          }
        }
      );
    } catch (error) {
      notificationPopUp();
    }
  };

  const notificationPopUp = () => {
    Store.addNotification({
      title: "Note: ",
      message:
        "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before using.",
      type: "warning",
      insert: "top",
      container: "top-right",
      dismiss: {
        duration: 5000,
        onScreen: true,
      },
    });
    window.setTimeout(function () {
      window.open(
        `https://chrome.google.com/webstore/detail/super/${process.env.REACT_APP_CHROME_TAB_ID}`,
        "_blank"
      );
    }, 5000);
  };

  return (
    <>
      <Modal className="cdModal" isOpen={stepOne}>
        <ModalBody>
          {" "}
          <div className="cdm-block">
            <div className="col-md-12 cdm-first-step">
              <h4 className="cdm-title">Let's make a connection</h4>
              <div className="flex-cdm">
                <div className="cdm-ico">
                  <img src={Connection} alt="" />
                </div>
                <div className="cdm-text">
                  <p>
                    To run the bot on your computer, <br />
                    we need to connect to it.
                  </p>
                </div>
              </div>
              <div className="cdm-btns">
                <button
                  onClick={() => {
                    stepOneToggle(false);
                  }}
                  className="btn btn-sm btn-danger"
                  data-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    checkChromeExtension();
                  }}
                  className="btn btn-sm btn-primary"
                >
                  Connect to my computer
                </button>
              </div>
            </div>
          </div>
        </ModalBody>
      </Modal>
    </>
  );
};

export default StepOne;
