import React, { useState } from "react";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";

const VersionUpdatePromptModal = ({
  setVersionCheckModal,
  blobURL,
  stepThreeToggle,
  stepFourToggle,
}) => {
  const [versionPromptModal, setVersionPromptModal] = useState(true);

  const toggle = () => {
    setVersionPromptModal(!versionPromptModal);
    setVersionCheckModal(false);
  };

  return (
    <Modal isOpen={versionPromptModal} toggle={toggle}>
      <ModalHeader
        className="border-0"
        style={{ padding: "0px" }}
        toggle={toggle}
      >
        Install Latest Version !!!
      </ModalHeader>
      <ModalBody>
        It seems your current Super Assistant App version is outdated. <br />
        <br /> A latest version is available for Super Assistant App. Click on
        update to download the latest version. Once downloaded, double click on
        it to start the installation process. Note that you must uninstall the
        previous version of Super Assistant App before installing the latest
        version..
        <br />
      </ModalBody>
      <ModalFooter>
        <Button
          color="primary"
          onClick={() => {
            setVersionPromptModal(!versionPromptModal);
            setVersionCheckModal(false);
            window.open(blobURL, "_self");
            stepThreeToggle(true);
          }}
        >
          Update
        </Button>
        <Button
          color="secondary"
          onClick={() => {
            setVersionPromptModal(!versionPromptModal);
            stepThreeToggle(false);
            stepFourToggle(true);
            setVersionCheckModal(false);
          }}
        >
          Cancel
        </Button>
      </ModalFooter>
    </Modal>
  );
};

export default VersionUpdatePromptModal;
