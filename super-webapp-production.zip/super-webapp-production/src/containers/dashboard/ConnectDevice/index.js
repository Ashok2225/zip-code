/*global chrome*/
import React, { useState, useEffect } from "react";
import { Spinner } from "reactstrap";
import { Store } from "react-notifications-component";
import axios from "axios";
import close from "../../../images/close.png";
import { getKeycloackToken } from "../../../redux/actions/auth";
import VersionUpdatePromptModal from "./common/VersionUpdatePromptModal";
import StepTwo from "./components/StepTwo";
import {
  extractVersionFromBlobName,
  getDeviceInfoApi,
  notificationPopUp,
} from "./util";
import { useDispatch, useSelector } from "react-redux";
import { setSuperWindowDeviceName } from "../../../redux/actions/user";
// import { useSelector } from 'react-redux';

const ConnectDevice = ({
  connectDevice,
  stepOneToggle,
  connectDeviceToggle,
  stepTwoToggle,
  superWindowDeviceName,
  stepThree,
  stepThreeToggle,
  stepFourToggle,
}) => {
  const deviceInfo = useSelector((state) => state.userReducer.devicename);
  var device = false;
  console.log(connectDevice);
  const [blobURL, setBlobURL] = useState({});
  const [latestBlobVersion, setLatestBlobVersion] = useState();
  const [versionCheckModal, setVersionCheckModal] = useState(false);
  const [spinnerCondition, setSpinnerCondition] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    downloadExeFile();
    checkDevice();
  }, []);

  async function downloadExeFile() {
    let token = await getKeycloackToken();
    axios
      .get(`${process.env.REACT_APP_BOT_SERVICE_URL}/download`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then(async (res) => {
        const {
          data: { url, blobName },
        } = res;
        setBlobURL(url);
        setLatestBlobVersion(blobName);
      })
      .catch((e) => console.log(e));
  }

  const checkChromeExtension = () => {
    stepTwoToggle(true);
    try {
      chrome.runtime.sendMessage(
        process.env.REACT_APP_CHROME_TAB_ID,
        { type: "ping" },
        (response) => {
          if (!response) {
            notificationPopUp();
          } else {
            stepTwoToggle(false);
            stepThreeToggle(true);
            verifyVersion();
          }
        }
      );
    } catch (error) {
      notificationPopUp();
    }
  };

  const verifyVersion = async () => {
    let token = await getKeycloackToken();
    let conf = {
      method: "GET",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const sessionRes = await axios(conf);

    if (sessionRes && sessionRes.data && sessionRes.data.uniqueDevices.length) {
      let _storedVersion;
      let _versionNumber;
      const {
        meta_data: { version },
        session_name,
      } = sessionRes.data.uniqueDevices[0];
      const latestStudioVersion = extractVersionFromBlobName(latestBlobVersion);
      dispatch(setSuperWindowDeviceName(session_name));
      let checkOldVersion = version.includes("v");
      if (checkOldVersion) {
        _storedVersion = version.split("v");
        _versionNumber = _storedVersion[1];
      } else {
        _versionNumber = version;
      }

      if (_versionNumber !== latestStudioVersion) {
        setVersionCheckModal(true);
      } else {
        stepThreeToggle(false);
        stepFourToggle(true);
      }
    } else {
      window.open(blobURL, "_self");
      stepThreeToggle(true);
    }
  };

  const checkDevice = async () => {
    setSpinnerCondition(true);
    // const val =getDeviceInfoApi()
    // console.log("daaaaa",val)
    let token = await getKeycloackToken();
    let conf = {
      method: "GET",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const sessionRes = await axios(conf);
    setSpinnerCondition(false);
    if (sessionRes && sessionRes.data && sessionRes.data.uniqueDevices.length) {
      const { session_name } = sessionRes.data.uniqueDevices[0];
      dispatch(setSuperWindowDeviceName(session_name));
    }
  };

  return (
    <>
      <div className="connect-block">
        <div className="cdb-title">
          <h4>Super for Windows</h4>
          <div id="connect-close" className="close">
            <img
              src={close}
              onClick={() => {
                connectDeviceToggle(false);
              }}
              alt=""
            />
          </div>
        </div>
        {device && (
          <div className="cdb-cont">
            <label>Device</label>
            <input type="text" />
          </div>
        )}

        <div className="cdb-ld">
          {spinnerCondition ? (
            <div className="text-center">
              {" "}
              <Spinner color="dark" className="spinnerBorder" />
            </div>
          ) : (
            <React.Fragment>
              {deviceInfo ? <input value={deviceInfo} disabled={true} /> : ""}
            </React.Fragment>
          )}
          <span>
            Super Assistant for Windows will help you to create and execute
            desktop driven automation skills.
          </span>
          <button
            onClick={() => {
              checkChromeExtension();
            }}
            data-toggle="modal"
            data-target="#connectModal"
            className="btn btn-sm btn-primary mx-1"
          >
            {deviceInfo ? "Update" : "Proceed"}
          </button>
          <button
            className="btn btn-sm btn-danger"
            onClick={() => {
              connectDeviceToggle(false);
            }}
          >
            Cancel
          </button>
        </div>
      </div>
      {versionCheckModal && (
        <VersionUpdatePromptModal
          setVersionCheckModal={setVersionCheckModal}
          blobURL={blobURL}
          stepThreeToggle={stepThreeToggle}
          stepFourToggle={stepFourToggle}
        />
      )}
      {/* <StepTwo openStepTwo={openStepTwo} /> */}
    </>
  );
};

export default ConnectDevice;
