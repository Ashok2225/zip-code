/*global chrome*/
import { Store } from "react-notifications-component";
import { getKeycloackToken } from "../../../redux/actions/auth";
import axios from "axios";

export const notificationPopUp = () => {
  Store.addNotification({
    title: "Note: ",
    message:
      "Ohh! Seems you don't have Super browser extension added to your browser. Please add it before using.",
    type: "warning",
    insert: "top",
    container: "top-right",
    dismiss: {
      duration: 5000,
      onScreen: true,
    },
  });
  window.setTimeout(function () {
    window.open(
      `https://chrome.google.com/webstore/detail/super/${process.env.REACT_APP_CHROME_TAB_ID}`,
      "_blank"
    );
  }, 5000);
};

export const extractVersionFromBlobName = (blobName) => {
  // const blobNameExtract = blobName.split("-");
  // const blobVersionExtract = blobNameExtract[3].split(".exe");
  const blobNameExtract = blobName.split("-");
  const blobVersionExtract = blobNameExtract[blobNameExtract.length-1].split(".exe");
  return blobVersionExtract[0];
};

export const getDeviceInfoApi = async () => {
  let token = await getKeycloackToken();
  return await axios({
    method: "GET",
    url: `${process.env.REACT_APP_BOT_SERVICE_URL}/user/retrieveSession`,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  })
    .then((res) => {
      return res;
    })
    .catch((err) => {
      throw err;
    });
};

export const downloadExe = async () => {
  try {
    let token = await getKeycloackToken();
    var config = {
      method: "GET",
      url: `${process.env.REACT_APP_BOT_SERVICE_URL}/download`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
    const result = await axios(config);
    return result;
  } catch (err) {
    throw err;
  }
};
