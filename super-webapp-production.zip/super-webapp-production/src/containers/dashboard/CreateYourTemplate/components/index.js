import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { compose } from "redux";
import TemplateActionMenu from "./templateActionMenu";
import { getTemplateById } from "../../../../redux/actions/template";
import ConfigureTemplate from "./configureTemplate";

class TemplateFlowScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount = () => {
    this.getTemplateFlow();
  };

  getTemplateFlow = async () => {
    const tempId = this.props.match.params.id;

    const tempFlow = await this.props.getTemplateById(tempId);
  };
  render() {
    return (
      <React.Fragment>
        <div className="fw-screen">
          <div className="chat-col-skill">
            <TemplateActionMenu />
            <ConfigureTemplate />
          </div>
        </div>
      </React.Fragment>
    );
  }
}
const mapStateToProps = (state) => ({
  templateReducer: state.templateReducer,
});

export default compose(
  withRouter,
  connect(mapStateToProps, {
    getTemplateById,
  })
)(TemplateFlowScreen);
