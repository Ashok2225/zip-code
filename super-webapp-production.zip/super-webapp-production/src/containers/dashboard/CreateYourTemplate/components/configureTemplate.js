// import React, { Component } from "react";
// import "antd/dist/antd.css";
import { connect } from "react-redux";

import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { v4 as uuid } from "uuid";
import { useParams, useHistory } from "react-router-dom";
import { Edit, AllInclusive, Storage, ReportProblem } from "@material-ui/icons";

import settingIcon from "../../../../images/branching/setting-icon.svg";
import recordIcon from "../../../../images/branching/record.svg";
import assertIcon from "../../../../images/branching/assert.svg";
import waitIcon from "../../../../images/branching/wait.svg";
import stopIcon from "../../../../images/branching/stop.svg";
import branchIcon from "../../../../images/branching/branching.svg";
import imageIcon from "../../../../images/image-pic.png";
import playWhite from "../../../../images/play-white.png";
import Loader from "../../../../components/loader";
import readIcon from "../../../../images/branching/readIcon.png";
import filesandfolders from "../../../../images/branching/files.png";
import outlookIcon from "../../../../images/branching/outlook-icon.png";
import outlookImage from "../../../../images/branching/outlook-image.png";
import webAutomationIcon from "../../../../images/template-img/web-automation.png";
import automationIcon from "../../../../images/template-img/automation-icon.png";
import folderIcon from "../../../../images/template-img/MIS.png";
import assign from "../../../../images/assign.png";
import httpApi from "../../../../images/httpApi.png";
import httpApiIcon from "../../../../images/httpApiIcon.png";
import assignIcon from "../../../../images/assignIcon.png";
import InvokeSkillIcon from "../../../../images/InvokeSkillIcon.png";
import InvokeSkillImg from "../../../../images/InvokeSkillImg.png";
import todoIcon from "../../../../images/todo-icon.png";
import excelIcon from "../../../../images/excel-action.png";
import automation from "../../../../images/template-img/data-loading.png";
import web_automation from "../../../../images/web_automation.png";
import desktopIcon from "../../../../images/desktop_automation1.png";
import desktopImage from "../../../../images/training/configure-image.png";
import webImg from "../../../../images/template-img/web.PNG";

import Zoom from "react-medium-image-zoom";

import FlowBuilder, {
  NodeContext,
  BuilderContext,
  buildFlatNodes,
} from "react-flow-builder";
import { Select, Drawer } from "antd";

import _ from "lodash";

import { store } from "../../../../redux";

import {
  getTemplateById,
  setTemplateData,
  updateTemplateData,
} from "../../../../redux/actions/template";
import $ from "jquery";

import ExcelConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/ExcelConfig";
import ReadValueConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/readValueConfig";
import FilesFoldersConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/FilesFoldersConfig";
import EchoConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/echoConfig";
import TechnologyConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/TechnologyConfig";
import OpenAppConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/OpenAppConfig";
import CloseAppConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/CloseAppConfig";
import SwitchAppConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/SwitchAppConfig";
import MessageBoxConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/messageBoxConfig";
import HttpApiConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/httpApiConfigPanel";
import AssignConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/assignConfig";
import SendMailConfigForm from "../../mySkills/components/FlowScreen/components/FlowDiagram/mailConfig";
import InvokeSkillConfigForm from "../../mySkills/components/FlowScreen/components/FlowDiagram/invokeSkillConfig";
import ToDoSkillConfigForm from "../../mySkills/components/FlowScreen/components/FlowDiagram/toDoSkillConfig";
import ConfigPanel from "../../mySkills/components/FlowScreen/components/FlowDiagram/configPanel";
import LoopConfigPanel from "../../mySkills/components/FlowScreen/components/FlowDiagram/loopConfigPanel";
import ConfigDataSet from "../../mySkills/components/FlowScreen/components/FlowDiagram/configureDataSet";
import ConfigS3 from "../../mySkills/components/FlowScreen/components/FlowDiagram/ConfigS3";
import ConfigS3Archive from "../../mySkills/components/FlowScreen/components/FlowDiagram/ConfigS3Archive";
import ConfigS3Download from "../../mySkills/components/FlowScreen/components/FlowDiagram/ConfigS3Download";
import ConfigReadCredentials from "../../mySkills/components/FlowScreen/components/FlowDiagram/ReadCredentials";
import ReadTableConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/ReadTableConfig";
import KeyboardShortcutConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/KeyboardShortcutConfig";
import CloseFileConfig from "../../mySkills/components/FlowScreen/components/FlowDiagram/CloseFileConfig";

import { ADDABLE_SKILL_TYPES } from "../../../../redux/constants/skillConstants";
import breakIcon from "../../../../images/break.png";
import continueIcon from "../../../../images/continue.png";
import echoIcon from "../../../../images/branching/echoIcon.png";
import echoImage from "../../../../images/branching/echo-image.png";
import javascriptImage from "../../../../images/branching/javascriptImage.png";
import javascriptIcon from "../../../../images/branching/javascriptIcon.png";
import openAppIcon from "../../../../images/branching/open-app.svg";
import openAppImage from "../../../../images/branching/open-app-ill.svg";
import switchAppIcon from "../../../../images/branching/switch-app.svg";
import closeAppIcon from "../../../../images/branching/close-app.svg";
import closeAppImage from "../../../../images/branching/close-app-ill.svg";
import switchAppImage from "../../../../images/branching/switch-app-ill.svg";
import messageBoxIcon from "../../../../images/branching/messageBoxIcon.png";
import messageBoxImage from "../../../../images/branching/messageBox-image.png";
import s3ConnectIcon from "../../../../images/s3-connect.png";
import s3Connect from "../../../../images/AWS-S3-Connect.png";
import s3ArchiveIcon from "../../../../images/s3-archive.png";
import s3FileDownloadIcon from "../../../../images/s3-file-download.png";
import s3Archive from "../../../../images/s3-archive-illustration.png";
import s3Download from "../../../../images/s3-file-download-illustration.png";
import readCredIcon from "../../../../images/read-icon.svg";
import readTableIcon from "../../../../images/table-icon.png";
import readCred from "../../../../images/read-illustration.png";
import readTable from "../../../../images/table-illustration.png";
import keyboardshortCutIcon from "../../../../images/keyboard-shortcut.png";
import keyboardshortCut from "../../../../images/keyboard-illustration.png";
import closeFileIcon from "../../../../images/closefile-icon.png";
import closeFile from "../../../../images/closefile-illustration.png";

const updateDescription = (value, id) => {
  let {
    templateReducer: { getTemplate },
  } = store.getState();
  let actions = findAndUpdate(getTemplate?.template_data, id, {
    description: value,
  });
  store.dispatch(
    setTemplateData({
      ...getTemplate,
      template_data: actions,
    })
  );
  $(`#${id}`).toggle();
};

const findAndRemove = (arr, id) => {
  let found = arr.findIndex((i) => i.id === id);
  if (found > -1) {
    arr.splice(found, 1);
    console.log(arr);
  } else {
    arr.forEach((element) => {
      if (
        ["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)
      ) {
        console.log("recurssive", element.children, id);
        findAndRemove(element.children, id);
      }
    });
  }
  return arr;
};

const findAndUpdate = (arr, id, payload) => {
  let found = arr.findIndex((i) => i.id == id);
  if (found > -1) {
    arr[found] = { ...arr[found], ...payload };
  } else {
    arr.forEach((element) => {
      if (
        ["branch", "condition", "loop", "loop-nodes",  "try", "try-catch-node"].includes(element.type)
      ) {
        findAndUpdate(element.children, id, payload);
      }
    });
  }
  return arr;
};

const LoopStartDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div>
      <div className={`stop-node delay-node rt-block-full`}>
        {/* <span style={{ fontSize: 12, fontWeight: 'bold' }}> Description: </span> */}
        <div className="delay-flex">
          <div
            className="stepIconBlock"
            style={{ backgroundColor: "#eff1ff", borderColor: "#9f64ff" }}
          >
            <AllInclusive style={{ color: "#9f64ff" }} />
          </div>
          <div className="delay-text">
            <h4 className="node-titles">Loop start</h4>
          </div>
          {/* <div className="rth-tooltip">
            <div className="flex-rth-title">
              <p> Tooltip: </p>
              <Edit onClick={() => $(`#${node.id}`).toggle()} />
            </div>
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
            <div
              id={`${node.id}`}
              style={{ display: "none", marginTop: 10 }}
              className="rth-tooltip"
            >
              <input
                defaultValue={node.description}
                onBlur={(e) => updateDescription(e.target.value, node.id)}
              ></input>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
};

const StartNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className="start-node">
      {/* {node.name} */}
      <div className="rt-block rt-start">
        <div
          className="rtb-ico"
          style={{
            backgroundColor: "#02ce9d",
            cursor: "default",
          }}
        >
          <img src={playWhite} alt="" />
        </div>
        <div className="rtb-text">
          <p>Start</p>
        </div>
      </div>
    </div>
  );
};

const EndNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className="end-node">
      {/* {node.name} */}
      <div className="rt-block rt-end">
        <div
          className="rtb-ico"
          style={{
            backgroundColor: "#ff3333",
            cursor: "default",
          }}
        >
          <span className="circle"></span>
        </div>
        <div className="rtb-text">
          <p>End</p>
        </div>
      </div>
    </div>
  );
};

const NodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <>
      <div className="rt-block-full recording-block">
        <div className="rcd-icon">
          <img src={recordIcon} />
        </div>
        <div className="rcd-text " style={{ width: "100%" }}>
          <h4>Initiate Web/Desktop show process</h4>
          <div className="rth-tooltip">
            <div className="flex-rth-title">
              <p> Tooltip: </p>
              <Edit onClick={() => $(`#${node.id}`).toggle()} />
            </div>
            {node.description ? (
              <span style={{ fontSize: 12, fontWeight: "400" }}>
                {node.description}
              </span>
            ) : null}
            <div
              id={`${node.id}`}
              style={{ display: "none", marginTop: 10 }}
              className="rth-tooltip"
            >
              <textarea
                defaultValue={node.description}
                onBlur={(e) => updateDescription(e.target.value, node.id)}
              ></textarea>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

const ConditionNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div
      className={`rt-block-full condition-node ${
        false ? "node-configuring" : ""
      } ${true ? "node-status-error" : ""}`}
    >
      <div className="rotate-content">
        <h4 className="node-titles">{node.name}</h4>
      </div>
    </div>
  );
};

const StopNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
        >
          <img src={stopIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.name}</h4>
        </div>
      </div>
    </div>
  );
};

const DelayNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      {/* <span style={{ fontSize: 12, fontWeight: 'bold' }}> Description: </span> */}
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={waitIcon} />
        </div>

        <div className="delay-text">
          <h4 className="node-titles">Wait</h4>
          {/* <Edit onClick={() => $(`#${node.id}`).toggle()} /> */}
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      >
        {/* <input
          defaultValue={node.time}
          onBlur={(e) => updateTime(e.target.value, node.id)}
        ></input> */}
      </div>
    </div>
  );
};

const ReadValueNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div className="tl-cont-ico" style={{ borderColor: "#411bbe" }}>
              <img src={readIcon} style={{ width: "14px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Read</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img
          src={automationIcon}
          alt="pageScreenshot"
          style={{ width: "70%" }}
        />
      </div>
    </div>
  );
};

const MailIntegrationNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div className="tl-cont-ico">
              <img src={outlookIcon} style={{ width: "30px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Outlook Mail</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={outlookImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const FilesNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img src={filesandfolders} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Files / Folders</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={folderIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const ExcelNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img src={excelIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Excel Actions</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>

      <div className="rtb-screenshot filled-bg">
        <img src={automation} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const HttpApiNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
            >
              <img src={httpApi} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Service Call</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={httpApiIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const AssignNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={assign} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Assign</p>
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={assignIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const InvokeSkillNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={InvokeSkillIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              {node?.skillName ? (
                <p>{`Invoke Skill - ${node.skillName}`}</p>
              ) : (
                <p>{`Invoke Skill`}</p>
              )}
            </div>
          </div>
        </div>
        <div className="rth-tooltip">
          <div className="flex-rth-title">
            <p> Tooltip: </p>
            <Edit onClick={() => $(`#${node.id}`).toggle()} />
          </div>
          {node.description ? (
            <span style={{ fontSize: 12, fontWeight: "400" }}>
              {node.description}
            </span>
          ) : null}
          <div
            id={`${node.id}`}
            style={{ display: "none", marginTop: 10 }}
            className="rth-tooltip"
          >
            <textarea
              defaultValue={node.description}
              onBlur={(e) => updateDescription(e.target.value, node.id)}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={InvokeSkillImg} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const ToDoSkillNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#128fff", backgroundColor: "#eaf5ff" }}
            >
              <img src={todoIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              {node?.skillName ? (
                <p>{`To Do - ${node.skillName}`}</p>
              ) : (
                <p>{`To Do`}</p>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        <div className="flex-rth-title">
          <p> Tooltip: </p>
          <Edit onClick={() => $(`#${node.id}`).toggle()} />
        </div>
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}
        <div
          id={`${node.id}`}
          style={{ display: "none", marginTop: 10 }}
          className="rth-tooltip"
        >
          <textarea
            defaultValue={node.description}
            onBlur={(e) => updateDescription(e.target.value, node.id)}
          ></textarea>
        </div>
      </div>
    </div>
  );
};

const AddDataSetNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#00CD9D", backgroundColor: "#b2f7e6" }}
            >
              <Storage
                s
                style={{
                  width: "12px",
                  borderColor: "#00CD9D",
                  backgroundColor: "#b2f7e6",
                  color: "#00CD9D",
                }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Dataset</p>
            </div>
          </div>
          <div className="rth-tooltip">
            <div className="flex-rth-title">
              <p> Tooltip: </p>
              <Edit onClick={() => $(`#${node.id}`).toggle()} />
            </div>
            {node.description ? (
              <span style={{ fontSize: 12, fontWeight: "400" }}>
                {node.description}
              </span>
            ) : null}
            <div
              id={`${node.id}`}
              style={{ display: "none", marginTop: 10 }}
              className="rth-tooltip"
            >
              <textarea
                defaultValue={node.description}
                onBlur={(e) => updateDescription(e.target.value, node.id)}
              ></textarea>
            </div>
          </div>
        </div>
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={folderIcon} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const ContinueNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={continueIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      ></div>
    </div>
  );
};
const BreakNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`stop-node delay-node rt-block-full`}>
      <div className="delay-flex">
        <div
          className="stepIconBlock"
          style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
        >
          <img src={breakIcon} />
        </div>
        <div className="delay-text">
          <h4 className="node-titles">{node.description}</h4>
        </div>
      </div>
      <div
        id={`${node.id}`}
        style={{ display: "none", marginTop: 10 }}
        className="rth-tooltip"
      ></div>
    </div>
  );
};
const EchoNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              // style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
              style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img
                src={echoIcon}
                // style={{ width: "12px" }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Echo</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={echoImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const TechnologyNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#e6b921", backgroundColor: "#fff2c4" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={javascriptIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Javascript</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={javascriptImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const OpenAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#9f64ff", backgroundColor: "#f2eaff" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={openAppIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Open App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={openAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const CloseAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={closeAppIcon} style={{ width: "10px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Close App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={closeAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const SwitchAppNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#02b6ce", backgroundColor: "#edfdff" }}
              //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img src={switchAppIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Switch App</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={switchAppImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const MessageBoxNodeDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              // style={{ borderColor: "#ff07f5", backgroundColor: "#ffe5fe" }}
              style={{ padding: "0px", borderRadius: "0px", border: "none" }}
            >
              <img
                src={messageBoxIcon}
                // style={{ width: "12px" }}
              />
            </div>
            <div className="rth-tl-tp">
              <p>Message Box</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={messageBoxImage} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const SecretNodeDisplay = () => {
  const node = useContext(NodeContext);
  return <div>{null}</div>;
};
const AddS3Node = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#ff7007", backgroundColor: "#ffe3ce" }}
            >
              <img style={{ width: "12px" }} src={s3ConnectIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 Connect</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Connect} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const AddS3ArchiveNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#173bff", backgroundColor: "#eff1ff" }}
            >
              <img style={{ width: "12px" }} src={s3ArchiveIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 Archive</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Archive} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const AddS3DownloadNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ borderColor: "#1d262e", backgroundColor: "#ebebeb" }}
            >
              <img style={{ width: "12px" }} src={s3FileDownloadIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>S3 File Download</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={s3Download} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const ReadCredentialsNode = () => {
  const node = useContext(NodeContext);
  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
            >
              <img style={{ width: "12px" }} src={readCredIcon} alt="" />
            </div>
            <div className="rth-tl-tp">
              <p>Read Credentials</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={readCred} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const ReadTableNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
            >
              <img src={readTableIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Read Table</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={readTable} alt="pageScreenshot" />
      </div>
    </div>
  );
};
const keyboardShortcutNode = () => {
  return {
    actionType: "KEY_STROKES",
    label: "Keyboard ShortCuts",
    key: "keyboardshortcuts",
    description: "",
    instruction: "",
    status: true,
    breakpoint: false,
  };
};
const CloseFileNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
            >
              <img src={closeFileIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Close File</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={closeFile} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const KeyboardShortcutNodeDisplay = () => {
  const node = useContext(NodeContext);

  return (
    <div className={`delay-node rt-block-full`}>
      <div className="rt-block-header">
        <div className="rth-title">
          <div className="tl-cont flex-irt">
            <div
              className="tl-cont-ico"
              style={{ backgroundgColor : "#f2eaff" ,  borderColor : "#9f64ff" }}
            >
              <img src={keyboardshortCutIcon} style={{ width: "12px" }} />
            </div>
            <div className="rth-tl-tp">
              <p>Keyboard ShortCuts</p>
            </div>
          </div>
        </div>
      </div>
      <div className="rth-tooltip">
        {node.description ? (
          <span style={{ fontSize: 12, fontWeight: "400" }}>
            {node.description}
          </span>
        ) : null}{" "}
      </div>
      <div className="rtb-screenshot filled-bg">
        <img src={keyboardshortCut} alt="pageScreenshot" />
      </div>
    </div>
  );
};

const TryCatchDisplay = () => {
  const node = useContext(NodeContext);
  return (
    <div>
      {node.name == "Error Handle" ? (
        <div className={`stop-node delay-node rt-block-full`}>
          <div className="delay-flex">
            <div
              className="stepIconBlock"
              style={{ backgroundColor: "#f4c6c6", borderColor: "#ff0000" }}
            >
              {node.name == "Error Handle" ? (
                <ReportProblem style={{ color: "#ff0000" }} />
              ) : null}
            </div>

            <div className="delay-text">
              <h4 className="node-titles">{node.name}</h4>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

let registerNodes = [
  {
    type: "start",
    name: "start",
    actionType: "start",
    displayComponent: StartNodeDisplay,
    isStart: true,
    addableNodeTypes: ["try"],
  },
  {
    type: "end",
    name: "end",
    actionType: "end",
    displayComponent: EndNodeDisplay,
    isEnd: true,
  },
  {
    type: "record",
    name: "show",
    actionType: "record",
    displayComponent: NodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff3ea", borderColor: "#ff7007" }}
      >
        <img src={recordIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "continue",
    name: "continue",
    actionType: "continue",
    displayComponent: ContinueNodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={continueIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "break",
    name: "break",
    actionType: "break",
    displayComponent: BreakNodeDisplay,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={breakIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "wait",
    name: "wait",
    actionType: "wait",
    displayComponent: DelayNodeDisplay,
    configComponent: null,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eff1ff", borderColor: "#173bff" }}
      >
        <img src={waitIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "read",
    name: "read",
    actionType: "read",
    displayComponent: ReadValueNodeDisplay,
    configComponent: ReadValueConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eff1ff", borderColor: "#411bbd" }}
      >
        <img src={readIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "filesandfolders",
    name: "Files/Folders",
    actionType: "readfile",
    displayComponent: FilesNodeDisplay,
    configComponent: FilesFoldersConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={filesandfolders} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "excel",
    name: "Excel",
    actionType: "OPEN_SPREADSHEET",
    displayComponent: ExcelNodeDisplay,
    configComponent: ExcelConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={excelIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "echo",
    name: "Echo",
    actionType: "ECHO",
    displayComponent: EchoNodeDisplay,
    configComponent: EchoConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        // style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
        style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={echoIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "TECHNOLOGY",
    name: "Javascript",
    actionType: "TECHNOLOGY",
    displayComponent: TechnologyNodeDisplay,
    configComponent: TechnologyConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={javascriptIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "OPENAPP",
    name: "Open App",
    actionType: "OPENAPP",
    displayComponent: OpenAppNodeDisplay,
    configComponent: OpenAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={openAppIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "CLOSEAPP",
    name: "Close App",
    actionType: "CLOSEAPP",
    displayComponent: CloseAppNodeDisplay,
    configComponent: CloseAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={closeAppIcon} style={{ width: "10px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "SWITCHAPP",
    name: "Switch App",
    actionType: "SWITCHAPP",
    displayComponent: SwitchAppNodeDisplay,
    configComponent: SwitchAppConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2c4", borderColor: "#e6b921" }}
        //style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={switchAppIcon} style={{ width: "12px" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "messagebox",
    name: "Message Box",
    actionType: "MESSAGE_BOX",
    displayComponent: MessageBoxNodeDisplay,
    configComponent: MessageBoxConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        // style={{ backgroundColor: "#ffe3ce", borderColor: "#ff7007" }}
        style={{ padding: "0px", borderRadius: "0px", border: "none" }}
      >
        <img src={messageBoxIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "httpapi",
    name: "Service Call",
    actionType: "httpapi",
    displayComponent: HttpApiNodeDisplay,
    configComponent: HttpApiConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ffe5fe", borderColor: "#ff07f5" }}
      >
        <img src={httpApi} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "assign",
    name: "Assign",
    actionType: "assign",
    displayComponent: AssignNodeDisplay,
    configComponent: AssignConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={assign} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "GET_AZURESECRET",
    name: "Get Secret",
    actionType: "GET_AZURESECRET",
    displayComponent: SecretNodeDisplay,
    configComponent: null,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={assign} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "sendMail",
    name: "Outlook Mail",
    actionType: "sendMail",
    displayComponent: MailIntegrationNodeDisplay,
    configComponent: SendMailConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#deeef9", borderColor: "#0D75BB" }}
      >
        <img src={outlookIcon} style={{ width: "24px", maxWidth: "initial" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "invokeSkill",
    name: "Invoke Skill",
    actionType: "invokeSkill",
    displayComponent: InvokeSkillNodeDisplay,
    configComponent: InvokeSkillConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff", borderColor: "#000" }}
      >
        <img
          src={InvokeSkillIcon}
          style={{ width: "12px", maxWidth: "initial" }}
        />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "toDoSkill",
    name: "Add a ToDo",
    actionType: "toDoSkill",
    displayComponent: ToDoSkillNodeDisplay,
    configComponent: ToDoSkillConfigForm,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#eaf5ff", borderColor: "#128fff" }}
      >
        <img src={todoIcon} style={{ width: "12px", maxWidth: "initial" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "condition",
    name: "condition",
    actionType: "condition",
    displayComponent: ConditionNodeDisplay,
    configComponent: ConfigPanel,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    configTitle: "Configure Condition",
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "stop",
    name: "stop",
    displayComponent: StopNodeDisplay,
    actionType: "stop",
    configComponent: null,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img src={stopIcon} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "loop",
    name: "loop",
    conditionNodeType: "loop-nodes",
    actionType: "loop",
    addConditionIcon: null,
    configComponent: null,
    conditionMaxNum: 1,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "loop-nodes",
    name: "loop-nodes",
    displayComponent: LoopStartDisplay,
    actionType: "loopStart",
    configComponent: LoopConfigPanel,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "data-set",
    name: "Add Dataset",
    actionType: "addDataSet",
    displayComponent: AddDataSetNode,
    configComponent: ConfigDataSet,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#b2f7e6", borderColor: "#00CD9D" }}
      >
        <Storage style={{ color: "#00CD9D" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_CONNECT",
    name: "S3 Connect",
    actionType: "S3_CONNECT",
    displayComponent: AddS3Node,
    configComponent: ConfigS3,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: " #ffe3ce", borderColor: "#ff7007" }}
      >
        <img src={s3ConnectIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_FILE_ARCHIVE",
    name: "S3 File Archive",
    actionType: "S3_FILE_ARCHIVE",
    displayComponent: AddS3ArchiveNode,
    configComponent: ConfigS3Archive,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: " #ffe3ce", borderColor: " #173bff" }}
      >
        <img src={s3ArchiveIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "S3_FILE_DOWNLOAD",
    name: "S3 File Download",
    actionType: "S3_FILE_DOWNLOAD",
    displayComponent: AddS3DownloadNode,
    configComponent: ConfigS3Download,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#ebebeb", borderColor: "#1d262e" }}
      >
        <img style={{ width: "12px" }} src={s3FileDownloadIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "READ_CREDENTIALS",
    name: "Read Credentials",
    actionType: "READ_CREDENTIALS",
    displayComponent: ReadCredentialsNode,
    configComponent: ConfigReadCredentials,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img style={{ width: "12px" }} src={readCredIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "READ_TABLE",
    name: "Read Table",
    actionType: "READ_TABLE",
    displayComponent: ReadTableNodeDisplay,
    configComponent: ReadTableConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
      >
        <img src={readTableIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "CLOSE",
    name: "Close File",
    actionType: "CLOSE",
    displayComponent: CloseFileNodeDisplay,
    configComponent: CloseFileConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#fff2f2", borderColor: "#ff3333" }}
      >
        <img src={closeFileIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },

  {
    type: "KEY_STROKES",
    name: "Keyboard ShortCuts",
    actionType: "KEY_STROKES",
    displayComponent: KeyboardShortcutNodeDisplay,
    configComponent: KeyboardShortcutConfig,
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundgColor : "#f2eaff" ,  borderColor : "#9f64ff"  }}
      >
        <img src={keyboardshortCutIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "branch",
    name: "branch",
    actionType: "branch",
    conditionNodeType: "condition",
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#edfdff", borderColor: "#02b6ce" }}
      >
        <img src={branchIcon} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
  {
    type: "try",
    name: "try",
    conditionNodeType: "try-catch-node",
    actionType: "try",
    addConditionIcon: null,
    configComponent: null,
    conditionMaxNum: 1,
    customRemove: true,
    className: "try-catch-parent try-catch-parent-verbose",
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: [],
  },

  {
    type: "try-catch-node",
    name: "try-catch-node",
    className: "try-catch-node try-catch-node-verbose",
    displayComponent: TryCatchDisplay,
    actionType: "try-catch-node",
    customRemove: true,
    configComponent: null,
    deleteConfirmTitle: "Are you sure to delete this action block?",
    addIcon: (
      <div
        className="stepIconBlock"
        style={{ backgroundColor: "#f2eaff", borderColor: "#9f64ff" }}
      >
        <AllInclusive style={{ color: "#9f64ff" }} />
      </div>
    ),
    addableNodeTypes: ADDABLE_SKILL_TYPES,
  },
];

const getNode = (type, child = false) => {
  return {
    id: uuid(),
    type: type,
    name: type,
    actionType: type,
    children: child ? [] : undefined,
    isStart: type === "start",
    isEnd: type === "end",
  };
};

const getWaitNode = () => {
  return {
    actionType: "wait",
    label: "Wait",
    key: "wait",
    allowNesting: false,
    description: ``,
    status: true,
    breakpoint: false,
    instruction: "",
  };
};


const getExcelActionNode = () => {
  return {
    actionType: "OPEN_SPREADSHEET",
    label: "Excel",
    key: "excel",
    instruction: "",
    description: "",
    status: true,
  };
};

const getFilesAndFolderNode = () => {
  return {
    actionType: "READFILE",
    label: "Files/Folders",
    key: "filesandfolders",
    instruction: "",
    description: "",
    status: true,
  };
};

const getHttpApiNode = () => {
  return {
    actionType: "HTTP",
    label: "HTTP API",
    key: "httpapi",

    reqBody: "",
    method: "GET",
    body: false,
    url: "",
    headers: false,
    apiHeaders: [
      {
        id: 1,
        headerKey: "Content-Type",
        headerValue: "application/json",
        keyId: 1.1,
      },
    ],
    variableName: "",
    instruction:
      "api_config = { method:'POST', header:[\"Content-Type:application/json\"],body:{}}\napi sds\necho api_result\necho api_json",

    description: "API call to sds with Content-Type:application/json",
    apiFileAttachments: "",
    status: true,
    attachments: false,
  };
};

const getAssignNode = () => {
  return {
    actionType: "ASSIGN",
    label: "Assign",
    key: "assign",
    variable1: "",
    variable2: "",

    varType: "",

    description: "",
  };
};

const getSendMailNode = () => {
  return {
    actionType: "sendOutlookMail",
    label: "sendOutlookMail",
    key: "sendOutlookMail",
    subActions: [],
    allowNesting: true,
    // to: "",
    // subject: "",
    // body: "",
    // cc: "",
    // bcc: "",
    // attachments: "",
    api: "http://localhost:8002/api/v1/sendMail",
    description: "",
    status: true,
    breakpoint: false,
    instruction: "",
  };
};

const getInvokeSkillNode = () => {
  return {
    actionType: "invokeSkill",
    label: "invokeSkill",
    key: "invokeSkill",
    status: true,
    description: "",
    instruction: "",
    skillId: "",
    skillName: "",
  };
};
const getToDoSkillNode = () => {
  return {
    actionType: "invokeSkill",
    label: "invokeSkill",
    key: "invokeSkill",
    status: true,
    description: "",
    instruction: "",
    skillId: "",
    skillName: "",
  };
};
const getContinueNode = () => {
  return {
    actionType: "continue",
    label: "Statements",
    key: "continue",
    allowNesting: false,
    statement: "continue",
    variableName: "",
    instruction: "continue",
    status: true,
    breakpoint: false,
    description: "Continue",
  };
};

const getBreakNode = () => {
  return {
    actionType: "break",
    label: "Statements",
    key: "break",
    allowNesting: false,
    statement: "break",
    variableName: "",
    instruction: "break",
    status: true,
    breakpoint: false,
    description: "Break",
  };
};
const getReadNode = () => {
  return {
    actionType: "read",
    label: "read",
    key: "read",
    status: true,
    readFromElement: "",
    readToVariable: "",
    instruction: "",
  };
};
const downloadS3Node = () => {
  return {
    actionType: "S3_FILE_DOWNLOAD",
    label: "Download File",
    key: "s3downloadfile",
    description: "",
    allowNesting: false,
    bucketName: "",
    folderPath: "",
    keyName: "",
    status: true,
    breakpoint: false,
    instruction: "download s3 file",
    description: "Download file from AWS S3",
    Region: "", //(mandate)
    Archive: false, //(optional)
    ArchiveToBucketName: "", //(optional)
    ArchiveKeyName: "", //(optional)
  };
};

const connectS3ArchiveNode = () => {
  return {
    actionType: "S3_FILE_ARCHIVE",
    label: "Archive File",
    key: "s3archivefile",
    description: "",
    allowNesting: false,
    status: true,
    sourceBucketName: "", //(mandate)
    sourceKeyName: "", //(mandate)
    breakpoint: false,
    instruction: "archive s3 file",
    description: "archive s3 file",
    Region: "", //(mandate)
    destinationBucketName: "", //(mandate)
    destinationKeyName: "", //(optional)
  };
};
const connectS3Node = () => {
  return {
    actionType: "S3_CONNECT",
    label: "S3 Connection",
    key: "s3connection",
    description: "",
    allowNesting: false,
    accessKey: "",
    secretKey: "",
    status: true,
    breakpoint: false,
    instruction: "Connect to S3",
    description: "Connect to AWS S3",
  };
};
const readCredentialsNode = () => {
  return {
    actionType: "READ_CREDENTIALS",
    label: "Read Credentials",
    key: "ReadCredentials",
    allowNesting: false,
    CredName: "",
    variable: "",
    UserName: "",
    Password: "",
    variableName: "",
    instruction: "",
    status: true,
    description: "read credentials",
    newdescription: "read credentials",
  };
};
const closeFileNode = () => {
  return {
    actionType: "CLOSE",
    label: "Close File",
    key: "close",
    description: "",
    instruction: "",
    status: true,
    breakpoint: false,
  };
};
// const getDesktopAutomation = () => {
//   return {
//     origin: "desktop",
//     actionType: "desktop",
//     label: "Desktop Automation",
//     key: "desktop",
//     isShow: true,
//     description: "",
//     instruction: "",
//   };
// };

// const getWebAutomation = () => {
//   return {
//     actionType: "webautomation",
//     label: "Web Automation",
//     key: "webautomation",
//     isShow: true,
//     description: "",
//     instruction: "",
//   };
// };

const getRearrangedData = (actions) => {
  let temp = [];
  temp.push(getNode("start"));
  actions.forEach((a, i) => {
    if (a.nodeId && a.kind === "branch") {
      a.type = "branch";
      a.actionType = "branch";
      a.children = a.children || [];
      temp.push(a);
    } else if (!a.type) {
      a.type = a.actionType;
      temp.push(a);
    } else {
      temp.push(a);
    }
  });
  temp.push(getNode("end"));
  return temp;
};

const findDiff = (arr1, arr2, type) => {
  let obj1, obj2, diff;
  if (arr1?.length !== arr2?.length) {
    diff = _.differenceWith(arr2, arr1, _.isEqual).filter(
      (i) => i.type === type
    )[0];
  } else {
    obj1 = buildFlatNodes({ registerNodes, nodes: arr1 });
    obj2 = buildFlatNodes({ registerNodes, nodes: arr2 });
    diff = _.differenceWith(obj2, obj1, _.isEqual).filter(
      (i) => i.type === type
    )[0];
  }
  return diff;
};

const saveFlow = (templateData, actions) => {
  let updatedData = { ...templateData, template_data: actions };
  store.dispatch(updateTemplateData(updatedData));
};

const ConfigureTemplate = () => {
  const dispatch = useDispatch();
  const params = useParams();
  const [nodes, setNodes] = useState([]);
  const [customClassName, setCustomClassName] = useState("");

  const [loader, setLoader] = useState(false);
  const getTemplate = useSelector(
    (state) => state.templateReducer?.getTemplate
  );

  const loading = useSelector((state) => state.templateReducer.loading);
  const currentTeam = JSON.parse(localStorage.getItem("orgDetails"));

  useEffect(() => {
    let _actions = _.cloneDeep(getTemplate?.template_data);

    let actions = getRearrangedData(_actions || []);
    setNodes(actions);
  }, [getTemplate]);

  useEffect(() => {
    setLoader(loading);
  }, [loading]);

  const handleChange = (_nodes, e) => {
    console.log(_nodes, e, "Handle change");
    let diff = {};
    switch (e) {
      case "init-builder":
        setNodes(_nodes);
        break;
      case "click-node":
      case "close-drawer":
        break;
      case "add-node__record":
      case "node__record":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        saveFlow(getTemplate, _nodes);
        break;
      case "add-node__branch":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        _nodes.forEach((i) => {
          if (i.type === "branch") {
            i.nodeId = i.id;
            i.kind = "branch";
          }
        });
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        // saveFlow(getTemplate, _nodes);

        break;
      case "add-node__wait":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "wait");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getWaitNode() });
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        // saveFlow(getTemplate, _nodes);

        break;

      case "add-node__read":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "read");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getReadNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        // saveFlow(getTemplate, _nodes);

        break;

      case "add-node__filesandfolders":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "filesandfolders");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getFilesAndFolderNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;

      case "add-node__excel":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "excel");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getExcelActionNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
      case "add-node__httpapi":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "httpapi");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getHttpApiNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;

      case "add-node__assign":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "assign");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getAssignNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
      case "add-node__sendMail":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "sendMail");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getSendMailNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;

      case "add-node__invokeSkill":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "invokeSkill");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getInvokeSkillNode() });

        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
      case "add-node__toDoSkill":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "toDoSkill");
        _nodes = findAndUpdate(_nodes, diff.id, { ...getToDoSkillNode() });
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
      case "add-node__loop":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "loop");
        diff.actionType = "loop";
        diff.children.pop();
        diff.children[0].actionType = "loop-nodes";
        setCustomClassName("flow-builder-for-loop");
        _nodes = findAndUpdate(_nodes, diff.id, { ...diff });
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
      case "add-node__loop-nodes":
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        diff = findDiff(getTemplate?.template_data, _nodes, "loop-nodes");
        _nodes = findAndRemove(_nodes, diff.id);
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
        break;
        case "add-node__continue":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "continue");
          _nodes = findAndUpdate(_nodes, diff.id, { ...getContinueNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
        case "add-node__break":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "break");
          _nodes = findAndUpdate(_nodes, diff.id, { ...getBreakNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
        case "add-node__S3_FILE_DOWNLOAD":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "S3_FILE_DOWNLOAD");
          _nodes = findAndUpdate(_nodes, diff.id, { ...downloadS3Node() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
        case "add-node__S3_CONNECT":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "S3_CONNECT");
          _nodes = findAndUpdate(_nodes, diff.id, { ...connectS3Node() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
        case "add-node__S3_FILE_ARCHIVE":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "S3_FILE_ARCHIVE");
          _nodes = findAndUpdate(_nodes, diff.id, { ...connectS3ArchiveNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
        case "add-node__READ_CREDENTIALS":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "READ_CREDENTIALS");
          _nodes = findAndUpdate(_nodes, diff.id, { ...readCredentialsNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
        case "add-node__CLOSE":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "CLOSE");
          _nodes = findAndUpdate(_nodes, diff.id, { ...closeFileNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
        case "add-node__KEY_STROKES":
          _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
          diff = findDiff(getTemplate?.template_data, _nodes, "KEY_STROKES");
          _nodes = findAndUpdate(_nodes, diff.id, { ...keyboardShortcutNode() });
          dispatch(
            setTemplateData({
              ...getTemplate,
              template_data: _nodes,
            })
          );
          break;
      default:
        _nodes = _nodes.filter((i) => !(i.isStart || i.isEnd));
        dispatch(
          setTemplateData({
            ...getTemplate,
            template_data: _nodes,
          })
        );
    }
  };
  return (
    <>
      {loading ? (
        <Loader
          styles={{ width: "80px", margin: "auto" }}
          root={{ display: "flex" }}
        />
      ) : (
        <>
          <FlowBuilder
            className={`crt-tpl-flow outer-drag scrollable ${customClassName}`}
            // className="outer-drag scrollable"
            nodes={nodes}
            onChange={handleChange}
            registerNodes={registerNodes}
            zoomTool
            backgroundColor={"#F2F5F6"}
            readonly={parseInt(getTemplate?.organizationId) !== currentTeam?.id}
          />
        </>
      )}
    </>
  );
};

export default connect(null, {})(ConfigureTemplate);
