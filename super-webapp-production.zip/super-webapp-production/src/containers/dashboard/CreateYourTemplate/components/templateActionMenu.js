import React from "react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";

import saveimg from "../../../../images/doc-input.png";

import { notify } from "../../../../redux/actions/snack";

import {
  getTemplateById,
  setTemplateData,
  updateTemplateData,
} from "../../../../redux/actions/template";
import { store } from "../../../../redux";

const TemplateActionMenu = (props) => {
  const [isEditingTemplateName, setIsEditingTemplateName] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const [isFlowPublishing, setIsFlowPublishing] = useState("");
  const [isSavingFlow, setIsSavingFlow] = useState(false);

  const getTemplate = useSelector(
    (state) => state.templateReducer?.getTemplate
  );
  const currentTeam = JSON.parse(localStorage.getItem("orgDetails"));

  const dispatch = useDispatch();
  const history = useHistory();

  const changeTemplateName = (name) => {
    setIsEditingTemplateName(false);
  };

  const publishTemplate = async (itemId) => {
    setIsFlowPublishing(true);
    let _tempData = { ...getTemplate, status: "registered" };
    await dispatch(updateTemplateData(_tempData));
    dispatch(notify("success", "Published "));
    history.push(window.location.pathname);
    setIsFlowPublishing(false);
  };

  const skill = useSelector((state) => state.skillReducer.trainDraft);

  const saveTemplateDraft = async () => {
    let newAction = skill?.RAW_DATA?.actions;
    let _temp = getTemplate;
    setIsSavingFlow(true);

    if (newAction?.length) {
      _temp.template_data = newAction;
      if (getTemplate.status) {
        _temp.status = "pending";
      }
    }

    await dispatch(updateTemplateData(_temp));

    setIsSavingFlow(false);
    history.push(window.location.pathname);
  };
  console.log(isSavingFlow, "save");
  return (
    <React.Fragment>
      <div className="flex-title rt-flex-title">
        <div className="cts-title">
          {/* Template initials */}
          <div className="cts-ico">
            <span>
              {getTemplate?.template_name
                ? getTemplate?.template_name?.toUpperCase().charAt(0)
                : null}
            </span>
          </div>

          {/* Template Name */}

          <div className="cts-title-subt">
            <div class="title-edit-skill">
              {isEditingTemplateName ? (
                <input
                  name="template_Name"
                  placeholder="Enter Template Name"
                  defaultValue={getTemplate?.template_name}
                  onBlur={(e) => changeTemplateName(e.target.value)}
                ></input>
              ) : (
                <p>{getTemplate?.template_name}</p>
              )}

              <div
                className="edit-btn"
                tooltip="edit skill name"
                onClick={(e) => setIsEditingTemplateName(true)}
              >
                {/* <img src={editIcon} /> */}
              </div>
            </div>

            {/* Template Description */}
          </div>
        </div>

        {/* Template options  */}
        <div className="rt-btns">
          {/* Save button */}

          {parseInt(getTemplate?.organizationId) === currentTeam?.id ? (
            <>
              {isSavingFlow ? (
                <button className="sm-btn">
                  <div class="sp sp-circle text-light"></div>
                </button>
              ) : (
                <button
                  className="sm-btn"
                  disabled={getTemplate?.template_data ? "" : "disabled"}
                  onClick={() => saveTemplateDraft()}
                >
                  <img src={saveimg} alt="" />

                  <span>Save</span>
                </button>
              )}
            </>
          ) : null}
          {parseInt(getTemplate?.organizationId) === currentTeam?.id ? (
            <React.Fragment>
              {getTemplate?.status === "registered" ? (
                <>
                  <button className="sm-btn" disabled={"disable"}>
                    <img src={saveimg} alt="" />

                    <span>Registered</span>
                  </button>
                </>
              ) : (
                <>
                  {isFlowPublishing ? (
                    <button className="sm-btn">
                      <div class="sp sp-circle text-light"></div>
                    </button>
                  ) : (
                    <button
                      className="sm-btn"
                      disabled={getTemplate?.template_data ? "" : "disabled"}
                      onClick={() => publishTemplate()}
                    >
                      <img src={saveimg} alt="" />

                      <span>Register</span>
                    </button>
                  )}
                </>
              )}
            </React.Fragment>
          ) : null}
        </div>
      </div>
    </React.Fragment>
  );
};
export default TemplateActionMenu;
