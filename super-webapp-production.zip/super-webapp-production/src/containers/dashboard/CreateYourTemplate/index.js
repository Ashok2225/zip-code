import React, { useEffect, useState } from "react";
import EmptyLoader from "../../../components/emptyLoader";

import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { notify } from "../../../components/Snack";
import { getAllTemplates } from "../../../redux/actions/template";

import TemplateCard from "../CreateTemplate/TemplateCard";
import Loader from "../../../components/loader";

const CreateYourTemplate = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const templateReducer = useSelector((state) => state.templateReducer);
  const [loading, setIsLoading] = useState(true);
  const getOrgDetails = JSON.parse(window.localStorage.getItem("orgDetails"));
  const orgId = getOrgDetails ? getOrgDetails.id : null;
  useEffect(() => {
    if (orgId !== null) {
      getTemplateCard();
    }
  }, [orgId]);
  const getTemplateCard = async () => {
    await dispatch(getAllTemplates());
    setIsLoading(false);
  };
  return (
    <React.Fragment>
      <div className="template-flex">
        <div className="template-box scrollable">
          <div className="tp-title flex-title">
            <h3>Create A Custom Template To Get Started</h3>

            <div className="rt-btns">
              <button
                className="btn btn-primary btn-outline"
                data-toggle="modal"
                data-target="#viewCreateTemplate"
              >
                Create New
              </button>
            </div>
          </div>

          {loading ? (
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          ) : (
            <>
              {templateReducer?.allTemplates?.length ? (
                <TemplateCard />
              ) : (
                <EmptyLoader />
              )}
            </>
          )}
        </div>
      </div>
    </React.Fragment>
  );
};

export default CreateYourTemplate;
