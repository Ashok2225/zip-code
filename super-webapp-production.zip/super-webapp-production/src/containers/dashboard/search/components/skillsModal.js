import React, { Component } from "react";
import { connect } from "react-redux";
import getColors from "../../../../components/colors"
class SkillsModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skills: []
    };
  }

  saveSkill = (item) => {
    this.props.saveFavoriteSkill(item);
  };

  componentWillReceiveProps(nextProps) {
    const { favoriteSkills, my_skills } = nextProps.skillReducer;
    const _skills = my_skills.map((item) => {
      if (!favoriteSkills.map((_i) => _i.ID).includes(item.ID)) {
        return item;
      }
    });
    this.setState({ skills: _skills });
  }

  render() {
    return (
      <div className="modal crt-skill fade" id="add-new-skill" role="dialog">
        <div className="modal-dialog modal-sm">
          <div className="modal-content">
            <button type="button" className="close" data-dismiss="modal">
              &times;
            </button>
            <div className="modal-body">
              <div className="modal-body md-search-list">
                {this.state.skills.length === 0 && (
                  <p style={{ textAlign: "center" }}> No skill found!</p>
                )}

                {this.state.skills.map((item, i) => {
                  if (item) {
                    return (
                      <div
                        className="mds-list align-row"
                        data-dismiss="modal"
                        onClick={() => this.saveSkill(item)}
                        style={{ margin: "10px 0px" }}
                        key={i}
                      >
                        <div className="tl-icon">
                          <div
                            className="cts-avatar"
                            style={{ backgroundColor: getColors(item.SKILL_NAME) }}
                          >
                            <span>{item ? item.SKILL_NAME[0] : ""}</span>
                          </div>
                        </div>
                        <div
                          className="tl-cont"
                          style={{ height: 30, lineHeight: "30px" }}
                        >
                          {item ? item.SKILL_NAME : ""}
                        </div>
                      </div>
                    );
                  }
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer
});

export default connect(mapStateToProps, {})(SkillsModal);
