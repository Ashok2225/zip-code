import React, { Component } from "react";
import { connect } from "react-redux";

import { setMessage } from '../../../redux/actions/chatActions'
import { getKeycloackRefreshToken } from "../../../redux/actions/auth"
import { getUserSkills, saveFavoriteSkill, getFavoriteSkills } from '../../../redux/actions/skill'
import { removeFavoriteSkill } from '../../../redux/actions/skill'

import Chat from '../../chat'
import SkillsModal from "./components/skillsModal";

import fevicon from "../../../images/fevicon.png"
import backArrow from "../../../images/back-arrow.png"
import search from "../../../images/search.png"
import micIcon from "../../../images/mic-icon.png"
import deleteIcon from "../../../images/training/delete-red.png"
import getColors from "../../../components/colors"

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mySkills: [],
      query: "",
      showChat: false,
      defaultInputPlaceHolder: 'Hi, I’m Super, your personal assistant. How may I help you?',
      inputPlaceHolder: 'Hi, I’m Super, your personal assistant. How may I help you?'
    };
  }

  handleSearchResults = () => {

  }

  setQuery = (e) => {
    this.setState({ query: e.target.value })
  }

  toggleChat = () => {
    let { showChat } = this.state;
    this.setState({ showChat: !showChat })
  }

  onKeyPress = async (e) => {
    if (e.key === 'Enter') {
      let _message = { text: this.state.query, start_over: true }
      _message = window.chatSocket.finalPayload(_message, true, await getKeycloackRefreshToken(), this.state.query)
      this.props.setMessage(_message)
      window.chatSocket.conn.send(_message)
      this.toggleChat()
    }
  }

  componentDidMount() {
    this.props.getUserSkills();
    this.props.getFavoriteSkills();
  }

  saveFavoriteSkill = (skill) => {
    this.props.saveFavoriteSkill(skill)
  }

  loadSkillAndRedirect = (skill) => {
    this.props.history.push({
      pathname: '/dashboard/skills',
      state: { skill, enableChat: true }
    })
  }


  speechToText = () => {
    let { defaultInputPlaceHolder } = this.state;
    var SpeechRecognition = SpeechRecognition || window.webkitSpeechRecognition;
    var recognition = new SpeechRecognition();
    recognition.onstart = () => {
      this.setState({ inputPlaceHolder: "Listening ...", query: "" })
    };

    recognition.onspeechend = () => {
      this.setState({ inputPlaceHolder: "Thinking ..." })
      recognition.stop();
    }
    recognition.onresult = (event) => {
      var transcript = event.results[0][0].transcript;
      console.log('[SPEECH_RECOGNIZE]', transcript)
      this.setState({ inputPlaceHolder: defaultInputPlaceHolder, query: transcript })
      this.onKeyPress({ key: "Enter" })
    };
    recognition.start();
  }

  render() {
    let { showChat, inputPlaceHolder, query } = this.state;
    let { favoriteSkills, my_skills } = this.props.skillReducer;
    return (
      <>
        <div className="knb-chat" >
          <SkillsModal skills={my_skills} favoriteSkills={favoriteSkills} saveFavoriteSkill={this.saveFavoriteSkill} />
          {
            showChat ?
              <div className="align-row" style={{ backgroundColor: "#f2f5f6" }}>
                <div className="align-column" style={{ width: '100%' }}>
                  <div className="" >
                    <div class="knb-title">
                      <div class="back-title">
                        <button class="back-qa" onClick={() => { this.toggleChat() }}><img src={backArrow} alt={backArrow} /></button>
                      </div>
                      <p class="kn-title" style={{ flex: 1 }}>Back to Search</p>
                      <div class="btn-right">
                      </div>
                    </div>
                  </div>
                  <Chat showHistory={false} showStartOver={false} />
                </div>
              </div> :
              <div className="align-row full-height" style={{ backgroundColor: "#f2f5f6", height: '100vh' }}>

                <div className="align-middle" style={{ width: '60%' }}>
                  <div className="search-g-img">
                    <img src={fevicon} alt="logo" />
                  </div>
                  <div class="search-g-input">
                    <div class="input-search">
                      <span class="search-icon">
                        <img src={search} alt="" />
                      </span>
                    </div>
                    <div class="input-gs">
                      <input className="super-search" type="text" onChange={(e) => this.setQuery(e)} onKeyDown={(e) => this.onKeyPress(e)} placeholder={inputPlaceHolder} value={query} />
                    </div>
                    <div class="mic-g-s">
                      <img src={micIcon} onClick={this.speechToText} />
                    </div>
                  </div>

                  <div class="sg-opt">
                    <div className="sh-list">

                      <div className="pinned-items">
                        {favoriteSkills ? favoriteSkills.map(skill => {
                          if (skill) {
                            return (
                              <div class="tl-blocks" style={{ position: "relative" }}>
                                <div onClick={() => { this.loadSkillAndRedirect(skill) }}>
                                  <div class="tl-icons" role="button">
                                    <div class="cts-avatars" style={{ backgroundColor: getColors(skill.SKILL_NAME) }}>
                                      <span>{skill.SKILL_NAME[0]}</span>
                                    </div>
                                  </div>
                                  <div class="tl-conts">
                                    <p>{skill.SKILL_NAME}</p>
                                  </div>
                                </div>
                                <div className="deleteIcon" onClick={() => this.props.removeFavoriteSkill(skill)} style={{ position: "absolute", top: -30, right: 10 }}>
                                  <img src={deleteIcon} />
                                </div>
                              </div>)
                          } else {
                            return null
                          }

                        }) : null

                        }
                        <div class="add-new tl-blocks" data-toggle="modal" data-target="#add-new-skill">
                          <div class="tl-icons">
                            <div class="cts-avatars" style={{ backgroundColor: "#f2f5f6", border: "1px solid #455462" }}>
                              <span style={{ color: "#1d262e", fontSize: "22px" }}>+</span>
                            </div>
                          </div>
                          <div class="tl-conts">
                            <p>Pin New Skill</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

          }


        </div>
      </>
    );
  }
};

const mapStateToProps = (state) => ({
  skillReducer: state.skillReducer
});

export default connect(mapStateToProps, {
  setMessage,
  getUserSkills,
  saveFavoriteSkill,
  getFavoriteSkills,
  removeFavoriteSkill
})(Search);
