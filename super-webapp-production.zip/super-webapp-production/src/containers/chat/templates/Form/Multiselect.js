import React from "react"
import Select from 'react-select'
import '../../css/style.css'
class Multiselect extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
    }

    handleSelect = (e) => {
        if(e == null){
            this.setState({multiselect: []}, () => this.props.handleFormValues(this.state))
        }else{
            this.setState({multiselect: e}, () => this.props.handleFormValues(this.state))
        }
    }

    // componentDidMount() {
    //     let selectItems = this.props.props[0]
    //     let values = selectItems.value
    // }

    render() {
        let selectItems = this.props.props[0]
        let values = selectItems.value
        let title = selectItems.title
        let selectedOption = this.props.props[1]

        return (
            <div className="form-fields">
                <div className="form-group">
                    <div className="label-top-space"></div>
                    <label>{title}</label>
                    <div className="label-top-space"></div>
                    <Select
                        isMulti
                        options={values}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        onChange={this.handleSelect}
                        value={selectedOption?selectedOption:this.state.select}
                    />
                </div>
            </div>
        )
    }
}

export default Multiselect
