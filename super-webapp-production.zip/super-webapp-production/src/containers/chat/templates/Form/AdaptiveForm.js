import React from "react";
import Select from "react-select";
import "../../css/style.css";
class AdaptiveForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      filters: [],
      pivotData: [],
    };
  }

  componentDidMount() {
    this.filterData();
  }
  filterData = () => {
    let formItems = this.props.props.body;
    if (formItems[0].key === "") {
      this.setState({
        filters: formItems,
      });
    } else if (formItems[0].name === "") {
      this.setState({
        pivotData: formItems,
      });
    }
  };
  refreshPivotData = () => {
    let formItems = this.props.props.body;

    this.setState({
      pivotData: formItems,
    });
  };

  refreshFilterData = () => {
    let formItems = this.props.props.body;

    this.setState({
      filters: formItems,
    });
  };

  handleColumnName = (i, e) => {
    let filters = [...this.state.filters];
    filters[i].key = e.target.value;
    this.setState({ filters }, () =>
      this.props.handleFormValues(this.state.filters)
    );
  };
  handleColumnValue = (e, i) => {
    // console.log(i, e, "lvaluel")

    let filters = [...this.state.filters];
    filters[i].value = e.target.value;
    this.setState({ filters }, () =>
      this.props.handleFormValues(this.state.filters)
    );
  };

  showCard = (action) => {
    if (this.state.filters.length > 0) {
      let newField = { key: "", value: "" };
      this.state.filters.push(newField);
      this.refreshFilterData();
    } else if (this.state.pivotData.length > 0) {
      let newField = { name: "", type: "", function: "" };
      this.state.pivotData.push(newField);
      this.refreshPivotData();
    }
  };

  hideCard = () => {
    if (this.state.filters.length > 0 && this.state.filters.length !== 1) {
      this.state.filters.pop();
      this.refreshFilterData();
    } else if (
      this.state.pivotData.length > 0 &&
      this.state.pivotData.length !== 1
    ) {
      this.state.pivotData.pop();
      this.refreshPivotData();
    }
  };

  handleChangeType = (e, i) => {
    let pivotData = [...this.state.pivotData];
    pivotData[i].type = e.target.value;
    this.setState({ pivotData }, () =>
      this.props.handleFormValues(this.state.pivotData)
    );
  };

  handleChangeName = (e, i) => {
    // console.log(e, i)
    let pivotData = [...this.state.pivotData];

    pivotData[i].name = e.target.value;
    this.setState({ pivotData }, () =>
      this.props.handleFormValues(this.state.pivotData)
    );
  };

  handleChangeFunction = (e, i) => {
    let pivotData = [...this.state.pivotData];
    pivotData[i].function = e.target.value;
    this.setState({ pivotData }, () =>
      this.props.handleFormValues(this.state.pivotData)
    );
  };

  render() {
    // console.log(this.state, "formi")

    let actionItems = this.props.props.actions;
    return (
      <div>
        {
          <div className="form-fields">
            {this.state.filters.length !== 0 &&
              this.state.filters.map((fields, i) => {
                // console.log(fields, "loooo")
                return (
                  <div key={i}>
                    {fields.key !== null && fields.value !== null && (
                      <div className="flex-input">
                        {fields.key !== null && (
                          <div className="f-input">
                            <input
                              type="text"
                              placeholder="Column Name"
                              onChange={this.handleColumnName.bind(this, i)}
                            ></input>
                          </div>
                        )}
                        {fields.value !== null && (
                          <div className="f-input">
                            <input
                              type="text"
                              placeholder="Column Value"
                              onChange={(e) => {
                                this.handleColumnValue(e, i);
                              }}
                            ></input>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

            {this.state.pivotData.length !== 0 &&
              this.state.pivotData.map((fields, i) => {
                return (
                  <div key={i}>
                    <div className="flex-input">
                      {fields.name !== null && (
                        <div className="f-input">
                          <input
                            type="text"
                            placeholder="Header Name"
                            onChange={(e) => {
                              this.handleChangeName(e, i);
                            }}
                          ></input>
                        </div>
                      )}
                      {fields.type !== null && (
                        <div className="f-input">
                          <input
                            type="text"
                            placeholder="Header Area"
                            onChange={(e) => {
                              this.handleChangeType(e, i);
                            }}
                          ></input>
                        </div>
                      )}
                      {fields.function !== null && (
                        <div className="f-input">
                          <input
                            type="text"
                            placeholder="Function"
                            onChange={(e) => {
                              this.handleChangeFunction(e, i);
                            }}
                          ></input>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

            {actionItems.map((action) => (
              <div>
                {action.type === "Action.ShowCard" && (
                  <div className="f-btns">
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={() => this.showCard()}
                    >
                      Add
                    </button>
                    &nbsp;&nbsp;
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => this.hideCard()}
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        }
      </div>
    );
  }
}

export default AdaptiveForm;

// import React from "react"
// import '../../css/style.css'
// class TextField extends React.Component {
//     constructor(props) {
//         super(props)
//         this.state = {}
//     }

//     handleChange = (event) => {
//         this.setState({
//             [event.target.name]: event.target.value
//         }, () => this.props.handleFormValues(this.state))
//     }

//     componentWillMount() {
//         let formItems = this.props.props
//         formItems.map((item, index) => (
//             this.setState({ [item.value]: '' })
//         ))
//     }

//     render() {
//         let formItems = this.props.props
//         let selectedOption = this.props.selectedOption
//         return (
//             <div>
//                 {
//                     <div className="form-fields">
//                         {
//                             formItems.map((item, index) => {
//                                 if (item.type === 'textarea') {
//                                     return (
//                                         <div className="form-group" key={index}>
//                                             <div className="label-top-space"></div>
//                                             <label>{item.title}</label>
//                                             <div className="label-bottom-space"></div>
//                                             <textarea className="form-control" disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]}  key={index} onChange={ this.handleChange }  ></textarea>
//                                         </div>
//                                     )
//                                 }
//                                 return (
//                                     <div className="form-group" key={index}>
//                                         <div className="label-top-space"></div>
//                                         <label>{item.title}</label>
//                                         <div className="label-bottom-space"></div>
//                                         <input type={item.type} disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]} className="form-control" key={index} onChange={this.handleChange} />
//                                     </div>
//                                 )
//                             })
//                         }
//                     </div>
//                 }
//             </div>
//         )
//     }
// }

// export default TextField
