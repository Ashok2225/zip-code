import React from "react"

class CheckBox extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
    handleClick = (event) => {
        let temp = event.target.name
        let checkdata = this.state.checkselect
        let data = this.state;
        if ((data[temp] || data[temp] == "") && event.target.value == "on") {
            delete data[temp]
            let checkdat = this.state.checkselect;
            let index = checkdat.indexOf(temp)
            checkdat.splice(index, 1)
            this.setState({ ...data, checkselect: checkdat }, () => this.props.handleFormValues(this.state, { 'mode': "delete", "key": temp }))
        } else {
            
            this.setState({
                [event.target.name]: ((event.target.name.toUpperCase() == "OTHERS" || event.target.name.toUpperCase() == "OTHER") ? (event.target.value != "on" ? event.target.value : "") : event.target.id),
                "checkselect": [...checkdata, event.target.name]
            }, () => this.props.handleFormValues(this.state))
        }
    }

    componentWillMount() {
        this.setState({
            "checkselect": []
        })
    }
    render() {
        let checkItems = this.props.props[0]
        let values = checkItems.value
        let title = checkItems.title

        let selectedOption = this.props.props[1]
        let others = selectedOption[selectedOption.length - 1]
        let textvalue = "";
        if (typeof others == "object") {
            textvalue = Object.keys(others)[0]
        }
        return (
            <div className="form-fields">
                <div>
                    <div className="label-top-space"></div>
                    <label>{title}</label>
                    <div className="label-bottom-space"></div>
                    {
                        values.map((item, index) => {
                            return (
                                <div className="form-group" key={index}>
                                    <label>
                                        <input type="checkbox" disabled={selectedOption.length > 0 || this.props.disable ? true : false} id={index} name={item[Object.keys(item)[1]]} checked={selectedOption.length ? ((selectedOption[index] == item[Object.keys(item)[0]]) || (textvalue == item.value) ? true : null) : this.isChecked} onChange={this.handleClick} />
                                        {item.titleType == "img" ? <img style={{ width: "200px" }} src={item[Object.keys(item)[0]]} /> : item[Object.keys(item)[0]]}
                                    </label>
                                    {((item.value.toUpperCase() == "OTHERS" || item.value.toUpperCase() == "OTHER") && (this.state[item.value] == "" || this.state[item.value])) || textvalue == item.value ?
                                        <input type="text" disabled={selectedOption.length > 0 || this.props.disable ? true : false} name={item.value} value={selectedOption[index] ? selectedOption[index][textvalue] : this.state[item.value]} placeholder={item.value} style={{ "width": "150px", "height": "25px" }} className="form-control" key={index} onChange={this.handleClick} autoComplete="off" />
                                        : null
                                    }
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        )
    }
}
export default CheckBox
