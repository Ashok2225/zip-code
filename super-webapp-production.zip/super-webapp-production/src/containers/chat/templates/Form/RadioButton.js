import React from "react"
import '../../css/style.css'
class Radio extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
        }
    }

    handleClick = (event) => {
        this.setState({
            //[event.target.value]: true
            "radioselect": event.target.value,
            "title": event.target.value
            //radiotitle: event.target.name,
            //radiovalue: event.target.value
        }, () => this.props.handleFormValues(this.state))
    }

    render() {
        let selectedValue = this.state.title
        let radioItems = this.props.props[0]
        let values = radioItems.value
        let title = radioItems.title
        let selectedOption = this.props.props[1] ? this.props.props[1] : null;
        let o = values[0]
        return (
            <div className="form-fields">
                <div className="form-group">
                    <div className="label-top-space"></div>
                    <label>{title}</label>
                    <div className="label-bottom-space"></div>
                    {
                        values.map((item, index) => {
                            return (
                                <div className="form-group" key={index}>
                                    <label>
                                        <input type="radio" disabled={selectedOption || this.props.disable ? true : false} id={index} name="title" value={item.value} checked={((selectedValue == item.value) || (item.value == selectedOption))} onChange={this.handleClick} />
                                        {item.value}
                                    </label>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        )
    }
}

export default Radio
