import React from 'react'
import TextFieldWidget from "./TextField"
import DropDownWidget from "./DropDown"
import CheckBoxWidget from "./Checkbox"
import RadioWidget from "./RadioButton"
import MultiselectWidget from "./Multiselect"
import { getKeycloackRefreshToken } from "../../../../redux/actions/auth"

import './css/style.css'
import AdaptiveForm from './AdaptiveForm'

class Form extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
    }
    handleFormValues = (data, utility = false) => {
        if (utility) {
            if (utility.mode == "delete") {
                delete this.state[utility.key]
            }
        }
        this.setState({
            ...data
        })
    }

    //Hideing the Footer component
    componentDidMount() {
        if (this.props.isLast) {
            //   document.getElementById('footer_Input').style.display = "none"
        }
    }

    componentWillMount() {
        let { content } = this.props.props[0]
        if (content.items.length) {
            content.items.map((item, index) => (
                this.setState({ [item.value]: '' })
            ))
        }
        if (content.facts.length) {
            content.facts.map((fact, index) => {
                if (fact.dropdown && fact.dropdown.title) {
                    this.setState({ "dropdownselect": "" })
                }
                if (fact.checkbox && fact.checkbox.title) {
                    this.setState({ "checkselect": [] })
                }
                if (fact.radio && fact.radio.title) {
                    this.setState({ "radioselect": "" })
                }
                if (fact.multiselect && fact.multiselect.title) {
                    this.setState({ "multiselect": "" })
                }
            })
        }
    }

    onFormSubmit = async () => {
        let flag = true;
        for (let [key, value] of Object.entries(this.state)) {
            var spaceValidate = ""
            if (value.type) {
                if (value.type == "email") {
                    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                    value = value.value.trim();
                    spaceValidate = value.length == 0 ? "" : value.split(" ").join("")
                    if (!reg.test(value)) {
                        alert("Please enter valid mail")
                        flag = false;
                        break;
                    }
                }
                // if(value.type == "textarea"){
                //     value = value.value.trim();
                //     spaceValidate = value.length == 0 ? "" : value.split(" ").join("")
                //     if(value.length > 500){
                //         alert("limit 500 characters only")
                //         flag = false;
                //         break;
                //     }
                // }
                else if (value.type == 'phone') {
                    value = value.value.trim();
                    let valInt = parseInt(value)
                    spaceValidate = value.length == 0 ? "" : value.split(" ").join("")
                    if (value == valInt) {
                        if (!(value.length == 10 || value.length == 11)) {
                            alert("Please enter valid mobile number")
                            flag = false;
                            break;
                        }
                    } else {
                        alert("Please enter valid mobile number")
                        flag = false;
                        break;
                    }
                } else {
                    // let trimmed = value.value
                    // value.value = trimmed.replace(/^\s+|\s+$/g, "");//removes unwanted \n
                    // value = value.value.trim(); //To check for empty spaces
                    // spaceValidate = value.length == 0 ? "" : value.split(" ").join("")
                }
            } else {
            
                if (Array.isArray(value)) {
                    if (value.includes("None") && value.length != 1) {
                        alert("Please select valid input; Cannot select multiple options with 'None'.");
                        flag = false;
                        break;
                    }
                }
                // value = Array.isArray(value) ? (value.length > 0 ? value[0].trim() : "") : value.trim(); //To check for empty spaces
                // spaceValidate = key == "multiselect" ? (value.length == 0 ? "" : value[0]["label"].split(" ").join("")) : (Array.isArray(value) ? (value.length == 0 ? "" : value[0].split(" ").join("")) : value.split(" ").join(""))
            }
            // if (value.length == 0 || spaceValidate.length == 0) {
            //     alert("Please fill out the form completely")
            //     flag = false;
            //     break;
            // }
        }
        if (flag) {
            this.setState({ disable: true })
            let _message = { text: JSON.stringify(this.state), payload: { showTitle: true, title: 'Submitted' } }
            this.props.send_message_to_bot(_message)
            _message = window.chatSocket.finalPayload(_message, false, await getKeycloackRefreshToken())            
            this.props.setMessage(_message)
            window.chatSocket.conn.send(_message)
        }
        // let flag = true;
        // for (let [key, value] of Object.entries(this.state)) {
        //     var spaceValidate = key == "multiselect" ? (value.length == 0 ? "" : value[0]["label"].split(" ").join("")) : (Array.isArray(value) ? (value.length == 0 ? "" : value[0].split(" ").join("")) : value.split(" ").join(""))
        //     if(value.length == 0 || spaceValidate.length == 0){
        //       alert("Please fill out the form completely")
        //       flag = false;
        //       break;
        //     }
        // }
        // if(flag){
        //     this.setState({disable: true})
        //     this.props.send_message_to_bot({ text: JSON.stringify(this.state), payload: { showTitle: true, title: 'Submitted' } })
        // }
    }

    render() {
        let textfield, adaptiveForm, dropdownComponent, checkboxComponents, radioComponents, multiselectComponent = false
        let { content } = this.props.props[0]
        let selectedOption = undefined
        if (this.props.selectedOption) {
            try {
                selectedOption = JSON.parse(this.props.selectedOption)
            } catch (e) {
                selectedOption = this.props.selectedOption
            }
        }
        let index = this.props.index
        let dropdown = []
        let checkbox = []
        let radio = []
        let multiselect = []
        let { facts } = this.props.props[0].content
        facts.map(fact => {
            if (fact.dropdown) {
                dropdown.push(fact.dropdown)
                if (fact.dropdown.value) {
                    fact.dropdown.value.map((value) => {
                        if (selectedOption) {
                            if (value.value == selectedOption.dropdownvalue) {
                                dropdown.push(selectedOption.dropdownvalue);
                            }
                        }
                    })
                }
            }
            if (fact.multiselect) {
                multiselect.push(fact.multiselect)
                if (selectedOption) {
                    multiselect.push(selectedOption.multiselect);
                }
            }
            if (fact.checkbox) {

                checkbox.push(fact.checkbox)
                let check = []
                if (fact.checkbox.value) {
                    fact.checkbox.value.map((value, index) => {

                        if (selectedOption) {
                            let selected = Object.keys(selectedOption);
                            let keys = selected.includes("Other") || selected.includes("other") ? "OTHER" : "OTHERS";
                            if (value.value.toUpperCase() != keys && selectedOption[value.value]) {
                                //check.push(value.value);
                                check[selectedOption[value.value]] = value.value
                            } else if ((value.value.toUpperCase() == "OTHERS" || value.value.toUpperCase() == "OTHER")) {
                                //let index1 = findIndex(value);
                                if (selected.includes(value.value)) {
                                    check[index] = { [value.value]: selectedOption[value.value] }
                                }
                            }
                        }
                    })
                    checkbox.push(check)
                }
            }
            if (fact.radio) {
                radio.push(fact.radio)
                if (fact.radio.value) {
                    fact.radio.value.map((value) => {
                        if (selectedOption) {
                            if (value.value == selectedOption.title) {
                                radio.push(selectedOption.title);
                            }
                        }
                    })
                }
            }
        })

        if (content.items) {
            textfield = true
        }
        if (content.body) {
            adaptiveForm = true
        }
        if (dropdown[0].title && dropdown[0].value) {
            dropdownComponent = true
        }
        if (multiselect.length > 0) {
            if (multiselect[0].title && multiselect[0].value) {
                multiselectComponent = true
            }
        }
        if (checkbox[0].title && checkbox[0].value) {
            checkboxComponents = true
        }
        if (radio[0].title && radio[0].value) {
            radioComponents = true
        }
        return (

            <div className="form" style={this.props.styles}>
                <form onSubmit={(e) => { e.preventDefault() }}>
                    {adaptiveForm ? <AdaptiveForm props={content} disable={this.state.disable} selectedOption={selectedOption} handleFormValues={data => this.handleFormValues(data)} /> : null}

                    {textfield ? <TextFieldWidget props={content.items} disable={this.state.disable} selectedOption={selectedOption} handleFormValues={data => this.handleFormValues(data)} /> : null}
                    {dropdownComponent ? <DropDownWidget disable={this.state.disable} props={dropdown} handleFormValues={data => this.handleFormValues(data)} /> : null}
                    {checkboxComponents ? <CheckBoxWidget disable={this.state.disable} props={checkbox} handleFormValues={this.handleFormValues} /> : null}
                    {radioComponents ? <RadioWidget disable={this.state.disable} props={radio} handleFormValues={data => this.handleFormValues(data)} /> : null}
                    {multiselectComponent ? <MultiselectWidget disable={this.state.disable} props={multiselect} handleFormValues={data => this.handleFormValues(data)} /> : null}
                    {
                        content.buttons.map((button, index) => {
                            if (!this.state.disable) {
                                if (button.value && selectedOption == undefined) {
                                    return (
                                        <a className="button" key={index} onClick={this.onFormSubmit} >
                                            {button.title}
                                        </a>
                                    )
                                }
                            }
                        })
                    }
                </form>
            </div>
        )
    }
}
export default Form
