import React from "react"
import Select from 'react-select'
import '../../css/style.css'
class TextField extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            //dataEntered: "0"
        }
    }

    phoneCodeChange = (e) => {
        e.preventDefault();
        const re = /[0-9 +]+$/;
        if (e.target.value == '' || re.test(e.target.value)) {
            this.setState({ phonecode: e.target.value }, () => this.props.handleFormValues(this.state))
        }
    }

    handlePhone = (e, type) => {
        this.setState({
            [e.target.name]: {
                value: e.target.value,
                type: type
            }
        }, () => this.props.handleFormValues(this.state))
    }

    handleChange = (event) => {
        let { name, type, value } = event.target
        if (type == "textarea" && value.length > 500) {
            alert("Limit only 500 characters")
        } else {
            this.setState({
                [event.target.name]: {
                    value: event.target.value,
                    type: event.target.type
                }
            }, () => this.handleForm(name, type))
        }
    }

    handleForm = (name, type) => {
        if (type == "textarea") {
            this.setState({ [name]: { ...this.state[name], dataEntered: JSON.stringify(this.state[name].value.length) } }, () => this.props.handleFormValues(this.state))
        } else {
            this.props.handleFormValues(this.state)
        }
    }

    handleSelect = (e) => {
        if (e == null) {
            this.props.props.map((item) => {
                if (item.type === "multiselect") {
                    this.setState({ [item.value]: [] }, () => this.props.handleFormValues(this.state))
                }
            })
        } else {
            this.props.props.map((item) => {
                if (item.type === "multiselect") {
                    this.setState({ [item.value]: e }, () => this.props.handleFormValues(this.state))
                }
            })
        }
    }

    componentWillMount() {
        let formItems = this.props.props
        // console.log(formItems, "formit")
        formItems.map((item, index) => {
            if (item.type === "multiselect") {
                this.setState({ [item.value]: [] })
            } else {
                this.setState({ [item.value]: { "dataEntered": "0" } })
                // console.log()
            }
        })
    }

    render() {
        let formItems = this.props.props
        let selectedOption = this.props.selectedOption
        return (
            <div>
                {
                    <div className="form-fields">
                        {
                            formItems.map((item, index) => {
                                if (item.type === 'overlays') {
                                    return (
                                        <div>
                                            <div className="form-group" key={index}>
                                                <div className="label-top-space"></div>
                                                <label>{item.title}</label>
                                                <div className="label-bottom-space"></div>
                                                <textarea className="form-control" placeholder="Please type your message here: excluding special character #" disabled={selectedOption || this.props.disable ? true : false} name={item.value} value={selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].value : this.state[item.value].value) : this.state[item.value].value} key={index} onChange={this.handleChange}  ></textarea>
                                            </div>
                                            {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].dataEntered : this.state[item.value].dataEntered) : (this.state[item.value].dataEntered != "0" ? this.state[item.value].dataEntered : "0")}/500
                                        </div>
                                    )
                                } else if (item.type === 'textarea') {
                                    return (
                                        <div>
                                            <div className="form-group" key={index}>
                                                <div className="label-top-space"></div>
                                                <label>{item.title}</label>
                                                <div className="label-bottom-space"></div>
                                                <textarea className="form-control" placeholder="limit 500 characters" disabled={selectedOption || this.props.disable ? true : false} name={item.value} value={selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].value : this.state[item.value].value) : this.state[item.value].value} key={index} onChange={this.handleChange}  ></textarea>
                                            </div>
                                            {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].dataEntered : this.state[item.value].dataEntered) : (this.state[item.value].dataEntered != "0" ? this.state[item.value].dataEntered : "0")}/500
                                        </div>
                                    )
                                } else if (item.type === "multiselect") {
                                    return (
                                        <div className="form-group" key={index}>
                                            <div className="label-top-space"></div>
                                            <label>{item.title}</label>
                                            <div className="label-bottom-space"></div>
                                            <Select
                                                isMulti
                                                name={item.value}
                                                options={this.state.colourOptions}
                                                className="basic-multi-select"
                                                classNamePrefix="select"
                                                onChange={this.handleSelect}
                                                disabled={selectedOption || this.props.disable ? true : false}
                                                value={selectedOption ? selectedOption[item.value] : this.state[item.value]}
                                            />
                                        </div>
                                    )
                                }
                                else if (item.type === "email") {
                                    return (
                                        <div className="form-group" key={index}>
                                            <div className="label-top-space"></div>
                                            <label>{item.title}</label>
                                            <div className="label-bottom-space"></div>
                                            <input type={item.type} disabled={selectedOption || this.props.disable ? true : false} name={item.value} value={selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].value : this.state[item.value].value) : this.state[item.value].value} className="form-control" key={index} onChange={this.handleChange} autocomplete="off" />
                                        </div>
                                    )
                                } else if (item.type == 'phone') {
                                    return (
                                        <div className="form-group" key={index}>
                                            {/*<label htmlFor="key">{item.title}</label>
                                        <span style={{color:'red'}}>  *</span>*/}
                                            <label htmlFor="key">{item.title}</label>
                                            <input type="text" name="phoneCode"
                                                className="form-control"
                                                style={{ width: "30%" }}
                                                name='phonecode'
                                                value={this.state.phonecode}
                                                disabled={selectedOption || this.props.disable ? true : false}
                                                onChange={this.phoneCodeChange}
                                                placeholder="+000" autocomplete="off" />
                                            <input type={item.type} style={{ width: "66%", float: "right", marginTop: "-34px" }}
                                                className="form-control"
                                                id="key" placeholder="9999999999"
                                                name={item.value}
                                                value={selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].value : this.state[item.value].value) : this.state[item.value].value}
                                                key={index}
                                                disabled={selectedOption || this.props.disable ? true : false}
                                                onChange={(e) => this.handlePhone(e, item.type)}
                                                autocomplete="off" />
                                        </div>
                                    )
                                }
                                return (
                                    <div className="form-group" key={index}>
                                        <div className="label-top-space"></div>
                                        <label>{item.title}</label>
                                        <div className="label-bottom-space"></div>
                                        <input type={item.type} disabled={selectedOption || this.props.disable ? true : false} name={item.value} value={selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].value : this.state[item.value].value) : this.state[item.value].value} className="form-control" key={index} onChange={this.handleChange} autocomplete="off" />
                                    </div>
                                )
                            })
                        }
                    </div>
                }
            </div>
        )
    }
}

export default TextField

// import React from "react"
// import '../../css/style.css'
// class TextField extends React.Component {
//     constructor(props) {
//         super(props)
//         this.state = {}
//     }

//     handleChange = (event) => {
//         this.setState({
//             [event.target.name]: event.target.value
//         }, () => this.props.handleFormValues(this.state))
//     }

//     componentWillMount() {
//         let formItems = this.props.props
//         formItems.map((item, index) => (
//             this.setState({ [item.value]: '' })
//         ))
//     }

//     render() {
//         let formItems = this.props.props
//         let selectedOption = this.props.selectedOption
//         return (
//             <div>
//                 {
//                     <div className="form-fields">
//                         {
//                             formItems.map((item, index) => {
//                                 if (item.type === 'textarea') {
//                                     return (
//                                         <div className="form-group" key={index}>
//                                             <div className="label-top-space"></div>
//                                             <label>{item.title}</label>
//                                             <div className="label-bottom-space"></div>
//                                             <textarea className="form-control" disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]}  key={index} onChange={ this.handleChange }  ></textarea>
//                                         </div>
//                                     )
//                                 }
//                                 return (
//                                     <div className="form-group" key={index}>
//                                         <div className="label-top-space"></div>
//                                         <label>{item.title}</label>
//                                         <div className="label-bottom-space"></div>
//                                         <input type={item.type} disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]} className="form-control" key={index} onChange={this.handleChange} />
//                                     </div>
//                                 )
//                             })
//                         }
//                     </div>
//                 }
//             </div>
//         )
//     }
// }

// export default TextField
