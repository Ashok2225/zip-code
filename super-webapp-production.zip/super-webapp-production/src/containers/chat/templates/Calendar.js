import React, { Component } from 'react'
import $ from 'jquery'
import jQuery from 'jquery'
import axios from 'axios'

import '../css/style.css'

export default class Calendar extends Component {

  constructor(props) {
    super()
    this.state = {
      slots: {},
      date: "",
      time: 0,
      slotId: "",
      colors: ["purple", "red", "orange", "blue", "yellow"]
    }
  }

  componentDidMount() {

    let options = {
      url: "https://bot.techforce.ai/slots",
      method: "get"
    }

    axios(options).then(res => {
      if (res.data.status) {
        let slots = res.data.slots;
        slots = slots.reduce((acc, cv, ci, arr) => {
          if (cv.date in acc) {
            acc[cv.date].push(cv)
          }
          else {
            acc[cv.date] = []
            acc[cv.date].push(cv)
          }
          return acc
        }, {})
        this.setState({ slots })
      }
    }).catch(e => console.log(e))



    // $("#date_select_card .meeting_content label input[type='radio']").click(function () {
    //   var date = $(this).val();
    //   console.log(this)
    //   $("#time_select_card .meeting_content label input[type='radio']").val(date);
    //   $("#time_select_card .meeting_content label .append_date").html(date);
    //   $("#date_select_card").hide();
    //   $("#time_select_card").show();
    //   $("#flag_select_card").hide();
    // });

    $("#date_meeting_dropdown, #time_meeting_dropdown").click(function () {
      $("#date_select_card").hide();
      $("#time_select_card").hide();
      $("#flag_select_card").show();
    });

    $("#time_back_to_date, #flag_back_to_date").click(function () {
      $("#date_select_card").show();
      $("#time_select_card").hide();
      $("#flag_select_card").hide();
    });
  }

  setDate = (e) => {
    this.setState({ date: e.target.value }, () => {
      $("#date_select_card").hide();
      $("#time_select_card").show();
      $("#flag_select_card").hide();
    })
  }

  setTime = (e, slotId) => {
    this.setState({ time: e.target.value, slotId }, () => {
      console.log(this.state)
    })
  }

  convert24to12 = (time) => {
    if (time > 0 && time < 12) {
      return { time: time + ":00 AM", type: "day" }
    }
    else if (time == 12) {
      return { time: time + ":00 PM", type: "noon" }
    }
    else {
      return { time: (time - 12) + ":00 PM", type: (time - 12) >= 6 ? "night" : "noon" }
    }
  }

  render() {

    let { props } = this.props
    let { slots, date, slotId, time, colors } = this.state;

    return (
      <div className="row text-left no_margin component_box">
        <div className="col-xs-1 align-top no_padding">
          <img src={require("../images/bot_logo.png")} alt="Bot Image" className="bot_img" />
        </div>
        <div className="col-xs-10 align-top no_padding bot_chat">
          <div className="calendar card">
            <div id="date_select_card">
              <ul className="list-group list-group-flush text-center">
                <li className="list-group-item meeting_header">
                  <div className="meeting_icon">
                    <img src={require("../images/meeting_icon.png")} alt="Meeting Icon" />
                  </div>
                  <div className="meeting_head">
                    <p className="meeting_title">
                      <span>{props.title}</span>
                      <span>1 hour</span>
                    </p>
                    <p className="meeting_dropdown" id="date_meeting_dropdown">
                      <span>Timezone - India</span>
                    </p>
                  </div>
                </li>

                <li className="list-group-item meeting_content">


                  {
                    Object.keys(slots).map((slot, index) => {
                      return (
                        <label htmlFor={"radio_date" + (index + 1)} key={index} >
                          <input
                            type="radio"
                            name="radio_date"
                            id={"radio_date" + (index + 1)}
                            checked={date == slot}
                            onChange={(e) => this.setDate(e)}
                            value={slot} />
                          <div className="meeting_box">
                            <p className={"meeting_circle color_" + colors[index]}>
                              <span>{new Date(slot).toDateString()[0]}</span>
                            </p>
                            <p className="meeting_text">
                              <span>{new Date(slot).toDateString()}</span>
                            </p>
                          </div>
                        </label>
                      )
                    })}

                </li>

                <li className="list-group-item meeting_footer"
                  style={{ backgroundColor: time == 0 ? "#eaeaea" : "#02ce9d", cursor: time == 0 ? "not-allowed" : "pointer" }}>
                  <button
                    disabled={time == 0 ? true : false}
                    onClick={() => this.props.send_message_to_bot({ text: "Schedule my meeting", payload: { date, time, slotId } })}
                    style={{
                      backgroundColor: time == 0 ? "#eaeaea" : "#02ce9d",
                      color: time == 0 ? "#333333" : "#FFFFFF",
                      cursor: time == 0 ? "not-allowed" : "pointer",
                      padding: 10,
                      border: "none",
                      outline: "none"
                    }}
                  >Confirm</button>
                </li>
              </ul>
            </div>


            <div id="time_select_card" className="hide">
              <ul className="list-group list-group-flush text-center">
                <li className="list-group-item meeting_header">
                  <div className="meeting_icon">
                    <img src={require("../images/meeting_icon.png")} alt="Meeting Icon" />
                  </div>
                  <div className="meeting_head">
                    <p className="meeting_title">
                      <span>{props.title}</span>
                      <span>1 hour</span>
                    </p>
                    <p className="meeting_dropdown" id="time_meeting_dropdown">
                      <span>Timezone - India</span>
                      <img src={require("../images/down_icon.svg")} alt="Icon" />
                    </p>
                  </div>
                </li>
                <li className="list-group-item meeting_content">
                  {
                    slots && slots[date] ?
                      slots[date].map((item, index) => {
                        return (
                          <label htmlFor={"radio_time" + index} key={index}>
                            <input
                              type="radio"
                              name="radio_time"
                              id={"radio_time" + index}
                              value={item.time}
                              checked={time == item.time}
                              onChange={(e, slotId) => { this.setTime(e, item._id) }} />
                            <div className="meeting_box time_section">
                              <p className={"meeting_circle color_" + this.convert24to12(item.time).type}>
                                <img src={require("../images/icon_" + this.convert24to12(item.time).type + ".png")} alt="Icon" />
                              </p>
                              <p className="meeting_text">
                                <strong>{this.convert24to12(item.time).time}</strong>
                                {item.booked ?
                                  <span className="append_date" style={{ color: "#f96854" }}> ! Booked</span>
                                  :
                                  <span className="append_date">{item.date}</span>}
                              </p>
                            </div>
                          </label>
                        )
                      }) : null

                  }

                </li>
                <li className="list-group-item meeting_footer">
                  <div className="meeting_redirect active" id="time_back_to_date">
                    <img src={require("../images/icon_circle_active.png")} alt="Icon" />
                    <span>Date</span>
                  </div>
                </li>
                <li className="list-group-item meeting_footer"
                  style={{ backgroundColor: time == 0 ? "#eaeaea" : "#02ce9d", cursor: time == 0 ? "not-allowed" : "pointer" }}>
                  <button
                    onClick={() => this.props.send_message_to_bot({ text: "Schedule my meeting", payload: { date, time, slotId } })}
                    disabled={time == 0 ? true : false}
                    style={{
                      backgroundColor: time == 0 ? "#eaeaea" : "#02ce9d",
                      color: time == 0 ? "#333333" : "#FFFFFF",
                      cursor: time == 0 ? "not-allowed" : "pointer",
                      padding: 10,
                      border: "none",
                      outline: "none"
                    }}
                  >Confirm</button>
                </li>
              </ul>
            </div>
            
            <div id="flag_select_card" className="hide">
              <ul className="list-group list-group-flush text-center">
                <li className="list-group-item meeting_header">
                  <div className="meeting_icon flag_section" id="flag_back_to_date">
                    <img src={require("../images/down_icon.svg")} alt="Back Icon" />
                  </div>
                  <div className="meeting_head flag_section">
                    <p className="meeting_title">
                      Time Zone
                  </p>
                  </div>
                </li>
                <li className="list-group-item meeting_content">
                  <label htmlFor="radio_flag1">
                    <input type="radio" name="radio_flag" id="radio_flag1" value="UTC-8:00 (PST)" />
                    <div className="meeting_box flag_section">
                      <p className="meeting_flag">
                        <img src={require("../images/flag_icon_canada.png")} alt="Flag Icon" />
                      </p>
                      <p className="meeting_text">
                        <span>UTC-8:00</span>
                        <strong>(PST)</strong>
                      </p>
                    </div>
                  </label>
                  <label htmlFor="radio_flag2">
                    <input type="radio" name="radio_flag" id="radio_flag2" value="UTC-5:00 (EST)" />
                    <div className="meeting_box flag_section">
                      <p className="meeting_flag">
                        <img src={require("../images/flag_icon_usa.png")} alt="Flag Icon" />
                      </p>
                      <p className="meeting_text">
                        <span>UTC-5:00</span>
                        <strong>(EST)</strong>
                      </p>
                    </div>
                  </label>
                  <label htmlFor="radio_flag3">
                    <input type="radio" name="radio_flag" id="radio_flag3" value="UTC+1:00 (CET)" />
                    <div className="meeting_box flag_section">
                      <p className="meeting_flag">
                        <img src={require("../images/flag_icon_uk.png")} alt="Flag Icon" />
                      </p>
                      <p className="meeting_text">
                        <span>UTC+1:00</span>
                        <strong>(CET)</strong>
                      </p>
                    </div>
                  </label>
                  <label htmlFor="radio_flag4">
                    <input type="radio" name="radio_flag" id="radio_flag4" value="UTC+5:30 (IST)" />
                    <div className="meeting_box flag_section">
                      <p className="meeting_flag">
                        <img src={require("../images/flag_icon_india.png")} alt="Flag Icon" />
                      </p>
                      <p className="meeting_text">
                        <span>UTC+5:30</span>
                        <strong>(IST)</strong>
                      </p>
                    </div>
                  </label>
                  <label htmlFor="radio_flag5">
                    <input type="radio" name="radio_flag" id="radio_flag5" value="UTC+8:00 (AWST)" />
                    <div className="meeting_box flag_section">
                      <p className="meeting_flag">
                        <img src={require("../images/flag_icon_australia.png")} alt="Flag Icon" />
                      </p>
                      <p className="meeting_text">
                        <span>UTC+8:00</span>
                        <strong>(AWST)</strong>
                      </p>
                    </div>
                  </label>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    )
  }
}





