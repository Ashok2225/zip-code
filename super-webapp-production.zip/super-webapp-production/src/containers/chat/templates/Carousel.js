import React, { Component, useState } from 'react'
import '../css/style.css'
import ShowMoreText from "react-show-more-text";
import $ from "jquery";

import Carousel from 'react-alice-carousel';
import 'react-alice-carousel/lib/alice-carousel.css';
import playBlack from "../../../images/play.png";
import ThumbsUp from "../../../images/Thumbs-up.png";
import ThumbsDown from "../../../images/Thumbs-down.png";
import Sample from "../../../images/sample.png";
import Tech from "../../../images/Techforce-Signup-Bg.png";
import bot_logo from "../../../images/chat-avt.png"


export default class TfCarousel extends Component {

  

  constructor(props) {
    super(props)
    this.state = {
      disableButton: false,
      thumbsUpBG: "",
      thumbsDownBG: "",
      expandBox: false,
    }
  } 
  
  expandMore = () => {
    if(this.state.expandBox == true) {
      this.setState({expandBox: false});
    } else {
      this.setState({expandBox: true});
    }    
  }

  handleButton = (val) => {
    if(val == "like"){
      this.setState({thumbsUpBG: "green", humbsDownBG: ""})
    }else{
      this.setState({thumbsUpBG: "", thumbsDownBG: "red"})
    }
    this.setState({disableButton: true})
    let _message = { text: val, payload: { showTitle: true, title: val } }
    this.props.send_message_to_bot(_message, true)
  }

  // componentWillUnmount(){
  //   if(this.props.selectedOption) return
  //   let _message = { text: "no option selected", payload: { showTitle: true, title: "no option selected" } }
  //   this.props.send_message_to_bot(_message, true)
  // }  

  textModify = (text) => {
    var urlRegex = /(https?:\/\/[^\s]+)|(http?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return url.includes('.gif' || '.GIF') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
            (url.includes('.png' || '.PNG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                (url.includes('.jpg' || '.JPG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                    (url.includes('.jpeg' || '.JPEG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                        (url.includes('.mp4' || '.MP4') ? `<video id="chat_bot_video" width="100%" height="100%" controls> <source src=${url.replace('<br>','')} type="video/mp4"></video>` :
                            url.includes('.xlsx' || '.XLSX') ? `<embed src="http://35.244.41.29:1337/uploads/2uploads/dcb088a711984eba8e7ec664b06f3db3.xlsx"  height="230" width="500" />` : `<a href=${url.replace('<br>','')} target="_blank">${url.replace('<br>','')}</a>`))))
    })
  }

  render() {
    let { disableButton, thumbsUpBG, thumbsDownBG } = this.state;
    let selectedOption  = undefined;
    if(this.props.selectedOption) {
      try{
        selectedOption = JSON.parse(this.props.selectedOption)
      }catch(e){
        selectedOption = this.props.selectedOption
      }
    }
    if(selectedOption){
      if(selectedOption == "like"){
        thumbsUpBG = "green";
        thumbsDownBG = "";
      }else if(selectedOption == "dislike"){
        thumbsUpBG = "";
        thumbsDownBG = "red";
      }
    }     
    
  //   executeOnClick = (isExpanded) => {
  //     console.log(isExpanded);
  // }
    return (
        <div>
          {this.props.props.map((item, index) => {
            return(
            item.content.text && item.content.text.toUpperCase() == "SUPERCAROUSEL" ? 
              <div className="chat-message bot-mode">
                <div className="chat-bot-message-box liked-message">
                  <img src={bot_logo} alt="Bot Image" className="bot_img chat-bot-message-logo" />
                  <div className="chat-action">
                    {/* <div className="lm-box lm-content">
                      <div  className="title-like">
                        {item.content.title ? <div className={this.state.expandBox == true ? 'expand-less' : 'expand-more'} dangerouslySetInnerHTML={{ __html: this.textModify(item.content.title) }}></div> : null}
                        <div className="thumbs-btn">
                          <button style={disableButton || selectedOption ? {opacity: "0.6", cursor: "default", backgroundColor: thumbsUpBG} : {}} disabled={disableButton || selectedOption ? true : false} onClick={() => this.handleButton("like")}><img src={ThumbsUp} /></button>
                          <button style={disableButton || selectedOption ? {opacity: "0.6", cursor: "default", backgroundColor: thumbsDownBG} : {}} disabled={disableButton || selectedOption ? true : false} onClick={() => this.handleButton("dislike")}><img src={ThumbsDown} /></button>
                        </div>
                      </div>
                      <div className="cb-img">
                        {item.content.images[0].url ?
                          <img src={item.content.images[0].url} />
                          : null
                        }
                      </div>
                      <button className="btn-link" onClick={this.expandMore.bind(this)} id="readMore">{this.state.expandBox == true ? 'Read Less' : 'Read More'}</button>
                    </div> */}
                    <div className="lm-box lm-content">
                    <div className="thumbs-btn">
                          <button style={disableButton || selectedOption ? {opacity: "0.6", cursor: "default", backgroundColor: thumbsUpBG} : {}} disabled={disableButton || selectedOption ? true : false} onClick={() => this.handleButton("like")}><img src={ThumbsUp} /></button>
                          <button style={disableButton || selectedOption ? {opacity: "0.6", cursor: "default", backgroundColor: thumbsDownBG} : {}} disabled={disableButton || selectedOption ? true : false} onClick={() => this.handleButton("dislike")}><img src={ThumbsDown} /></button>
                        </div>
                    <ShowMoreText
                /* Default options */
                lines={5}
                more="Show more"
                less="Show less"
                className="content-css"
                anchorClass="my-anchor-css-class"
                // onClick={this.executeOnClick}
                expanded={false}
                width={480}
                truncatedEndingComponent={"... "}
            >
                      <div  className="title-like">
                        {item.content.title ? <div className="text-block-carousel" dangerouslySetInnerHTML={{ __html: this.textModify(item.content.title) }}></div> : null}                        
                      </div>
                      <div className="cb-img">
                        {item.content.images[0].url ?
                          <img src={item.content.images[0].url} />
                          : null
                        }
                      </div>  
                      </ShowMoreText>                    
                    </div>                    
                    <div className="lm-box lm-actions">
                      <div className="list-action">
                        {
                          item.content.buttons.length > 0 ? 
                            <ul>
                              {
                                item.content.buttons.map((button) => {
                                  return(
                                    <li>
                                        <a className="lm-items" href={button.value} target="_blank"><img src={Sample}/><p>{button.title}</p></a>
                                    </li>
                                  )
                                })
                              }
                            </ul>
                          : 
                          null
                        }
                      </div>  
                    </div> 
                  </div>                       
                </div>
              </div>
            :
            <div className="chat-msg chat-slider sl-chatSlider">
              <Carousel
                showArrows={true}
                autoWidth={true}
              >
                <div className="chatSlider ss-block" key={index} style={{ width: 350, height: 250 }}>
                  <div className="ss-box sl-box">
                    <span className="label label-sl label-warning" style={{ padding: "5px 10px", position: "absolute", top: 0, right: '10%' }}>{item.content.text}</span>
                    <div className="ss-title-cont">
                      <div className="ss-ico">
                        {item.content.images[0].url ?
                          <img src={item.content.images[0].url} />
                          : null
                        }
                      </div>
                      {item.content.title ? <h5 title={item.content.title}>{item.content.title.length > 35 ? `${item.content.title.substring(0, 35)}...` : item.content.title}</h5> : null}
                      {item.content.subtitle ? <p title={item.content.subtitle}>{item.content.subtitle.length > 80 ? `${item.content.subtitle.substring(0, 80)}...` : item.content.subtitle}</p> : null}
                    </div>
                    <div className="ss-footer">
                      <a href={item.content.buttons[0].value} target="_blank">
                        <div className="use-now">
                          <div class="use-ico">
                            <img src={playBlack} />
                          </div>
                          {/* <p>Use Now</p> */}
                          <p>{item.content.buttons[0].title}</p>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </Carousel>
            </div>
            )
          })}
      </div>
    )
  }
}


