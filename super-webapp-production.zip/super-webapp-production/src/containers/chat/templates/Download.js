import React, { Component } from 'react'
import '../css/style.css'
import axios from 'axios'
import bot_logo from '../../../images/chat-avt.png'
import { getKeycloackRefreshToken } from "../../../redux/actions/auth"

export default class Download extends Component {
  constructor(props){
    super(props);
    this.state={

    }
  }

  onClick=()=>{
    this.setState({processClass:"loader"})
    let items= this.props.props;
    if(items[0].title=="azure"){
        let url = items[0].id;
        let urlsplit = url.split("/");
        let extfilename = urlsplit[urlsplit.length - 1]; 
        let fileName = extfilename.replace(/%20/g," ");
        let bucketName = items[0].title;
        // let containerName = urlsplit[urlsplit.length - 2];
        let azureDownloadUrl = process.env.REACT_APP_AZUREDOWNLOADURL;
        axios({
            'url': `${azureDownloadUrl}?filename=${fileName}`,
            'method': 'GET',
            'responseType': 'blob'
            }).then((res) => {
                if(res.data){
                    console.log(res)
                    let data = res.data;
                    // const href = window.URL.createObjectURL(new Blob([data]));
                    const href = window.URL.createObjectURL(data); 
                    const link = document.createElement('a');
                    link.href = href;
                    link.id = "tempdownload"
                    link.setAttribute('download',fileName); //or any other extension
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    this.setState({disable: true})
                    let _message = { text: items[0].id, payload: { showTitle: true, title: "Successfully Dowloaded" } }
                    this.props.send_message_to_bot(_message)
                    _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
                    this.props.setMessage(_message)
                    window.chatSocket.conn.send(_message)
                }
            }).catch((error) => {
                console.log("error:",error)
                    this.setState({disable: true})
                    let _message = { text: items[0].id, payload: { showTitle: true, title: "Dowloaded Failed" } }
                    this.props.send_message_to_bot(_message)
                    _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
                    this.props.setMessage(_message)
                    window.chatSocket.conn.send(_message)
            })
    }else{
        let url = items[0].id;
        let urlsplit = url.split("/");
        let extfilename = urlsplit[urlsplit.length - 1]; 
        let fileName = extfilename.replace(/%20/g," ");
        let bucketName = items[0].title;
        let s3DownloadUrl = process.env.REACT_APP_S3DOWNLOADURL;
        axios({
        'url': `${s3DownloadUrl}?filename=${fileName}&bucketname=${bucketName}`,
        'method': 'GET',
        'responseType': 'blob',
        }).then((res) => {
            if(res.data){
                let data = res.data;
                //const href = window.URL.createObjectURL(new Blob([data]));
                const href = window.URL.createObjectURL(data);
                const link = document.createElement('a');
                link.href = href;
                link.id = "tempdownload"
                link.setAttribute('download',fileName); //or any other extension
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                this.setState({disable: true})
                let _message = { text: items[0].id, payload: { showTitle: true, title: "Successfully Dowloaded" } }
                this.props.send_message_to_bot(_message)
                _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
                this.props.setMessage(_message)
                window.chatSocket.conn.send(_message)
            }
        }).catch((error) => {
            console.log("error:",error)
                this.setState({disable: true})
                let _message = { text: items[0].id, payload: { showTitle: true, title: "Dowloaded Failed" } }
                this.props.send_message_to_bot(_message)
                _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
                this.props.setMessage(_message)
                window.chatSocket.conn.send(_message)
        })
    }
  }


  render(){
    let items= this.props.props;
    let selectedOption  = undefined;
        if(this.props.selectedOption) {
            try{
              selectedOption = JSON.parse(this.props.selectedOption)
            }catch(e){
              selectedOption = this.props.selectedOption
            }
          }
      return (
          
        <div className="row text-left no_margin component_box">
            { selectedOption || this.state.disable ? null :
						<div className="col-xs-1 align-top no_padding">
							<img src={bot_logo} alt="Bot Image" className="bot_img" />
                        </div>}
                        { selectedOption || this.state.disable ? null :
						<div className="col-xs-10 align-top no_padding bot_chat">
							<div className="input card">
								<ul className="list-group list-group-flush text-center">
                  <div className="row">
                      <div className="col-xs-6">
                          <li className="download-button filled list-group-item">
                              <a  style={{color: "#ffffff"}} onClick={() => { this.onClick(); }} >
                                  Download
                              </a>
                          </li>
                      </div>
                      <div className="col-xs-6">
                          <li className="download-button filled list-group-item">
                              <a  style={{color: "#ffffff"}} onClick={() => {this.setState({disable: true}); this.props.send_message_to_bot({ text:  items[0].id, payload: { showTitle: true, title: "Download is Cancelled " } }) }} >
                                  Cancel
                              </a>
                          </li>
                      </div>
                  </div>
          		</ul>
							</div>
						</div> }
                     <div className={this.state.processClass}></div> 
            </div> 
      );
  }
}
