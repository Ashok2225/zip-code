import React, { Component } from 'react'

import '../css/HomeContainer.css'
import bot_logo from "../images/bot_logo.png"
import { getKeycloackRefreshToken } from "../../../redux/actions/auth"

export default class QandA extends Component {

    constructor(props) {
        super(props);
        this.state={
            disable: false
        }
    }

    //Hideing the Footer component
        componentDidMount(){
             if(this.props.isLast){
                //   document.getElementById('footer_Input').style.display = "block"
          }
        }

    handleQA = (qa) => {
        this.setState({disable: true});
        let _message = { text: qa.value, payload: { showTitle: true, title: qa.title } }
        this.props.send_message_to_bot(_message)
        _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
        this.props.setMessage(_message)
        window.chatSocket.conn.send(_message)
    }

    render() {
        let items = this.props.props;
        let selectedOption  = undefined
          if(this.props.selectedOption) {
            try{
              selectedOption = JSON.parse(this.props.selectedOption)
            }catch(e){
              selectedOption = this.props.selectedOption
            }
          }
        return (
            <div className="row text-left no_margin component_box">
                {selectedOption || this.state.disable ? null : <div className="align-top no_padding">
                {/* <img src={bot_logo} alt="Bot Image" className="bot_img" /> */}
                </div>}
                {selectedOption || this.state.disable ? null :
                <div className="col-xs-8 chat-btn-group align-top no_padding bot_chat">
                    {/* <div className="select card">
                       <ul className="list-group list-group-flush text-center">
                            {
                                items.map((item, index) => {
                                    return (
                                        <li className="list-group-item">
                                            <a  onClick={() => { window.imBack({ text: item.content.buttons[0].value, payload: { showTitle: true, title: item.content.buttons[0].value } }) }} >
                                            {item.content.buttons[0].value}
                                            </a>
                                        </li>
                                    )
                                })
                            }
                       </ul>
                    </div> */}

                         <div>{
                            items.map((item, index) => {

                               return (
                                   <a  onClick={() => this.handleQA(item.content.buttons[0])} >
                                       <button type="button"  style = {item.content.buttons[0].colour ? {flexWrap: "nowrap", overflowX: "auto", whiteSpace:"normal", backgroundColor: item.content.buttons[0].colour, color: "#ffffff"} : {flexWrap: "nowrap", overflowX: "auto"}} disabled={selectedOption ? true : false} className={selectedOption == item.content.buttons[0].value ? "btn burgerBtn button_box  text-center qna-btn-color-selected" : "btn burgerBtn button_box  text-center"} >
                                            {item.content.buttons[0].value}
                                        </button>
                                  </a>

                               )
                            })
                       }
                    </div>
                </div>}
            </div>

        )
    }
}
