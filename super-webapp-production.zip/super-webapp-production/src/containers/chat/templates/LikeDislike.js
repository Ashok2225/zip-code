import React, { Component } from "react";
import bot_logo from "../../../images/chat-avt.png";

class LikeAndDislike extends Component {
  constructor(props) {
    super();
    this.state = {
      thumbUpBG: "",
      thumbDownBG: "",
      disableButtons: false
    };
  }

  handleThumsup = event => {
    this.setState({
      thumbUpBG: "green",
      thumbDownBG: "",
      disableButtons: true
    });
    let items = this.props.props.content.items;
    items[0].flag = "like";
    let feedback = {
      userId: sessionStorage.getItem("userId"),
      data: items
    };
    //this.apiCall(feedback);
  };

  handleThumsDown = event => {
    this.setState({
      thumbDownBG: "red",
      thumbUpBG: "",
      disableButtons: true
    });
    let items = this.props.props.content.items;
    items[0].flag = "dislike";
    let feedback = {
      userId: sessionStorage.getItem("userId"),
      data: items
    };
    // this.apiCall(feedback);
  };

  // apiCall = feedback => {
  //   try {
  //     let config = {
  //       method: "post",
  //       url: "http://localhost:5000/v1/chatbot/nayara/userfeedback",
  //       data: feedback
  //     };
  //     axios(config);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };

  render() {
    let items = this.props.props.content.items[0];
    return (
      <div className="row text-left no_margin component_box">
        <div className="chat-bot-message-box" style={{marginLeft: "16px"}}>
          <img src={bot_logo} alt="Bot Image" className="chat-bot-message-logo" />
          <div className="chat-bot-message">
            <p>{items.answer}</p>
          </div>
        </div>
        <div style={this.state.disableButtons ? {pointerEvents: "none", opacity: "0.6"} : {}} className="col-xs-10 align-top no_padding bot_chat">
          <section className="rating-area align-center">
            <div className="thumbs-up-circle align-center transition-fast">
              <span className="thumbs-up transition-fast">
                <i
                  className="icon fa fa-thumbs-up thumb"
                  onClick={this.handleThumsup}
                  style={{ color: this.state.thumbUpBG }}
                />
              </span>
            </div>
            <div className="thumbs-up-circle align-center transition-fast">
              <span className="thumbs-down transition-fast">
                <i
                  className="icon fa fa-thumbs-down thumb"
                  onClick={this.handleThumsDown}
                  style={{ color: this.state.thumbDownBG }}
                />
              </span>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default LikeAndDislike;
