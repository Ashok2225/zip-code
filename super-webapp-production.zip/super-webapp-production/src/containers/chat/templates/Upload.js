import React, { Component } from 'react'
import '../css/style.css'
import axios from 'axios'
import Config from "./../../config.json"
import bot_logo from '../../../images/chat-avt.png'
import { getKeycloackRefreshToken } from "../../../redux/actions/auth"

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = { file: "" }
  }
  handleChange = (e) => {
    this.setState({ file: e.target.files[0] })
  }

  storeFile = async () => {
    let file1 = this.state.file
    let payload = this.props.props[0].content.items[0];
    if (payload.filetypes) {
      let fileTypes = payload.filetypes.split(","); // To split all the file types into array
      let typeOfFile = file1.name.split(".");
      let fileExt = typeOfFile[typeOfFile.length - 1];
      let fileValid = fileTypes.includes("." + fileExt) || fileTypes.includes(" ." + fileExt);// To check file type in the array
      if (fileValid) {
        let formData = new FormData();
        formData.append("files", file1);
        let d = this.getAsyncData(formData).then((res, state) => {
          if (res.data.Location) {
            let { Key, Location } = res.data;
            let msg = { Key, Location }
            msg = JSON.stringify(msg)
            this.setState({ disable: true })
            this.setState({ disable: true })
            let _message = { text: msg, payload: { showTitle: true, title: "File Upload Successfully" } }
            this.props.send_message_to_bot(_message)
            _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
            this.props.setMessage(_message)
            window.chatSocket.conn.send(_message)
          } else if (res.data.url) {
            let { url } = res.data;
            let msg = { url }
            msg = JSON.stringify(msg)
            this.setState({ disable: true })
            this.setState({ disable: true })
            let _message = { text: msg, payload: { showTitle: true, title: "File Upload Successfully" } }
            this.props.send_message_to_bot(_message)
            _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
            this.props.setMessage(_message)
            window.chatSocket.conn.send(_message)
          }
          else {
            this.setState({ disable: true })
            let _message = { text: "not uploaded", payload: { showTitle: true, title: "File Upload Failed" } }
            this.props.send_message_to_bot(_message)
            _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
            this.props.setMessage(_message)
            window.chatSocket.conn.send(_message)
          }
        }).catch((err) => {
          this.setState({ disable: true })
          console.log(err, "err")
          let _message = { text: "not uploaded", payload: { showTitle: true, title: "File Upload Failed" } }
          this.props.send_message_to_bot(_message)
          _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
          this.props.setMessage(_message)
          window.chatSocket.conn.send(_message)
        })
      } else {
        alert("Input file type is invalid. Please select valid input file type")
      }
    } else {
      // let state = this.state
      let formData = new FormData();
      formData.append("files", file1);
      let d = this.getAsyncData(formData).then((res, state) => {
        if (res.data.Location) {
          let { Key, Location } = res.data;
          let msg = { Key, Location }
          msg = JSON.stringify(msg)
          this.setState({ disable: true })
          let _message = { text: msg, payload: { showTitle: true, title: "File Upload Successfully" } }
          this.props.send_message_to_bot(_message)
          _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
          this.props.setMessage(_message)
          window.chatSocket.conn.send(_message)
        } else if (res.data.url) {
          let { url } = res.data;
          let msg = { url }
          msg = JSON.stringify(msg)
          this.setState({ disable: true })
          let _message = { text: msg, payload: { showTitle: true, title: "File Upload Successfully" } }
          this.props.send_message_to_bot(_message)
          _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
          this.props.setMessage(_message)
          window.chatSocket.conn.send(_message)
        } else {
          this.setState({ disable: true })
          let _message = { text: "not uploaded", payload: { showTitle: true, title: "File Upload Failed" } }
          this.props.send_message_to_bot(_message)
          _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
          this.props.setMessage(_message)
          window.chatSocket.conn.send(_message)
        }
      }).catch((err) => {
        console.log(err, "err")
        this.setState({ disable: true })
        let _message = { text: "not uploaded", payload: { showTitle: true, title: "File Upload Failed" } }
        this.props.send_message_to_bot(_message)
        _message = window.chatSocket.finalPayload(_message, false, getKeycloackRefreshToken())
        this.props.setMessage(_message)
        window.chatSocket.conn.send(_message)
      })
    }

    //   let file1 = this.state.file
    //   let state = this.state
    //   let formData = new FormData();
    //   formData.append("files",file1);
    //  let d =  this.getAsyncData(formData).then((res, state) => {
    //      if(res.data.Location){
    //          let { Key, Location } = res.data;
    //          let msg = { Key, Location }
    //          msg = JSON.stringify(msg)
    //        this.props.send_message_to_bot({ text: msg,payload: { showTitle: true, title: "file uploaded successfully" } })
    //      }
    //      else{
    //        this.props.send_message_to_bot({ text: "not uploaded", payload: { showTitle: true, title: "file upload faiiled" } })
    //      }
    //    }).catch((err)=>{
    //       console.log(err,"err")
    //      this.props.send_message_to_bot({ text: "not uploaded", payload: { showTitle: true, title: "file upload failed" } })
    //    })
  }

  getAsyncData = (formData) => {
    let payload = this.props.props[0].content.items[0];
    formData.append("endpoint", payload.endpoint)
    if (payload.storage == "CUSTOM") {
      return new Promise((resolve, reject) => {
        resolve(axios({
          method: payload.method,
          url: payload.url,
          headers: { "Content-Type": payload.headers },
          data: formData
        }))
      })
    } else if (payload.storage == "S3") {
      return new Promise((resolve, reject) => {
        resolve(axios({
          method: "post",
          url: process.env.REACT_APP_S3UPLOADURL,
          headers: { "Content-Type": "application/json" },
          data: formData
        })
        )
      })
    } else if (payload.storage.toUpperCase() == "AZURE") {
      return new Promise((resolve, reject) => {
        resolve(axios({
          method: "post",
          url: process.env.REACT_APP_AZUREUPLOADURL,
          headers: { "Content-Type": "application/json" },
          data: formData
        })
        )
      })
    }
  }
  render() {
    let { filetypes: acceptFiletypes } = this.props.props[0].content.items[0]
    let selectedOption = undefined
    if (this.props.selectedOption) {
      try {
        selectedOption = JSON.parse(this.props.selectedOption)
      } catch (e) {
        selectedOption = this.props.selectedOption
      }
    }
    return (
      <div className="row text-left no_margin component_box">
        {selectedOption || this.state.disable ? null :
          <div className="col-xs-1 align-top no_padding">
            <img src={bot_logo} alt="Bot Image" className="bot_img" />
          </div>}
        {selectedOption || this.state.disable ? null :
          <div className="col-xs-10 align-top no_padding bot_chat">
            <div className="input card">
                <ul className="list-group list-group-flush text-center">
                  <li className="list-group-item">
                    <input type="file" name="file" id="uploadfile" accept={acceptFiletypes} onChange={this.handleChange} />
                    {/*<input type="submit" />*/}
                  </li>
                  <li className="list-group-item filled">
                    <a style={{ color: "#ffffff" }} onClick={() => { this.storeFile() }} >
                      Upload
                    </a>
                  </li>
                </ul>
            </div>
          </div>
        }
      </div>
    );
  }
}
