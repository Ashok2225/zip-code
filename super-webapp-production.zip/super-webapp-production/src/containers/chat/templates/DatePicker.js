import React, { Component } from 'react'
import Calendar from 'react-calendar';
import '../css/style.css'

export default class DatePicker extends Component {

  constructor(props) {
    super()
    this.state = {
      date: new Date(),
      selectedDates: []
    }
  }

  render() {
    let { title, action } = this.props.props
    return (
      <div className="row text-left no_margin component_box">
        <div className="col-xs-1 align-top no_padding">
          <img src={require("../images/bot_logo.png")} alt="Bot Image" className="bot_img" />
        </div>
        <div className="col-xs-10 align-top no_padding bot_chat">
          <div className="bubble card">
            {title}
          </div>
          <div className="select card">

            <Calendar
              selectRange={true}
              onChange={(e) => this.setState({ selectedDates: e })}
              value={this.state.date}
            />
          </div>
          <div style={{ margin: "0px 5px 0px" }}>
            <button
              onClick={() => this.props.send_message_to_bot({ text: action.reply, payload: this.state.selectedDates })}
              style={{
                margin: "margin: 10px 5px 0px",
                width: "100%",
                backgroundColor: "#02ce9d",
                color: "#FFFFFF",
                cursor: "pointer",
                padding: 10,
                border: "none",
                outline: "none",
                borderBottomLeftRadius: ".25rem",
                borderBottomRightRadius: ".25rem",
              }}
            >{action.text}</button>
          </div>

          <div className="select smiley text-right">
            <img src={require("../images/smiley_heart_eyes.png")} alt="Smiley" />
          </div>
        </div>
      </div>
    )
  }
}





