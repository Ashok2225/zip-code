import React from "react"
import '../../css/style.css'
class Radio extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
        }
    }

    validate = (input) => {
        return true;
    }

    handleClick = (event) => {
        let temp = event.target.value;
        this.setState({selectedValue: temp})
        if(this.validate(temp)){
            let data = this.props.data;
            data["value"] = temp;
            this.props.updateRadioBox(data,this.props.key)
        }
    }

    render() {
        let {selectedValue} = this.state
        let radioItems = this.props.data
        let values = radioItems.radioButtons
        let title = radioItems.title
        let selectedOption = null;
        let o = values[0]
        return (
            <div className="form-fields">
                <div className="form-group">
                    <div className="label-top-space"></div>
                    <label>{title}</label>
                    <div className="label-bottom-space"></div>
                    {
                        values.map((item, index) => {
                            //console.log("radioooooooooooooooooooooo:",item)
                            return (
                                <div className="form-group" key={index}>
                                    <label>
                                        <input type="radio" disabled={selectedOption ? true : false} id={index} name={item.label} value={item.label} checked={item.label == selectedValue} onChange={this.handleClick} />
                                        {item.label}
                                    </label>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        )
    }
}

export default Radio
