import React from 'react'
import TextFieldWidget from "./TextField"
import DropDownWidget from "./DropDown"
import CheckBoxWidget from "./Checkbox"
import RadioWidget from "./RadioButton"
import MultiselectWidget from "./Multiselect"

import './css/style.css'

class FormBuild extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            message : {},
		    filled_message : {},
		    valid_elements : 0,
        }
    }

    //Hideing the Footer component
    componentDidMount(){
        if(this.props.isLast){
            document.getElementById('footer_Input').style.display = "none"
        }
        let facts = this.props.props[0].payload.inputs;
        this.setState({message: facts, filled_message: facts})
    }

    update_radio_box = (data, index) => {
        let valid_elements = this.state.valid_elements
	    valid_elements ++;
	    let filled_message = this.state.filled_message
	    filled_message[index] = data
	    this.setState({filled_message: filled_message,valid_elements: valid_elements})
    }

    update_check_box = (data, index) => {
        let valid_elements = this.state.valid_elements
	    valid_elements ++;
	    let filled_message = this.state.filled_message
	    filled_message[index] = data
	    this.setState({filled_message: filled_message,valid_elements: valid_elements})
    }

    renderFormFields = (fact, index) => {
        switch(fact.type) {
            case "radio" :
                return <RadioWidget key={index} data={fact} updateRadioBox={this.update_radio_box} />

            case undefined :
                return <CheckBoxWidget key={index} data={fact} updateRadioBox={this.update_check_box} />
        }
    }

    onFormSubmit = () => {
        // let flag = true;
        // for (let [key, value] of Object.entries(this.state)) {
        //     console.log("hiii:",key,value)
        //     var spaceValidate = key == "multiselect" ? (value.length == 0 ? "" : value[0]["label"].split(" ").join("")) : (Array.isArray(value) ? (value.length == 0 ? "" : value[0].split(" ").join("")) : value.split(" ").join(""))
        //     if(value.length == 0 || spaceValidate.length == 0){
        //       alert("Please fill out the form completely")
        //       flag = false;
        //       break;
        //     }
        // }
        // if(flag){
        //     document.getElementById('footer_Input').style.display = "block";
        //     this.props.send_message_to_bot({ text: JSON.stringify(this.state), payload: { showTitle: true, title: 'Submitted' } })
        // }
        document.getElementById('footer_Input').style.display = "block";
        this.props.send_message_to_bot({ text: JSON.stringify(this.state.filled_message), payload: { showTitle: true, title: 'Submitted' } })
    }

    render() {
        //console.log("form props:",this.props)
        let selectedOption = this.props.selectedOption
        let facts = this.props.props[0].payload.inputs
        return (
            <div className="form">
                <form>
                {
                    facts.map((fact, index) => {
                        return this.renderFormFields(fact, index)
                    })
                }
                <a className="button" key={this.props.index} onClick={this.onFormSubmit} >
                                    Submit
                </a>
                {/* {
                    content.buttons.map((button, index) => {
                        if (button.value && selectedOption == undefined) {
                            return (
                                <a className="button" key={index} onClick={this.onFormSubmit} >
                                    {button.title}
                                </a>
                            )
                        }
                    })
                } */}
                </form>
            </div>
        )
    }
}
export default FormBuild
