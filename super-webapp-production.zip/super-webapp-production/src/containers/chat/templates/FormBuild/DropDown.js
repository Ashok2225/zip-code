import React from "react"
import '../../css/style.css'
class DropDown extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
    }

    handleClick = (event) => {
        let title=document.getElementById(event.target.value).text
        this.setState({
           // [event.target.name]: event.target.value
           "dropdownselect": title,
           "dropdownvalue" : event.target.value,
           "dropdowntitle": title
        }, () => this.props.handleFormValues(this.state))

    }
    componentDidMount() {
        let dropItems = this.props.props[0]
        let values = dropItems.value
        let selectedOpt = this.props.props[1]
        if(selectedOpt){
            this.setState({
                "dropdownselect": selectedOpt,
                "dropdownvalue": selectedOpt,
                "dropdowntitle": selectedOpt
            })
        } else {
            this.setState({
                "dropdownselect": values[0].title,
                "dropdownvalue" : typeof(values[0].value) == "number" ? JSON.stringify(values[0].value) : values[0].value,
                "dropdowntitle": values[0].title
            }, () => this.props.handleFormValues(this.state))
        }
    }

    render() {
        let dropItems = this.props.props[0]
        let values = dropItems.value
        let title = dropItems.title
        let dropdownObj = values[0]
        let selectedOpt = this.props.props[1]

        return (
            <div className="form-fields">
                <div className="form-group">
                    <div className="label-top-space"></div>
                    <label>{title}</label>
                    <div className="label-top-space"></div>
                    <select className="form-control" name={Object.keys(dropdownObj)[1]}
                        value={this.state.dropdownvalue} disabled={selectedOpt ? true : false}
                        onChange={this.handleClick}>
                        {
                            values.map((item, index) => {
                                return (
                                    <option key={index} id={item.value} value={item.value} >{item.title}</option>
                                )
                            }
                            )
                        }
                    </select>
                </div>
            </div>
        )
    }
}

export default DropDown
