import React from "react"
import '../../css/style.css'
class TextField extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        }, () => this.props.handleFormValues(this.state))
    }

    componentWillMount() {
        let formItems = this.props.props
        formItems.map((item, index) => (
            this.setState({ [item.value]: '' })
        ))
    }

    render() {
        let formItems = this.props.props
        let selectedOption = this.props.selectedOption
        return (
            <div>
                {
                    <div className="form-fields">
                        {
                            formItems.map((item, index) => {
                                if (item.type === 'textarea') {
                                    return (
                                        <div className="form-group" key={index}>
                                            <div className="label-top-space"></div>
                                            <label>{item.title}</label>
                                            <div className="label-bottom-space"></div>
                                            <textarea className="form-control" disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]}  key={index} onChange={ this.handleChange }  ></textarea>
                                        </div>
                                    )
                                }
                                return (
                                    <div className="form-group" key={index}>
                                        <div className="label-top-space"></div>
                                        <label>{item.title}</label>
                                        <div className="label-bottom-space"></div>
                                        <input type={item.type} disabled={selectedOption ? true : false} name={item.value} value={selectedOption?selectedOption[item.value]:this.state[item.value]} className="form-control" key={index} onChange={this.handleChange} />
                                    </div>
                                )
                            })
                        }
                    </div>
                }
            </div>
        )
    }
}

export default TextField
