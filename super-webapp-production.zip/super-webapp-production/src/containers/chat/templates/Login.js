import React, { Component } from 'react'
import '../css/style.css'

export default class Login extends Component {
  constructor(props){
    super(props);
    this.state={
        userName:'',
        passWord:''
    }
  }

handleChange=(e)=>{
      this.setState({ passWord: e.target.value });
      window.localStorage.setItem('user', this.state);
}
handleChange1=(e)=>{
      this.setState({ userName: e.target.value });
}

//Hideing the Footer component
    componentDidMount(){
         if(this.props.isLast){
              document.getElementById('footer_Input').style.display = "none"
      }
    }

  render(){
    let items= this.props.props;

      return (
        <div className="row text-left no_margin component_box">
  							<div className="col-xs-1 align-top no_padding">
  								<img src={require("../images/bot_logo.png")} alt="Bot Image" className="bot_img" />
  							</div>
  							<div className="col-xs-10 align-top no_padding bot_chat">
  								<div className="input card">
  									<ul className="list-group list-group-flush text-center">
  										<li className="list-group-item">
                        <form action="#" method="post" className="form_box text-left" autocomplete="off">

                        {
                            items[0].content.items.map((item ,index)=>{
                              let pwd = item.title
                              let pwd1 = pwd.toLocaleLowerCase();
                              let resPwd1 = pwd1.includes('password');
                              if(resPwd1){
                                return(
                                  <div className="form-group" key={index}>
                                    <label htmlFor="password">{pwd}</label>
                                    <input type="password" className="form-control" value={this.state.passWord} id="password" onChange={ this.handleChange } />
                                  </div>
                                )
                              }else{
                                return(
                                  <div className="form-group" key={index}>
                                    <label htmlFor="username">{pwd}</label>
                                    <input type="text" className="form-control" id="username" value={this.state.userName} onChange={ this.handleChange1 } />
                                  </div>
                                )
                              }
                            })
                      }
                        </form>
  										</li>
  										<li className="list-group-item filled">
                          <a  onClick={() => {document.getElementById('footer_Input').style.display = "block"; this.props.send_message_to_bot({ text: JSON.stringify(this.state), payload: { showTitle: true, title: items[0].content.buttons[0].value } }) }} >
                          {items[0].content.buttons[0].title}
                          </a>
                      </li>
  									</ul>
  								</div>
  							</div>
  						</div>
      );
  }
}
