import React from 'react'
import './css/main.css'
import './css/table.css'
import logo from './img/logo.png'
import bell from './img/bell.png'
import settings from './img/setting-icon.png'
import user from './img/user.png'
import close from './img/close.svg'
import cheveron from './img/cheveron.svg'
import axios from 'axios'
import Config from "../../../config.json"

class Sh extends React.Component {
    state = {
        forecast : [],
        annual_sales : {
            1 : [200,105,305],
            2 : [180,140,300],
            3 : [170,125,200],
            4 : [200,205,250],
            5 : [100,120,150]
        },
        bottom_up : {
            1 : [180,140,300],
            2 : [200,105,305],
            3 : [200,205,250],
            4 : [100,120,150],
            5 : [170,125,200]
            
        },
        editData : {
            1 : "",
            2 : "",
            3 : "",
            4 : "",
            5 : ""
        },
        showSideBar: false,
        dropDownList: ["Feb-21","Mar-21","Apr-21","May-21"],
        month: "Feb-21",
        dates: ["Mar-21","Apr-21","May-21"],
        copyActions: false,
        copyForecastData: [],
        user_id: 1010,
        user_details: {},
        zsm_details: [],
        user_location: "",
        orglevel: "",
        orgid: 1,
        status: "Submitted by ZSM",
        disableSubmit: false,
        sku: "All",
        product: "All",
        statusData: {},
        disableFilters: false,
        sku: "All",
        product: "All",
        statusData: {},
        disableFilters: false
    }

    showSideBar = () => {
        this.setState({showSideBar: true})
    }

    componentWillMount(){
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let STRAPI_URL = window.runtimeConfig && window.runtimeConfig.STRAPI_URL ? window.runtimeConfig.STRAPI_URL : Config.STRAPI_URL;
        // axios.get(`${STRAPI_URL}/tf-logins/1`).then((data)=>{
        //     console.log("555555555555555555555:",data)
            this.setState({user_id: this.props.user.sub})
            axios.get(`${URL}/shdetails?user_id=${this.props.user.sub}`).then((data)=>{
                console.log("555555555555555555555:",data)
                this.setState({user_details: data.data, zsm_details: data.data.zsmdetails, "orgid": data.data.zsmdetails[0].user_id, "orglevel": data.data.zsmdetails[0].user_name})
                axios.get(`${URL}/shproduct?zsm_user_id=${this.state.zsm_details[0].user_id}`).then((data)=>{
                    console.log("6666666666666666666:",data)
                    this.setState({statusData: data.data, status: data.data.status})
                    let res = data.data;
                    if(res.status == "Submitted by ZSM"){
                        axios.get(`${URL}/shdata?month=${this.state.month}&zsm_user_id=${this.state.zsm_details[0].user_id}&sku_shortname=${this.state.sku}&product_group=${this.state.product}`).then((data)=>{
                            console.log("6666666666666666666:",data)
                            // this.setState({forecast: data.data, copyForecastData: data.data})
                            let copyData = data.data.map((dataObj, index) => {
                                let copyForecastObj = {...dataObj};
                                // copyForecastObj["updated_quantity1"] = dataobj.updated_quantity1;
                                // copyForecastObj["updated_quantity2"] = dataobj.updated_quantity2;
                                // copyForecastObj["updated_quantity3"] = dataobj.updated_quantity3;
                                // copyForecastObj["remarks"] = "";
                                copyForecastObj["color1"] = "lightgray";
                                copyForecastObj["color2"] = "lightgray";
                                copyForecastObj["color3"] = "lightgray";
                                return copyForecastObj;
                            })
                            this.setState({forecast: data.data, copyForecastData: copyData})
                        }).catch((err) => console.log("err:",err))
                    }
                }).catch((err) => console.log("err:",err))
            }).catch((err) => console.log("err:",err))
        // }).catch((err) => console.log("err:",err))
    }

    componentDidUpdate(prevProps, prevState){
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let newState = this.state;
        console.log("66666666666666666666666666666666:",prevState)
        console.log("9999999)9999999)999999)999):",this.state)
        if(prevState.month != newState.month || prevState.sku != newState.sku || prevState.product != newState.product){
            axios.get(`${URL}/shdata?month=${newState.month}&zsm_user_id=${newState.orgid}&sku_shortname=${this.state.sku}&product_group=${this.state.product}`).then((data)=>{
                console.log("555555555555555555555:",data)
                // this.setState({forecast: data.data, copyForecastData: data.data})
                let copyData = data.data.map((dataObj, index) => {
                    let copyForecastObj = {...dataObj};
                    // copyForecastObj["updated_quantity1"] = dataobj.updated_quantity1;
                    // copyForecastObj["updated_quantity2"] = dataobj.updated_quantity2;
                    // copyForecastObj["updated_quantity3"] = dataobj.updated_quantity3;
                    // copyForecastObj["remarks"] = "";
                    copyForecastObj["color1"] = "lightgray";
                    copyForecastObj["color2"] = "lightgray";
                    copyForecastObj["color3"] = "lightgray";
                    return copyForecastObj;
                })
                this.setState({forecast: data.data, copyForecastData: copyData})
            }).catch((err) => console.log("err:",err))
        }else if(prevState.orglevel != newState.orglevel && prevState.orglevel != ""){
            console.log("999999)999999999999999999999)99999999999)========================",prevState, "000000000",newState)
            axios.get(`${URL}/shproduct?zsm_user_id=${newState.orgid}`).then((data)=>{
                console.log("6666666666666666666:",data)
                this.setState({statusData: data.data, status: data.data.status})
                let res = data.data;
                if(res.status == "Submitted by ZSM"){
                    axios.get(`${URL}/shdata?month=${newState.month}&zsm_user_id=${newState.orgid}&sku_shortname=${this.state.sku}&product_group=${this.state.product}`).then((data)=>{
                        console.log("6666666666666666666:",data)
                        // this.setState({forecast: data.data, copyForecastData: data.data})
                        let copyData = data.data.map((dataObj, index) => {
                            let copyForecastObj = {...dataObj};
                            // copyForecastObj["updated_quantity1"] = dataobj.updated_quantity1;
                            // copyForecastObj["updated_quantity2"] = dataobj.updated_quantity2;
                            // copyForecastObj["updated_quantity3"] = dataobj.updated_quantity3;
                            // copyForecastObj["remarks"] = "";
                            copyForecastObj["color1"] = "lightgray";
                            copyForecastObj["color2"] = "lightgray";
                            copyForecastObj["color3"] = "lightgray";
                            return copyForecastObj;
                        })
                        this.setState({forecast: data.data, copyForecastData: copyData})
                    }).catch((err) => console.log("err:",err))
                }else{
                    this.setState({forecast: [], copyForecastData: []})
                }
            }).catch((err) => console.log("err:",err))
        }
    }

    handleDropdown = (e) => {
        let dates = [];
        let {name,value} = e.target;
        console.log("6666:",name,value);
        if(name == "month"){
            // axios.get(`${URL}/shdata?month=${value}&zsm_user_id=${this.state.orgid}`).then((data)=>{
            //     console.log("555555555555555555555:",data)
            //     this.setState({forecast: data.data, copyForecastData: data.data})
            // }).catch((err) => console.log("err:",err))
            let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let reqMonth = value.split("-")[0];
            let evaluateMonth = months.includes(reqMonth);
            console.log("333333333:",evaluateMonth)
            if(evaluateMonth){
                let dates1 = new Date(`01-${value}`)
                let dates2 = new Date(`01-${value}`)
                let dates3 = new Date(`01-${value}`)
                console.log(dates1,dates2,dates3)
                let newDate1 = new Date(dates1.setMonth(dates1.getMonth()+1));
                let newDate2 = new Date(dates2.setMonth(dates2.getMonth()+2));
                let newDate3 = new Date(dates3.setMonth(dates3.getMonth()+3));
                //console.log(date1.getMonth(),date1.getFullYear());
                let date1 = `${months[newDate1.getMonth()]}-${newDate1.getFullYear().toString().substr(-2)}`;
                let date2 = `${months[newDate2.getMonth()]}-${newDate2.getFullYear().toString().substr(-2)}`;
                let date3 = `${months[newDate3.getMonth()]}-${newDate3.getFullYear().toString().substr(-2)}`;
                console.log(date1,date2,date3);
                dates = [date1,date2,date3];
                this.setState({dates})
            }
        }else if(name == "orglevel"){
            // let { name,value } = e.target;
            let { zsm_details } = this.state;
            let user_id;
            for(let i=0; i< zsm_details.length; ++i){
                let userObj = zsm_details[i];
                if(userObj.user_name == value){
                    user_id = userObj.user_id;
                    break;
                }
            }
            this.setState({"orgid": user_id})
        }
        this.setState({[name]: value})
    }

    // handleOrgDropdown = (e) => {
    //     let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
    //     let { name,value } = e.target;
    //     let { zsm_details } = this.state;
    //     let user_id;
    //     for(let i=0; i< zsm_details.length; ++i){
    //         let userObj = zsm_details[i];
    //         if(userObj.user_name == value){
    //             user_id = userObj.user_id;
    //             break;
    //         }
    //     }
    //     console.log(user_id)
    //     this.setState({[name]: value, "orgid": user_id})
    //     // axios.get(`http://localhost:5000/getlocation?user_id=${user_id}`).then((data)=>{
    //     //     console.log("6666666666666666666:",data)
    //     //     this.setState({user_location: data.data})
    //         axios.get(`${URL}/shdata?month=${this.state.month}&zsm_user_id=${user_id}`).then((data)=>{
    //             console.log("6666666666666666666:",data)
    //             this.setState({forecast: data.data, copyForecastData: data.data})
    //         }).catch((err) => console.log("err:",err))
    //     // }).catch((err) => console.log("err:",err))
    // }

    // handleMonthDropdown = (e) => {
    //     let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
    //     let dates = [];
    //     let {name,value} = e.target;
    //     console.log("6666:",name,value);
    //     axios.get(`${URL}/shdata?month=${value}&zsm_user_id=${this.state.orgid}`).then((data)=>{
    //         console.log("555555555555555555555:",data)
    //         this.setState({forecast: data.data, copyForecastData: data.data})
    //     }).catch((err) => console.log("err:",err))
    //     let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    //     let reqMonth = value.split("-")[0];
    //     let evaluateMonth = months.includes(reqMonth);
    //     console.log("333333333:",evaluateMonth)
    //     if(evaluateMonth){
    //         let dates1 = new Date(`01-${value}`)
    //         let dates2 = new Date(`01-${value}`)
    //         let dates3 = new Date(`01-${value}`)
    //         console.log(dates1,dates2,dates3)
    //         let newDate1 = new Date(dates1.setMonth(dates1.getMonth()+1));
    //         let newDate2 = new Date(dates2.setMonth(dates2.getMonth()+2));
    //         let newDate3 = new Date(dates3.setMonth(dates3.getMonth()+3));
    //         //console.log(date1.getMonth(),date1.getFullYear());
    //         let date1 = `${months[newDate1.getMonth()]}-${newDate1.getFullYear().toString().substr(-2)}`;
    //         let date2 = `${months[newDate2.getMonth()]}-${newDate2.getFullYear().toString().substr(-2)}`;
    //         let date3 = `${months[newDate3.getMonth()]}-${newDate3.getFullYear().toString().substr(-2)}`;
    //         console.log(date1,date2,date3);
    //         dates = [date1,date2,date3];
    //     }
    //     this.setState({[name]: value, dates})
    // }

    // handleChange = (e,index) => {
    //     let { name, value } = e.target;
    //     console.log(name,value,typeof value);
    //     let data = this.state.copyForecastData;
    //     if(name == "remarks"){
    //         data[index][name] = value;
    //     }else{
    //         data[index][name] = parseInt(value);
    //     }
    //     this.setState({copyForecastData: data})
    // }

    handleChange = (e,index) => {
        let { name, value } = e.target;
        let { dates } = this.state;
        console.log(e.target,e.target.month);
        let data = this.state.copyForecastData;
        let data1 = this.state.forecast;
        if(name == "remarks"){
            data[index][name] = value;
        }else{
            let action = {};
            let subtract = parseFloat(value) - data1[index][name.split("_")[1]];
            let divide = subtract / parseFloat(value);
            let variance = divide * 100;
            console.log("subtract",subtract);
            console.log("divide",divide);
            console.log("variance",variance);
            let field = "";
            let colorField = "";
            if(name == "updated_quantity1"){
                //data[index][dates[0]] = dates[0];
                console.log(parseFloat(value) - data1[index][name]);
                if(parseFloat(value) - data1[index]["quantity1"] != parseFloat(value)){
                    action["updated_quantity1"] = `${dates[0]}_update`
                    field = "variance1"
                    colorField = "color1"
                }else{
                    action["updated_quantity1"] = `${dates[0]}_insert`
                    field = "variance1"
                    colorField = "color1"
                }
            }else if(name == "updated_quantity2"){
                //data[index][dates[0]] = dates[0];
                console.log(parseFloat(value) - data1[index][name]);
                if(parseFloat(value) - data1[index]["quantity2"] != parseFloat(value)){
                    action["updated_quantity2"] = `${dates[1]}_update`
                    field = "variance2"
                    colorField = "color2"
                }else{
                    action["updated_quantity2"] = `${dates[1]}_insert`
                    field = "variance2"
                    colorField = "color2"
                }
            }else if(name == "updated_quantity3"){
                //data[index][dates[0]] = dates[0];
                console.log(parseFloat(value) - data1[index][name]);
                if(parseFloat(value) - data1[index]["quantity3"] != parseFloat(value)){
                    action["updated_quantity3"] = `${dates[2]}_update`
                    field = "variance3"
                    colorField = "color3"
                }else{
                    action["updated_quantity3"] = `${dates[2]}_insert`
                    field = "variance3"
                    colorField = "color3"
                }
            }
            data[index][name] = parseFloat(value);
            if(variance > 15 || variance < -15){
                data[index][colorField] = "orangered";
            }else{
                data[index][colorField] = "white";
            }
            //data[index][field] = variance.toFixed(2);
            data[index][field] = Math.round((variance + Number.EPSILON) * 100) / 100;
            data[index]["action"] = data[index].hasOwnProperty('action') ? {...data[index]["action"], ...action} : action;
        }
        this.setState({copyForecastData: data})
    }

    // copyForecast = () => {
    //     let { forecast } = this.state;
    //     let copyForecastData = forecast.map((data, index) => {
    //         let copyForecastObj = {};
    //         copyForecastObj["quantity1"] = data.quantity1;
    //         copyForecastObj["quantity2"] = data.quantity2;
    //         copyForecastObj["quantity3"] = data.quantity3;
    //         copyForecastObj["remarks"] = "";
    //         return copyForecastObj;
    //     })
    //     this.setState({"copyActions": true, copyForecastData});
    // }

    // copyAnnualSales = () => {
    //     let { forecast } = this.state;
    //     let copyForecastData = forecast.map((data, index) => {
    //         let copyForecastObj = {};
    //         copyForecastObj["quantity1"] = data.quantity1;
    //         copyForecastObj["quantity2"] = data.quantity2;
    //         copyForecastObj["quantity3"] = data.quantity3;
    //         copyForecastObj["remarks"] = "";
    //         return copyForecastObj;
    //     })
    //     this.setState({"copyActions": true, copyForecastData});
    // }

    // copyBottomUp = () => {
    //     let { forecast } = this.state;
    //     let copyForecastData = forecast.map((data, index) => {
    //         let copyForecastObj = {};
    //         copyForecastObj["quantity1"] = data.quantity1;
    //         copyForecastObj["quantity2"] = data.quantity2;
    //         copyForecastObj["quantity3"] = data.quantity3;
    //         copyForecastObj["remarks"] = "";
    //         return copyForecastObj;
    //     })
    //     this.setState({"copyActions": true, copyForecastData});
    // }

    handleApprove = () => {
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let { copyForecastData } = this.state;
        let submitData = [];
        let flag = false;
        for(var i=0; i<copyForecastData.length; ++i){
            if(copyForecastData[i].hasOwnProperty('action')){
                submitData.push(copyForecastData[i])
            }
            if(copyForecastData[i].variance1 > 15 || copyForecastData[i].variance1 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }else if(copyForecastData[i].variance2 > 15 || copyForecastData[i].variance2 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }else if(copyForecastData[i].variance3 > 15 || copyForecastData[i].variance3 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }
        }
        console.log("submit data:",submitData)
        if(!flag){
            this.setState({disableSubmit: true, disableFilters: true, status: "Submitted"});
            this.props.send_message_to_bot({ text: "Approved",payload: { showTitle: true, title: "Approved" } })
            // let { copyForecastData } = this.state;
            let data = axios.post(`${URL}/shd/shddata?user_id=${this.state.user_id}&zsm_user_id=${this.state.orgid}`,{
                data: submitData
            })
        }
    }

    handleReject = () => {
        this.setState({disableSubmit: true, disableFilters: true, status: "Rejected"});
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        this.props.send_message_to_bot({ text: "Rejected",payload: { showTitle: true, title: "Rejected" } });
        let data = axios.put(`${URL}/shdisapprove`,{
            data: {
                flag: 'ASM',
                zsm_user_id: this.state.orgid
            }
        })
    }

    sortData = (col) => {
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        this.setState({[col]: !this.state[col], sort: col})
        let sortData = `${col}-${!this.state[col]}`
        axios.get(`${URL}/shdata?month=${this.state.month}&zsm_user_id=${this.state.orgid}&sku_shortname=${this.state.sku}&product_group=${this.state.product}&sort=${sortData}`).then((data)=>{
            console.log("6666666666666666666:",data)
            // this.setState({forecast: data.data, copyForecastData: data.data})
            let copyData = data.data.map((dataObj, index) => {
                let copyForecastObj = {...dataObj};
                // copyForecastObj["updated_quantity1"] = dataobj.updated_quantity1;
                // copyForecastObj["updated_quantity2"] = dataobj.updated_quantity2;
                // copyForecastObj["updated_quantity3"] = dataobj.updated_quantity3;
                // copyForecastObj["remarks"] = "";
                copyForecastObj["color1"] = "lightgray";
                copyForecastObj["color2"] = "lightgray";
                copyForecastObj["color3"] = "lightgray";
                return copyForecastObj;
            })
            this.setState({forecast: data.data, copyForecastData: copyData})
        }).catch((err) => console.log("err:",err))
    }

    render() {
        console.log("4444444444444:",this.state);
        const usFormatter = new Intl.NumberFormat("en-US");
        return (
            <React.Fragment>
                <header>
        {/* <div className="top-header">
            <div className="container-fluid">
                <div className="top-flex">
                    <div className="logo-menu">
                        <div className="menu-btn" onClick={this.showSideBar}>
                            <span className="menu-ico"></span>
                            <span className="menu-ico"></span>
                            <span className="menu-ico"></span>
                        </div>
                        <div className="logo">
                            <img src={logo} alt=""/>
                        </div>
                    </div>
                    <div className="user-notify">
                        <div className="setting">
                            <img src={settings} alt=""/>
                        </div>
                        <div className="notify">
                            <img src={bell} alt=""/>
                        </div>
                        <div className="user-pr">
                            <div className="user-dt">
                                <p>Arvind Patel</p>
                                <span>S&OP User</span>
                            </div>
                            <img src={user} alt=""/>
                        </div>
                    </div>
                </div>
                {
                    this.state.showSideBar ? 
                    <div className="sidebar">
                        <div className="close-btn">
                            <img src={close} alt=""/>
                        </div>
                        <div className="main-navigation">
                            <ul className="nav-m">
                            <li><a >Home</a></li>
                            <li><a >Organisation Management </a></li>
                            <li><a >User Management</a></li>
                            <li><a >Access Management</a></li>
                            <li id="op-submenu">
                                <a >Modules <span className="cheveron"><img src={cheveron} alt=""/></span></a>
                                <ul className="submenu">
                                    <li><a >Demand Planning</a></li>
                                    <li><a >Supply Planning</a></li>
                                    <li><a >Dispatch Planning</a></li>
                                </ul>
                            </li>
                            <li><a >Dashboard & Analytics</a></li>
                            </ul>
                        </div>
                    </div>
                    : null
                }
            </div>
        </div> */}
        
        <div className="container-fluid">
            <div className="header-action">
                <div className="btn-flex">
                    <div className="button-box">
                        <label for="">Month</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="month" className="btn btn-primary dropdown-toggle" value={this.state.month} onChange={this.handleDropdown}>
                                {
                                    this.state.dropDownList.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    })
                                }
                            </select>
                            {/* <button className="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Mar 2021
                                <span className="caret"></span></button> */}
                            <ul className="dropdown-menu">
                                <li><a >select year</a></li>
                            </ul>
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">Org Level</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="orglevel" className="btn btn-primary dropdown-toggle" value={this.state.orglevel} onChange={this.handleDropdown}>
                                {
                                    this.state.zsm_details.map((val,index) => {
                                        return <option key={index} id={index} userid={val.user_id} value={val.user_name} >{val.user_name}</option>
                                    })
                                }
                            </select>
                            {/* <button className="btn btn-primary dropdown-toggle" type="button"
                                data-toggle="dropdown">SH
                                <span className="caret"></span></button>
                            <ul className="dropdown-menu">
                                <li><a >select</a></li>
                            </ul> */}
                        </div>
                    </div>
                    {/* <div className="button-box">
                        <label for="">Location</label>
                        <div className="dropdown">
                            <button className="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">{this.state.user_location}
                                <span className="caret"></span></button>
                            <ul className="dropdown-menu">
                                <li><a >select</a></li>
                            </ul>
                        </div>
                    </div> */}
                    <div className="button-box">
                    <label for="">SKU Level</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="sku" className="btn btn-primary dropdown-toggle" value={this.state.sku} onChange={this.handleDropdown}>
                                {
                                    this.state.statusData.hasOwnProperty("sku_shortname") ?
                                    this.state.statusData.sku_shortname.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    }) : 
                                    null
                                }
                            </select>
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">Product Group</label>
                        <div className="dropdown">
                        <select disabled={this.state.disableFilters ? true : false} name="product" className="btn btn-primary dropdown-toggle" value={this.state.product} onChange={this.handleDropdown}>
                                {
                                    this.state.statusData.hasOwnProperty("product_group") ?
                                    this.state.statusData.product_group.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    }) : 
                                    null
                                }
                            </select>
                        </div>
                    </div>
                    {/* <div className="button-ud">
                        <button className="btn-download">Download</button>
                        <button className="btn-upload">Upload</button>
                    </div> */}
                </div>
                <div className="avat">
                    <div className="user-pr">
                        <div className="user-dt">
                            <p>{this.state.user_details.user_name}</p>
                            <span>{this.state.user_details.role_name}</span>
                        </div>
                        <img src={user} alt=""/>
                    </div>
                    <div className="text-flex">
                        {/* <p>Active Cycle : <strong>April 2020</strong></p> */}
                        <p>Submission Status: <span style={{color: "#fff", fontWeight: "bold"}}>{this.state.forecast.length > 0 ? this.state.status : "No Data Found"}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div className="content-wrapper">
      <div className="container-fluid">
        <div className="table-responsive">
          <table className="table table-bordered main-tb">
            <thead className="td-header">
              {/* <tr className="tb-buttons">
                <th colspan="4"></th>
                <th colspan="3"><button className="tbs-primary" onClick={this.copyForecast}>Copy Base Forecast</button></th>
                <th colspan="3"><button className="tbs-primary" onClick={this.copyAnnualSales}>Copy Annual Sales Plan</button></th>
                <th colspan="3"><button className="tbs-primary" onClick={this.copyBottomUp}>Copy Bottom-up Estimate</button></th>
                
              </tr> */}
              <tr className="fixed-tb">
                <th colspan="3"></th>
                <th colspan="3">Forecasted Demand Estimate</th>
                <th colspan="3">Annual Sales Plan</th>
                <th colspan="3">Top-up Estimate</th>
                
              </tr>
            </thead>
            <tbody>
              <tr className="hd-table">
                <th>SKU <button onClick={()=>this.sortData("sku_desc")}>S</button></th>
                {/* <th>City</th> */}
                <th>Product Name <button onClick={()=>this.sortData("product_name")}>S</button></th>
                <th>Product Group <button onClick={()=>this.sortData("product_group")}>S</button></th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>
              </tr>
              {
                this.state.forecast.length > 0 ? 
                    this.state.forecast.map((data,index) => {
                        return(
                            <tr>
                                <td style={{textAlign: "left"}}>{data.sku_desc}</td>
                                {/* <td style={{textAlign: "left"}}>{data.location_name}</td> */}
                                <td style={{textAlign: "left"}}>{data.product_name}</td>
                                <td style={{textAlign: "left"}}>{data.product_group}</td>
                
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity1)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity2)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity3)}</td>
                
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity1)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity2)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity3)}</td>
                
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity1)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity2)}</td>
                                <td style={{textAlign: "right"}}>{usFormatter.format(data.quantity3)}</td>
                            </tr>
                        )
                    })
                :
                null
              }
              </tbody>
          </table>
          <table className="table table-bordered main-tb">
            <thead className="td-header">
              {/* <tr className="tb-buttons">
                <th colspan="3"><button className="tbs-primary" style={{opacity: "0"}}></button></th>
                <th><button className="tbs-primary" style={{opacity: "0"}}></button></th>
              </tr> */}
              <tr className="fixed-tb">
                <th colspan="3">Final Demand Estimate Plan</th>
                {/* <th>Remarks</th> */}
              </tr>
            </thead> 
            <tbody>
            <tr className="hd-table">
                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                {/* <th>-</th> */}
              </tr>
              {
                this.state.copyForecastData.length > 0 ? 
                    this.state.copyForecastData.map((data,index) => {
                        return(
                            <tr>
                                <td style={{textAlign: "right", backgroundColor: data.color1}}><input type="number" name="updated_quantity1" onChange={(e) => this.handleChange(e,index)} style={{textAlign: "right", backgroundColor: data.color1}} value={data.updated_quantity1.toString().length > 0 ? data.updated_quantity1 : ""} /></td>
                                <td style={{textAlign: "right", backgroundColor: data.color2}}><input type="number" name="updated_quantity2" onChange={(e) => this.handleChange(e,index)} style={{textAlign: "right", backgroundColor: data.color2}} value={data.updated_quantity2.toString().length > 0 ? data.updated_quantity2 : ""}  /></td>
                                <td style={{textAlign: "right", backgroundColor: data.color3}}><input type="number" name="updated_quantity3" onChange={(e) => this.handleChange(e,index)} style={{textAlign: "right", backgroundColor: data.color3}} value={data.updated_quantity3.toString().length > 0 ? data.updated_quantity3 : ""}  /></td>
                
                                {/* <td style={{textAlign: "left"}}><input type="text" name="remarks" onChange={(e) => this.handleChange(e,index)} style={{textAlign: "left"}} value={data.remarks == null || data.remarks.length > 0 ? data.remarks : ""}  /></td>    */}
                            </tr>
                        )
                    })
                :
                    this.state.forecast.map((data,index) => {
                        return(
                            <tr>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                
                                {/* <td>{"-"}</td>    */}
                            </tr>
                        )
                    })
              }
            </tbody>
          </table>
          <table className="table table-bordered main-tb">
            <thead className="td-header">
              {/* <tr className="tb-buttons">
                <th colspan="3"><button className="tbs-primary" style={{opacity: "0"}}></button></th>
                <th><button className="tbs-primary" style={{opacity: "0"}}></button></th>
              </tr> */}
              <tr className="fixed-tb">
                <th colspan="3">Variance %</th>
                {/* <th>Remarks</th> */}
              </tr>
            </thead> 
            <tbody>
            <tr className="hd-table">
                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                {/* <th>-</th> */}
              </tr>
              {
                this.state.copyForecastData.length > 0 ? 
                    this.state.copyForecastData.map((data,index) => {
                        return(
                            <tr>
                                <td>{data.variance1}</td>
                                <td>{data.variance2}</td>
                                <td>{data.variance3}</td>
                            </tr>
                        )
                    })
                :
                    this.state.forecast.map((data,index) => {
                        return(
                            <tr>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                
                                {/* <td>{"-"}</td>    */}
                            </tr>
                        )
                    })
              }
            </tbody>
          </table>
        </div>
        <div className="table-btns">
            <button style={this.state.disableSubmit || this.state.forecast.length == 0 ? {opacity: "0.6"} : null} disabled={this.state.disableSubmit || this.state.forecast.length == 0 ? true : false} onClick={this.handleReject} class="tbs-danger" data-toggle="modal" data-target="#myModal">Reject</button>
            <button style={this.state.disableSubmit || this.state.forecast.length == 0 ? {opacity: "0.6"} : null} disabled={this.state.disableSubmit || this.state.forecast.length == 0 ? true : false} onClick={this.handleApprove} class="tbs-submit" data-toggle="modal" data-target="#myModal">Approve</button>
        </div>
      </div>
    </div>
            </React.Fragment>
        )
    }
}
export default Sh;