import React from 'react'
import '../css/main.css'
import '../css/table.css'
import logo from '../img/logo.png'
import bell from '../img/bell.png'
import settings from '../img/setting-icon.png'
import user from '../img/user.png'
import close from '../img/close.svg'
import cheveron from '../img/cheveron.svg'
import axios from 'axios'
import Config from "../../../../config.json"

class Report extends React.Component {
    state = {
        forecast : [],
        annual_sales : {
            1 : [200,105,305],
            2 : [180,140,300],
            3 : [170,125,200],
            4 : [200,205,250],
            5 : [100,120,150]
        },
        bottom_up : {
            1 : [180,140,300],
            2 : [200,105,305],
            3 : [200,205,250],
            4 : [100,120,150],
            5 : [170,125,200]
            
        },
        editData : {
            1 : "",
            2 : "",
            3 : "",
            4 : "",
            5 : ""
        },
        showSideBar: false,
        dropDownList: ["Feb-21","Mar-21","Apr-21","May-21"],
        month: "Feb-21",
        dates: ["Mar-21","Apr-21","May-21"],
        copyActions: false,
        copyForecastData: [],
        user_id: 1001,
        user_details: {},
        disableSubmit: false,
        status: "",
        sku: "All",
        product: "All",
        disableCopyButtons: false,
        disableFilters: false,
        sort: "",
        sku_desc: false,
        product_name: false,
        product_group: false
    }

    showSideBar = () => {
        this.setState({showSideBar: true})
    }

    componentWillMount(){
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let STRAPI_URL = window.runtimeConfig && window.runtimeConfig.STRAPI_URL ? window.runtimeConfig.STRAPI_URL : Config.STRAPI_URL;
        // axios.get(`${STRAPI_URL}/tf-logins/1`).then((data)=>{
        //     console.log("555555555555555555555:",data)
            this.setState({user_id: "833cab50-7991-48ff-8bea-f2634e903b2b"})
            axios.get(`${URL}/asmdetails?user_id=833cab50-7991-48ff-8bea-f2634e903b2b`).then((data)=>{
                console.log("555555555555555555555:",data)
                this.setState({user_details: data.data})
                let res = data.data;
                if(res.process_flag == 'U' && res.status == 'U'){
                    this.setState({status: "New"})
                }else if(res.process_flag == 'U' && res.status == 'R'){
                    this.setState({status: "Rejected by ZSM", copyActions: true, disableCopyButtons: true})
                }
                axios.get(`${URL}/asmdata?month=${this.state.month}&sku_shortname=${this.state.sku}&product_group=${this.state.product}&location=${this.state.user_details.location_name}`).then((data)=>{
                    console.log("6666666666666666666:",data)
                    var res = data.data;
                    let copyData = res.map((res1)=>{
                        let copyForecastObj = {...res1};
                        copyForecastObj["quantity1"] = this.state.status == "New" ? res1.quantity1 : res1.updated_quantity1;
                        copyForecastObj["quantity2"] = this.state.status == "New" ? res1.quantity2 : res1.updated_quantity2;
                        copyForecastObj["quantity3"] = this.state.status == "New" ? res1.quantity3 : res1.updated_quantity3;
                        copyForecastObj["username"] = this.state.user_details.user_name;
                        copyForecastObj["color1"] = "lightgray";
                        copyForecastObj["color2"] = "lightgray";
                        copyForecastObj["color3"] = "lightgray";
                        return copyForecastObj;
                    })
                    this.setState({forecast: data.data, copyForecastData: copyData})
                    // axios.get(`${URL}/status?location=${this.state.user_details.location_name}`).then((data)=>{
                    //     console.log("6666666666666666666:",data)
                    //     let res = data.data;
                    //     if(res.process_flag == 'U' && res.status == 'U'){
                    //         this.setState({status: "New"})
                    //     }else if(res.process_flag == 'U' && res.status == 'R'){
                    //         this.setState({status: "Rejected by ZSM"})
                    //     }
                    // }).catch((err) => console.log("err:",err))
                }).catch((err) => console.log("err:",err))
            }).catch((err) => console.log("err:",err))
        // }).catch((err) => console.log("err:",err))
    }

    componentDidUpdate(prevProps, prevState){
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let newState = this.state;
        if(prevState.month != newState.month || prevState.sku != newState.sku || prevState.product != newState.product){
            axios.get(`${URL}/asmdata?month=${newState.month}&sku_shortname=${newState.sku}&product_group=${newState.product}&location=${this.state.user_details.location_name}`).then((data)=>{
                console.log("6666666666666666666666666666:",data)
                var res = data.data;
                    let copyData = res.map((res1)=>{
                        let copyForecastObj = {...res1};
                        copyForecastObj["quantity1"] = this.state.status == "New" ? res1.quantity1 : res1.updated_quantity1;
                        copyForecastObj["quantity2"] = this.state.status == "New" ? res1.quantity2 : res1.updated_quantity2;
                        copyForecastObj["quantity3"] = this.state.status == "New" ? res1.quantity3 : res1.updated_quantity3;
                        copyForecastObj["username"] = this.state.user_details.user_name;
                        copyForecastObj["color1"] = "lightgray";
                        copyForecastObj["color2"] = "lightgray";
                        copyForecastObj["color3"] = "lightgray";
                        return copyForecastObj;
                    })
                    this.setState({forecast: data.data, copyForecastData: copyData})
            }).catch((err) => console.log("err:",err))
        }
    }

    handleDropdown = (e) => {
        let dates = [];
        let {name,value} = e.target;
        if(name == "month"){
            console.log("6666:",name,value);
            // axios.get(`${URL}/asmdata?month=${value}&location=${this.state.user_details.location_name}`).then((data)=>{
            //     console.log("6666666666666666666666666666:",data)
            //     this.setState({forecast: data.data, copyActions: false})
            // }).catch((err) => console.log("err:",err))
            let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let reqMonth = value.split("-")[0];
            let evaluateMonth = months.includes(reqMonth);
            console.log("333333333:",evaluateMonth)
            if(evaluateMonth){
                let dates1 = new Date(`01-${value}`)
                let dates2 = new Date(`01-${value}`)
                let dates3 = new Date(`01-${value}`)
                console.log(dates1,dates2,dates3)
                let newDate1 = new Date(dates1.setMonth(dates1.getMonth()+1));
                let newDate2 = new Date(dates2.setMonth(dates2.getMonth()+2));
                let newDate3 = new Date(dates3.setMonth(dates3.getMonth()+3));
                //console.log(date1.getMonth(),date1.getFullYear());
                let date1 = `${months[newDate1.getMonth()]}-${newDate1.getFullYear().toString().substr(-2)}`;
                let date2 = `${months[newDate2.getMonth()]}-${newDate2.getFullYear().toString().substr(-2)}`;
                let date3 = `${months[newDate3.getMonth()]}-${newDate3.getFullYear().toString().substr(-2)}`;
                console.log(date1,date2,date3);
                dates = [date1,date2,date3];
                this.setState({dates})
            }
        }
        this.setState({[name]: value})
    }

    handleChange = (e,index) => {
        let { name, value } = e.target;
        let { dates } = this.state;
        console.log(e.target,e.target.month);
        let data = this.state.copyForecastData;
        let data1 = this.state.forecast;
        if(name == "remarks"){
            data[index][name] = value;
        }else{
            let subtract = parseFloat(value) - data1[index][name];
            let divide = subtract / parseFloat(value);
            let variance = divide * 100;
            console.log("subtract",subtract);
            console.log("divide",divide);
            console.log("variance",variance);
            let field = ""
            let colorField = ""
            // if(divide >= 0.15 || divide <= -0.15){
                // alert("Variance is greater than 15%. Please review your changes");
                let action = {};
                if(name == "quantity1"){
                    //data[index][dates[0]] = dates[0];
                    console.log(parseFloat(value) - data1[index][name]);
                    if(parseFloat(value) - data1[index][name] != parseFloat(value)){
                        action["quantity1"] = `${dates[0]}_update`
                        field = "variance1"
                        colorField = "color1"
                    }else{
                        action["quantity1"] = `${dates[0]}_insert`
                        field = "variance1"
                        colorField = "color1"
                    }
                }else if(name == "quantity2"){
                    //data[index][dates[0]] = dates[0];
                    console.log(parseFloat(value) - data1[index][name]);
                    if(parseFloat(value) - data1[index][name] != parseFloat(value)){
                        action["quantity2"] = `${dates[1]}_update`
                        field = "variance2"
                        colorField = "color2"
                    }else{
                        action["quantity2"] = `${dates[1]}_insert`
                        field = "variance2"
                        colorField = "color2"
                    }
                }else if(name == "quantity3"){
                    //data[index][dates[0]] = dates[0];
                    console.log(parseFloat(value) - data1[index][name]);
                    if(parseFloat(value) - data1[index][name] != parseFloat(value)){
                        action["quantity3"] = `${dates[2]}_update`
                        field = "variance3"
                        colorField = "color3"
                    }else{
                        action["quantity3"] = `${dates[2]}_insert`
                        field = "variance3"
                        colorField = "color3"
                    }
                }
                data[index][name] = parseFloat(value);
                if(variance > 15 || variance < -15){
                    data[index][colorField] = "orangered";
                }else{
                    data[index][colorField] = "white";
                }
                // data[index][field] = variance.toFixed(2);
                data[index][field] = Math.round((variance + Number.EPSILON) * 100) / 100;
                data[index]["action"] = data[index].hasOwnProperty('action') ? {...data[index]["action"], ...action} : action;
        }
        this.setState({copyForecastData: data})
    }

    copyForecast = () => {
        this.setState({"copyActions": true});
    }

    copyAnnualSales = () => {
        this.setState({"copyActions": true});
    }

    copyBottomUp = () => {
        this.setState({"copyActions": true});
    }

    handleSubmit = () => {
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        let { copyForecastData } = this.state;
        let submitData = [];
        let flag = false;
        for(var i=0; i<copyForecastData.length; ++i){
            if(copyForecastData[i].hasOwnProperty('action')){
                submitData.push(copyForecastData[i])
            }
            if(copyForecastData[i].variance1 > 15 || copyForecastData[i].variance1 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }else if(copyForecastData[i].variance2 > 15 || copyForecastData[i].variance2 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }else if(copyForecastData[i].variance3 > 15 || copyForecastData[i].variance3 < -15){
                flag = true;
                alert(`Variance is greater than 15% or less than -15% at ${copyForecastData[i].sku_desc}. Please review your changes`);
                break;
            }
        }
        console.log("submit data:",submitData)
        if(!flag){
            this.setState({disableSubmit: true, disableFilters: true, status: "Submitted"});
            console.log("666:",this.state.copyForecastData);
            this.props.send_message_to_bot({ text: "Submitted",payload: { showTitle: true, title: "Submitted" } })
            let data = axios.post(`${URL}/kpmg/asmreviseddata?user_id=${this.state.user_id}&location_name=${this.state.user_details.location_name}`,{
                data: submitData
            })
        }
    }

    sortData = (col) => {
        let URL = window.runtimeConfig && window.runtimeConfig.KPMG_API_URL ? window.runtimeConfig.KPMG_API_URL : Config.KPMG_API_URL;
        this.setState({[col]: !this.state[col], sort: col})
        let sortData = `${col}-${!this.state[col]}`
        axios.get(`${URL}/asmdata?month=${this.state.month}&sku_shortname=${this.state.sku}&product_group=${this.state.product}&location=${this.state.user_details.location_name}&sort=${sortData}`).then((data)=>{
            console.log("6666666666666666666666666666:",data)
            var res = data.data;
                let copyData = res.map((res1)=>{
                    let copyForecastObj = {...res1};
                    copyForecastObj["quantity1"] = this.state.status == "New" ? res1.quantity1 : res1.updated_quantity1;
                    copyForecastObj["quantity2"] = this.state.status == "New" ? res1.quantity2 : res1.updated_quantity2;
                    copyForecastObj["quantity3"] = this.state.status == "New" ? res1.quantity3 : res1.updated_quantity3;
                    copyForecastObj["username"] = this.state.user_details.user_name;
                    copyForecastObj["color1"] = "lightgray";
                    copyForecastObj["color2"] = "lightgray";
                    copyForecastObj["color3"] = "lightgray";
                    return copyForecastObj;
                })
                this.setState({forecast: data.data, copyForecastData: copyData})
        }).catch((err) => console.log("err:",err))
    }

    render() {
        console.log("4444444444444:",this.state);
        const usFormatter = new Intl.NumberFormat("en-US");
        return (
            <React.Fragment>
                <header>
        {/* <div className="top-header">
            <div className="container-fluid">
                <div className="top-flex">
                    <div className="logo-menu">
                        <div className="menu-btn" onClick={this.showSideBar}>
                            <span className="menu-ico"></span>
                            <span className="menu-ico"></span>
                            <span className="menu-ico"></span>
                        </div>
                        <div className="logo">
                            <img src={logo} alt=""/>
                        </div>
                    </div>
                    <div className="user-notify">
                        <div className="setting">
                            <img src={settings} alt=""/>
                        </div>
                        <div className="notify">
                            <img src={bell} alt=""/>
                        </div>
                        <div className="user-pr">
                            <div className="user-dt">
                                <p>{this.state.user_details.user_name}</p>
                                <span>{this.state.user_details.role_name}</span>
                            </div>
                            <img src={user} alt=""/>
                        </div>
                    </div>
                </div>
                {
                    this.state.showSideBar ? 
                    <div className="sidebar">
                        <div className="close-btn">
                            <img src={close} alt=""/>
                        </div>
                        <div className="main-navigation">
                            <ul className="nav-m">
                            <li><a >Home</a></li>
                            <li><a >Organisation Management </a></li>
                            <li><a >User Management</a></li>
                            <li><a >Access Management</a></li>
                            <li id="op-submenu">
                                <a >Modules <span className="cheveron"><img src={cheveron} alt=""/></span></a>
                                <ul className="submenu">
                                    <li><a >Demand Planning</a></li>
                                    <li><a >Supply Planning</a></li>
                                    <li><a >Dispatch Planning</a></li>
                                </ul>
                            </li>
                            <li><a >Dashboard & Analytics</a></li>
                            </ul>
                        </div>
                    </div>
                    : null
                }
            </div>
        </div> */}
        
        <div className="container-fluid">
            <div className="header-action">
                <div className="btn-flex">
                    <div className="button-box">
                        <label for="">Month</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="month" className="btn btn-primary dropdown-toggle" value={this.state.month} onChange={this.handleDropdown}>
                                {
                                    this.state.dropDownList.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    })
                                }
                            </select>
                            {/* <button className="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Mar 2021
                                <span className="caret"></span></button> */}
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">Org Level</label>
                        <div className="dropdown">
                            <button disabled={this.state.disableFilters ? true : false} className="btn btn-primary dropdown-toggle" type="button"
                                data-toggle="dropdown">{this.state.user_details.role_name}
                                <span className="caret"></span></button>
                            {/* <ul className="dropdown-menu">
                                <li><a >select</a></li>
                            </ul> */}
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">Location</label>
                        <div className="dropdown">
                            <button disabled={this.state.disableFilters ? true : false} className="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">{this.state.user_details.location_name}
                                <span className="caret"></span></button>
                            {/* <ul className="dropdown-menu">
                                <li><a >select</a></li>
                            </ul> */}
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">SKU Level</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="sku" className="btn btn-primary dropdown-toggle" value={this.state.sku} onChange={this.handleDropdown}>
                                {
                                    this.state.user_details.hasOwnProperty("sku_shortname") ?
                                    this.state.user_details.sku_shortname.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    }) : 
                                    null
                                }
                            </select>
                        </div>
                    </div>
                    <div className="button-box">
                        <label for="">Product Group</label>
                        <div className="dropdown">
                            <select disabled={this.state.disableFilters ? true : false} name="product" className="btn btn-primary dropdown-toggle" value={this.state.product} onChange={this.handleDropdown}>
                                {
                                    this.state.user_details.hasOwnProperty("product_group") ?
                                    this.state.user_details.product_group.map((val,index) => {
                                        return <option key={index} id={val} value={val} >{val}</option>
                                    }) : 
                                    null
                                }
                            </select>
                        </div>
                    </div>
                    {/* <div className="button-ud">
                        <button className="btn-download">Download</button>
                        <button className="btn-upload">Upload</button>
                    </div> */}
                </div>
                <div className="avat">
                    <div className="user-pr">
                        <div className="user-dt">
                            <p>{this.state.user_details.user_name}</p>
                            <span>{this.state.user_details.role_name}</span>
                        </div>
                        <img src={user} alt=""/>
                    </div>
                    <div className="text-flex">
                        {/* <p>Active Cycle : <strong>April 2020</strong></p> */}
                        <p>Submission Status: <span style={{color: "#fff", fontWeight: "bold"}}>{this.state.forecast.length > 0 ? this.state.status : "No Data Found"}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div className="content-wrapper">
      <div className="container-fluid">
        <div className="table-responsive">
          <table className="table table-bordered main-tb">
            <thead className="td-header">
              <tr className="tb-buttons">
                <th colspan="3"></th>
                <th colspan="3"><button className="tbs-primary" disabled={this.state.disableCopyButtons ? true : false} onClick={this.copyForecast}>Copy Base Forecast</button></th>
                <th colspan="3"><button className="tbs-primary" disabled={this.state.disableCopyButtons ? true : false} onClick={this.copyAnnualSales}>Copy Annual Sales Plan</button></th>
                <th colspan="3"><button className="tbs-primary" disabled={this.state.disableCopyButtons ? true : false} onClick={this.copyBottomUp}>Copy Bottom-up Estimate</button></th>
                
              </tr>
              <tr className="fixed-tbs">
                <th colspan="3"></th>
                <th colspan="3" style={{color: "#00338d"}}>Forecasted Demand Estimate</th>
                <th colspan="3" style={{color: "#00338d"}}>Annual Sales Plan</th>
                <th colspan="3" style={{color: "#00338d"}}>Bottom-up Estimate</th>
                
              </tr>
            </thead>
            <tbody>
              <tr className="hd-tables">
                <th>SKU </th>
                {/* <th>City</th> */}
                <th>Product Name </th>
                <th>Product Group </th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>
              </tr>
              {
                this.state.forecast.length > 0 ? 
                    this.state.forecast.map((data,index) => {
                        return(
                            <tr>
                                <td style={{textAlign: "left"}}>{data.sku_desc}</td>
                                {/* <td style={{textAlign: "left"}}>{data.location_name}</td> */}
                                <td style={{textAlign: "left"}}>{data.product_name}</td>
                                <td style={{textAlign: "left"}}>{data.product_group}</td>
                
                                <td style={{textAlign: "right"}}>{data.quantity1 == 0 ? data.quantity1.toFixed(2) : parseFloat(data.quantity1.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity2 == 0 ? data.quantity2.toFixed(2) : parseFloat(data.quantity2.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity3 == 0 ? data.quantity3.toFixed(2) : parseFloat(data.quantity3.toFixed(2)).toLocaleString('en-IN')}</td>
                
                                <td style={{textAlign: "right"}}>{data.quantity1 == 0 ? data.quantity1.toFixed(2) : parseFloat(data.quantity1.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity2 == 0 ? data.quantity2.toFixed(2) : parseFloat(data.quantity2.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity3 == 0 ? data.quantity3.toFixed(2) : parseFloat(data.quantity3.toFixed(2)).toLocaleString('en-IN')}</td>
                
                                <td style={{textAlign: "right"}}>{data.quantity1 == 0 ? data.quantity1.toFixed(2) : parseFloat(data.quantity1.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity2 == 0 ? data.quantity2.toFixed(2) : parseFloat(data.quantity2.toFixed(2)).toLocaleString('en-IN')}</td>
                                <td style={{textAlign: "right"}}>{data.quantity3 == 0 ? data.quantity3.toFixed(2) : parseFloat(data.quantity3.toFixed(2)).toLocaleString('en-IN')}</td>
                            </tr>
                        )
                    })
                :
                null
              }
              </tbody>
          </table>
          <table className="table table-bordered main-tb">
            <thead className="td-header">
              <tr className="tb-buttons">
                <th colspan="3"><button className="tbs-primary" style={{opacity: "0"}}></button></th>
                <th><button className="tbs-primary" style={{opacity: "0"}}></button></th>
              </tr>
              <tr className="fixed-tbs">
                <th colspan="3">Final Demand Estimate Plan</th>
                <th>Remarks</th>
              </tr>
            </thead> 
            <tbody>
            <tr className="hd-tables">
                <th>{this.state.dates[0]}</th>
                <th>{this.state.dates[1]}</th>
                <th>{this.state.dates[2]}</th>

                <th>-</th>
              </tr>
              {
                this.state.copyForecastData.length > 0 ? 
                    this.state.copyForecastData.map((data,index) => {
                        return(
                            <tr>
                                <td style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color1} : {textAlign: "right"}}><input type="number" name="quantity1" onChange={(e) => this.handleChange(e,index)} style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color1} : {textAlign: "right"}} value={data.quantity1.toString().length > 0 && this.state.copyActions ? data.quantity1 : ""} /></td>
                                <td style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color2} : {textAlign: "right"}}><input type="number" name="quantity2" onChange={(e) => this.handleChange(e,index)} style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color2} : {textAlign: "right"}} value={data.quantity2.toString().length > 0 && this.state.copyActions ? data.quantity2 : ""}  /></td>
                                <td style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color3} : {textAlign: "right"}}><input type="number" name="quantity3" onChange={(e) => this.handleChange(e,index)} style={this.state.copyActions ? {textAlign: "right", backgroundColor: data.color3} : {textAlign: "right"}} value={data.quantity3.toString().length > 0 && this.state.copyActions ? data.quantity3 : ""}  /></td>
                
                                <td style={{textAlign: "left"}}><input type="text" name="remarks" onChange={(e) => this.handleChange(e,index)} style={{textAlign: "left"}} value={data.remarks == null || data.remarks.length > 0 && this.state.copyActions ? data.remarks : ""}  /></td>   
                            </tr>
                        )
                    })
                :
                    this.state.forecast.map((data,index) => {
                        return(
                            <tr>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                                <td>{"-"}</td>
                
                                <td>{"-"}</td>   
                            </tr>
                        )
                    })
              }
            </tbody>
          </table>
        </div>
        <div className="table-btns">
          <button className="tbs-submit" style={this.state.disableSubmit || this.state.forecast.length == 0 ? {opacity: "0.6"} : null} disabled={this.state.disableSubmit || this.state.forecast.length == 0 ? true : false} onClick={this.handleSubmit}>Submit</button>
        </div>
      </div>
    </div>
            </React.Fragment>
        )
    }
}
export default Report;