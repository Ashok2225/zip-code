import React from 'react'
import Zsm from './Zsm'

class App extends React.Component {
    render() {
        return (
            <>
                <Zsm user={this.props.user} send_message_to_bot={this.props.send_message_to_bot} />
            </>
        )
    }
}
 export default App;
