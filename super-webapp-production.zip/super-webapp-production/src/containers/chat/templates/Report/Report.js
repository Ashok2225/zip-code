import React from 'react'
import Asm from './Asm'
import Zsm from './Zsm'
import Sh from './Sh'

function Report(props){
    console.log("444444444444444444444444",props)
    let { content } = props.props;
    let role;
    if(content.items.length>0){
        role = content.items[0].title;
    }
    return(
        <div>
            {role == "asm" ? <Asm selectedOption={props.selectedOption} send_message_to_bot={props.send_message_to_bot} user={props.user}/> : null}
            {role == "zsm" ? <Zsm selectedOption={props.selectedOption} send_message_to_bot={props.send_message_to_bot} user={props.user}/> : null}
            {role == "sh" ? <Sh selectedOption={props.selectedOption} send_message_to_bot={props.send_message_to_bot} user={props.user}/> : null}
        </div>
    )
}

export default Report;