import React from 'react';
import { getKeycloackRefreshToken } from "../../../redux/actions/auth"

class Textfield extends React.Component {
  constructor() {
    super()
    this.state={
      //phonecode:''
    }
  }
  handleChange = (event,type) => {
       event.preventDefault();
       this.setState({
           [event.target.name]: {
             val:event.target.value,
             type:type
           }
       })
   }

   phoneCodeChange=(e)=>{
    // event.preventDefault();
    const re = /[0-9 +]+$/;
    if (e.target.value==''||re.test(e.target.value)) {
       this.setState({phonecode: e.target.value})
    }
   }

   componentDidMount(){
    let {content} = this.props.props;
      if(this.props.isLast){
          //  document.getElementById('footer_Input').style.display = "none"
    }
    content.items.map((item, index) => (
      this.setState({ [item.value]: '' })
      )
    )
   }

   // KeyEvents = (event) => {
   //     if (event.key === "Enter") {
   //         this.props.send_message_to_bot({ text: JSON.stringify(this.state), payload: { showTitle: true, title: 'Details Submitted' } })
   //     }
   // }

   componentWillMount() {
       let {content} = this.props.props
       content.items.map((item, index) => (
           this.setState({ [item.value]: {} })
       ))
   }

   onClick = async () => {
     let flag = true;
     for (let [key, value] of Object.entries(this.state)) {
       var spaceValidate = ((key == "phonecode") || (value < 1)) ? value.split(" ").join("") : value.val.split(" ").join("")
          if((key !='phonecode' &&  (Object.keys(value).length == 0 || value.val.length<1)) || spaceValidate.length == 0){
            alert("Please fill out the form completely")
            flag = false;
            break;
          }
           if(value.type==='email'){
            let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
            if(!reg.test(value.val))
            {
              alert("Please enter valid mail")
              flag = false;
              break;
            }
          }else if(value.type=='phone'){
            // let reg=/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im
            // (123) 456-7890
            // (123)456-7890
            // 123-456-7890
            // 123.456.7890
            // 1234567890
            // +31636363634
            // 075-63546725

            let valInt = parseInt(value.val)
            if(value.val == valInt){
              if(!(value.val.length == 10 || value.val.length == 11)){
                alert("Please enter valid mobile number")
                flag = false;
                  break;
              }
            }else {
                alert("Please enter valid mobile number")
                flag = false;
                  break;
            }
        } else if(value.type=='text') {
          if(value.val.length>0){
          }
          else {
            alert(`Please fill out the form completely`)
            flag = false;
              break;
          }
        }
    }
      if(flag){
        let stateData = this.state
        let response = {}
        delete stateData.phonecode;
        for (let [key, value] of Object.entries(stateData)) {
          if(value && value.type){
            response[key] = value.val
          }
        }
        this.setState({disable: true})
        let _message = { text: JSON.stringify(this.state), payload: { showTitle: true, title: 'Submitted' } }
        this.props.send_message_to_bot(_message)
        _message = window.chatSocket.finalPayload(_message, false, await getKeycloackRefreshToken())            
        this.props.setMessage(_message)
        window.chatSocket.conn.send(_message)
        //document.getElementById('footer_Input').style.display = "block" ;
      }
   }

  render(){
    let {content} = this.props.props;
    let selectedOption  = undefined
          if(this.props.selectedOption) {
            try{
              selectedOption = JSON.parse(this.props.selectedOption)
            }catch(e){

              selectedOption = this.props.selectedOption
            }
          }
    return(
          <div className="row text-left no_margin component_box">
							<div className="col-xs-1 align-top no_padding">
							  {/* <img src={require("../images/bot_logo.png")} alt="Bot Image" className="bot_img" /> */}
							</div>
							<div className="col-xs-10 align-top no_padding bot_chat">
								<div className="input card">
									<ul className="list-group list-group-flush text-center">
										<li className="list-group-item">
											<form action="#" method="post" className="form_box text-left" autocomplete="off">
                      {
                            content.items.map((item, index) => {

                                if (item.type === 'text') {
                                    return(
                                      <div className="form-group" key={index}>
              													{/*<label htmlFor="key">{item.title}</label>
                                        <span style={{color:'red'}}>  *</span>*/}
                                        <label htmlFor="key">{item.title}</label>
              													<input type={item.type}
                                            className="form-control"
                                            id="key"
                                            name={item.value}
                                            disabled={selectedOption || this.state.disable ? true : false}
                                            value = {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].val : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])) : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])}
                                            key= {index} require="true"
                                            onChange={(e)=>this.handleChange(e,item.type)}
                                          />
              												</div>
                                    )
                                }else if(item.type == 'email'){
                                  return(
                                    <div className="form-group" key={index}>
                                      {/*<label htmlFor="key">{item.title}</label>
                                      <span style={{color:'red'}}>  *</span>*/}
                                      <label htmlFor="key">{item.title}</label>
                                      <input type={item.type}
                                          className="form-control"
                                          id="key"
                                          name={item.value}
                                          disabled={selectedOption || this.state.disable ? true : false}
                                          value = {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].val : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])) : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])}
                                          key= {index}
                                          onChange={(e)=>this.handleChange(e,item.type)}
                                          />
                                    </div>
                                  )}else if(item.type == 'phone'){
                                  return(
                                    <div className="form-group" key={index}>
                                      {/*<label htmlFor="key">{item.title}</label>
                                      <span style={{color:'red'}}>  *</span>*/}
                                      <label htmlFor="key">{item.title}</label>
                                      <input   type="text" name="phoneCode"
                                          className="form-control"
                                          style={{width:"30%"}}
                                          name = 'phonecode'
                                          value = {this.state.phonecode}
                                          disabled={selectedOption || this.state.disable ? true : false}
                                          onChange={this.phoneCodeChange}
                                          placeholder="+000"  />
                                      <input type={item.type} style={{width:"66%", float: "right", marginTop: "-34px"}}
                                          className="form-control"
                                          id="key" placeholder = "9999999999"
                                          name={item.value}
                                          value = {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].val : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])) : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])}
                                          key= {index}
                                          disabled={selectedOption || this.state.disable ? true : false}
                                          onChange={(e)=>this.handleChange(e,item.type)}
                                        />
                                    </div>
                                  )}
                                return(
                                 <div className="form-group" key={index}>
                                    {/*<label htmlFor="key">{item.title}</label>
                                    <span style={{color:'red'}}>  *</span>*/}
                                    <label htmlFor="key">{item.title}</label>
                                    <input type={item.type}
                                        className="form-control"
                                        id="key"
                                        name={item.value}
                                        value = {selectedOption ? (selectedOption[item.value] ? selectedOption[item.value].val : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])) : ((typeof this.state[item.value]) == 'object'?this.state[item.value].val:this.state[item.value])}
                                        key= {index}
                                        disabled={selectedOption || this.state.disable ? true : false}
                                        onChange={(e)=>this.handleChange(e,item.type)}
                                      />
                                    </div>
                                )
                            })

                        }
											</form>
										</li>
                    <li className="list-group-item filled" onClick={this.onClick}>
                    {
                        content.buttons.map((button, index) => {
                          if(!this.state.disable){
                            if (button.value && (selectedOption == undefined)) {
                                return (
                                        <a style={{color: "#ffffff"}} >
                                             {button.value}
                                        </a>

                                )
                            }
                          }  
                        })
                    }
                    </li>

									</ul>
								</div>
							</div>
						</div>

    )
  }
}

export default Textfield;
