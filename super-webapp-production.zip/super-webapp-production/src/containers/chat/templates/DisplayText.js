import React from 'react'
import bot_logo from '../../../images/chat-avt.png'

class Displaytext extends React.Component {
  constructor(props) {
    super(props)
  }

  textModify = (text) => {
    var urlRegex = /(https?:\/\/[^\s]+)|(http?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return url.includes('.gif' || '.GIF') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
            (url.includes('.png' || '.PNG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                (url.includes('.jpg' || '.JPG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                    (url.includes('.jpeg' || '.JPEG') ? `<a href=${url.replace('<br>','')} target="_blank"><img src=${url.replace('<br>','')} alt="" /></a>` :
                        (url.includes('.mp4' || '.MP4') ? `<video id="chat_bot_video" width="100%" height="100%" controls> <source src=${url.replace('<br>','')} type="video/mp4"></video>` :
                            url.includes('.xlsx' || '.XLSX') ? `<embed src="http://35.244.41.29:1337/uploads/2uploads/dcb088a711984eba8e7ec664b06f3db3.xlsx"  height="230" width="500" />` : `<a href=${url.replace('<br>','')} target="_blank">${url.replace('<br>','')}</a>`))))
    })
  }

  render(){
    let data = this.props.props.content.items[0].displaytext;
    let name = this.props.props.content.items[0].displayname;
    let value = this.props.props.content.items[0].displayvalue;
    return(
      <div className="chat-message bot-mode">
        <div className="chat-bot-message-box">
          <img src={bot_logo} className="chat-bot-message-logo" />
            <div className="related-msg">
              {name != null ? <div style={{textAlign: "right", fontSize: "10px"}}>
                <button className="related-button">{name}</button> <br/>
              </div> : <div style={{marginTop: "19px"}}></div>}
              <div
                  dangerouslySetInnerHTML={{ __html: this.textModify(data) }} 
              ></div>
              {/* <span className="related-text">{name}</span><br/>
              <span className="related-desc">{data}</span> */}
            </div>
        </div>
      </div>
  )
  }
}

export default Displaytext;
