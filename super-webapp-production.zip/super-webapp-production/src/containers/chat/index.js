import React, { Component } from "react";
import { connect } from "react-redux";

import backArrow from "../../images/back-arrow.png";
import smileicon from "../../images/smile.png";
import submitwhiteicon from "../../images/submit-white.png";
import bot_logo from "../../images/chat-avt.png";
import user_logo from "../../images/chat-user.png";
import refreshIcon from "../chat/images/refresh.png";
import micicon from "../../images/mic-icon.png";

import ReactTooltip from "react-tooltip";
import Card from "./templates/Card";
import InputCard from "./templates/InputCard";
import Carousel from "./templates/Carousel";
import Calendar from "./templates/Calendar";
import Download from "./templates/Download";
import DatePicker from "./templates/DatePicker";
import ListView from "./templates/ListView";
import Receipt from "./templates/Receipt";
import MyLeaves from "./templates/MyLeaves";
import Invoice from "./templates/Invoice";
import QandA from "./templates/Q&A";
import ContactUS from "./templates/ContactUS";
import Login from "./templates/Login";
import FormWidget from "./templates/Form/Form";
// import FormBuild from "./templates/FormBuild/FormBuild"
import TextFields from "./templates/Textfield";
import LikeAndDislike from "./templates/LikeDislike";
import DisplayText from "./templates/DisplayText";
import Upload from "./templates/Upload";
import Report from "./templates/Report/Report";
import Loader from "../../components/loader";

import { setMessage, clearMessages } from "../../redux/actions/chatActions";
import { getKeycloackRefreshToken } from "../../redux/actions/auth";

class Chat extends Component {
  constructor(props) {
    super(props);
    this.state = {
      context: null,
      height: "calc(100vh - 60px)",
      width: "100%",
      padding: "0px 10px",
      backgroundColor: "#f2f5f6",
      active_form_payload: null,
      query: "",
      defaultInputPlaceHolder: "Please ask your question",
      inputPlaceHolder: "Please ask your question",
    };
  }

  componentDidMount() {
    this.setContext();
    this.setStyle();
  }

  setContext = () => {
    let url = window.location.pathname;
    let context = url.split("/dashboard")[1];
    this.setState({ context });
  };

  setupChatHistory = () => {
    const { ready, historyLoaded } = this.props.chatReducer;
    if (ready & !historyLoaded) {
      setTimeout(() => {
        window.chatSocket.loadHistory();
      }, 1000);
    }
  };

  componentDidUpdate() {
    if (this.props.showHistory) {
      this.setupChatHistory();
    }
  }

  componentWillUnmount() {
    this.props.clearMessages();
  }

  setStyle = () => {
    const { height, width, backgroundColor } = this.props;
    if (height && width && backgroundColor) {
      this.setState({ height, width, backgroundColor });
    }
  };

  setQuery = (e) => {
    this.setState({ query: e.target.value });
  };

  speechToText = () => {
    let { defaultInputPlaceHolder } = this.state;
    var SpeechRecognition = SpeechRecognition || window.webkitSpeechRecognition;
    var recognition = new SpeechRecognition();
    recognition.onstart = () => {
      this.setState({ inputPlaceHolder: "Listening ...", query: "" });
    };

    recognition.onspeechend = () => {
      this.setState({ inputPlaceHolder: "Thinking ..." });
      recognition.stop();
    };
    recognition.onresult = (event) => {
      var transcript = event.results[0][0].transcript;
      console.log("[SPEECH_RECOGNIZE]", transcript);
      this.setState({
        inputPlaceHolder: defaultInputPlaceHolder,
        query: transcript,
      });
      this.handleKeyDown({ key: "Enter" });
    };
    recognition.start();
  };

  handleKeyDown = (e) => {
    if (e.key === "Enter") {
      let { query, context } = this.state;
      let shouldStartOver = context === "search";
      let needRasa = context === "search";
      this.sendMessage(query, needRasa, shouldStartOver);
      this.setState({ query: "" });
    }
  };

  sendMessage = async (message, rasa = false, startOver = false) => {
    let _message = { text: message, start_over: startOver };
    _message = window.chatSocket.finalPayload(
      _message,
      rasa ? false : true,
      await getKeycloackRefreshToken(),
      message
    );
    this.props.setMessage(_message);
    window.chatSocket.conn.send(_message);
  };

  send_message_to_bot = async (message, carousel = false) => {
    message.datetime = new Date();
    let { messages, chatHistory } = this.props.chatReducer;
    if (messages.length > 0) {
      messages[0]["selectedOption"] = message.text;
      if (carousel) return;
      window.chatSocket.conn.send(JSON.stringify(messages[0]));
    } else if (chatHistory.length > 0) {
      chatHistory[0]["selectedOption"] = message.text;
      if (carousel) return;
      window.chatSocket.conn.send(JSON.stringify(chatHistory[0]));
    }
    // this.state.active_form_payload["selectedOption"] = message.text;
    // let finalPayload = window.chatSocket.finalPayload(message, true, await getKeycloackRefreshToken());
    // window.chatSocket.conn.send(finalPayload)
    this.state.active_form_payload = undefined;
  };

  wrapBotTemplate = (template, index, today = new Date()) => {
    today = today.localTimestamp ? new Date(today.localTimestamp) : new Date();
    let date_string =
      today.toLocaleDateString("en-IN") +
      " " +
      today.toLocaleTimeString("en-IN");
    return (
      <div key={index} className="chat-message">
        <div className="chat-bot-message-widget">
          {template}
          {/* <span className="chat-bot-message-time-widget">
            {date_string}
          </span> */}
        </div>
      </div>
    );
  };

  renderTemplate = (message, index, make_as_active = true) => {
    switch (message.attachmentLayout) {
      case "card":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Card
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "calendar":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Calendar
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "inputcard":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <InputCard
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "listview":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <ListView
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "download":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Download
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].content.items}
            selectedOption={message.selectedOption}
            setMessage={this.props.setMessage}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "datepicker":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <DatePicker
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "receipt":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Receipt
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0].payload}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "carousel":
        if (make_as_active) this.state.active_form_payload = message;
        return (
          <Carousel
            send_message_to_bot={this.send_message_to_bot}
            selectedOption={message.selectedOption}
            key={index}
            props={message.attachments}
          />
        );

      case "Report":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Report
            user={this.props.user}
            send_message_to_bot={this.send_message_to_bot}
            user={this.props.user}
            key={index}
            props={message.attachments[0]}
            selectedOption={message.selectedOption}
            isLast={message.isLast}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "MyLeaves":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <MyLeaves
            send_message_to_bot={this.send_message_to_bot}
            props={message.attachments[0].payload.leaves}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "invoice":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Invoice
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0]}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "contactus":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <ContactUS
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0]}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "Q&A":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <QandA
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments}
            isLast={message.isLast}
            selectedOption={message.selectedOption}
            setMessage={this.props.setMessage}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "login":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Login
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments}
            isLast={message.isLast}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "form":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <FormWidget
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments}
            selectedOption={message.selectedOption}
            index={index}
            isLast={message.isLast}
            setMessage={this.props.setMessage}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      // case "formtemplate":
      //   if(make_as_active) this.state.active_form_payload = message
      //   return this.wrapBotTemplate( <FormBuild send_message_to_bot={this.send_message_to_bot}  key={index} props = {message.attachments} selectedOption={message.selectedOption} index = {index}  isLast = {message.isLast} />, index, message.localTimestamp ? message.localTimestamp: new Date())

      case "textfields":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <TextFields
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0]}
            selectedOption={message.selectedOption}
            isLast={message.isLast}
            setMessage={this.props.setMessage}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "likeanddislike":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <LikeAndDislike
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0]}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "displaytext":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <DisplayText
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments[0]}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      case "upload":
        if (make_as_active) this.state.active_form_payload = message;
        return this.wrapBotTemplate(
          <Upload
            send_message_to_bot={this.send_message_to_bot}
            key={index}
            props={message.attachments}
            selectedOption={message.selectedOption}
            setMessage={this.props.setMessage}
          />,
          index,
          message.localTimestamp ? message.localTimestamp : new Date()
        );

      default:
        return this.renderTextMessages(message, index);
    }
  };

  textModify = (text) => {
    var urlRegex = /(https?:\/\/[^\s]+)|(http?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
      return url.includes(".gif" || ".GIF")
        ? `<a href=${url.replace(
            "<br>",
            ""
          )} target="_blank"><img src=${url.replace("<br>", "")} alt="" /></a>`
        : url.includes(".png" || ".PNG")
        ? `<a href=${url.replace(
            "<br>",
            ""
          )} target="_blank"><img src=${url.replace("<br>", "")} alt="" /></a>`
        : url.includes(".jpg" || ".JPG")
        ? `<a href=${url.replace(
            "<br>",
            ""
          )} target="_blank"><img src=${url.replace("<br>", "")} alt="" /></a>`
        : url.includes(".jpeg" || ".JPEG")
        ? `<a href=${url.replace(
            "<br>",
            ""
          )} target="_blank"><img src=${url.replace("<br>", "")} alt="" /></a>`
        : url.includes(".mp4" || ".MP4")
        ? `<video id="chat_bot_video" width="100%" height="100%" controls> <source src=${url.replace(
            "<br>",
            ""
          )} type="video/mp4"></video>`
        : url.includes(".xlsx" || ".XLSX")
        ? `<embed src="http://35.244.41.29:1337/uploads/2uploads/dcb088a711984eba8e7ec664b06f3db3.xlsx"  height="230" width="500" />`
        : `<a href=${url.replace("<br>", "")} target="_blank">${url.replace(
            "<br>",
            ""
          )}</a>`;
    });
  };

  renderTextMessages = (message, index) => {
    let today = message.localTimestamp
      ? new Date(message.localTimestamp)
      : new Date();
    let date_string =
      today.toLocaleDateString("en-IN") +
      " " +
      today.toLocaleTimeString("en-IN");
    if (
      message.speech ||
      message.type === "typing" ||
      message.new_user ||
      message.type === "endOfConversation" ||
      message.text === "I didn't understand. Please try again."
    ) {
      return null;
    }
    if (message.isBot == false) {
      return (
        <div>
          <div key={index} className="chat-message" style={{}}>
            <div
              style={{
                float: "right",
                marginLeft: "auto",
                order: "2",
                display: "flex",
              }}
            >
              <div className="chat-user-message">
                {message.payload && message.payload.showTitle
                  ? message.payload.title
                  : message.text}
              </div>
              <span style={{ marginLeft: "8px" }}>
                <img
                  src={user_logo}
                  className="chat-bot-message-logo"
                  alt="user-logo"
                />
              </span>
            </div>
          </div>
          <div
            className="chat-user-message-time"
            align="right"
            style={{ marginRight: 70 }}
          >
            {date_string}
          </div>
        </div>
      );
    } else {
      if (message.suggestedActions) {
        let quickReplies = message.suggestedActions.actions;
        return (
          <div>
            <div
              key={index}
              className="chat-message bot-mode"
              style={{ width: "70%" }}
            >
              <div className="chat-bot-message-box">
                <img
                  src={bot_logo}
                  className="chat-bot-message-logo"
                  alt="bot-logo"
                />
                <div
                  dangerouslySetInnerHTML={{
                    __html: this.textModify(message.text),
                  }}
                  className="chat-bot-message"
                ></div>
              </div>
            </div>
            <div>
              <div className="col-xs-8 chat-btn-group align-top no_padding bot_chat">
                {quickReplies.map((item, index) => {
                  return (
                    <a>
                      <button
                        onClick={() => this.sendMessage(item.value)}
                        type="button"
                        style={{ flexWrap: "nowrap", overflowX: "auto" }}
                        className="btn burgerBtn button_box  text-center"
                      >
                        {item.title}
                      </button>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        );
      } else {
        return (
          <div
            key={index}
            className="chat-message bot-mode"
            style={{ width: "70%" }}
          >
            <div className="chat-bot-message-box">
              <img
                src={bot_logo}
                className="chat-bot-message-logo"
                alt="bot-logo"
              />
              <div
                dangerouslySetInnerHTML={{
                  __html: this.textModify(message.text),
                }}
                className="chat-bot-message"
              ></div>
            </div>
            <div
              style={{ marginLeft: "70px" }}
              className="chat-bot-message-time"
            >
              {date_string}
            </div>
          </div>
        );
      }
    }
  };

  renderMessages = (messages, loadHistory = false) => {
    return messages.map((message, i) => {
      if (loadHistory) {
        let len = messages.length - 1;
        if (
          ["form", "textfields", "Q&A", "upload"].includes(
            message.attachmentLayout
          ) &&
          message.selectedOption == undefined &&
          i != 0
        )
          return;
      }
      return (
        <div key={i} className="renderChatMessage">
          {this.renderTemplate(message, i)}
        </div>
      );
    });
  };

  render() {
    const { inputPlaceHolder, query } = this.state;
    const { chatHistory, messages, ready } = this.props.chatReducer;

    return (
      <div className="chat-text">
        {!ready ? (
          <>
            <Loader
              styles={{ width: "80px", margin: "auto" }}
              root={{ display: "flex" }}
            />
          </>
        ) : (
          <div className="scrollable chat-block-scroll">
            {this.renderMessages(messages)}
            {this.renderMessages(chatHistory, true)}
          </div>
        )}
        <div
          className="chat-input-box"
          style={
            !ready
              ? { flex: 0.1, marginTop: "-85px" }
              : { flex: 0.1, marginTop: "10px" }
          }
        >
          <div className="chat-textbox">
            <div className="mic-attach">
              <div style={{ marginLeft: "10px" }} className="mic-ico">
                <img src={micicon} alt="" onClick={this.speechToText} />
              </div>
              {this.props.showStartOver ? (
                <div
                  onClick={this.props.startOver}
                  className="mic-ico"
                  data-tip
                  data-for="create"
                >
                  <img src={refreshIcon} alt="" />
                  <ReactTooltip
                    id="create"
                    type="error"
                    backgroundColor="black"
                  >
                    <span>Start over</span>
                  </ReactTooltip>
                </div>
              ) : null}
              {/* <div className="attach-ico">
                Fileupload Component here
              </div> */}
            </div>
            <div className="input-block">
              <input
                type="text"
                autoComplete="off"
                className="chat-input"
                placeholder={inputPlaceHolder}
                name="current_message"
                value={query}
                onChange={(e) => {
                  this.setQuery(e);
                }}
                onKeyDown={(e) => {
                  this.handleKeyDown(e);
                }}
              />
            </div>
            <div className="smile-submit">
              <div className="smile-ico">
                <img src={smileicon} alt="" />
              </div>
              <button onClick={(e) => {}}>
                Send <img src={submitwhiteicon} alt="" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Chat.defaultProps = {
  showHistory: true,
  showStartOver: true,
};

const mapStateToProps = (state) => ({
  chatReducer: state.chatReducer,
});

export default connect(mapStateToProps, {
  setMessage,
  clearMessages,
})(Chat);
