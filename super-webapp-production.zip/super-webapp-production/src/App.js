import React, { Component } from "react";
import { connect } from "react-redux";
import $ from "jquery";
import { Switch, Route, Redirect } from "react-router-dom";
import DashboardContainer from "./containers/dashboard";
import axios from "axios";

import { setCurrentUser, acceptInvite } from "./redux/actions/user";
import {
  setIncommingMessage,
  setReadyState,
} from "./redux/actions/chatActions";

import { SocketManager } from "./ws";
import "./css/app.css";
import "./css/training.css";
import "./css/responsive.css";

import logo from "./images/fevicon.png";
import modalArt from "./images/modal-art.png";

import Settings from "./containers/dashboard/Settings";
import MyProfileSetting from "./containers/dashboard/Settings/components/MyProfileSetting";
// import Notifications from "./containers/dashboard/Notifications";
import OrganisationSetting from "./containers/dashboard/Settings/components/OrganisationSetting";
import Device from "./containers/dashboard/Settings/components/MyProfileSetting/components/Device";
import OrganisationProfile from "./containers/dashboard/Settings/components/OrganisationSetting/components/Organisation-Profile";
import OrganisationTeam from "./containers/dashboard/Settings/components/OrganisationSetting/components/OrganisationTeam";
import OrganisationPeople from "./containers/dashboard/Settings/components/OrganisationSetting/components/OrganisationPeople";
import ProfileTeam from "./containers/dashboard/Settings/components/Profile/ProfileTeam";
import ProfilePeople from "./containers/dashboard/Settings/components/Profile/ProfilePeople";
import NavBar from "./components/navbarGlobal";
import { getKeycloackToken } from "./redux/actions/auth";
import OrganizationCategories from "./containers/dashboard/Settings/components/OrganisationSetting/components/Organization-Categories";
import {
  loadNotifications,
  setNotificationMessage,
  changeMode,
} from "./redux/actions/appActions";
import Notifications from "./components/notifications";
import Snacks from "./components/snacks";

import Sidebar from "./components/sidebarGlobal";
import ActionLibrary from "./containers/dashboard/CreateTemplateStudio/components/ActionLibrary";
import TemplateMapper from "./containers/dashboard/CreateTemplateStudio/components/TemplateMapper";
import InviteModal from "./containers/dashboard/CreateTemplate/InviteModal";

// import * as Sentry from "@sentry/react";
// import { Integrations } from "@sentry/tracing";

// Sentry.init({
//   dsn: "https://3c72106ff7ea40dbbcc569df6163f895@o1122122.ingest.sentry.io/6159452",
//   integrations: [new Integrations.BrowserTracing()],
//   tracesSampleRate: 1.0,
// });

var lt = 1;
var gt = 0;
var limit = 0;
export class App extends Component {
  constructor() {
    super();
    this.state = {
      selectedArea: "",
      notified: 0,
      minMode: false,
    };
  }
  changeMode= () => {
    const mode = this.props?.appReducer?.minMode? false : true
    this.props.changeMode(mode)
  };


  enableNotifyTab = (main) => {
    $("#notify-tab").on("click", () => {
      // $('.user-tabs li').removeClass('active');
      // $('.notify-list').addClass('active');
      // $('.user-tab-pane').removeClass('in active');
      // $('#notification').addClass('in active');
      $(".user-pr").addClass("active-sd");
      $(".overlay").addClass("active-ol");
    });
    $(".overlay").on("click", function () {
      $(".user-pr").removeClass("active-sd");
      $(this).removeClass("active-ol");
    });
    if (main) {
      this.props.setNotificationMessage({ data: "0" });
      this.props.loadNotifications(this.props.user);
    }
  };

  connectSocket = (user) => {
    let uuid = user.sub;
    let metadata = `$$metadata$$ ${uuid}`;
    let req_his = `$$req_his$$ lt=>${lt}$$gt=>${gt}`;
    let sendDefault = [metadata, req_his];
    lt--;
    gt--;
    let socketConfig = {
      url: process.env.REACT_APP_CHM_WS_URL,
      uuid: uuid,
      sendDefault: sendDefault,
      user: user,
      onMessage: this.props.setIncommingMessage,
      onReadyState: this.props.setReadyState,
    };
    let socket = new SocketManager(socketConfig);
    return socket;
  };

  notifyConnectSocket = async (user) => {
    let uuid = user.sub;
    let token = await getKeycloackToken();
    let socketConfig = {
      url: `${process.env.REACT_APP_SUPERAPP_API_SOCKCET_URL}/botapi/webapp`,
      uuid: uuid,
      user: user,
      onMessage: this.props.setNotificationMessage,
      onReadyState: () => console.log("Notification Socket Ready"),
      token: btoa(token),
    };
    let notifysocket = new SocketManager(socketConfig);
    window.notifyConnectSocket = notifysocket;
    notifysocket.init(() => {
      console.log("Connecting Notifications WS");
    });
    // return notifysocket;
  };

  trackActivity = () => {
    setTimeout(() => {
      document.addEventListener("click", () => {
        window?.chrome?.runtime?.sendMessage(
          process.env.REACT_APP_CHROME_TAB_ID,
          {
            type: "userActivity",
          }
        );
      });
    }, 5000);
  };

  componentDidMount() {
    this.trackActivity();
    this.props.setCurrentUser(this.props.user);
    // window.chatSocket = this.connectSocket(this.props.user);
    // window.chatSocket.init(() => {
    //   console.log("Connecting  WS");
    // });
    window.notifySocketConnection = this.notifyConnectSocket(this.props.user);
    document.getElementById("notify-tab").click();
  }

  getParameterByName = (name, url = window.location.href) => {
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  };

  render() {
    return (
      <div className="d-flex">
        <NavBar
          {...this.props}
          enableNotify={this.enableNotifyTab}
          notified={this.props.notified}
          deleteNotification={this.deleteNotification}
        />

        <InviteModal />
        <Notifications />
        <Snacks />

        <Switch>
          <Route path="/studio" component={ActionLibrary} />
          <Route path="/dashboard" component={Sidebar} />
        </Switch>
        {/* <ActionLibrary /> */}
        {/* <Sidebar user={this.props.user} /> */}
        <div className="body-main-right">
          <div className="mb-header">
            <div className="mh-logo">
              <img src={logo} />
            </div>
            <div className={this.props?.appReducer?.minMode ? "task-list sidebar-global" : "menu-btn"}
             onClick={()=> this.changeMode() }> 
              <span className="mh-ico"></span>
              <span className="mh-ico"></span>
              <span className="mh-ico"></span>
            </div>
          </div>
          <Switch>
            <Route
              exact
              path="/"
              render={() => {
                return <Redirect to="dashboard/create" />;
              }}
            />
            <Route
              exact
              path="/accept-invite"
              render={(props = this.props) => {
                let code = this.getParameterByName("invitationCode");
                this.props.acceptInvite(code);
                setTimeout(props.history.push("/dashboard/create"));
              }}
            />
            <Route path="/dashboard" component={DashboardContainer} />
            <Route exact path="/settings" component={Settings} />
            <Route
              path="/settings/myprofile-settings/"
              component={MyProfileSetting}
            />
             
            {/* <Route
              path="/notifications"
              component={Notifications}
            /> */}
            {/* <Route
              exact
              path="/settings/organization-settings/"
              component={OrganisationSetting}
            /> */}
            {/* Renaming organization route and label to teams route */}

            <Route
              exact
              path="/settings/teams-settings/"
              component={OrganisationSetting}
            />

            <Route
              exact
              path="/settings/device"
              component={Device}
            />

            {/* <Route
              exact
              path="/settings/organization/:id"
              component={OrganisationProfile}
            /> */}

            <Route
              exact
              path="/settings/teams/:id"
              component={OrganisationProfile}
            />

            {/* <Route
              exact
              path="/settings/organization/:id/team"
              component={OrganisationTeam}
            /> */}

            {/* Renaming people under organization to teams under org */}
            {/* <Route
              exact
              path="/settings/organization/:id/people"
              component={OrganisationPeople}
            /> */}

            <Route
              exact
              path="/settings/teams/:id/people"
              component={OrganisationPeople}
            />

            <Route path="/createYourTemplate" component={TemplateMapper} />

            {/* <Route
              exact
              path="/settings/organization/:id/categories"
              component={OrganizationCategories}
            /> */}

            {/* Renaming Categories under org to categories under team */}

            {/* <Route
              exact
              path="/settings/teams/:id/categories"
              component={OrganizationCategories}
            /> */}

            {/* <Route
              path="/settings/organization/:id/team/:teamId/profile"
              component={ProfileTeam}
            />
            <Route
              path="/settings/organization/:id/team/:teamId/people"
              component={ProfilePeople}
            /> */}
          </Switch>
        </div>
        {/* <div className="overlay active-ol"></div>
        <div className="app-download">
            <span className="ap-close">+</span>
            <div className="ap-box">
              <div className="apb-left">
                <img src={modalArt} />
              </div>
              <div className="apb-right">
                <p>Hey 👋</p>
                <h3>Download the Super App</h3>
                <h4>Get Your Super Assistant App Now!</h4>
                <span>Just click on the download button<br/> To get app</span>
                <div className="apb-btns">
                  <button className="btn btn-primary">Download</button>
                  <button className="btn btn-default">I have it already</button>
                </div>
              </div>
            </div>
          </div> */}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({appReducer:state.appReducer});

export default connect(mapStateToProps, {
  acceptInvite,
  setCurrentUser,
  setIncommingMessage,
  setReadyState,
  loadNotifications,
  setNotificationMessage,
  changeMode
})(App);
