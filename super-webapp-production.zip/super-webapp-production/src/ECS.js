import axios from 'axios'

export default class EventCollectionService {
  constructor() {
    this.baseURL = process.env.REACT_APP_ECS_HOST_URL
  }

  send(data) {
    let conf = {
      baseURL: this.baseURL,
      url: '/event',
      method: 'post',
      headers: { "Content-Type": "application/json" },
      data: data
    }
    axios(conf)
  }
}